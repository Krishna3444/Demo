import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ConfirmModal.jsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport1_react_jsxDevRuntime["Fragment"];const React = __vite__cjsImport3_react;import * as RefreshRuntime from "/@react-refresh";
var _jsxFileName = "C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/components/ConfirmModal.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=325d36c7";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
	if (!window.$RefreshReg$) {
		throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong.");
	}
	prevRefreshReg = window.$RefreshReg$;
	prevRefreshSig = window.$RefreshSig$;
	window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/components/ConfirmModal.jsx");
	window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=325d36c7";
/**
* Generic confirmation modal (used for delete confirmation).
*/
export default function ConfirmModal({ show, title, message, confirmLabel = "Delete", confirmClass = "btn-danger", loading = false, onConfirm, onCancel }) {
	if (!show) return null;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "modal fade show d-block",
		tabIndex: -1,
		role: "dialog",
		style: { background: "rgba(15,23,42,0.45)" },
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "modal-dialog modal-dialog-centered",
			role: "document",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "modal-content",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "modal-header",
						children: [/* @__PURE__ */ _jsxDEV("h5", {
							className: "modal-title",
							children: [/* @__PURE__ */ _jsxDEV("i", {
								className: "bi bi-exclamation-triangle text-danger me-2",
								"aria-hidden": "true"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 33,
								columnNumber: 15
							}, this), title]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 32,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							className: "btn-close",
							"aria-label": "Close",
							onClick: onCancel,
							disabled: loading
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 36,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 31,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "modal-body",
						children: /* @__PURE__ */ _jsxDEV("p", {
							className: "mb-0",
							children: message
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 39,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 38,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "modal-footer",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							className: "btn btn-outline-secondary",
							onClick: onCancel,
							disabled: loading,
							children: "Cancel"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 42,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							className: `btn ${confirmClass}`,
							onClick: onConfirm,
							disabled: loading,
							children: loading ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "spinner-border spinner-border-sm me-2",
								role: "status",
								"aria-hidden": "true"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 48,
								columnNumber: 19
							}, this), "Deleting…"] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 47,
								columnNumber: 15
							}, this) : confirmLabel
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 45,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 41,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 30,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 29,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 28,
		columnNumber: 5
	}, this);
}
_c = ConfirmModal;
var _c;
$RefreshReg$(_c, "ConfirmModal");
if (import.meta.hot && !inWebWorker) {
	window.$RefreshReg$ = prevRefreshReg;
	window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
	RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
		RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/components/ConfirmModal.jsx", currentExports);
		import.meta.hot.accept((nextExports) => {
			if (!nextExports) return;
			const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/components/ConfirmModal.jsx", currentExports, nextExports);
			if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
		});
	});
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsT0FBT0EsV0FBVzs7OztBQUtsQixlQUFlLFNBQVNDLGFBQWEsRUFBRUMsTUFBTUMsT0FBT0MsU0FBU0MsZUFBZSxVQUFVQyxlQUFlLGNBQWNDLFVBQVUsT0FBT0MsV0FBV0MsWUFBWTtDQUN6SixJQUFJLENBQUNQLE1BQU0sT0FBTztDQUNsQixPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO0VBQTBCLFVBQVUsQ0FBQztFQUFHLE1BQUs7RUFBUyxPQUFPLEVBQUVRLFlBQVksc0JBQXNCO1lBQzlHLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO0dBQXFDLE1BQUs7YUFDdkQsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWQsQ0FDRSx3QkFBQyxLQUFEO1FBQUcsV0FBVTtRQUE4QyxlQUFZO09BQU07Ozs7aUJBQzVFUCxLQUNDOzs7OztnQkFDSix3QkFBQyxVQUFEO09BQVEsTUFBSztPQUFTLFdBQVU7T0FBWSxjQUFXO09BQVEsU0FBU007T0FBVSxVQUFVRjtNQUFROzs7O2NBQ2pHOzs7Ozs7S0FDTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDYix3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBUUg7TUFBVzs7Ozs7S0FDN0I7Ozs7O0tBQ0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxVQUFEO09BQVEsTUFBSztPQUFTLFdBQVU7T0FBNEIsU0FBU0s7T0FBVSxVQUFVRjtpQkFBUTtNQUV6Rjs7OztnQkFDUix3QkFBQyxVQUFEO09BQVEsTUFBSztPQUFTLFdBQVcsT0FBT0Q7T0FBZ0IsU0FBU0U7T0FBVyxVQUFVRDtpQkFDbkZBLFVBQ0MsZ0RBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7UUFBd0MsTUFBSztRQUFTLGVBQVk7T0FBTTs7OztpQkFBQSxXQUUxRjs7OztrQkFFQUY7TUFFSTs7OztjQUNMOzs7Ozs7SUFDRjs7Ozs7O0VBQ0Y7Ozs7O0NBQ0Y7Ozs7O0FBRVQ7QUFBQ00sS0FuQ3VCVjtBQUFZLElBQUFVO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwiQ29uZmlybU1vZGFsIiwic2hvdyIsInRpdGxlIiwibWVzc2FnZSIsImNvbmZpcm1MYWJlbCIsImNvbmZpcm1DbGFzcyIsImxvYWRpbmciLCJvbkNvbmZpcm0iLCJvbkNhbmNlbCIsImJhY2tncm91bmQiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDb25maXJtTW9kYWwuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcblxuLyoqXG4gKiBHZW5lcmljIGNvbmZpcm1hdGlvbiBtb2RhbCAodXNlZCBmb3IgZGVsZXRlIGNvbmZpcm1hdGlvbikuXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIENvbmZpcm1Nb2RhbCh7IHNob3csIHRpdGxlLCBtZXNzYWdlLCBjb25maXJtTGFiZWwgPSBcIkRlbGV0ZVwiLCBjb25maXJtQ2xhc3MgPSBcImJ0bi1kYW5nZXJcIiwgbG9hZGluZyA9IGZhbHNlLCBvbkNvbmZpcm0sIG9uQ2FuY2VsIH0pIHtcbiAgaWYgKCFzaG93KSByZXR1cm4gbnVsbDtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm1vZGFsIGZhZGUgc2hvdyBkLWJsb2NrXCIgdGFiSW5kZXg9ey0xfSByb2xlPVwiZGlhbG9nXCIgc3R5bGU9e3sgYmFja2dyb3VuZDogXCJyZ2JhKDE1LDIzLDQyLDAuNDUpXCIgfX0+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1vZGFsLWRpYWxvZyBtb2RhbC1kaWFsb2ctY2VudGVyZWRcIiByb2xlPVwiZG9jdW1lbnRcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtb2RhbC1jb250ZW50XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtb2RhbC1oZWFkZXJcIj5cbiAgICAgICAgICAgIDxoNSBjbGFzc05hbWU9XCJtb2RhbC10aXRsZVwiPlxuICAgICAgICAgICAgICA8aSBjbGFzc05hbWU9XCJiaSBiaS1leGNsYW1hdGlvbi10cmlhbmdsZSB0ZXh0LWRhbmdlciBtZS0yXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICAgICAge3RpdGxlfVxuICAgICAgICAgICAgPC9oNT5cbiAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImJ0bi1jbG9zZVwiIGFyaWEtbGFiZWw9XCJDbG9zZVwiIG9uQ2xpY2s9e29uQ2FuY2VsfSBkaXNhYmxlZD17bG9hZGluZ30gLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1vZGFsLWJvZHlcIj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm1iLTBcIj57bWVzc2FnZX08L3A+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtb2RhbC1mb290ZXJcIj5cbiAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImJ0biBidG4tb3V0bGluZS1zZWNvbmRhcnlcIiBvbkNsaWNrPXtvbkNhbmNlbH0gZGlzYWJsZWQ9e2xvYWRpbmd9PlxuICAgICAgICAgICAgICBDYW5jZWxcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPXtgYnRuICR7Y29uZmlybUNsYXNzfWB9IG9uQ2xpY2s9e29uQ29uZmlybX0gZGlzYWJsZWQ9e2xvYWRpbmd9PlxuICAgICAgICAgICAgICB7bG9hZGluZyA/IChcbiAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic3Bpbm5lci1ib3JkZXIgc3Bpbm5lci1ib3JkZXItc20gbWUtMlwiIHJvbGU9XCJzdGF0dXNcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgICAgICAgICAgRGVsZXRpbmfigKZcbiAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICBjb25maXJtTGFiZWxcbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiJDOi9Vc2Vycy91c2VyL0Rvd25sb2Fkcy9kaGFuaXRpLWFwcC11cGdyYWRlZC9kaGFuaXRpLWFwcC9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9Db25maXJtTW9kYWwuanN4In0=