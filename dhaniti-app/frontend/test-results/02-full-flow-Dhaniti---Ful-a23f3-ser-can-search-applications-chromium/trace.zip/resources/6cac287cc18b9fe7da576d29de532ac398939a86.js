import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/ResetPassword.jsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport1_react_jsxDevRuntime["Fragment"];const React = __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];import * as RefreshRuntime from "/@react-refresh";
var _jsxFileName = "C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/pages/ResetPassword.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=325d36c7";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
	if (!window.$RefreshReg$) {
		throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong.");
	}
	prevRefreshReg = window.$RefreshReg$;
	prevRefreshSig = window.$RefreshSig$;
	window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/pages/ResetPassword.jsx");
	window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=325d36c7";
import { Link, useLocation, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=325d36c7";
import { authApi } from "/src/api/auth.js";
import { ApiError } from "/src/api/client.js";
import { useToast } from "/src/context/ToastContext.jsx";
const RULES = [
	{
		id: "length",
		label: "At least 8 characters",
		test: (p) => p.length >= 8
	},
	{
		id: "letter",
		label: "At least one letter",
		test: (p) => /[A-Za-z]/.test(p)
	},
	{
		id: "number",
		label: "At least one number",
		test: (p) => /\d/.test(p)
	}
];
export default function ResetPassword() {
	_s();
	const location = useLocation();
	const navigate = useNavigate();
	const toast = useToast();
	const resetToken = location.state?.resetToken || "";
	const email = location.state?.email || "";
	const [password, setPassword] = useState("");
	const [confirm, setConfirm] = useState("");
	const [errors, setErrors] = useState({});
	const [apiError, setApiError] = useState("");
	const [loading, setLoading] = useState(false);
	const [done, setDone] = useState(false);
	useEffect(() => {
		if (!resetToken) navigate("/forgot-password", { replace: true });
	}, [resetToken, navigate]);
	function validate() {
		const next = {};
		if (!password) next.password = "New password is required.";
		else if (RULES.some((r) => !r.test(password))) next.password = "Password must meet the required security rules.";
		if (confirm !== password) next.confirm = "Passwords do not match.";
		setErrors(next);
		return Object.keys(next).length === 0;
	}
	async function handleSubmit(e) {
		e.preventDefault();
		setApiError("");
		if (!validate()) return;
		setLoading(true);
		try {
			await authApi.resetPassword(resetToken, password);
			setDone(true);
			toast.success("Password updated. Sign in with your new password.");
			setTimeout(() => navigate("/login", { replace: true }), 1800);
		} catch (err) {
			setApiError(err instanceof ApiError ? err.message : "Could not reset the password.");
		} finally {
			setLoading(false);
		}
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "login-wrapper",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "card login-card",
			style: { maxWidth: 420 },
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "card-header text-center",
				children: [/* @__PURE__ */ _jsxDEV("h5", {
					className: "mb-0 fw-semibold",
					children: "Choose a new password"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 81,
					columnNumber: 11
				}, this), email && /* @__PURE__ */ _jsxDEV("p", {
					className: "text-muted small mb-0 mt-1",
					children: ["for ", email]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 82,
					columnNumber: 21
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 80,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "card-body p-4",
				children: [
					apiError && /* @__PURE__ */ _jsxDEV("div", {
						className: "alert alert-danger py-2",
						role: "alert",
						children: apiError
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 86,
						columnNumber: 24
					}, this),
					done && /* @__PURE__ */ _jsxDEV("div", {
						className: "alert alert-success py-2",
						role: "alert",
						children: "Password updated successfully — redirecting to sign in…"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 88,
						columnNumber: 11
					}, this),
					!done && /* @__PURE__ */ _jsxDEV("form", {
						onSubmit: handleSubmit,
						noValidate: true,
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "mb-3",
								children: [
									/* @__PURE__ */ _jsxDEV("label", {
										htmlFor: "np",
										className: "form-label",
										children: "New password"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 96,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("input", {
										type: "password",
										className: `form-control ${errors.password ? "is-invalid" : ""}`,
										id: "np",
										value: password,
										onChange: (e) => setPassword(e.target.value),
										autoComplete: "new-password",
										disabled: loading
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 97,
										columnNumber: 17
									}, this),
									errors.password && /* @__PURE__ */ _jsxDEV("div", {
										className: "invalid-feedback",
										children: errors.password
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 106,
										columnNumber: 37
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "password-rules mt-2",
										children: RULES.map((rule) => /* @__PURE__ */ _jsxDEV("div", {
											className: `small ${rule.test(password) ? "text-success" : "text-muted"}`,
											children: [/* @__PURE__ */ _jsxDEV("i", {
												className: `bi ${rule.test(password) ? "bi-check-circle-fill" : "bi-circle"} me-1`,
												"aria-hidden": "true"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 110,
												columnNumber: 23
											}, this), rule.label]
										}, rule.id, true, {
											fileName: _jsxFileName,
											lineNumber: 109,
											columnNumber: 17
										}, this))
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 107,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 95,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "mb-4",
								children: [
									/* @__PURE__ */ _jsxDEV("label", {
										htmlFor: "npc",
										className: "form-label",
										children: "Confirm new password"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 118,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("input", {
										type: "password",
										className: `form-control ${errors.confirm ? "is-invalid" : ""}`,
										id: "npc",
										value: confirm,
										onChange: (e) => setConfirm(e.target.value),
										autoComplete: "new-password",
										disabled: loading
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 119,
										columnNumber: 17
									}, this),
									errors.confirm && /* @__PURE__ */ _jsxDEV("div", {
										className: "invalid-feedback",
										children: errors.confirm
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 128,
										columnNumber: 36
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 117,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "submit",
								className: "btn btn-dhaniti w-100",
								disabled: loading,
								children: loading ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "spinner-border spinner-border-sm me-2",
									role: "status",
									"aria-hidden": "true"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 134,
									columnNumber: 21
								}, this), "Saving…"] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 133,
									columnNumber: 15
								}, this) : "Set new password"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 131,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 94,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-center small mt-4 mb-0",
						children: /* @__PURE__ */ _jsxDEV(Link, {
							to: "/login",
							children: "Back to sign in"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 145,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 144,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 85,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 79,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 78,
		columnNumber: 5
	}, this);
}
_s(ResetPassword, "dJBPWuI8S83Wnai13MX8XRxjhnc=", false, function() {
	return [
		useLocation,
		useNavigate,
		useToast
	];
});
_c = ResetPassword;
var _c;
$RefreshReg$(_c, "ResetPassword");
if (import.meta.hot && !inWebWorker) {
	window.$RefreshReg$ = prevRefreshReg;
	window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
	RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
		RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/pages/ResetPassword.jsx", currentExports);
		import.meta.hot.accept((nextExports) => {
			if (!nextExports) return;
			const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/pages/ResetPassword.jsx", currentExports, nextExports);
			if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
		});
	});
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLE9BQU9BLFNBQVNDLFdBQVdDLGdCQUFnQjtBQUMzQyxTQUFTQyxNQUFNQyxhQUFhQyxtQkFBbUI7QUFDL0MsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsZ0JBQWdCO0FBRXpCLE1BQU1DLFFBQVE7Q0FDWjtFQUFFQyxJQUFJO0VBQVVDLE9BQU87RUFBeUJDLE9BQU9DLE1BQU1BLEVBQUVDLFVBQVU7Q0FBRTtDQUMzRTtFQUFFSixJQUFJO0VBQVVDLE9BQU87RUFBdUJDLE9BQU9DLE1BQU0sV0FBV0QsS0FBS0MsQ0FBQztDQUFFO0NBQzlFO0VBQUVILElBQUk7RUFBVUMsT0FBTztFQUF1QkMsT0FBT0MsTUFBTSxLQUFLRCxLQUFLQyxDQUFDO0NBQUU7QUFBQztBQUczRSxlQUFlLFNBQVNFLGdCQUFnQjtDQUFBQyxHQUFBO0NBQ3RDLE1BQU1DLFdBQVdiLFlBQVk7Q0FDN0IsTUFBTWMsV0FBV2IsWUFBWTtDQUM3QixNQUFNYyxRQUFRWCxTQUFTO0NBRXZCLE1BQU1ZLGFBQWFILFNBQVNJLE9BQU9ELGNBQWM7Q0FDakQsTUFBTUUsUUFBUUwsU0FBU0ksT0FBT0MsU0FBUztDQUV2QyxNQUFNLENBQUNDLFVBQVVDLGVBQWV0QixTQUFTLEVBQUU7Q0FDM0MsTUFBTSxDQUFDdUIsU0FBU0MsY0FBY3hCLFNBQVMsRUFBRTtDQUN6QyxNQUFNLENBQUN5QixRQUFRQyxhQUFhMUIsU0FBUyxDQUFDLENBQUM7Q0FDdkMsTUFBTSxDQUFDMkIsVUFBVUMsZUFBZTVCLFNBQVMsRUFBRTtDQUMzQyxNQUFNLENBQUM2QixTQUFTQyxjQUFjOUIsU0FBUyxLQUFLO0NBQzVDLE1BQU0sQ0FBQytCLE1BQU1DLFdBQVdoQyxTQUFTLEtBQUs7Q0FFdENELGdCQUFnQjtFQUNkLElBQUksQ0FBQ21CLFlBQVlGLFNBQVMsb0JBQW9CLEVBQUVpQixTQUFTLEtBQUssQ0FBQztDQUNqRSxHQUFHLENBQUNmLFlBQVlGLFFBQVEsQ0FBQztDQUV6QixTQUFTa0IsV0FBVztFQUNsQixNQUFNQyxPQUFPLENBQUM7RUFDZCxJQUFJLENBQUNkLFVBQVVjLEtBQUtkLFdBQVc7T0FDMUIsSUFBSWQsTUFBTTZCLE1BQU1DLE1BQU0sQ0FBQ0EsRUFBRTNCLEtBQUtXLFFBQVEsQ0FBQyxHQUFHYyxLQUFLZCxXQUFXO0VBQy9ELElBQUlFLFlBQVlGLFVBQVVjLEtBQUtaLFVBQVU7RUFDekNHLFVBQVVTLElBQUk7RUFDZCxPQUFPRyxPQUFPQyxLQUFLSixJQUFJLENBQUMsQ0FBQ3ZCLFdBQVc7Q0FDdEM7Q0FFQSxlQUFlNEIsYUFBYUMsR0FBRztFQUM3QkEsRUFBRUMsZUFBZTtFQUNqQmQsWUFBWSxFQUFFO0VBQ2QsSUFBSSxDQUFDTSxTQUFTLEdBQUc7RUFDakJKLFdBQVcsSUFBSTtFQUNmLElBQUk7R0FDRixNQUFNMUIsUUFBUXVDLGNBQWN6QixZQUFZRyxRQUFRO0dBQ2hEVyxRQUFRLElBQUk7R0FDWmYsTUFBTTJCLFFBQVEsbURBQW1EO0dBQ2pFQyxpQkFBaUI3QixTQUFTLFVBQVUsRUFBRWlCLFNBQVMsS0FBSyxDQUFDLEdBQUcsSUFBSTtFQUM5RCxTQUFTYSxLQUFLO0dBQ1psQixZQUFZa0IsZUFBZXpDLFdBQVd5QyxJQUFJQyxVQUFVLCtCQUErQjtFQUNyRixVQUFVO0dBQ1JqQixXQUFXLEtBQUs7RUFDbEI7Q0FDRjtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFDYix3QkFBQyxPQUFEO0dBQUssV0FBVTtHQUFrQixPQUFPLEVBQUVrQixVQUFVLElBQUk7YUFBeEQsQ0FDRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBbUI7SUFBeUI7Ozs7Y0FDekQ1QixTQUFTLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQWIsQ0FBMEMsUUFBS0EsS0FBUzs7Ozs7WUFDL0Q7Ozs7O2FBRUwsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNHTyxZQUFZLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO01BQTBCLE1BQUs7Z0JBQVNBO0tBQWM7Ozs7O0tBQ2pGSSxRQUNDLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO01BQTJCLE1BQUs7Z0JBQU87S0FFakQ7Ozs7O0tBR04sQ0FBQ0EsUUFDQSx3QkFBQyxRQUFEO01BQU0sVUFBVVM7TUFBYztnQkFBOUI7T0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLFNBQUQ7VUFBTyxTQUFRO1VBQUssV0FBVTtvQkFBYTtTQUFtQjs7Ozs7U0FDOUQsd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxXQUFXLGdCQUFnQmYsT0FBT0osV0FBVyxlQUFlO1VBQzVELElBQUc7VUFDSCxPQUFPQTtVQUNQLFdBQVdvQixNQUFNbkIsWUFBWW1CLEVBQUVRLE9BQU9DLEtBQUs7VUFDM0MsY0FBYTtVQUNiLFVBQVVyQjtTQUFROzs7OztTQUVuQkosT0FBT0osWUFBWSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBb0JJLE9BQU9KO1NBQWM7Ozs7O1NBQzVFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUNaZCxNQUFNNEMsS0FBS0MsU0FDVix3QkFBQyxPQUFEO1dBQW1CLFdBQVcsU0FBU0EsS0FBSzFDLEtBQUtXLFFBQVEsSUFBSSxpQkFBaUI7cUJBQTlFLENBQ0Usd0JBQUMsS0FBRDtZQUFHLFdBQVcsTUFBTStCLEtBQUsxQyxLQUFLVyxRQUFRLElBQUkseUJBQXlCLFlBQVc7WUFBUyxlQUFZO1dBQU07Ozs7cUJBQ3hHK0IsS0FBSzNDLEtBQ0g7YUFISzJDLEtBQUs1Qzs7OztpQkFHVixDQUNOO1NBQ0U7Ozs7O1FBQ0Y7Ozs7OztPQUVMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsU0FBRDtVQUFPLFNBQVE7VUFBTSxXQUFVO29CQUFhO1NBQTJCOzs7OztTQUN2RSx3QkFBQyxTQUFEO1VBQ0UsTUFBSztVQUNMLFdBQVcsZ0JBQWdCaUIsT0FBT0YsVUFBVSxlQUFlO1VBQzNELElBQUc7VUFDSCxPQUFPQTtVQUNQLFdBQVdrQixNQUFNakIsV0FBV2lCLEVBQUVRLE9BQU9DLEtBQUs7VUFDMUMsY0FBYTtVQUNiLFVBQVVyQjtTQUFROzs7OztTQUVuQkosT0FBT0YsV0FBVyx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBb0JFLE9BQU9GO1NBQWE7Ozs7O1FBQ3ZFOzs7Ozs7T0FFTCx3QkFBQyxVQUFEO1FBQVEsTUFBSztRQUFTLFdBQVU7UUFBd0IsVUFBVU07a0JBQy9EQSxVQUNDLGdEQUNFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO1NBQXdDLE1BQUs7U0FBUyxlQUFZO1FBQU07Ozs7a0JBQUEsU0FFMUY7Ozs7bUJBRUE7T0FFSTs7Ozs7TUFDSjs7Ozs7O0tBR1Isd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQ1gsd0JBQUMsTUFBRDtPQUFNLElBQUc7aUJBQVM7TUFBcUI7Ozs7O0tBQ3RDOzs7OztJQUNBOzs7OztXQUNGOzs7Ozs7Q0FDRjs7Ozs7QUFFVDtBQUFDZixHQXZIdUJELGVBQWE7Q0FBQTtFQUNsQlg7RUFDQUM7RUFDSEc7Q0FBUTtBQUFBO0FBQUEsS0FIQU87QUFBYSxJQUFBd0M7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIkxpbmsiLCJ1c2VMb2NhdGlvbiIsInVzZU5hdmlnYXRlIiwiYXV0aEFwaSIsIkFwaUVycm9yIiwidXNlVG9hc3QiLCJSVUxFUyIsImlkIiwibGFiZWwiLCJ0ZXN0IiwicCIsImxlbmd0aCIsIlJlc2V0UGFzc3dvcmQiLCJfcyIsImxvY2F0aW9uIiwibmF2aWdhdGUiLCJ0b2FzdCIsInJlc2V0VG9rZW4iLCJzdGF0ZSIsImVtYWlsIiwicGFzc3dvcmQiLCJzZXRQYXNzd29yZCIsImNvbmZpcm0iLCJzZXRDb25maXJtIiwiZXJyb3JzIiwic2V0RXJyb3JzIiwiYXBpRXJyb3IiLCJzZXRBcGlFcnJvciIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwiZG9uZSIsInNldERvbmUiLCJyZXBsYWNlIiwidmFsaWRhdGUiLCJuZXh0Iiwic29tZSIsInIiLCJPYmplY3QiLCJrZXlzIiwiaGFuZGxlU3VibWl0IiwiZSIsInByZXZlbnREZWZhdWx0IiwicmVzZXRQYXNzd29yZCIsInN1Y2Nlc3MiLCJzZXRUaW1lb3V0IiwiZXJyIiwibWVzc2FnZSIsIm1heFdpZHRoIiwidGFyZ2V0IiwidmFsdWUiLCJtYXAiLCJydWxlIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUmVzZXRQYXNzd29yZC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IExpbmssIHVzZUxvY2F0aW9uLCB1c2VOYXZpZ2F0ZSB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XG5pbXBvcnQgeyBhdXRoQXBpIH0gZnJvbSBcIi4uL2FwaS9hdXRoLmpzXCI7XG5pbXBvcnQgeyBBcGlFcnJvciB9IGZyb20gXCIuLi9hcGkvY2xpZW50LmpzXCI7XG5pbXBvcnQgeyB1c2VUb2FzdCB9IGZyb20gXCIuLi9jb250ZXh0L1RvYXN0Q29udGV4dC5qc3hcIjtcblxuY29uc3QgUlVMRVMgPSBbXG4gIHsgaWQ6IFwibGVuZ3RoXCIsIGxhYmVsOiBcIkF0IGxlYXN0IDggY2hhcmFjdGVyc1wiLCB0ZXN0OiAocCkgPT4gcC5sZW5ndGggPj0gOCB9LFxuICB7IGlkOiBcImxldHRlclwiLCBsYWJlbDogXCJBdCBsZWFzdCBvbmUgbGV0dGVyXCIsIHRlc3Q6IChwKSA9PiAvW0EtWmEtel0vLnRlc3QocCkgfSxcbiAgeyBpZDogXCJudW1iZXJcIiwgbGFiZWw6IFwiQXQgbGVhc3Qgb25lIG51bWJlclwiLCB0ZXN0OiAocCkgPT4gL1xcZC8udGVzdChwKSB9LFxuXTtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUmVzZXRQYXNzd29yZCgpIHtcbiAgY29uc3QgbG9jYXRpb24gPSB1c2VMb2NhdGlvbigpO1xuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gIGNvbnN0IHRvYXN0ID0gdXNlVG9hc3QoKTtcblxuICBjb25zdCByZXNldFRva2VuID0gbG9jYXRpb24uc3RhdGU/LnJlc2V0VG9rZW4gfHwgXCJcIjtcbiAgY29uc3QgZW1haWwgPSBsb2NhdGlvbi5zdGF0ZT8uZW1haWwgfHwgXCJcIjtcblxuICBjb25zdCBbcGFzc3dvcmQsIHNldFBhc3N3b3JkXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbY29uZmlybSwgc2V0Q29uZmlybV0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW2Vycm9ycywgc2V0RXJyb3JzXSA9IHVzZVN0YXRlKHt9KTtcbiAgY29uc3QgW2FwaUVycm9yLCBzZXRBcGlFcnJvcl0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbZG9uZSwgc2V0RG9uZV0gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIXJlc2V0VG9rZW4pIG5hdmlnYXRlKFwiL2ZvcmdvdC1wYXNzd29yZFwiLCB7IHJlcGxhY2U6IHRydWUgfSk7XG4gIH0sIFtyZXNldFRva2VuLCBuYXZpZ2F0ZV0pO1xuXG4gIGZ1bmN0aW9uIHZhbGlkYXRlKCkge1xuICAgIGNvbnN0IG5leHQgPSB7fTtcbiAgICBpZiAoIXBhc3N3b3JkKSBuZXh0LnBhc3N3b3JkID0gXCJOZXcgcGFzc3dvcmQgaXMgcmVxdWlyZWQuXCI7XG4gICAgZWxzZSBpZiAoUlVMRVMuc29tZSgocikgPT4gIXIudGVzdChwYXNzd29yZCkpKSBuZXh0LnBhc3N3b3JkID0gXCJQYXNzd29yZCBtdXN0IG1lZXQgdGhlIHJlcXVpcmVkIHNlY3VyaXR5IHJ1bGVzLlwiO1xuICAgIGlmIChjb25maXJtICE9PSBwYXNzd29yZCkgbmV4dC5jb25maXJtID0gXCJQYXNzd29yZHMgZG8gbm90IG1hdGNoLlwiO1xuICAgIHNldEVycm9ycyhuZXh0KTtcbiAgICByZXR1cm4gT2JqZWN0LmtleXMobmV4dCkubGVuZ3RoID09PSAwO1xuICB9XG5cbiAgYXN5bmMgZnVuY3Rpb24gaGFuZGxlU3VibWl0KGUpIHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgc2V0QXBpRXJyb3IoXCJcIik7XG4gICAgaWYgKCF2YWxpZGF0ZSgpKSByZXR1cm47XG4gICAgc2V0TG9hZGluZyh0cnVlKTtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgYXV0aEFwaS5yZXNldFBhc3N3b3JkKHJlc2V0VG9rZW4sIHBhc3N3b3JkKTtcbiAgICAgIHNldERvbmUodHJ1ZSk7XG4gICAgICB0b2FzdC5zdWNjZXNzKFwiUGFzc3dvcmQgdXBkYXRlZC4gU2lnbiBpbiB3aXRoIHlvdXIgbmV3IHBhc3N3b3JkLlwiKTtcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4gbmF2aWdhdGUoXCIvbG9naW5cIiwgeyByZXBsYWNlOiB0cnVlIH0pLCAxODAwKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHNldEFwaUVycm9yKGVyciBpbnN0YW5jZW9mIEFwaUVycm9yID8gZXJyLm1lc3NhZ2UgOiBcIkNvdWxkIG5vdCByZXNldCB0aGUgcGFzc3dvcmQuXCIpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwibG9naW4td3JhcHBlclwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkIGxvZ2luLWNhcmRcIiBzdHlsZT17eyBtYXhXaWR0aDogNDIwIH19PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQtaGVhZGVyIHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgPGg1IGNsYXNzTmFtZT1cIm1iLTAgZnctc2VtaWJvbGRcIj5DaG9vc2UgYSBuZXcgcGFzc3dvcmQ8L2g1PlxuICAgICAgICAgIHtlbWFpbCAmJiA8cCBjbGFzc05hbWU9XCJ0ZXh0LW11dGVkIHNtYWxsIG1iLTAgbXQtMVwiPmZvciB7ZW1haWx9PC9wPn1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkLWJvZHkgcC00XCI+XG4gICAgICAgICAge2FwaUVycm9yICYmIDxkaXYgY2xhc3NOYW1lPVwiYWxlcnQgYWxlcnQtZGFuZ2VyIHB5LTJcIiByb2xlPVwiYWxlcnRcIj57YXBpRXJyb3J9PC9kaXY+fVxuICAgICAgICAgIHtkb25lICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWxlcnQgYWxlcnQtc3VjY2VzcyBweS0yXCIgcm9sZT1cImFsZXJ0XCI+XG4gICAgICAgICAgICAgIFBhc3N3b3JkIHVwZGF0ZWQgc3VjY2Vzc2Z1bGx5IOKAlCByZWRpcmVjdGluZyB0byBzaWduIGlu4oCmXG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAgeyFkb25lICYmIChcbiAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9IG5vVmFsaWRhdGU+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItM1wiPlxuICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwibnBcIiBjbGFzc05hbWU9XCJmb3JtLWxhYmVsXCI+TmV3IHBhc3N3b3JkPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJwYXNzd29yZFwiXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2Bmb3JtLWNvbnRyb2wgJHtlcnJvcnMucGFzc3dvcmQgPyBcImlzLWludmFsaWRcIiA6IFwiXCJ9YH1cbiAgICAgICAgICAgICAgICAgIGlkPVwibnBcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3Bhc3N3b3JkfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRQYXNzd29yZChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJuZXctcGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2xvYWRpbmd9XG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICB7ZXJyb3JzLnBhc3N3b3JkICYmIDxkaXYgY2xhc3NOYW1lPVwiaW52YWxpZC1mZWVkYmFja1wiPntlcnJvcnMucGFzc3dvcmR9PC9kaXY+fVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGFzc3dvcmQtcnVsZXMgbXQtMlwiPlxuICAgICAgICAgICAgICAgICAge1JVTEVTLm1hcCgocnVsZSkgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17cnVsZS5pZH0gY2xhc3NOYW1lPXtgc21hbGwgJHtydWxlLnRlc3QocGFzc3dvcmQpID8gXCJ0ZXh0LXN1Y2Nlc3NcIiA6IFwidGV4dC1tdXRlZFwifWB9PlxuICAgICAgICAgICAgICAgICAgICAgIDxpIGNsYXNzTmFtZT17YGJpICR7cnVsZS50ZXN0KHBhc3N3b3JkKSA/IFwiYmktY2hlY2stY2lyY2xlLWZpbGxcIiA6IFwiYmktY2lyY2xlXCJ9IG1lLTFgfSBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIHtydWxlLmxhYmVsfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTRcIj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cIm5wY1wiIGNsYXNzTmFtZT1cImZvcm0tbGFiZWxcIj5Db25maXJtIG5ldyBwYXNzd29yZDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZm9ybS1jb250cm9sICR7ZXJyb3JzLmNvbmZpcm0gPyBcImlzLWludmFsaWRcIiA6IFwiXCJ9YH1cbiAgICAgICAgICAgICAgICAgIGlkPVwibnBjXCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtjb25maXJtfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRDb25maXJtKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cIm5ldy1wYXNzd29yZFwiXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17bG9hZGluZ31cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIHtlcnJvcnMuY29uZmlybSAmJiA8ZGl2IGNsYXNzTmFtZT1cImludmFsaWQtZmVlZGJhY2tcIj57ZXJyb3JzLmNvbmZpcm19PC9kaXY+fVxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBjbGFzc05hbWU9XCJidG4gYnRuLWRoYW5pdGkgdy0xMDBcIiBkaXNhYmxlZD17bG9hZGluZ30+XG4gICAgICAgICAgICAgICAge2xvYWRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzcGlubmVyLWJvcmRlciBzcGlubmVyLWJvcmRlci1zbSBtZS0yXCIgcm9sZT1cInN0YXR1c1wiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgICAgICAgICAgIFNhdmluZ+KAplxuICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgIFwiU2V0IG5ldyBwYXNzd29yZFwiXG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHNtYWxsIG10LTQgbWItMFwiPlxuICAgICAgICAgICAgPExpbmsgdG89XCIvbG9naW5cIj5CYWNrIHRvIHNpZ24gaW48L0xpbms+XG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiJDOi9Vc2Vycy91c2VyL0Rvd25sb2Fkcy9kaGFuaXRpLWFwcC11cGdyYWRlZC9kaGFuaXRpLWFwcC9mcm9udGVuZC9zcmMvcGFnZXMvUmVzZXRQYXNzd29yZC5qc3gifQ==