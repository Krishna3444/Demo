import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/VerifyOtp.jsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport1_react_jsxDevRuntime["Fragment"];const React = __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"]; const useState = __vite__cjsImport3_react["useState"];import * as RefreshRuntime from "/@react-refresh";
var _jsxFileName = "C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/pages/VerifyOtp.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=325d36c7";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
	if (!window.$RefreshReg$) {
		throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong.");
	}
	prevRefreshReg = window.$RefreshReg$;
	prevRefreshSig = window.$RefreshSig$;
	window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/pages/VerifyOtp.jsx");
	window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=325d36c7";
import { Link, useLocation, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=325d36c7";
import OtpInput from "/src/components/OtpInput.jsx";
import { authApi } from "/src/api/auth.js";
import { ApiError } from "/src/api/client.js";
import { useAuth } from "/src/context/AuthContext.jsx";
import { useToast } from "/src/context/ToastContext.jsx";
const PURPOSE_META = {
	login: {
		title: "Enter Verification Code",
		subtitle: "We sent a login verification code to:",
		cta: "Verify & Sign In"
	},
	email_verification: {
		title: "Verify Your Email",
		subtitle: "We sent a verification code to:",
		cta: "Verify Email"
	},
	password_reset: {
		title: "Enter Verification Code",
		subtitle: "We sent a password-reset code to:",
		cta: "Continue"
	}
};
export default function VerifyOtp() {
	_s();
	const location = useLocation();
	const navigate = useNavigate();
	const toast = useToast();
	const { applySession } = useAuth();
	const email = (location.state?.email || "").trim();
	const purpose = location.state?.purpose || "login";
	const sendNow = Boolean(location.state?.sendNow);
	const meta = PURPOSE_META[purpose] || PURPOSE_META.login;
	const [code, setCode] = useState("");
	const [loading, setLoading] = useState(false);
	const [sending, setSending] = useState(false);
	const [error, setError] = useState("");
	const [secondsLeft, setSecondsLeft] = useState(120);
	const [resent, setResent] = useState(0);
	const sentRef = useRef(false);
	// Users must arrive with an email in state.
	useEffect(() => {
		if (!email) navigate("/login", { replace: true });
	}, [email, navigate]);
	// Optionally auto-send the code when arriving from "Login with OTP".
	useEffect(() => {
		if (sendNow && email && !sentRef.current) {
			sentRef.current = true;
			(async () => {
				setSending(true);
				try {
					await authApi.sendOtp(email, purpose === "email_verification" ? "login" : purpose);
					toast.info(`Verification code sent to ${email}`);
				} catch (err) {
					setError(err.message);
				} finally {
					setSending(false);
				}
			})();
		}
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [sendNow, email]);
	// Countdown timer.
	useEffect(() => {
		if (secondsLeft <= 0) return;
		const timer = setInterval(() => setSecondsLeft((s) => Math.max(0, s - 1)), 1e3);
		return () => clearInterval(timer);
	}, [secondsLeft]);
	const mm = String(Math.floor(secondsLeft / 60)).padStart(2, "0");
	const ss = String(secondsLeft % 60).padStart(2, "0");
	async function handleVerify(submitted) {
		if (!submitted || submitted.length < 6) {
			setError("Enter the complete verification code.");
			return;
		}
		setError("");
		setLoading(true);
		try {
			if (purpose === "password_reset") {
				const { resetToken } = await authApi.verifyResetOtp(email, submitted);
				navigate("/reset-password", { state: {
					email,
					resetToken
				} });
			} else {
				const { token, user } = await authApi.verifyOtp(email, submitted, purpose);
				applySession(token, user);
				toast.success("Verification successful. Welcome!");
				navigate("/dashboard", { replace: true });
			}
		} catch (err) {
			setError(err instanceof ApiError && err.details?.length ? `${err.message}` : err.message);
			setCode("");
		} finally {
			setLoading(false);
		}
	}
	async function handleResend() {
		if (resent >= 3) {
			setError("Too many resend requests. Please wait before requesting another code.");
			return;
		}
		setError("");
		setSending(true);
		try {
			const sendPurpose = purpose === "email_verification" ? "email_verification" : purpose === "password_reset" ? "password_reset" : "login";
			await authApi.sendOtp(email, sendPurpose === "email_verification" ? "login" : sendPurpose);
			setResent((r) => r + 1);
			setSecondsLeft(120);
			setCode("");
			toast.success("A new verification code has been sent.");
		} catch (err) {
			setError(err.message);
		} finally {
			setSending(false);
		}
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "login-wrapper",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "card login-card",
			style: { maxWidth: 420 },
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "card-header text-center",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "mx-auto mb-2 d-flex align-items-center justify-content-center",
						style: {
							width: 48,
							height: 48,
							borderRadius: 14,
							background: "linear-gradient(135deg, #0f766e 0%, #134e4a 100%)",
							color: "white",
							fontSize: 22
						},
						children: /* @__PURE__ */ _jsxDEV("i", {
							className: "bi bi-shield-check",
							"aria-hidden": "true"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 148,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 137,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("h5", {
						className: "mb-0 fw-semibold",
						children: meta.title
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 150,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-muted small mb-0 mt-1",
						children: meta.subtitle
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 151,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "fw-medium mb-0 mt-1",
						children: email
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 152,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 136,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "card-body p-4",
				children: [
					error && /* @__PURE__ */ _jsxDEV("div", {
						className: "alert alert-danger py-2",
						role: "alert",
						children: error
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 156,
						columnNumber: 21
					}, this),
					/* @__PURE__ */ _jsxDEV(OtpInput, {
						value: code,
						onChange: setCode,
						onComplete: handleVerify,
						disabled: loading || sending
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 158,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						className: "btn btn-dhaniti w-100 mt-4",
						disabled: loading || sending || code.length < 6,
						onClick: () => handleVerify(code),
						children: loading ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "spinner-border spinner-border-sm me-2",
							role: "status",
							"aria-hidden": "true"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 172,
							columnNumber: 17
						}, this), "Verifying…"] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 171,
							columnNumber: 13
						}, this) : "Verify"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 165,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-center text-muted small mt-3 mb-2",
						children: [
							"Code expires in:",
							" ",
							/* @__PURE__ */ _jsxDEV("span", {
								className: "fw-semibold text-dhaniti",
								"data-testid": "otp-countdown",
								children: [
									mm,
									":",
									ss
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 182,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 180,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("hr", {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 187,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-center text-muted small mb-1",
						children: "Didn't receive it?"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 188,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "text-center",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							className: "btn btn-sm btn-outline-dhaniti",
							onClick: handleResend,
							disabled: sending || resent >= 3 || secondsLeft > 90,
							children: sending ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "spinner-border spinner-border-sm me-1",
								role: "status",
								"aria-hidden": "true"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 197,
								columnNumber: 19
							}, this), "Sending code…"] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 196,
								columnNumber: 15
							}, this) : "Resend Code"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 190,
							columnNumber: 13
						}, this), resent >= 3 && /* @__PURE__ */ _jsxDEV("div", {
							className: "small text-danger mt-2",
							children: "Maximum resends reached — please try again later."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 205,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 189,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-center small mt-4 mb-0",
						children: /* @__PURE__ */ _jsxDEV(Link, {
							to: "/login",
							children: [/* @__PURE__ */ _jsxDEV("i", {
								className: "bi bi-arrow-left me-1",
								"aria-hidden": "true"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 211,
								columnNumber: 15
							}, this), "Back to sign in"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 210,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 209,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 155,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 135,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 134,
		columnNumber: 5
	}, this);
}
_s(VerifyOtp, "8wniUg6I6/lUQRu6d4BvsJQtg44=", false, function() {
	return [
		useLocation,
		useNavigate,
		useToast,
		useAuth
	];
});
_c = VerifyOtp;
var _c;
$RefreshReg$(_c, "VerifyOtp");
if (import.meta.hot && !inWebWorker) {
	window.$RefreshReg$ = prevRefreshReg;
	window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
	RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
		RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/pages/VerifyOtp.jsx", currentExports);
		import.meta.hot.accept((nextExports) => {
			if (!nextExports) return;
			const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/pages/VerifyOtp.jsx", currentExports, nextExports);
			if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
		});
	});
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLE9BQU9BLFNBQVNDLFdBQVdDLFFBQVFDLGdCQUFnQjtBQUNuRCxTQUFTQyxNQUFNQyxhQUFhQyxtQkFBbUI7QUFDL0MsT0FBT0MsY0FBYztBQUNyQixTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLGdCQUFnQjtBQUV6QixNQUFNQyxlQUFlO0NBQ25CQyxPQUFPO0VBQUVDLE9BQU87RUFBMkJDLFVBQVU7RUFBeUNDLEtBQUs7Q0FBbUI7Q0FDdEhDLG9CQUFvQjtFQUFFSCxPQUFPO0VBQXFCQyxVQUFVO0VBQW1DQyxLQUFLO0NBQWU7Q0FDbkhFLGdCQUFnQjtFQUFFSixPQUFPO0VBQTJCQyxVQUFVO0VBQXFDQyxLQUFLO0NBQVc7QUFDckg7QUFFQSxlQUFlLFNBQVNHLFlBQVk7Q0FBQUMsR0FBQTtDQUNsQyxNQUFNQyxXQUFXaEIsWUFBWTtDQUM3QixNQUFNaUIsV0FBV2hCLFlBQVk7Q0FDN0IsTUFBTWlCLFFBQVFaLFNBQVM7Q0FDdkIsTUFBTSxFQUFFYSxpQkFBaUJkLFFBQVE7Q0FFakMsTUFBTWUsU0FBU0osU0FBU0ssT0FBT0QsU0FBUyxHQUFFLENBQUVFLEtBQUs7Q0FDakQsTUFBTUMsVUFBVVAsU0FBU0ssT0FBT0UsV0FBVztDQUMzQyxNQUFNQyxVQUFVQyxRQUFRVCxTQUFTSyxPQUFPRyxPQUFPO0NBQy9DLE1BQU1FLE9BQU9uQixhQUFhZ0IsWUFBWWhCLGFBQWFDO0NBRW5ELE1BQU0sQ0FBQ21CLE1BQU1DLFdBQVc5QixTQUFTLEVBQUU7Q0FDbkMsTUFBTSxDQUFDK0IsU0FBU0MsY0FBY2hDLFNBQVMsS0FBSztDQUM1QyxNQUFNLENBQUNpQyxTQUFTQyxjQUFjbEMsU0FBUyxLQUFLO0NBQzVDLE1BQU0sQ0FBQ21DLE9BQU9DLFlBQVlwQyxTQUFTLEVBQUU7Q0FDckMsTUFBTSxDQUFDcUMsYUFBYUMsa0JBQWtCdEMsU0FBUyxHQUFHO0NBQ2xELE1BQU0sQ0FBQ3VDLFFBQVFDLGFBQWF4QyxTQUFTLENBQUM7Q0FDdEMsTUFBTXlDLFVBQVUxQyxPQUFPLEtBQUs7O0NBRzVCRCxnQkFBZ0I7RUFDZCxJQUFJLENBQUN3QixPQUFPSCxTQUFTLFVBQVUsRUFBRXVCLFNBQVMsS0FBSyxDQUFDO0NBQ2xELEdBQUcsQ0FBQ3BCLE9BQU9ILFFBQVEsQ0FBQzs7Q0FHcEJyQixnQkFBZ0I7RUFDZCxJQUFJNEIsV0FBV0osU0FBUyxDQUFDbUIsUUFBUUUsU0FBUztHQUN4Q0YsUUFBUUUsVUFBVTtHQUNsQixDQUFDLFlBQVk7SUFDWFQsV0FBVyxJQUFJO0lBQ2YsSUFBSTtLQUNGLE1BQU03QixRQUFRdUMsUUFBUXRCLE9BQU9HLFlBQVksdUJBQXVCLFVBQVVBLE9BQU87S0FDakZMLE1BQU15QixLQUFLLDZCQUE2QnZCLE9BQU87SUFDakQsU0FBU3dCLEtBQUs7S0FDWlYsU0FBU1UsSUFBSUMsT0FBTztJQUN0QixVQUFVO0tBQ1JiLFdBQVcsS0FBSztJQUNsQjtHQUNGLEVBQUMsQ0FBRTtFQUNMOztDQUVGLEdBQUcsQ0FBQ1IsU0FBU0osS0FBSyxDQUFDOztDQUduQnhCLGdCQUFnQjtFQUNkLElBQUl1QyxlQUFlLEdBQUc7RUFDdEIsTUFBTVcsUUFBUUMsa0JBQWtCWCxnQkFBZ0JZLE1BQU1DLEtBQUtDLElBQUksR0FBR0YsSUFBSSxDQUFDLENBQUMsR0FBRyxHQUFJO0VBQy9FLGFBQWFHLGNBQWNMLEtBQUs7Q0FDbEMsR0FBRyxDQUFDWCxXQUFXLENBQUM7Q0FFaEIsTUFBTWlCLEtBQUtDLE9BQU9KLEtBQUtLLE1BQU1uQixjQUFjLEVBQUUsQ0FBQyxDQUFDLENBQUNvQixTQUFTLEdBQUcsR0FBRztDQUMvRCxNQUFNQyxLQUFLSCxPQUFPbEIsY0FBYyxFQUFFLENBQUMsQ0FBQ29CLFNBQVMsR0FBRyxHQUFHO0NBRW5ELGVBQWVFLGFBQWFDLFdBQVc7RUFDckMsSUFBSSxDQUFDQSxhQUFhQSxVQUFVQyxTQUFTLEdBQUc7R0FDdEN6QixTQUFTLHVDQUF1QztHQUNoRDtFQUNGO0VBQ0FBLFNBQVMsRUFBRTtFQUNYSixXQUFXLElBQUk7RUFDZixJQUFJO0dBQ0YsSUFBSVAsWUFBWSxrQkFBa0I7SUFDaEMsTUFBTSxFQUFFcUMsZUFBZSxNQUFNekQsUUFBUTBELGVBQWV6QyxPQUFPc0MsU0FBUztJQUNwRXpDLFNBQVMsbUJBQW1CLEVBQUVJLE9BQU87S0FBRUQ7S0FBT3dDO0lBQVcsRUFBRSxDQUFDO0dBQzlELE9BQU87SUFDTCxNQUFNLEVBQUVFLE9BQU9DLFNBQVMsTUFBTTVELFFBQVE2RCxVQUFVNUMsT0FBT3NDLFdBQVduQyxPQUFPO0lBQ3pFSixhQUFhMkMsT0FBT0MsSUFBSTtJQUN4QjdDLE1BQU0rQyxRQUFRLG1DQUFtQztJQUNqRGhELFNBQVMsY0FBYyxFQUFFdUIsU0FBUyxLQUFLLENBQUM7R0FDMUM7RUFDRixTQUFTSSxLQUFLO0dBQ1pWLFNBQVNVLGVBQWV4QyxZQUFZd0MsSUFBSXNCLFNBQVNQLFNBQVMsR0FBR2YsSUFBSUMsWUFBWUQsSUFBSUMsT0FBTztHQUN4RmpCLFFBQVEsRUFBRTtFQUNaLFVBQVU7R0FDUkUsV0FBVyxLQUFLO0VBQ2xCO0NBQ0Y7Q0FFQSxlQUFlcUMsZUFBZTtFQUM1QixJQUFJOUIsVUFBVSxHQUFHO0dBQ2ZILFNBQVMsdUVBQXVFO0dBQ2hGO0VBQ0Y7RUFDQUEsU0FBUyxFQUFFO0VBQ1hGLFdBQVcsSUFBSTtFQUNmLElBQUk7R0FDRixNQUFNb0MsY0FBYzdDLFlBQVksdUJBQXVCLHVCQUF1QkEsWUFBWSxtQkFBbUIsbUJBQW1CO0dBQ2hJLE1BQU1wQixRQUFRdUMsUUFBUXRCLE9BQU9nRCxnQkFBZ0IsdUJBQXVCLFVBQVVBLFdBQVc7R0FDekY5QixXQUFXK0IsTUFBTUEsSUFBSSxDQUFDO0dBQ3RCakMsZUFBZSxHQUFHO0dBQ2xCUixRQUFRLEVBQUU7R0FDVlYsTUFBTStDLFFBQVEsd0NBQXdDO0VBQ3hELFNBQVNyQixLQUFLO0dBQ1pWLFNBQVNVLElBQUlDLE9BQU87RUFDdEIsVUFBVTtHQUNSYixXQUFXLEtBQUs7RUFDbEI7Q0FDRjtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFDYix3QkFBQyxPQUFEO0dBQUssV0FBVTtHQUFrQixPQUFPLEVBQUVzQyxVQUFVLElBQUk7YUFBeEQsQ0FDRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBQ0Usd0JBQUMsT0FBRDtNQUNFLFdBQVU7TUFDVixPQUFPO09BQ0xDLE9BQU87T0FDUEMsUUFBUTtPQUNSQyxjQUFjO09BQ2RDLFlBQVk7T0FDWkMsT0FBTztPQUNQQyxVQUFVO01BQ1o7Z0JBRUEsd0JBQUMsS0FBRDtPQUFHLFdBQVU7T0FBcUIsZUFBWTtNQUFNOzs7OztLQUNqRDs7Ozs7S0FDTCx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBb0JsRCxLQUFLakI7S0FBVTs7Ozs7S0FDakQsd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQThCaUIsS0FBS2hCO0tBQVk7Ozs7O0tBQzVELHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUF1QlU7S0FBUzs7Ozs7SUFDMUM7Ozs7O2FBRUwsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNHYSxTQUFTLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO01BQTBCLE1BQUs7Z0JBQVNBO0tBQVc7Ozs7O0tBRTVFLHdCQUFDLFVBQUQ7TUFDRSxPQUFPTjtNQUNQLFVBQVVDO01BQ1YsWUFBWTZCO01BQ1osVUFBVTVCLFdBQVdFO0tBQVE7Ozs7O0tBRy9CLHdCQUFDLFVBQUQ7TUFDRSxXQUFVO01BQ1YsVUFBVUYsV0FBV0UsV0FBV0osS0FBS2dDLFNBQVM7TUFDOUMsZUFBZUYsYUFBYTlCLElBQUk7Z0JBRS9CRSxVQUNDLGdEQUNFLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO09BQXdDLE1BQUs7T0FBUyxlQUFZO01BQU07Ozs7Z0JBQUEsWUFFMUY7Ozs7aUJBRUE7S0FFSTs7Ozs7S0FFUix3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBYjtPQUFxRDtPQUNsQztPQUNqQix3QkFBQyxRQUFEO1FBQU0sV0FBVTtRQUEyQixlQUFZO2tCQUF2RDtTQUNHdUI7U0FBRztTQUFFSTtRQUNGOzs7Ozs7TUFDTDs7Ozs7O0tBRUgsd0JBQUMsTUFBRCxDQUFHOzs7OztLQUNILHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUFvQztLQUEwQjs7Ozs7S0FDM0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxVQUFEO09BQ0UsV0FBVTtPQUNWLFNBQVNXO09BQ1QsVUFBVXBDLFdBQVdNLFVBQVUsS0FBS0YsY0FBYztpQkFFakRKLFVBQ0MsZ0RBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7UUFBd0MsTUFBSztRQUFTLGVBQVk7T0FBTTs7OztpQkFBQSxlQUUxRjs7OztrQkFFQTtNQUVJOzs7O2dCQUNQTSxVQUFVLEtBQ1Qsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQXlCO01BQXNEOzs7O2NBRTdGOzs7Ozs7S0FFTCx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFDWCx3QkFBQyxNQUFEO09BQU0sSUFBRztpQkFBVCxDQUNFLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO1FBQXdCLGVBQVk7T0FBTTs7OztpQkFBQSxpQkFFbkQ7Ozs7OztLQUNMOzs7OztJQUNBOzs7OztXQUNGOzs7Ozs7Q0FDRjs7Ozs7QUFFVDtBQUFDdEIsR0F6THVCRCxXQUFTO0NBQUE7RUFDZGQ7RUFDQUM7RUFDSEs7RUFDV0Q7Q0FBTztBQUFBO0FBQUEsS0FKVlM7QUFBUyxJQUFBK0Q7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJ1c2VFZmZlY3QiLCJ1c2VSZWYiLCJ1c2VTdGF0ZSIsIkxpbmsiLCJ1c2VMb2NhdGlvbiIsInVzZU5hdmlnYXRlIiwiT3RwSW5wdXQiLCJhdXRoQXBpIiwiQXBpRXJyb3IiLCJ1c2VBdXRoIiwidXNlVG9hc3QiLCJQVVJQT1NFX01FVEEiLCJsb2dpbiIsInRpdGxlIiwic3VidGl0bGUiLCJjdGEiLCJlbWFpbF92ZXJpZmljYXRpb24iLCJwYXNzd29yZF9yZXNldCIsIlZlcmlmeU90cCIsIl9zIiwibG9jYXRpb24iLCJuYXZpZ2F0ZSIsInRvYXN0IiwiYXBwbHlTZXNzaW9uIiwiZW1haWwiLCJzdGF0ZSIsInRyaW0iLCJwdXJwb3NlIiwic2VuZE5vdyIsIkJvb2xlYW4iLCJtZXRhIiwiY29kZSIsInNldENvZGUiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsInNlbmRpbmciLCJzZXRTZW5kaW5nIiwiZXJyb3IiLCJzZXRFcnJvciIsInNlY29uZHNMZWZ0Iiwic2V0U2Vjb25kc0xlZnQiLCJyZXNlbnQiLCJzZXRSZXNlbnQiLCJzZW50UmVmIiwicmVwbGFjZSIsImN1cnJlbnQiLCJzZW5kT3RwIiwiaW5mbyIsImVyciIsIm1lc3NhZ2UiLCJ0aW1lciIsInNldEludGVydmFsIiwicyIsIk1hdGgiLCJtYXgiLCJjbGVhckludGVydmFsIiwibW0iLCJTdHJpbmciLCJmbG9vciIsInBhZFN0YXJ0Iiwic3MiLCJoYW5kbGVWZXJpZnkiLCJzdWJtaXR0ZWQiLCJsZW5ndGgiLCJyZXNldFRva2VuIiwidmVyaWZ5UmVzZXRPdHAiLCJ0b2tlbiIsInVzZXIiLCJ2ZXJpZnlPdHAiLCJzdWNjZXNzIiwiZGV0YWlscyIsImhhbmRsZVJlc2VuZCIsInNlbmRQdXJwb3NlIiwiciIsIm1heFdpZHRoIiwid2lkdGgiLCJoZWlnaHQiLCJib3JkZXJSYWRpdXMiLCJiYWNrZ3JvdW5kIiwiY29sb3IiLCJmb250U2l6ZSIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlZlcmlmeU90cC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZUVmZmVjdCwgdXNlUmVmLCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgTGluaywgdXNlTG9jYXRpb24sIHVzZU5hdmlnYXRlIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcbmltcG9ydCBPdHBJbnB1dCBmcm9tIFwiLi4vY29tcG9uZW50cy9PdHBJbnB1dC5qc3hcIjtcbmltcG9ydCB7IGF1dGhBcGkgfSBmcm9tIFwiLi4vYXBpL2F1dGguanNcIjtcbmltcG9ydCB7IEFwaUVycm9yIH0gZnJvbSBcIi4uL2FwaS9jbGllbnQuanNcIjtcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tIFwiLi4vY29udGV4dC9BdXRoQ29udGV4dC5qc3hcIjtcbmltcG9ydCB7IHVzZVRvYXN0IH0gZnJvbSBcIi4uL2NvbnRleHQvVG9hc3RDb250ZXh0LmpzeFwiO1xuXG5jb25zdCBQVVJQT1NFX01FVEEgPSB7XG4gIGxvZ2luOiB7IHRpdGxlOiBcIkVudGVyIFZlcmlmaWNhdGlvbiBDb2RlXCIsIHN1YnRpdGxlOiBcIldlIHNlbnQgYSBsb2dpbiB2ZXJpZmljYXRpb24gY29kZSB0bzpcIiwgY3RhOiBcIlZlcmlmeSAmIFNpZ24gSW5cIiB9LFxuICBlbWFpbF92ZXJpZmljYXRpb246IHsgdGl0bGU6IFwiVmVyaWZ5IFlvdXIgRW1haWxcIiwgc3VidGl0bGU6IFwiV2Ugc2VudCBhIHZlcmlmaWNhdGlvbiBjb2RlIHRvOlwiLCBjdGE6IFwiVmVyaWZ5IEVtYWlsXCIgfSxcbiAgcGFzc3dvcmRfcmVzZXQ6IHsgdGl0bGU6IFwiRW50ZXIgVmVyaWZpY2F0aW9uIENvZGVcIiwgc3VidGl0bGU6IFwiV2Ugc2VudCBhIHBhc3N3b3JkLXJlc2V0IGNvZGUgdG86XCIsIGN0YTogXCJDb250aW51ZVwiIH0sXG59O1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBWZXJpZnlPdHAoKSB7XG4gIGNvbnN0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKTtcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuICBjb25zdCB0b2FzdCA9IHVzZVRvYXN0KCk7XG4gIGNvbnN0IHsgYXBwbHlTZXNzaW9uIH0gPSB1c2VBdXRoKCk7XG5cbiAgY29uc3QgZW1haWwgPSAobG9jYXRpb24uc3RhdGU/LmVtYWlsIHx8IFwiXCIpLnRyaW0oKTtcbiAgY29uc3QgcHVycG9zZSA9IGxvY2F0aW9uLnN0YXRlPy5wdXJwb3NlIHx8IFwibG9naW5cIjtcbiAgY29uc3Qgc2VuZE5vdyA9IEJvb2xlYW4obG9jYXRpb24uc3RhdGU/LnNlbmROb3cpO1xuICBjb25zdCBtZXRhID0gUFVSUE9TRV9NRVRBW3B1cnBvc2VdIHx8IFBVUlBPU0VfTUVUQS5sb2dpbjtcblxuICBjb25zdCBbY29kZSwgc2V0Q29kZV0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbc2VuZGluZywgc2V0U2VuZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFtzZWNvbmRzTGVmdCwgc2V0U2Vjb25kc0xlZnRdID0gdXNlU3RhdGUoMTIwKTtcbiAgY29uc3QgW3Jlc2VudCwgc2V0UmVzZW50XSA9IHVzZVN0YXRlKDApO1xuICBjb25zdCBzZW50UmVmID0gdXNlUmVmKGZhbHNlKTtcblxuICAvLyBVc2VycyBtdXN0IGFycml2ZSB3aXRoIGFuIGVtYWlsIGluIHN0YXRlLlxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghZW1haWwpIG5hdmlnYXRlKFwiL2xvZ2luXCIsIHsgcmVwbGFjZTogdHJ1ZSB9KTtcbiAgfSwgW2VtYWlsLCBuYXZpZ2F0ZV0pO1xuXG4gIC8vIE9wdGlvbmFsbHkgYXV0by1zZW5kIHRoZSBjb2RlIHdoZW4gYXJyaXZpbmcgZnJvbSBcIkxvZ2luIHdpdGggT1RQXCIuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKHNlbmROb3cgJiYgZW1haWwgJiYgIXNlbnRSZWYuY3VycmVudCkge1xuICAgICAgc2VudFJlZi5jdXJyZW50ID0gdHJ1ZTtcbiAgICAgIChhc3luYyAoKSA9PiB7XG4gICAgICAgIHNldFNlbmRpbmcodHJ1ZSk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgYXdhaXQgYXV0aEFwaS5zZW5kT3RwKGVtYWlsLCBwdXJwb3NlID09PSBcImVtYWlsX3ZlcmlmaWNhdGlvblwiID8gXCJsb2dpblwiIDogcHVycG9zZSk7XG4gICAgICAgICAgdG9hc3QuaW5mbyhgVmVyaWZpY2F0aW9uIGNvZGUgc2VudCB0byAke2VtYWlsfWApO1xuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICBzZXRFcnJvcihlcnIubWVzc2FnZSk7XG4gICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgc2V0U2VuZGluZyhmYWxzZSk7XG4gICAgICAgIH1cbiAgICAgIH0pKCk7XG4gICAgfVxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9leGhhdXN0aXZlLWRlcHNcbiAgfSwgW3NlbmROb3csIGVtYWlsXSk7XG5cbiAgLy8gQ291bnRkb3duIHRpbWVyLlxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChzZWNvbmRzTGVmdCA8PSAwKSByZXR1cm47XG4gICAgY29uc3QgdGltZXIgPSBzZXRJbnRlcnZhbCgoKSA9PiBzZXRTZWNvbmRzTGVmdCgocykgPT4gTWF0aC5tYXgoMCwgcyAtIDEpKSwgMTAwMCk7XG4gICAgcmV0dXJuICgpID0+IGNsZWFySW50ZXJ2YWwodGltZXIpO1xuICB9LCBbc2Vjb25kc0xlZnRdKTtcblxuICBjb25zdCBtbSA9IFN0cmluZyhNYXRoLmZsb29yKHNlY29uZHNMZWZ0IC8gNjApKS5wYWRTdGFydCgyLCBcIjBcIik7XG4gIGNvbnN0IHNzID0gU3RyaW5nKHNlY29uZHNMZWZ0ICUgNjApLnBhZFN0YXJ0KDIsIFwiMFwiKTtcblxuICBhc3luYyBmdW5jdGlvbiBoYW5kbGVWZXJpZnkoc3VibWl0dGVkKSB7XG4gICAgaWYgKCFzdWJtaXR0ZWQgfHwgc3VibWl0dGVkLmxlbmd0aCA8IDYpIHtcbiAgICAgIHNldEVycm9yKFwiRW50ZXIgdGhlIGNvbXBsZXRlIHZlcmlmaWNhdGlvbiBjb2RlLlwiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgc2V0RXJyb3IoXCJcIik7XG4gICAgc2V0TG9hZGluZyh0cnVlKTtcbiAgICB0cnkge1xuICAgICAgaWYgKHB1cnBvc2UgPT09IFwicGFzc3dvcmRfcmVzZXRcIikge1xuICAgICAgICBjb25zdCB7IHJlc2V0VG9rZW4gfSA9IGF3YWl0IGF1dGhBcGkudmVyaWZ5UmVzZXRPdHAoZW1haWwsIHN1Ym1pdHRlZCk7XG4gICAgICAgIG5hdmlnYXRlKFwiL3Jlc2V0LXBhc3N3b3JkXCIsIHsgc3RhdGU6IHsgZW1haWwsIHJlc2V0VG9rZW4gfSB9KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnN0IHsgdG9rZW4sIHVzZXIgfSA9IGF3YWl0IGF1dGhBcGkudmVyaWZ5T3RwKGVtYWlsLCBzdWJtaXR0ZWQsIHB1cnBvc2UpO1xuICAgICAgICBhcHBseVNlc3Npb24odG9rZW4sIHVzZXIpO1xuICAgICAgICB0b2FzdC5zdWNjZXNzKFwiVmVyaWZpY2F0aW9uIHN1Y2Nlc3NmdWwuIFdlbGNvbWUhXCIpO1xuICAgICAgICBuYXZpZ2F0ZShcIi9kYXNoYm9hcmRcIiwgeyByZXBsYWNlOiB0cnVlIH0pO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgc2V0RXJyb3IoZXJyIGluc3RhbmNlb2YgQXBpRXJyb3IgJiYgZXJyLmRldGFpbHM/Lmxlbmd0aCA/IGAke2Vyci5tZXNzYWdlfWAgOiBlcnIubWVzc2FnZSk7XG4gICAgICBzZXRDb2RlKFwiXCIpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcbiAgICB9XG4gIH1cblxuICBhc3luYyBmdW5jdGlvbiBoYW5kbGVSZXNlbmQoKSB7XG4gICAgaWYgKHJlc2VudCA+PSAzKSB7XG4gICAgICBzZXRFcnJvcihcIlRvbyBtYW55IHJlc2VuZCByZXF1ZXN0cy4gUGxlYXNlIHdhaXQgYmVmb3JlIHJlcXVlc3RpbmcgYW5vdGhlciBjb2RlLlwiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgc2V0RXJyb3IoXCJcIik7XG4gICAgc2V0U2VuZGluZyh0cnVlKTtcbiAgICB0cnkge1xuICAgICAgY29uc3Qgc2VuZFB1cnBvc2UgPSBwdXJwb3NlID09PSBcImVtYWlsX3ZlcmlmaWNhdGlvblwiID8gXCJlbWFpbF92ZXJpZmljYXRpb25cIiA6IHB1cnBvc2UgPT09IFwicGFzc3dvcmRfcmVzZXRcIiA/IFwicGFzc3dvcmRfcmVzZXRcIiA6IFwibG9naW5cIjtcbiAgICAgIGF3YWl0IGF1dGhBcGkuc2VuZE90cChlbWFpbCwgc2VuZFB1cnBvc2UgPT09IFwiZW1haWxfdmVyaWZpY2F0aW9uXCIgPyBcImxvZ2luXCIgOiBzZW5kUHVycG9zZSk7XG4gICAgICBzZXRSZXNlbnQoKHIpID0+IHIgKyAxKTtcbiAgICAgIHNldFNlY29uZHNMZWZ0KDEyMCk7XG4gICAgICBzZXRDb2RlKFwiXCIpO1xuICAgICAgdG9hc3Quc3VjY2VzcyhcIkEgbmV3IHZlcmlmaWNhdGlvbiBjb2RlIGhhcyBiZWVuIHNlbnQuXCIpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgc2V0RXJyb3IoZXJyLm1lc3NhZ2UpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRTZW5kaW5nKGZhbHNlKTtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwibG9naW4td3JhcHBlclwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkIGxvZ2luLWNhcmRcIiBzdHlsZT17eyBtYXhXaWR0aDogNDIwIH19PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQtaGVhZGVyIHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgPGRpdlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwibXgtYXV0byBtYi0yIGQtZmxleCBhbGlnbi1pdGVtcy1jZW50ZXIganVzdGlmeS1jb250ZW50LWNlbnRlclwiXG4gICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICB3aWR0aDogNDgsXG4gICAgICAgICAgICAgIGhlaWdodDogNDgsXG4gICAgICAgICAgICAgIGJvcmRlclJhZGl1czogMTQsXG4gICAgICAgICAgICAgIGJhY2tncm91bmQ6IFwibGluZWFyLWdyYWRpZW50KDEzNWRlZywgIzBmNzY2ZSAwJSwgIzEzNGU0YSAxMDAlKVwiLFxuICAgICAgICAgICAgICBjb2xvcjogXCJ3aGl0ZVwiLFxuICAgICAgICAgICAgICBmb250U2l6ZTogMjIsXG4gICAgICAgICAgICB9fVxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxpIGNsYXNzTmFtZT1cImJpIGJpLXNoaWVsZC1jaGVja1wiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGg1IGNsYXNzTmFtZT1cIm1iLTAgZnctc2VtaWJvbGRcIj57bWV0YS50aXRsZX08L2g1PlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbXV0ZWQgc21hbGwgbWItMCBtdC0xXCI+e21ldGEuc3VidGl0bGV9PC9wPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZ3LW1lZGl1bSBtYi0wIG10LTFcIj57ZW1haWx9PC9wPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQtYm9keSBwLTRcIj5cbiAgICAgICAgICB7ZXJyb3IgJiYgPGRpdiBjbGFzc05hbWU9XCJhbGVydCBhbGVydC1kYW5nZXIgcHktMlwiIHJvbGU9XCJhbGVydFwiPntlcnJvcn08L2Rpdj59XG5cbiAgICAgICAgICA8T3RwSW5wdXRcbiAgICAgICAgICAgIHZhbHVlPXtjb2RlfVxuICAgICAgICAgICAgb25DaGFuZ2U9e3NldENvZGV9XG4gICAgICAgICAgICBvbkNvbXBsZXRlPXtoYW5kbGVWZXJpZnl9XG4gICAgICAgICAgICBkaXNhYmxlZD17bG9hZGluZyB8fCBzZW5kaW5nfVxuICAgICAgICAgIC8+XG5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJidG4gYnRuLWRoYW5pdGkgdy0xMDAgbXQtNFwiXG4gICAgICAgICAgICBkaXNhYmxlZD17bG9hZGluZyB8fCBzZW5kaW5nIHx8IGNvZGUubGVuZ3RoIDwgNn1cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVZlcmlmeShjb2RlKX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICB7bG9hZGluZyA/IChcbiAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzcGlubmVyLWJvcmRlciBzcGlubmVyLWJvcmRlci1zbSBtZS0yXCIgcm9sZT1cInN0YXR1c1wiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgICAgICAgVmVyaWZ5aW5n4oCmXG4gICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgXCJWZXJpZnlcIlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHRleHQtbXV0ZWQgc21hbGwgbXQtMyBtYi0yXCI+XG4gICAgICAgICAgICBDb2RlIGV4cGlyZXMgaW46e1wiIFwifVxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZnctc2VtaWJvbGQgdGV4dC1kaGFuaXRpXCIgZGF0YS10ZXN0aWQ9XCJvdHAtY291bnRkb3duXCI+XG4gICAgICAgICAgICAgIHttbX06e3NzfVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDwvcD5cblxuICAgICAgICAgIDxociAvPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHRleHQtbXV0ZWQgc21hbGwgbWItMVwiPkRpZG4mYXBvczt0IHJlY2VpdmUgaXQ/PC9wPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYnRuIGJ0bi1zbSBidG4tb3V0bGluZS1kaGFuaXRpXCJcbiAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlUmVzZW5kfVxuICAgICAgICAgICAgICBkaXNhYmxlZD17c2VuZGluZyB8fCByZXNlbnQgPj0gMyB8fCBzZWNvbmRzTGVmdCA+IDkwfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7c2VuZGluZyA/IChcbiAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic3Bpbm5lci1ib3JkZXIgc3Bpbm5lci1ib3JkZXItc20gbWUtMVwiIHJvbGU9XCJzdGF0dXNcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgICAgICAgICAgU2VuZGluZyBjb2Rl4oCmXG4gICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgXCJSZXNlbmQgQ29kZVwiXG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIHtyZXNlbnQgPj0gMyAmJiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic21hbGwgdGV4dC1kYW5nZXIgbXQtMlwiPk1heGltdW0gcmVzZW5kcyByZWFjaGVkIOKAlCBwbGVhc2UgdHJ5IGFnYWluIGxhdGVyLjwvZGl2PlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHNtYWxsIG10LTQgbWItMFwiPlxuICAgICAgICAgICAgPExpbmsgdG89XCIvbG9naW5cIj5cbiAgICAgICAgICAgICAgPGkgY2xhc3NOYW1lPVwiYmkgYmktYXJyb3ctbGVmdCBtZS0xXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICAgICAgQmFjayB0byBzaWduIGluXG4gICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiJDOi9Vc2Vycy91c2VyL0Rvd25sb2Fkcy9kaGFuaXRpLWFwcC11cGdyYWRlZC9kaGFuaXRpLWFwcC9mcm9udGVuZC9zcmMvcGFnZXMvVmVyaWZ5T3RwLmpzeCJ9