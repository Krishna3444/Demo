import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];const React = __vite__cjsImport3_react;import * as RefreshRuntime from "/@react-refresh";
var _jsxFileName = "C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/App.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=325d36c7";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
	if (!window.$RefreshReg$) {
		throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong.");
	}
	prevRefreshReg = window.$RefreshReg$;
	prevRefreshSig = window.$RefreshSig$;
	window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/App.jsx");
	window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=325d36c7";
import { Navigate, Route, Routes } from "/node_modules/.vite/deps/react-router-dom.js?v=325d36c7";
import { AuthProvider } from "/src/context/AuthContext.jsx";
import { ToastProvider } from "/src/context/ToastContext.jsx";
import Navbar from "/src/components/Navbar.jsx";
import ProtectedRoute from "/src/components/ProtectedRoute.jsx";
import Login from "/src/pages/Login.jsx";
import Register from "/src/pages/Register.jsx";
import VerifyOtp from "/src/pages/VerifyOtp.jsx";
import ForgotPassword from "/src/pages/ForgotPassword.jsx";
import ResetPassword from "/src/pages/ResetPassword.jsx";
import OAuthCallback from "/src/pages/OAuthCallback.jsx";
import Dashboard from "/src/pages/Dashboard.jsx";
import Applications from "/src/pages/Applications.jsx";
import Profile from "/src/pages/Profile.jsx";
import NotFound from "/src/pages/NotFound.jsx";
/** Layout for signed-in pages: navbar + routed content + footer. */
function AppShell({ children }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "d-flex flex-column min-vh-100",
		children: [
			/* @__PURE__ */ _jsxDEV(Navbar, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 42,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("main", {
				className: "flex-grow-1",
				children
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 43,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("footer", {
				className: "app-footer mt-auto",
				children: "Dhaniti Education Loan Dashboard · React + Bootstrap + FastAPI + SQLite · All records are synthetic. Do not treat as real customer or underwriting data."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 44,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 41,
		columnNumber: 5
	}, this);
}
_c = AppShell;
export default function App() {
	return /* @__PURE__ */ _jsxDEV(ToastProvider, { children: /* @__PURE__ */ _jsxDEV(AuthProvider, { children: /* @__PURE__ */ _jsxDEV(Routes, { children: [
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/login",
			element: /* @__PURE__ */ _jsxDEV(Login, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 58,
				columnNumber: 41
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 58,
			columnNumber: 11
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/register",
			element: /* @__PURE__ */ _jsxDEV(Register, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 59,
				columnNumber: 44
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 59,
			columnNumber: 11
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/verify-otp",
			element: /* @__PURE__ */ _jsxDEV(VerifyOtp, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 60,
				columnNumber: 46
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 60,
			columnNumber: 11
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/forgot-password",
			element: /* @__PURE__ */ _jsxDEV(ForgotPassword, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 61,
				columnNumber: 51
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 61,
			columnNumber: 11
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/reset-password",
			element: /* @__PURE__ */ _jsxDEV(ResetPassword, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 62,
				columnNumber: 50
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 62,
			columnNumber: 11
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/oauth/callback",
			element: /* @__PURE__ */ _jsxDEV(OAuthCallback, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 63,
				columnNumber: 50
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 63,
			columnNumber: 11
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/dashboard",
			element: /* @__PURE__ */ _jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ _jsxDEV(AppShell, { children: /* @__PURE__ */ _jsxDEV(Dashboard, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 71,
				columnNumber: 19
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 70,
				columnNumber: 17
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 69,
				columnNumber: 13
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 66,
			columnNumber: 11
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/applications",
			element: /* @__PURE__ */ _jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ _jsxDEV(AppShell, { children: /* @__PURE__ */ _jsxDEV(Applications, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 81,
				columnNumber: 19
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 80,
				columnNumber: 17
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 79,
				columnNumber: 13
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 76,
			columnNumber: 11
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/profile",
			element: /* @__PURE__ */ _jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ _jsxDEV(AppShell, { children: /* @__PURE__ */ _jsxDEV(Profile, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 91,
				columnNumber: 19
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 90,
				columnNumber: 17
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 89,
				columnNumber: 13
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 86,
			columnNumber: 11
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/",
			element: /* @__PURE__ */ _jsxDEV(Navigate, {
				to: "/dashboard",
				replace: true
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 98,
				columnNumber: 36
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 98,
			columnNumber: 11
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/index.html",
			element: /* @__PURE__ */ _jsxDEV(Navigate, {
				to: "/dashboard",
				replace: true
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 101,
				columnNumber: 22
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 99,
			columnNumber: 11
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "*",
			element: /* @__PURE__ */ _jsxDEV(AppShell, { children: /* @__PURE__ */ _jsxDEV(NotFound, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 107,
				columnNumber: 17
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 106,
				columnNumber: 13
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 103,
			columnNumber: 11
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 56,
		columnNumber: 9
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 55,
		columnNumber: 7
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 54,
		columnNumber: 5
	}, this);
}
_c2 = App;
var _c, _c2;
$RefreshReg$(_c, "AppShell");
$RefreshReg$(_c2, "App");
if (import.meta.hot && !inWebWorker) {
	window.$RefreshReg$ = prevRefreshReg;
	window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
	RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
		RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/App.jsx", currentExports);
		import.meta.hot.accept((nextExports) => {
			if (!nextExports) return;
			const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/App.jsx", currentExports, nextExports);
			if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
		});
	});
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsT0FBT0EsV0FBVztBQUNsQixTQUFTQyxVQUFVQyxPQUFPQyxjQUFjO0FBQ3hDLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxxQkFBcUI7QUFDOUIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxvQkFBb0I7QUFFM0IsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxjQUFjO0FBQ3JCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0Msb0JBQW9CO0FBQzNCLE9BQU9DLG1CQUFtQjtBQUMxQixPQUFPQyxtQkFBbUI7QUFDMUIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxrQkFBa0I7QUFDekIsT0FBT0MsYUFBYTtBQUNwQixPQUFPQyxjQUFjOztBQUdyQixTQUFTQyxTQUFTLEVBQUVDLFlBQVk7Q0FDOUIsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBQ0Usd0JBQUMsUUFBRCxDQUFPOzs7OztHQUNQLHdCQUFDLFFBQUQ7SUFBTSxXQUFVO0lBQWVBO0dBQWU7Ozs7O0dBQzlDLHdCQUFDLFVBQUQ7SUFBUSxXQUFVO2NBQW9CO0dBRzlCOzs7OztFQUNMOzs7Ozs7QUFFVDtBQUFDQyxLQVhRRjtBQWFULGVBQWUsU0FBU0csTUFBTTtDQUM1QixPQUNFLHdCQUFDLGVBQUQsWUFDRSx3QkFBQyxjQUFELFlBQ0Usd0JBQUMsUUFBRDtFQUVFLHdCQUFDLE9BQUQ7R0FBTyxNQUFLO0dBQVMsU0FBUyx3QkFBQyxPQUFELENBQU07Ozs7O0VBQUk7Ozs7O0VBQ3hDLHdCQUFDLE9BQUQ7R0FBTyxNQUFLO0dBQVksU0FBUyx3QkFBQyxVQUFELENBQVM7Ozs7O0VBQUk7Ozs7O0VBQzlDLHdCQUFDLE9BQUQ7R0FBTyxNQUFLO0dBQWMsU0FBUyx3QkFBQyxXQUFELENBQVU7Ozs7O0VBQUk7Ozs7O0VBQ2pELHdCQUFDLE9BQUQ7R0FBTyxNQUFLO0dBQW1CLFNBQVMsd0JBQUMsZ0JBQUQsQ0FBZTs7Ozs7RUFBSTs7Ozs7RUFDM0Qsd0JBQUMsT0FBRDtHQUFPLE1BQUs7R0FBa0IsU0FBUyx3QkFBQyxlQUFELENBQWM7Ozs7O0VBQUk7Ozs7O0VBQ3pELHdCQUFDLE9BQUQ7R0FBTyxNQUFLO0dBQWtCLFNBQVMsd0JBQUMsZUFBRCxDQUFjOzs7OztFQUFJOzs7OztFQUd6RCx3QkFBQyxPQUFEO0dBQ0UsTUFBSztHQUNMLFNBQ0Usd0JBQUMsZ0JBQUQsWUFDRSx3QkFBQyxVQUFELFlBQ0Usd0JBQUMsV0FBRCxDQUFVOzs7O1lBQ0Y7Ozs7WUFDSTs7Ozs7RUFDakI7Ozs7O0VBRUgsd0JBQUMsT0FBRDtHQUNFLE1BQUs7R0FDTCxTQUNFLHdCQUFDLGdCQUFELFlBQ0Usd0JBQUMsVUFBRCxZQUNFLHdCQUFDLGNBQUQsQ0FBYTs7OztZQUNMOzs7O1lBQ0k7Ozs7O0VBQ2pCOzs7OztFQUVILHdCQUFDLE9BQUQ7R0FDRSxNQUFLO0dBQ0wsU0FDRSx3QkFBQyxnQkFBRCxZQUNFLHdCQUFDLFVBQUQsWUFDRSx3QkFBQyxTQUFELENBQVE7Ozs7WUFDQTs7OztZQUNJOzs7OztFQUNqQjs7Ozs7RUFJSCx3QkFBQyxPQUFEO0dBQU8sTUFBSztHQUFJLFNBQVMsd0JBQUMsVUFBRDtJQUFVLElBQUc7SUFBYTtHQUFPOzs7OztFQUFJOzs7OztFQUM5RCx3QkFBQyxPQUFEO0dBQ0UsTUFBSztHQUNMLFNBQVMsd0JBQUMsVUFBRDtJQUFVLElBQUc7SUFBYTtHQUFPOzs7OztFQUFJOzs7OztFQUVoRCx3QkFBQyxPQUFEO0dBQ0UsTUFBSztHQUNMLFNBQ0Usd0JBQUMsVUFBRCxZQUNFLHdCQUFDLFVBQUQsQ0FBUzs7OztZQUNEOzs7OztFQUNYOzs7OztDQUVHOzs7O1VBQ0k7Ozs7VUFDRDs7Ozs7QUFFbkI7QUFBQ0MsTUEvRHVCRDtBQUFHLElBQUFELElBQUFFO0FBQUEsYUFBQUYsSUFBQTtBQUFBLGFBQUFFLEtBQUEiLCJuYW1lcyI6WyJSZWFjdCIsIk5hdmlnYXRlIiwiUm91dGUiLCJSb3V0ZXMiLCJBdXRoUHJvdmlkZXIiLCJUb2FzdFByb3ZpZGVyIiwiTmF2YmFyIiwiUHJvdGVjdGVkUm91dGUiLCJMb2dpbiIsIlJlZ2lzdGVyIiwiVmVyaWZ5T3RwIiwiRm9yZ290UGFzc3dvcmQiLCJSZXNldFBhc3N3b3JkIiwiT0F1dGhDYWxsYmFjayIsIkRhc2hib2FyZCIsIkFwcGxpY2F0aW9ucyIsIlByb2ZpbGUiLCJOb3RGb3VuZCIsIkFwcFNoZWxsIiwiY2hpbGRyZW4iLCJfYyIsIkFwcCIsIl9jMiJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBcHAuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IE5hdmlnYXRlLCBSb3V0ZSwgUm91dGVzIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcbmltcG9ydCB7IEF1dGhQcm92aWRlciB9IGZyb20gXCIuL2NvbnRleHQvQXV0aENvbnRleHQuanN4XCI7XG5pbXBvcnQgeyBUb2FzdFByb3ZpZGVyIH0gZnJvbSBcIi4vY29udGV4dC9Ub2FzdENvbnRleHQuanN4XCI7XG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuL2NvbXBvbmVudHMvTmF2YmFyLmpzeFwiO1xuaW1wb3J0IFByb3RlY3RlZFJvdXRlIGZyb20gXCIuL2NvbXBvbmVudHMvUHJvdGVjdGVkUm91dGUuanN4XCI7XG5cbmltcG9ydCBMb2dpbiBmcm9tIFwiLi9wYWdlcy9Mb2dpbi5qc3hcIjtcbmltcG9ydCBSZWdpc3RlciBmcm9tIFwiLi9wYWdlcy9SZWdpc3Rlci5qc3hcIjtcbmltcG9ydCBWZXJpZnlPdHAgZnJvbSBcIi4vcGFnZXMvVmVyaWZ5T3RwLmpzeFwiO1xuaW1wb3J0IEZvcmdvdFBhc3N3b3JkIGZyb20gXCIuL3BhZ2VzL0ZvcmdvdFBhc3N3b3JkLmpzeFwiO1xuaW1wb3J0IFJlc2V0UGFzc3dvcmQgZnJvbSBcIi4vcGFnZXMvUmVzZXRQYXNzd29yZC5qc3hcIjtcbmltcG9ydCBPQXV0aENhbGxiYWNrIGZyb20gXCIuL3BhZ2VzL09BdXRoQ2FsbGJhY2suanN4XCI7XG5pbXBvcnQgRGFzaGJvYXJkIGZyb20gXCIuL3BhZ2VzL0Rhc2hib2FyZC5qc3hcIjtcbmltcG9ydCBBcHBsaWNhdGlvbnMgZnJvbSBcIi4vcGFnZXMvQXBwbGljYXRpb25zLmpzeFwiO1xuaW1wb3J0IFByb2ZpbGUgZnJvbSBcIi4vcGFnZXMvUHJvZmlsZS5qc3hcIjtcbmltcG9ydCBOb3RGb3VuZCBmcm9tIFwiLi9wYWdlcy9Ob3RGb3VuZC5qc3hcIjtcblxuLyoqIExheW91dCBmb3Igc2lnbmVkLWluIHBhZ2VzOiBuYXZiYXIgKyByb3V0ZWQgY29udGVudCArIGZvb3Rlci4gKi9cbmZ1bmN0aW9uIEFwcFNoZWxsKHsgY2hpbGRyZW4gfSkge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZC1mbGV4IGZsZXgtY29sdW1uIG1pbi12aC0xMDBcIj5cbiAgICAgIDxOYXZiYXIgLz5cbiAgICAgIDxtYWluIGNsYXNzTmFtZT1cImZsZXgtZ3Jvdy0xXCI+e2NoaWxkcmVufTwvbWFpbj5cbiAgICAgIDxmb290ZXIgY2xhc3NOYW1lPVwiYXBwLWZvb3RlciBtdC1hdXRvXCI+XG4gICAgICAgIERoYW5pdGkgRWR1Y2F0aW9uIExvYW4gRGFzaGJvYXJkICZtaWRkb3Q7IFJlYWN0ICsgQm9vdHN0cmFwICsgRmFzdEFQSSArIFNRTGl0ZSAmbWlkZG90O1xuICAgICAgICBBbGwgcmVjb3JkcyBhcmUgc3ludGhldGljLiBEbyBub3QgdHJlYXQgYXMgcmVhbCBjdXN0b21lciBvciB1bmRlcndyaXRpbmcgZGF0YS5cbiAgICAgIDwvZm9vdGVyPlxuICAgIDwvZGl2PlxuICApO1xufVxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBBcHAoKSB7XG4gIHJldHVybiAoXG4gICAgPFRvYXN0UHJvdmlkZXI+XG4gICAgICA8QXV0aFByb3ZpZGVyPlxuICAgICAgICA8Um91dGVzPlxuICAgICAgICAgIHsvKiBQdWJsaWMgcm91dGVzICovfVxuICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL2xvZ2luXCIgZWxlbWVudD17PExvZ2luIC8+fSAvPlxuICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL3JlZ2lzdGVyXCIgZWxlbWVudD17PFJlZ2lzdGVyIC8+fSAvPlxuICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL3ZlcmlmeS1vdHBcIiBlbGVtZW50PXs8VmVyaWZ5T3RwIC8+fSAvPlxuICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL2ZvcmdvdC1wYXNzd29yZFwiIGVsZW1lbnQ9ezxGb3Jnb3RQYXNzd29yZCAvPn0gLz5cbiAgICAgICAgICA8Um91dGUgcGF0aD1cIi9yZXNldC1wYXNzd29yZFwiIGVsZW1lbnQ9ezxSZXNldFBhc3N3b3JkIC8+fSAvPlxuICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL29hdXRoL2NhbGxiYWNrXCIgZWxlbWVudD17PE9BdXRoQ2FsbGJhY2sgLz59IC8+XG5cbiAgICAgICAgICB7LyogUHJvdGVjdGVkIHJvdXRlcyAqL31cbiAgICAgICAgICA8Um91dGVcbiAgICAgICAgICAgIHBhdGg9XCIvZGFzaGJvYXJkXCJcbiAgICAgICAgICAgIGVsZW1lbnQ9e1xuICAgICAgICAgICAgICA8UHJvdGVjdGVkUm91dGU+XG4gICAgICAgICAgICAgICAgPEFwcFNoZWxsPlxuICAgICAgICAgICAgICAgICAgPERhc2hib2FyZCAvPlxuICAgICAgICAgICAgICAgIDwvQXBwU2hlbGw+XG4gICAgICAgICAgICAgIDwvUHJvdGVjdGVkUm91dGU+XG4gICAgICAgICAgICB9XG4gICAgICAgICAgLz5cbiAgICAgICAgICA8Um91dGVcbiAgICAgICAgICAgIHBhdGg9XCIvYXBwbGljYXRpb25zXCJcbiAgICAgICAgICAgIGVsZW1lbnQ9e1xuICAgICAgICAgICAgICA8UHJvdGVjdGVkUm91dGU+XG4gICAgICAgICAgICAgICAgPEFwcFNoZWxsPlxuICAgICAgICAgICAgICAgICAgPEFwcGxpY2F0aW9ucyAvPlxuICAgICAgICAgICAgICAgIDwvQXBwU2hlbGw+XG4gICAgICAgICAgICAgIDwvUHJvdGVjdGVkUm91dGU+XG4gICAgICAgICAgICB9XG4gICAgICAgICAgLz5cbiAgICAgICAgICA8Um91dGVcbiAgICAgICAgICAgIHBhdGg9XCIvcHJvZmlsZVwiXG4gICAgICAgICAgICBlbGVtZW50PXtcbiAgICAgICAgICAgICAgPFByb3RlY3RlZFJvdXRlPlxuICAgICAgICAgICAgICAgIDxBcHBTaGVsbD5cbiAgICAgICAgICAgICAgICAgIDxQcm9maWxlIC8+XG4gICAgICAgICAgICAgICAgPC9BcHBTaGVsbD5cbiAgICAgICAgICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAvPlxuXG4gICAgICAgICAgey8qIFJvb3QgJiBmYWxsYmFja3MgKi99XG4gICAgICAgICAgPFJvdXRlIHBhdGg9XCIvXCIgZWxlbWVudD17PE5hdmlnYXRlIHRvPVwiL2Rhc2hib2FyZFwiIHJlcGxhY2UgLz59IC8+XG4gICAgICAgICAgPFJvdXRlXG4gICAgICAgICAgICBwYXRoPVwiL2luZGV4Lmh0bWxcIlxuICAgICAgICAgICAgZWxlbWVudD17PE5hdmlnYXRlIHRvPVwiL2Rhc2hib2FyZFwiIHJlcGxhY2UgLz59XG4gICAgICAgICAgLz5cbiAgICAgICAgICA8Um91dGVcbiAgICAgICAgICAgIHBhdGg9XCIqXCJcbiAgICAgICAgICAgIGVsZW1lbnQ9e1xuICAgICAgICAgICAgICA8QXBwU2hlbGw+XG4gICAgICAgICAgICAgICAgPE5vdEZvdW5kIC8+XG4gICAgICAgICAgICAgIDwvQXBwU2hlbGw+XG4gICAgICAgICAgICB9XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9Sb3V0ZXM+XG4gICAgICA8L0F1dGhQcm92aWRlcj5cbiAgICA8L1RvYXN0UHJvdmlkZXI+XG4gICk7XG59XG4iXSwiZmlsZSI6IkM6L1VzZXJzL3VzZXIvRG93bmxvYWRzL2RoYW5pdGktYXBwLXVwZ3JhZGVkL2RoYW5pdGktYXBwL2Zyb250ZW5kL3NyYy9BcHAuanN4In0=