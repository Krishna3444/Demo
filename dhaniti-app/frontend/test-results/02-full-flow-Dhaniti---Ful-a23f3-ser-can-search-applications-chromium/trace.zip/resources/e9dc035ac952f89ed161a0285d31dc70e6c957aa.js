import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/context/ToastContext.jsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];const React = __vite__cjsImport3_react; const createContext = __vite__cjsImport3_react["createContext"]; const useCallback = __vite__cjsImport3_react["useCallback"]; const useContext = __vite__cjsImport3_react["useContext"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useRef = __vite__cjsImport3_react["useRef"]; const useState = __vite__cjsImport3_react["useState"];import * as RefreshRuntime from "/@react-refresh";
var _jsxFileName = "C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/context/ToastContext.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=325d36c7";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
	if (!window.$RefreshReg$) {
		throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong.");
	}
	prevRefreshReg = window.$RefreshReg$;
	prevRefreshSig = window.$RefreshSig$;
	window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/context/ToastContext.jsx");
	window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=325d36c7";
const ToastContext = createContext(null);
let nextId = 1;
/**
* Bootstrap-styled toast notifications.
*   const toast = useToast();
*   toast.success("Record created successfully");
*   toast.error("Unable to save record");
*/
export function ToastProvider({ children }) {
	_s();
	const [toasts, setToasts] = useState([]);
	const timers = useRef({});
	const dismiss = useCallback((id) => {
		setToasts((list) => list.filter((t) => t.id !== id));
		if (timers.current[id]) {
			clearTimeout(timers.current[id]);
			delete timers.current[id];
		}
	}, []);
	const push = useCallback((variant, message, options = {}) => {
		const id = nextId++;
		const toast = {
			id,
			variant,
			message,
			title: options.title || (variant === "success" ? "Success" : variant === "error" ? "Error" : "Notice"),
			duration: options.duration ?? 4500
		};
		setToasts((list) => [...list.slice(-4), toast]);
		timers.current[id] = setTimeout(() => dismiss(id), toast.duration);
		return id;
	}, [dismiss]);
	const toast = useMemo(() => ({
		success: (message, options) => push("success", message, options),
		error: (message, options) => push("error", message, options),
		info: (message, options) => push("info", message, options),
		warning: (message, options) => push("warning", message, options),
		dismiss
	}), [push, dismiss]);
	const variantClass = {
		success: "text-bg-success",
		error: "text-bg-danger",
		info: "text-bg-primary",
		warning: "text-bg-warning"
	};
	return /* @__PURE__ */ _jsxDEV(ToastContext.Provider, {
		value: toast,
		children: [children, /* @__PURE__ */ _jsxDEV("div", {
			className: "toast-container position-fixed top-0 end-0 p-3",
			style: {
				zIndex: 1090,
				maxWidth: 380
			},
			"aria-live": "polite",
			"aria-atomic": "true",
			children: toasts.map((t) => /* @__PURE__ */ _jsxDEV("div", {
				className: `toast show align-items-center border-0 ${variantClass[t.variant]}`,
				role: "alert",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "d-flex",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "toast-body",
						children: [/* @__PURE__ */ _jsxDEV("strong", {
							className: "d-block mb-1",
							children: t.title
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 92,
							columnNumber: 17
						}, this), t.message]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 91,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: "btn-close btn-close-white me-2 m-auto",
						"aria-label": "Close",
						onClick: () => dismiss(t.id)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 95,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 90,
					columnNumber: 13
				}, this)
			}, t.id, false, {
				fileName: _jsxFileName,
				lineNumber: 89,
				columnNumber: 9
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 82,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 80,
		columnNumber: 5
	}, this);
}
_s(ToastProvider, "RYubRc+HDfELq4ucxf4GpNuZbbU=");
_c = ToastProvider;
export function useToast() {
	_s2();
	const ctx = useContext(ToastContext);
	if (!ctx) throw new Error("useToast must be used inside <ToastProvider>");
	return ctx;
}
_s2(useToast, "/dMy7t63NXD4eYACoT93CePwGrg=");
var _c;
$RefreshReg$(_c, "ToastProvider");
if (import.meta.hot && !inWebWorker) {
	window.$RefreshReg$ = prevRefreshReg;
	window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
	RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
		RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/context/ToastContext.jsx", currentExports);
		import.meta.hot.accept((nextExports) => {
			if (!nextExports) return;
			const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/context/ToastContext.jsx", currentExports, nextExports);
			if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
		});
	});
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLE9BQU9BLFNBQVNDLGVBQWVDLGFBQWFDLFlBQVlDLFNBQVNDLFFBQVFDLGdCQUFnQjtBQUV6RixNQUFNQyxlQUFlTixjQUFjLElBQUk7QUFFdkMsSUFBSU8sU0FBUzs7Ozs7OztBQVFiLE9BQU8sU0FBU0MsY0FBYyxFQUFFQyxZQUFZO0NBQUFDLEdBQUE7Q0FDMUMsTUFBTSxDQUFDQyxRQUFRQyxhQUFhUCxTQUFTLEVBQUU7Q0FDdkMsTUFBTVEsU0FBU1QsT0FBTyxDQUFDLENBQUM7Q0FFeEIsTUFBTVUsVUFBVWIsYUFBYWMsT0FBTztFQUNsQ0gsV0FBV0ksU0FBU0EsS0FBS0MsUUFBUUMsTUFBTUEsRUFBRUgsT0FBT0EsRUFBRSxDQUFDO0VBQ25ELElBQUlGLE9BQU9NLFFBQVFKLEtBQUs7R0FDdEJLLGFBQWFQLE9BQU9NLFFBQVFKLEdBQUc7R0FDL0IsT0FBT0YsT0FBT00sUUFBUUo7RUFDeEI7Q0FDRixHQUFHLEVBQUU7Q0FFTCxNQUFNTSxPQUFPcEIsYUFDVnFCLFNBQVNDLFNBQVNDLFVBQVUsQ0FBQyxNQUFNO0VBQ2xDLE1BQU1ULEtBQUtSO0VBQ1gsTUFBTWtCLFFBQVE7R0FDWlY7R0FDQU87R0FDQUM7R0FDQUcsT0FBT0YsUUFBUUUsVUFBVUosWUFBWSxZQUFZLFlBQVlBLFlBQVksVUFBVSxVQUFVO0dBQzdGSyxVQUFVSCxRQUFRRyxZQUFZO0VBQ2hDO0VBQ0FmLFdBQVdJLFNBQVMsQ0FBQyxHQUFHQSxLQUFLWSxNQUFNLENBQUMsQ0FBQyxHQUFHSCxLQUFLLENBQUM7RUFDOUNaLE9BQU9NLFFBQVFKLE1BQU1jLGlCQUFpQmYsUUFBUUMsRUFBRSxHQUFHVSxNQUFNRSxRQUFRO0VBQ2pFLE9BQU9aO0NBQ1QsR0FDQSxDQUFDRCxPQUFPLENBQ1Y7Q0FFQSxNQUFNVyxRQUFRdEIsZUFDTDtFQUNMMkIsVUFBVVAsU0FBU0MsWUFBWUgsS0FBSyxXQUFXRSxTQUFTQyxPQUFPO0VBQy9ETyxRQUFRUixTQUFTQyxZQUFZSCxLQUFLLFNBQVNFLFNBQVNDLE9BQU87RUFDM0RRLE9BQU9ULFNBQVNDLFlBQVlILEtBQUssUUFBUUUsU0FBU0MsT0FBTztFQUN6RFMsVUFBVVYsU0FBU0MsWUFBWUgsS0FBSyxXQUFXRSxTQUFTQyxPQUFPO0VBQy9EVjtDQUNGLElBQ0EsQ0FBQ08sTUFBTVAsT0FBTyxDQUNoQjtDQUVBLE1BQU1vQixlQUFlO0VBQ25CSixTQUFTO0VBQ1RDLE9BQU87RUFDUEMsTUFBTTtFQUNOQyxTQUFTO0NBQ1g7Q0FFQSxPQUNFLHdCQUFDLGFBQWEsVUFBZDtFQUF1QixPQUFPUjtZQUE5QixDQUNHaEIsVUFDRCx3QkFBQyxPQUFEO0dBQ0UsV0FBVTtHQUNWLE9BQU87SUFBRTBCLFFBQVE7SUFBTUMsVUFBVTtHQUFJO0dBQ3JDLGFBQVU7R0FDVixlQUFZO2FBRVh6QixPQUFPMEIsS0FBS25CLE1BQ1gsd0JBQUMsT0FBRDtJQUFnQixXQUFXLDBDQUEwQ2dCLGFBQWFoQixFQUFFSTtJQUFZLE1BQUs7Y0FDbkcsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsVUFBRDtPQUFRLFdBQVU7aUJBQWdCSixFQUFFUTtNQUFjOzs7O2dCQUNqRFIsRUFBRUssT0FDQTs7Ozs7ZUFDTCx3QkFBQyxVQUFEO01BQ0UsTUFBSztNQUNMLFdBQVU7TUFDVixjQUFXO01BQ1gsZUFBZVQsUUFBUUksRUFBRUgsRUFBRTtLQUFFOzs7O2FBRTVCOzs7Ozs7R0FDRixHQWJLRyxFQUFFSDs7OztVQWFQLENBQ047RUFDRTs7OztVQUNnQjs7Ozs7O0FBRTNCO0FBQUNMLEdBM0VlRixlQUFhO0FBQUEsS0FBYkE7QUE2RWhCLE9BQU8sU0FBUzhCLFdBQVc7Q0FBQUMsSUFBQTtDQUN6QixNQUFNQyxNQUFNdEMsV0FBV0ksWUFBWTtDQUNuQyxJQUFJLENBQUNrQyxLQUFLLE1BQU0sSUFBSUMsTUFBTSw4Q0FBOEM7Q0FDeEUsT0FBT0Q7QUFDVDtBQUFDRCxJQUplRCxVQUFRO0FBQUEsSUFBQUk7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJjcmVhdGVDb250ZXh0IiwidXNlQ2FsbGJhY2siLCJ1c2VDb250ZXh0IiwidXNlTWVtbyIsInVzZVJlZiIsInVzZVN0YXRlIiwiVG9hc3RDb250ZXh0IiwibmV4dElkIiwiVG9hc3RQcm92aWRlciIsImNoaWxkcmVuIiwiX3MiLCJ0b2FzdHMiLCJzZXRUb2FzdHMiLCJ0aW1lcnMiLCJkaXNtaXNzIiwiaWQiLCJsaXN0IiwiZmlsdGVyIiwidCIsImN1cnJlbnQiLCJjbGVhclRpbWVvdXQiLCJwdXNoIiwidmFyaWFudCIsIm1lc3NhZ2UiLCJvcHRpb25zIiwidG9hc3QiLCJ0aXRsZSIsImR1cmF0aW9uIiwic2xpY2UiLCJzZXRUaW1lb3V0Iiwic3VjY2VzcyIsImVycm9yIiwiaW5mbyIsIndhcm5pbmciLCJ2YXJpYW50Q2xhc3MiLCJ6SW5kZXgiLCJtYXhXaWR0aCIsIm1hcCIsInVzZVRvYXN0IiwiX3MyIiwiY3R4IiwiRXJyb3IiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJUb2FzdENvbnRleHQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyBjcmVhdGVDb250ZXh0LCB1c2VDYWxsYmFjaywgdXNlQ29udGV4dCwgdXNlTWVtbywgdXNlUmVmLCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuXG5jb25zdCBUb2FzdENvbnRleHQgPSBjcmVhdGVDb250ZXh0KG51bGwpO1xuXG5sZXQgbmV4dElkID0gMTtcblxuLyoqXG4gKiBCb290c3RyYXAtc3R5bGVkIHRvYXN0IG5vdGlmaWNhdGlvbnMuXG4gKiAgIGNvbnN0IHRvYXN0ID0gdXNlVG9hc3QoKTtcbiAqICAgdG9hc3Quc3VjY2VzcyhcIlJlY29yZCBjcmVhdGVkIHN1Y2Nlc3NmdWxseVwiKTtcbiAqICAgdG9hc3QuZXJyb3IoXCJVbmFibGUgdG8gc2F2ZSByZWNvcmRcIik7XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBUb2FzdFByb3ZpZGVyKHsgY2hpbGRyZW4gfSkge1xuICBjb25zdCBbdG9hc3RzLCBzZXRUb2FzdHNdID0gdXNlU3RhdGUoW10pO1xuICBjb25zdCB0aW1lcnMgPSB1c2VSZWYoe30pO1xuXG4gIGNvbnN0IGRpc21pc3MgPSB1c2VDYWxsYmFjaygoaWQpID0+IHtcbiAgICBzZXRUb2FzdHMoKGxpc3QpID0+IGxpc3QuZmlsdGVyKCh0KSA9PiB0LmlkICE9PSBpZCkpO1xuICAgIGlmICh0aW1lcnMuY3VycmVudFtpZF0pIHtcbiAgICAgIGNsZWFyVGltZW91dCh0aW1lcnMuY3VycmVudFtpZF0pO1xuICAgICAgZGVsZXRlIHRpbWVycy5jdXJyZW50W2lkXTtcbiAgICB9XG4gIH0sIFtdKTtcblxuICBjb25zdCBwdXNoID0gdXNlQ2FsbGJhY2soXG4gICAgKHZhcmlhbnQsIG1lc3NhZ2UsIG9wdGlvbnMgPSB7fSkgPT4ge1xuICAgICAgY29uc3QgaWQgPSBuZXh0SWQrKztcbiAgICAgIGNvbnN0IHRvYXN0ID0ge1xuICAgICAgICBpZCxcbiAgICAgICAgdmFyaWFudCxcbiAgICAgICAgbWVzc2FnZSxcbiAgICAgICAgdGl0bGU6IG9wdGlvbnMudGl0bGUgfHwgKHZhcmlhbnQgPT09IFwic3VjY2Vzc1wiID8gXCJTdWNjZXNzXCIgOiB2YXJpYW50ID09PSBcImVycm9yXCIgPyBcIkVycm9yXCIgOiBcIk5vdGljZVwiKSxcbiAgICAgICAgZHVyYXRpb246IG9wdGlvbnMuZHVyYXRpb24gPz8gNDUwMCxcbiAgICAgIH07XG4gICAgICBzZXRUb2FzdHMoKGxpc3QpID0+IFsuLi5saXN0LnNsaWNlKC00KSwgdG9hc3RdKTsgLy8ga2VlcCBtYXggNSB2aXNpYmxlXG4gICAgICB0aW1lcnMuY3VycmVudFtpZF0gPSBzZXRUaW1lb3V0KCgpID0+IGRpc21pc3MoaWQpLCB0b2FzdC5kdXJhdGlvbik7XG4gICAgICByZXR1cm4gaWQ7XG4gICAgfSxcbiAgICBbZGlzbWlzc11cbiAgKTtcblxuICBjb25zdCB0b2FzdCA9IHVzZU1lbW8oXG4gICAgKCkgPT4gKHtcbiAgICAgIHN1Y2Nlc3M6IChtZXNzYWdlLCBvcHRpb25zKSA9PiBwdXNoKFwic3VjY2Vzc1wiLCBtZXNzYWdlLCBvcHRpb25zKSxcbiAgICAgIGVycm9yOiAobWVzc2FnZSwgb3B0aW9ucykgPT4gcHVzaChcImVycm9yXCIsIG1lc3NhZ2UsIG9wdGlvbnMpLFxuICAgICAgaW5mbzogKG1lc3NhZ2UsIG9wdGlvbnMpID0+IHB1c2goXCJpbmZvXCIsIG1lc3NhZ2UsIG9wdGlvbnMpLFxuICAgICAgd2FybmluZzogKG1lc3NhZ2UsIG9wdGlvbnMpID0+IHB1c2goXCJ3YXJuaW5nXCIsIG1lc3NhZ2UsIG9wdGlvbnMpLFxuICAgICAgZGlzbWlzcyxcbiAgICB9KSxcbiAgICBbcHVzaCwgZGlzbWlzc11cbiAgKTtcblxuICBjb25zdCB2YXJpYW50Q2xhc3MgPSB7XG4gICAgc3VjY2VzczogXCJ0ZXh0LWJnLXN1Y2Nlc3NcIixcbiAgICBlcnJvcjogXCJ0ZXh0LWJnLWRhbmdlclwiLFxuICAgIGluZm86IFwidGV4dC1iZy1wcmltYXJ5XCIsXG4gICAgd2FybmluZzogXCJ0ZXh0LWJnLXdhcm5pbmdcIixcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxUb2FzdENvbnRleHQuUHJvdmlkZXIgdmFsdWU9e3RvYXN0fT5cbiAgICAgIHtjaGlsZHJlbn1cbiAgICAgIDxkaXZcbiAgICAgICAgY2xhc3NOYW1lPVwidG9hc3QtY29udGFpbmVyIHBvc2l0aW9uLWZpeGVkIHRvcC0wIGVuZC0wIHAtM1wiXG4gICAgICAgIHN0eWxlPXt7IHpJbmRleDogMTA5MCwgbWF4V2lkdGg6IDM4MCB9fVxuICAgICAgICBhcmlhLWxpdmU9XCJwb2xpdGVcIlxuICAgICAgICBhcmlhLWF0b21pYz1cInRydWVcIlxuICAgICAgPlxuICAgICAgICB7dG9hc3RzLm1hcCgodCkgPT4gKFxuICAgICAgICAgIDxkaXYga2V5PXt0LmlkfSBjbGFzc05hbWU9e2B0b2FzdCBzaG93IGFsaWduLWl0ZW1zLWNlbnRlciBib3JkZXItMCAke3ZhcmlhbnRDbGFzc1t0LnZhcmlhbnRdfWB9IHJvbGU9XCJhbGVydFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkLWZsZXhcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0b2FzdC1ib2R5XCI+XG4gICAgICAgICAgICAgICAgPHN0cm9uZyBjbGFzc05hbWU9XCJkLWJsb2NrIG1iLTFcIj57dC50aXRsZX08L3N0cm9uZz5cbiAgICAgICAgICAgICAgICB7dC5tZXNzYWdlfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJ0bi1jbG9zZSBidG4tY2xvc2Utd2hpdGUgbWUtMiBtLWF1dG9cIlxuICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJDbG9zZVwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gZGlzbWlzcyh0LmlkKX1cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApKX1cbiAgICAgIDwvZGl2PlxuICAgIDwvVG9hc3RDb250ZXh0LlByb3ZpZGVyPlxuICApO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gdXNlVG9hc3QoKSB7XG4gIGNvbnN0IGN0eCA9IHVzZUNvbnRleHQoVG9hc3RDb250ZXh0KTtcbiAgaWYgKCFjdHgpIHRocm93IG5ldyBFcnJvcihcInVzZVRvYXN0IG11c3QgYmUgdXNlZCBpbnNpZGUgPFRvYXN0UHJvdmlkZXI+XCIpO1xuICByZXR1cm4gY3R4O1xufVxuIl0sImZpbGUiOiJDOi9Vc2Vycy91c2VyL0Rvd25sb2Fkcy9kaGFuaXRpLWFwcC11cGdyYWRlZC9kaGFuaXRpLWFwcC9mcm9udGVuZC9zcmMvY29udGV4dC9Ub2FzdENvbnRleHQuanN4In0=