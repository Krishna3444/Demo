import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Profile.jsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport1_react_jsxDevRuntime["Fragment"];const React = __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"];import * as RefreshRuntime from "/@react-refresh";
var _jsxFileName = "C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/pages/Profile.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=325d36c7";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
	if (!window.$RefreshReg$) {
		throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong.");
	}
	prevRefreshReg = window.$RefreshReg$;
	prevRefreshSig = window.$RefreshSig$;
	window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/pages/Profile.jsx");
	window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=325d36c7";
import { authApi } from "/src/api/auth.js";
import { ApiError } from "/src/api/client.js";
import { useAuth } from "/src/context/AuthContext.jsx";
import { useToast } from "/src/context/ToastContext.jsx";
const PROVIDER_LABEL = {
	local: "Email & password",
	google: "Google",
	github: "GitHub"
};
export default function Profile() {
	_s();
	const { currentUser, refreshUser } = useAuth();
	const toast = useToast();
	const [profile, setProfile] = useState({
		name: currentUser?.name || "",
		avatarUrl: currentUser?.avatarUrl || ""
	});
	const [profileErrors, setProfileErrors] = useState({});
	const [profileError, setProfileError] = useState("");
	const [savingProfile, setSavingProfile] = useState(false);
	const [pw, setPw] = useState({
		currentPassword: "",
		newPassword: "",
		confirm: ""
	});
	const [pwErrors, setPwErrors] = useState({});
	const [pwError, setPwError] = useState("");
	const [savingPw, setSavingPw] = useState(false);
	if (!currentUser) return null;
	async function saveProfile(e) {
		e.preventDefault();
		setProfileError("");
		const errors = {};
		if (!profile.name.trim() || profile.name.trim().length < 2) errors.name = "Name must be at least 2 characters long.";
		if (profile.avatarUrl && !/^https?:\/\//.test(profile.avatarUrl.trim())) errors.avatarUrl = "Avatar URL must start with http:// or https://.";
		setProfileErrors(errors);
		if (Object.keys(errors).length) return;
		setSavingProfile(true);
		try {
			await authApi.updateProfile({
				name: profile.name.trim(),
				avatarUrl: profile.avatarUrl.trim()
			});
			await refreshUser();
			toast.success("Profile updated successfully.");
		} catch (err) {
			setProfileError(err instanceof ApiError && err.details?.length ? `${err.message} ${err.details.join(" ")}` : err.message);
		} finally {
			setSavingProfile(false);
		}
	}
	async function changePassword(e) {
		e.preventDefault();
		setPwError("");
		const errors = {};
		if (!pw.currentPassword) errors.currentPassword = "Current password is required.";
		if (!pw.newPassword || pw.newPassword.length < 8 || !/[A-Za-z]/.test(pw.newPassword) || !/\d/.test(pw.newPassword)) errors.newPassword = "New password needs 8+ characters with at least one letter and one number.";
		if (pw.confirm !== pw.newPassword) errors.confirm = "Passwords do not match.";
		setPwErrors(errors);
		if (Object.keys(errors).length) return;
		setSavingPw(true);
		try {
			await authApi.changePassword(pw.currentPassword, pw.newPassword);
			toast.success("Password changed successfully.");
			setPw({
				currentPassword: "",
				newPassword: "",
				confirm: ""
			});
		} catch (err) {
			setPwError(err.message);
		} finally {
			setSavingPw(false);
		}
	}
	const initials = (currentUser.name || "?").split(/\s+/).slice(0, 2).map((w) => w[0]).join("").toUpperCase();
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "container py-4",
		style: { maxWidth: 900 },
		children: [
			/* @__PURE__ */ _jsxDEV("h4", {
				className: "mb-1",
				children: "Profile"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 95,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "text-muted small",
				children: "Manage your account details and password."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 96,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "row g-4",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "col-12 col-lg-4",
					children: /* @__PURE__ */ _jsxDEV("div", {
						className: "card section-card h-100",
						children: /* @__PURE__ */ _jsxDEV("div", {
							className: "card-body text-center",
							children: [
								currentUser.avatarUrl ? /* @__PURE__ */ _jsxDEV("img", {
									src: currentUser.avatarUrl,
									alt: "Avatar",
									className: "rounded-circle mb-3",
									style: {
										width: 96,
										height: 96,
										objectFit: "cover"
									}
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 104,
									columnNumber: 15
								}, this) : /* @__PURE__ */ _jsxDEV("div", {
									className: "rounded-circle mx-auto mb-3 d-flex align-items-center justify-content-center bg-dhaniti text-white",
									style: {
										width: 96,
										height: 96,
										fontSize: 34,
										fontWeight: 700
									},
									children: initials
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 106,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("h5", {
									className: "mb-1",
									children: currentUser.name
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 113,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-muted small mb-2",
									children: currentUser.email
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 114,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "badge text-bg-dark",
									children: currentUser.role
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 115,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("hr", {}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 116,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("dl", {
									className: "text-start small mb-0",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "d-flex justify-content-between",
											children: [/* @__PURE__ */ _jsxDEV("dt", {
												className: "text-muted fw-normal",
												children: "Sign-in method"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 119,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("dd", {
												className: "mb-1",
												children: PROVIDER_LABEL[currentUser.oauthProvider] || currentUser.oauthProvider
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 120,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 118,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "d-flex justify-content-between",
											children: [/* @__PURE__ */ _jsxDEV("dt", {
												className: "text-muted fw-normal",
												children: "Email verified"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 123,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("dd", {
												className: "mb-1",
												children: currentUser.isVerified ? /* @__PURE__ */ _jsxDEV("span", {
													className: "text-success",
													children: [/* @__PURE__ */ _jsxDEV("i", {
														className: "bi bi-check-circle-fill me-1",
														"aria-hidden": "true"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 126,
														columnNumber: 52
													}, this), "Yes"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 126,
													columnNumber: 21
												}, this) : /* @__PURE__ */ _jsxDEV("span", {
													className: "text-warning",
													children: "Pending"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 128,
													columnNumber: 21
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 124,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 122,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "d-flex justify-content-between",
											children: [/* @__PURE__ */ _jsxDEV("dt", {
												className: "text-muted fw-normal",
												children: "User ID"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 133,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("dd", {
												className: "mb-0 font-monospace",
												style: { fontSize: "0.72rem" },
												children: currentUser.userId
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 134,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 132,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 117,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 102,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 101,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 100,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "col-12 col-lg-8",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "card section-card mb-4",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "card-header",
							children: "Edit profile"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 144,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "card-body",
							children: [profileError && /* @__PURE__ */ _jsxDEV("div", {
								className: "alert alert-danger py-2",
								children: profileError
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 146,
								columnNumber: 32
							}, this), /* @__PURE__ */ _jsxDEV("form", {
								onSubmit: saveProfile,
								noValidate: true,
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "mb-3",
										children: [
											/* @__PURE__ */ _jsxDEV("label", {
												htmlFor: "p-name",
												className: "form-label",
												children: "Full name"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 149,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("input", {
												id: "p-name",
												className: `form-control ${profileErrors.name ? "is-invalid" : ""}`,
												value: profile.name,
												onChange: (e) => setProfile((p) => ({
													...p,
													name: e.target.value
												})),
												disabled: savingProfile
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 150,
												columnNumber: 19
											}, this),
											profileErrors.name && /* @__PURE__ */ _jsxDEV("div", {
												className: "invalid-feedback",
												children: profileErrors.name
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 157,
												columnNumber: 42
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 148,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "mb-3",
										children: [
											/* @__PURE__ */ _jsxDEV("label", {
												htmlFor: "p-avatar",
												className: "form-label",
												children: ["Avatar URL ", /* @__PURE__ */ _jsxDEV("span", {
													className: "text-muted small",
													children: "(optional)"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 160,
													columnNumber: 79
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 160,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("input", {
												id: "p-avatar",
												className: `form-control ${profileErrors.avatarUrl ? "is-invalid" : ""}`,
												value: profile.avatarUrl,
												onChange: (e) => setProfile((p) => ({
													...p,
													avatarUrl: e.target.value
												})),
												placeholder: "https://…",
												disabled: savingProfile
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 161,
												columnNumber: 19
											}, this),
											profileErrors.avatarUrl && /* @__PURE__ */ _jsxDEV("div", {
												className: "invalid-feedback",
												children: profileErrors.avatarUrl
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 169,
												columnNumber: 47
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 159,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										className: "btn btn-dhaniti",
										disabled: savingProfile,
										children: savingProfile ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "spinner-border spinner-border-sm me-2",
											role: "status",
											"aria-hidden": "true"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 174,
											columnNumber: 23
										}, this), "Saving…"] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 173,
											columnNumber: 19
										}, this) : "Save changes"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 171,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 147,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 145,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 143,
						columnNumber: 11
					}, this), currentUser.hasPassword !== false && /* @__PURE__ */ _jsxDEV("div", {
						className: "card section-card",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "card-header",
							children: "Change password"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 185,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "card-body",
							children: [pwError && /* @__PURE__ */ _jsxDEV("div", {
								className: "alert alert-danger py-2",
								children: pwError
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 187,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("form", {
								onSubmit: changePassword,
								noValidate: true,
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "mb-3",
										children: [
											/* @__PURE__ */ _jsxDEV("label", {
												htmlFor: "cp-current",
												className: "form-label",
												children: "Current password"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 190,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("input", {
												type: "password",
												id: "cp-current",
												className: `form-control ${pwErrors.currentPassword ? "is-invalid" : ""}`,
												value: pw.currentPassword,
												onChange: (e) => setPw((p) => ({
													...p,
													currentPassword: e.target.value
												})),
												autoComplete: "current-password",
												disabled: savingPw
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 191,
												columnNumber: 21
											}, this),
											pwErrors.currentPassword && /* @__PURE__ */ _jsxDEV("div", {
												className: "invalid-feedback",
												children: pwErrors.currentPassword
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 200,
												columnNumber: 50
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 189,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "row",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "col-12 col-md-6 mb-3",
											children: [
												/* @__PURE__ */ _jsxDEV("label", {
													htmlFor: "cp-new",
													className: "form-label",
													children: "New password"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 204,
													columnNumber: 23
												}, this),
												/* @__PURE__ */ _jsxDEV("input", {
													type: "password",
													id: "cp-new",
													className: `form-control ${pwErrors.newPassword ? "is-invalid" : ""}`,
													value: pw.newPassword,
													onChange: (e) => setPw((p) => ({
														...p,
														newPassword: e.target.value
													})),
													autoComplete: "new-password",
													disabled: savingPw
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 205,
													columnNumber: 23
												}, this),
												pwErrors.newPassword && /* @__PURE__ */ _jsxDEV("div", {
													className: "invalid-feedback",
													children: pwErrors.newPassword
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 214,
													columnNumber: 48
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 203,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "col-12 col-md-6 mb-3",
											children: [
												/* @__PURE__ */ _jsxDEV("label", {
													htmlFor: "cp-confirm",
													className: "form-label",
													children: "Confirm new password"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 217,
													columnNumber: 23
												}, this),
												/* @__PURE__ */ _jsxDEV("input", {
													type: "password",
													id: "cp-confirm",
													className: `form-control ${pwErrors.confirm ? "is-invalid" : ""}`,
													value: pw.confirm,
													onChange: (e) => setPw((p) => ({
														...p,
														confirm: e.target.value
													})),
													autoComplete: "new-password",
													disabled: savingPw
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 218,
													columnNumber: 23
												}, this),
												pwErrors.confirm && /* @__PURE__ */ _jsxDEV("div", {
													className: "invalid-feedback",
													children: pwErrors.confirm
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 227,
													columnNumber: 44
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 216,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 202,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										className: "btn btn-outline-dhaniti",
										disabled: savingPw,
										children: savingPw ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "spinner-border spinner-border-sm me-2",
											role: "status",
											"aria-hidden": "true"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 233,
											columnNumber: 25
										}, this), "Updating…"] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 232,
											columnNumber: 19
										}, this) : "Update password"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 230,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 188,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 186,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 184,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 142,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 98,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 94,
		columnNumber: 5
	}, this);
}
_s(Profile, "J/fVRtYMXBRz5H9AR0LivqW4yG0=", false, function() {
	return [useAuth, useToast];
});
_c = Profile;
var _c;
$RefreshReg$(_c, "Profile");
if (import.meta.hot && !inWebWorker) {
	window.$RefreshReg$ = prevRefreshReg;
	window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
	RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
		RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/pages/Profile.jsx", currentExports);
		import.meta.hot.accept((nextExports) => {
			if (!nextExports) return;
			const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/pages/Profile.jsx", currentExports, nextExports);
			if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
		});
	});
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLE9BQU9BLFNBQVNDLGdCQUFnQjtBQUNoQyxTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLGdCQUFnQjtBQUV6QixNQUFNQyxpQkFBaUI7Q0FBRUMsT0FBTztDQUFvQkMsUUFBUTtDQUFVQyxRQUFRO0FBQVM7QUFFdkYsZUFBZSxTQUFTQyxVQUFVO0NBQUFDLEdBQUE7Q0FDaEMsTUFBTSxFQUFFQyxhQUFhQyxnQkFBZ0JULFFBQVE7Q0FDN0MsTUFBTVUsUUFBUVQsU0FBUztDQUV2QixNQUFNLENBQUNVLFNBQVNDLGNBQWNmLFNBQVM7RUFDckNnQixNQUFNTCxhQUFhSyxRQUFRO0VBQzNCQyxXQUFXTixhQUFhTSxhQUFhO0NBQ3ZDLENBQUM7Q0FDRCxNQUFNLENBQUNDLGVBQWVDLG9CQUFvQm5CLFNBQVMsQ0FBQyxDQUFDO0NBQ3JELE1BQU0sQ0FBQ29CLGNBQWNDLG1CQUFtQnJCLFNBQVMsRUFBRTtDQUNuRCxNQUFNLENBQUNzQixlQUFlQyxvQkFBb0J2QixTQUFTLEtBQUs7Q0FFeEQsTUFBTSxDQUFDd0IsSUFBSUMsU0FBU3pCLFNBQVM7RUFBRTBCLGlCQUFpQjtFQUFJQyxhQUFhO0VBQUlDLFNBQVM7Q0FBRyxDQUFDO0NBQ2xGLE1BQU0sQ0FBQ0MsVUFBVUMsZUFBZTlCLFNBQVMsQ0FBQyxDQUFDO0NBQzNDLE1BQU0sQ0FBQytCLFNBQVNDLGNBQWNoQyxTQUFTLEVBQUU7Q0FDekMsTUFBTSxDQUFDaUMsVUFBVUMsZUFBZWxDLFNBQVMsS0FBSztDQUU5QyxJQUFJLENBQUNXLGFBQWEsT0FBTztDQUV6QixlQUFld0IsWUFBWUMsR0FBRztFQUM1QkEsRUFBRUMsZUFBZTtFQUNqQmhCLGdCQUFnQixFQUFFO0VBQ2xCLE1BQU1pQixTQUFTLENBQUM7RUFDaEIsSUFBSSxDQUFDeEIsUUFBUUUsS0FBS3VCLEtBQUssS0FBS3pCLFFBQVFFLEtBQUt1QixLQUFLLENBQUMsQ0FBQ0MsU0FBUyxHQUFHRixPQUFPdEIsT0FBTztFQUMxRSxJQUFJRixRQUFRRyxhQUFhLENBQUMsZUFBZXdCLEtBQUszQixRQUFRRyxVQUFVc0IsS0FBSyxDQUFDLEdBQUdELE9BQU9yQixZQUFZO0VBQzVGRSxpQkFBaUJtQixNQUFNO0VBQ3ZCLElBQUlJLE9BQU9DLEtBQUtMLE1BQU0sQ0FBQyxDQUFDRSxRQUFRO0VBRWhDakIsaUJBQWlCLElBQUk7RUFDckIsSUFBSTtHQUNGLE1BQU10QixRQUFRMkMsY0FBYztJQUFFNUIsTUFBTUYsUUFBUUUsS0FBS3VCLEtBQUs7SUFBR3RCLFdBQVdILFFBQVFHLFVBQVVzQixLQUFLO0dBQUUsQ0FBQztHQUM5RixNQUFNM0IsWUFBWTtHQUNsQkMsTUFBTWdDLFFBQVEsK0JBQStCO0VBQy9DLFNBQVNDLEtBQUs7R0FDWnpCLGdCQUFnQnlCLGVBQWU1QyxZQUFZNEMsSUFBSUMsU0FBU1AsU0FBUyxHQUFHTSxJQUFJRSxRQUFPLEdBQUlGLElBQUlDLFFBQVFFLEtBQUssR0FBRyxNQUFNSCxJQUFJRSxPQUFPO0VBQzFILFVBQVU7R0FDUnpCLGlCQUFpQixLQUFLO0VBQ3hCO0NBQ0Y7Q0FFQSxlQUFlMkIsZUFBZWQsR0FBRztFQUMvQkEsRUFBRUMsZUFBZTtFQUNqQkwsV0FBVyxFQUFFO0VBQ2IsTUFBTU0sU0FBUyxDQUFDO0VBQ2hCLElBQUksQ0FBQ2QsR0FBR0UsaUJBQWlCWSxPQUFPWixrQkFBa0I7RUFDbEQsSUFBSSxDQUFDRixHQUFHRyxlQUFlSCxHQUFHRyxZQUFZYSxTQUFTLEtBQUssQ0FBQyxXQUFXQyxLQUFLakIsR0FBR0csV0FBVyxLQUFLLENBQUMsS0FBS2MsS0FBS2pCLEdBQUdHLFdBQVcsR0FDL0dXLE9BQU9YLGNBQWM7RUFDdkIsSUFBSUgsR0FBR0ksWUFBWUosR0FBR0csYUFBYVcsT0FBT1YsVUFBVTtFQUNwREUsWUFBWVEsTUFBTTtFQUNsQixJQUFJSSxPQUFPQyxLQUFLTCxNQUFNLENBQUMsQ0FBQ0UsUUFBUTtFQUVoQ04sWUFBWSxJQUFJO0VBQ2hCLElBQUk7R0FDRixNQUFNakMsUUFBUWlELGVBQWUxQixHQUFHRSxpQkFBaUJGLEdBQUdHLFdBQVc7R0FDL0RkLE1BQU1nQyxRQUFRLGdDQUFnQztHQUM5Q3BCLE1BQU07SUFBRUMsaUJBQWlCO0lBQUlDLGFBQWE7SUFBSUMsU0FBUztHQUFHLENBQUM7RUFDN0QsU0FBU2tCLEtBQUs7R0FDWmQsV0FBV2MsSUFBSUUsT0FBTztFQUN4QixVQUFVO0dBQ1JkLFlBQVksS0FBSztFQUNuQjtDQUNGO0NBRUEsTUFBTWlCLFlBQVl4QyxZQUFZSyxRQUFRLElBQUcsQ0FBRW9DLE1BQU0sS0FBSyxDQUFDLENBQUNDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQ0MsS0FBS0MsTUFBTUEsRUFBRSxFQUFFLENBQUMsQ0FBQ04sS0FBSyxFQUFFLENBQUMsQ0FBQ08sWUFBWTtDQUUxRyxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO0VBQWlCLE9BQU8sRUFBRUMsVUFBVSxJQUFJO1lBQXZEO0dBQ0Usd0JBQUMsTUFBRDtJQUFJLFdBQVU7Y0FBTztHQUFXOzs7OztHQUNoQyx3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUFtQjtHQUE0Qzs7Ozs7R0FFNUUsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUVFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ2Isd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRzlDLFlBQVlNLFlBQ1gsd0JBQUMsT0FBRDtTQUFLLEtBQUtOLFlBQVlNO1NBQVcsS0FBSTtTQUFTLFdBQVU7U0FBc0IsT0FBTztVQUFFeUMsT0FBTztVQUFJQyxRQUFRO1VBQUlDLFdBQVc7U0FBUTtRQUFFOzs7O21CQUVuSSx3QkFBQyxPQUFEO1NBQ0UsV0FBVTtTQUNWLE9BQU87VUFBRUYsT0FBTztVQUFJQyxRQUFRO1VBQUlFLFVBQVU7VUFBSUMsWUFBWTtTQUFJO21CQUU3RFg7UUFDRTs7Ozs7UUFFUCx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBUXhDLFlBQVlLO1FBQVM7Ozs7O1FBQzNDLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUF5QkwsWUFBWW9EO1FBQVM7Ozs7O1FBQzNELHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFzQnBELFlBQVlxRDtRQUFXOzs7OztRQUM3RCx3QkFBQyxNQUFELENBQUc7Ozs7O1FBQ0gsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQWQ7VUFDRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUF1QjtXQUFrQjs7OztxQkFDdkQsd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQVEzRCxlQUFlTSxZQUFZc0Qsa0JBQWtCdEQsWUFBWXNEO1dBQWtCOzs7O21CQUM5Rjs7Ozs7O1VBQ0wsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBdUI7V0FBa0I7Ozs7cUJBQ3ZELHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUNYdEQsWUFBWXVELGFBQ1gsd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQWhCLENBQStCLHdCQUFDLEtBQUQ7Y0FBRyxXQUFVO2NBQStCLGVBQVk7YUFBTTs7Ozt1QkFBRyxLQUFTOzs7Ozt1QkFFekcsd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQWU7WUFBYTs7Ozs7V0FFNUM7Ozs7bUJBQ0Q7Ozs7OztVQUNMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQXVCO1dBQVc7Ozs7cUJBQ2hELHdCQUFDLE1BQUQ7WUFBSSxXQUFVO1lBQXNCLE9BQU8sRUFBRUwsVUFBVSxVQUFVO3NCQUFJbEQsWUFBWXdEO1dBQVc7Ozs7bUJBQ3pGOzs7Ozs7U0FDSDs7Ozs7O09BQ0Q7Ozs7OztLQUNGOzs7OztJQUNGOzs7O2NBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWM7TUFBaUI7Ozs7Z0JBQzlDLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0cvQyxnQkFBZ0Isd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQTJCQTtPQUFrQjs7OztpQkFDN0Usd0JBQUMsUUFBRDtRQUFNLFVBQVVlO1FBQWE7a0JBQTdCO1NBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWY7V0FDRSx3QkFBQyxTQUFEO1lBQU8sU0FBUTtZQUFTLFdBQVU7c0JBQWE7V0FBZ0I7Ozs7O1dBQy9ELHdCQUFDLFNBQUQ7WUFDRSxJQUFHO1lBQ0gsV0FBVyxnQkFBZ0JqQixjQUFjRixPQUFPLGVBQWU7WUFDL0QsT0FBT0YsUUFBUUU7WUFDZixXQUFXb0IsTUFBTXJCLFlBQVlxRCxPQUFPO2FBQUUsR0FBR0E7YUFBR3BELE1BQU1vQixFQUFFaUMsT0FBT0M7WUFBTSxFQUFFO1lBQ25FLFVBQVVoRDtXQUFjOzs7OztXQUV6QkosY0FBY0YsUUFBUSx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBb0JFLGNBQWNGO1dBQVU7Ozs7O1VBQy9FOzs7Ozs7U0FDTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZjtXQUNFLHdCQUFDLFNBQUQ7WUFBTyxTQUFRO1lBQVcsV0FBVTtzQkFBcEMsQ0FBaUQsZUFBVyx3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBbUI7WUFBZ0I7Ozs7b0JBQVE7Ozs7OztXQUN2SCx3QkFBQyxTQUFEO1lBQ0UsSUFBRztZQUNILFdBQVcsZ0JBQWdCRSxjQUFjRCxZQUFZLGVBQWU7WUFDcEUsT0FBT0gsUUFBUUc7WUFDZixXQUFXbUIsTUFBTXJCLFlBQVlxRCxPQUFPO2FBQUUsR0FBR0E7YUFBR25ELFdBQVdtQixFQUFFaUMsT0FBT0M7WUFBTSxFQUFFO1lBQ3hFLGFBQVk7WUFDWixVQUFVaEQ7V0FBYzs7Ozs7V0FFekJKLGNBQWNELGFBQWEsd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQW9CQyxjQUFjRDtXQUFlOzs7OztVQUN6Rjs7Ozs7O1NBQ0wsd0JBQUMsVUFBRDtVQUFRLFdBQVU7VUFBa0IsVUFBVUs7b0JBQzNDQSxnQkFDQyxnREFDRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtXQUF3QyxNQUFLO1dBQVMsZUFBWTtVQUFNOzs7O29CQUFBLFNBRTFGOzs7O3FCQUNFO1NBQ0U7Ozs7O1FBQ0o7Ozs7O2VBQ0g7Ozs7O2NBQ0Y7Ozs7O2VBRUpYLFlBQVk0RCxnQkFBZ0IsU0FDM0Isd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBYztNQUFvQjs7OztnQkFDakQsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDR3hDLFdBQVcsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQTJCQTtPQUFhOzs7O2lCQUNuRSx3QkFBQyxRQUFEO1FBQU0sVUFBVW1CO1FBQWdCO2tCQUFoQztTQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmO1dBQ0Usd0JBQUMsU0FBRDtZQUFPLFNBQVE7WUFBYSxXQUFVO3NCQUFhO1dBQXVCOzs7OztXQUMxRSx3QkFBQyxTQUFEO1lBQ0UsTUFBSztZQUNMLElBQUc7WUFDSCxXQUFXLGdCQUFnQnJCLFNBQVNILGtCQUFrQixlQUFlO1lBQ3JFLE9BQU9GLEdBQUdFO1lBQ1YsV0FBV1UsTUFBTVgsT0FBTzJDLE9BQU87YUFBRSxHQUFHQTthQUFHMUMsaUJBQWlCVSxFQUFFaUMsT0FBT0M7WUFBTSxFQUFFO1lBQ3pFLGNBQWE7WUFDYixVQUFVckM7V0FBUzs7Ozs7V0FFcEJKLFNBQVNILG1CQUFtQix3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBb0JHLFNBQVNIO1dBQXFCOzs7OztVQUMzRjs7Ozs7O1NBQ0wsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZjtZQUNFLHdCQUFDLFNBQUQ7YUFBTyxTQUFRO2FBQVMsV0FBVTt1QkFBYTtZQUFtQjs7Ozs7WUFDbEUsd0JBQUMsU0FBRDthQUNFLE1BQUs7YUFDTCxJQUFHO2FBQ0gsV0FBVyxnQkFBZ0JHLFNBQVNGLGNBQWMsZUFBZTthQUNqRSxPQUFPSCxHQUFHRzthQUNWLFdBQVdTLE1BQU1YLE9BQU8yQyxPQUFPO2NBQUUsR0FBR0E7Y0FBR3pDLGFBQWFTLEVBQUVpQyxPQUFPQzthQUFNLEVBQUU7YUFDckUsY0FBYTthQUNiLFVBQVVyQztZQUFTOzs7OztZQUVwQkosU0FBU0YsZUFBZSx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBb0JFLFNBQVNGO1lBQWlCOzs7OztXQUNuRjs7Ozs7b0JBQ0wsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWY7WUFDRSx3QkFBQyxTQUFEO2FBQU8sU0FBUTthQUFhLFdBQVU7dUJBQWE7WUFBMkI7Ozs7O1lBQzlFLHdCQUFDLFNBQUQ7YUFDRSxNQUFLO2FBQ0wsSUFBRzthQUNILFdBQVcsZ0JBQWdCRSxTQUFTRCxVQUFVLGVBQWU7YUFDN0QsT0FBT0osR0FBR0k7YUFDVixXQUFXUSxNQUFNWCxPQUFPMkMsT0FBTztjQUFFLEdBQUdBO2NBQUd4QyxTQUFTUSxFQUFFaUMsT0FBT0M7YUFBTSxFQUFFO2FBQ2pFLGNBQWE7YUFDYixVQUFVckM7WUFBUzs7Ozs7WUFFcEJKLFNBQVNELFdBQVcsd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQW9CQyxTQUFTRDtZQUFhOzs7OztXQUMzRTs7Ozs7a0JBQ0Y7Ozs7OztTQUNMLHdCQUFDLFVBQUQ7VUFBUSxXQUFVO1VBQTBCLFVBQVVLO29CQUNuREEsV0FDQyxnREFDRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtXQUF3QyxNQUFLO1dBQVMsZUFBWTtVQUFNOzs7O29CQUFBLFdBRTFGOzs7O3FCQUNFO1NBQ0U7Ozs7O1FBQ0o7Ozs7O2VBQ0g7Ozs7O2NBQ0Y7Ozs7O2FBRUo7Ozs7O1lBQ0Y7Ozs7OztFQUNGOzs7Ozs7QUFFVDtBQUFDdkIsR0ExTnVCRCxTQUFPO0NBQUEsUUFDUU4sU0FDdkJDLFFBQVE7QUFBQTtBQUFBLEtBRkFLO0FBQU8sSUFBQStEO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwidXNlU3RhdGUiLCJhdXRoQXBpIiwiQXBpRXJyb3IiLCJ1c2VBdXRoIiwidXNlVG9hc3QiLCJQUk9WSURFUl9MQUJFTCIsImxvY2FsIiwiZ29vZ2xlIiwiZ2l0aHViIiwiUHJvZmlsZSIsIl9zIiwiY3VycmVudFVzZXIiLCJyZWZyZXNoVXNlciIsInRvYXN0IiwicHJvZmlsZSIsInNldFByb2ZpbGUiLCJuYW1lIiwiYXZhdGFyVXJsIiwicHJvZmlsZUVycm9ycyIsInNldFByb2ZpbGVFcnJvcnMiLCJwcm9maWxlRXJyb3IiLCJzZXRQcm9maWxlRXJyb3IiLCJzYXZpbmdQcm9maWxlIiwic2V0U2F2aW5nUHJvZmlsZSIsInB3Iiwic2V0UHciLCJjdXJyZW50UGFzc3dvcmQiLCJuZXdQYXNzd29yZCIsImNvbmZpcm0iLCJwd0Vycm9ycyIsInNldFB3RXJyb3JzIiwicHdFcnJvciIsInNldFB3RXJyb3IiLCJzYXZpbmdQdyIsInNldFNhdmluZ1B3Iiwic2F2ZVByb2ZpbGUiLCJlIiwicHJldmVudERlZmF1bHQiLCJlcnJvcnMiLCJ0cmltIiwibGVuZ3RoIiwidGVzdCIsIk9iamVjdCIsImtleXMiLCJ1cGRhdGVQcm9maWxlIiwic3VjY2VzcyIsImVyciIsImRldGFpbHMiLCJtZXNzYWdlIiwiam9pbiIsImNoYW5nZVBhc3N3b3JkIiwiaW5pdGlhbHMiLCJzcGxpdCIsInNsaWNlIiwibWFwIiwidyIsInRvVXBwZXJDYXNlIiwibWF4V2lkdGgiLCJ3aWR0aCIsImhlaWdodCIsIm9iamVjdEZpdCIsImZvbnRTaXplIiwiZm9udFdlaWdodCIsImVtYWlsIiwicm9sZSIsIm9hdXRoUHJvdmlkZXIiLCJpc1ZlcmlmaWVkIiwidXNlcklkIiwicCIsInRhcmdldCIsInZhbHVlIiwiaGFzUGFzc3dvcmQiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQcm9maWxlLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGF1dGhBcGkgfSBmcm9tIFwiLi4vYXBpL2F1dGguanNcIjtcbmltcG9ydCB7IEFwaUVycm9yIH0gZnJvbSBcIi4uL2FwaS9jbGllbnQuanNcIjtcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tIFwiLi4vY29udGV4dC9BdXRoQ29udGV4dC5qc3hcIjtcbmltcG9ydCB7IHVzZVRvYXN0IH0gZnJvbSBcIi4uL2NvbnRleHQvVG9hc3RDb250ZXh0LmpzeFwiO1xuXG5jb25zdCBQUk9WSURFUl9MQUJFTCA9IHsgbG9jYWw6IFwiRW1haWwgJiBwYXNzd29yZFwiLCBnb29nbGU6IFwiR29vZ2xlXCIsIGdpdGh1YjogXCJHaXRIdWJcIiB9O1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBQcm9maWxlKCkge1xuICBjb25zdCB7IGN1cnJlbnRVc2VyLCByZWZyZXNoVXNlciB9ID0gdXNlQXV0aCgpO1xuICBjb25zdCB0b2FzdCA9IHVzZVRvYXN0KCk7XG5cbiAgY29uc3QgW3Byb2ZpbGUsIHNldFByb2ZpbGVdID0gdXNlU3RhdGUoe1xuICAgIG5hbWU6IGN1cnJlbnRVc2VyPy5uYW1lIHx8IFwiXCIsXG4gICAgYXZhdGFyVXJsOiBjdXJyZW50VXNlcj8uYXZhdGFyVXJsIHx8IFwiXCIsXG4gIH0pO1xuICBjb25zdCBbcHJvZmlsZUVycm9ycywgc2V0UHJvZmlsZUVycm9yc10gPSB1c2VTdGF0ZSh7fSk7XG4gIGNvbnN0IFtwcm9maWxlRXJyb3IsIHNldFByb2ZpbGVFcnJvcl0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW3NhdmluZ1Byb2ZpbGUsIHNldFNhdmluZ1Byb2ZpbGVdID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIGNvbnN0IFtwdywgc2V0UHddID0gdXNlU3RhdGUoeyBjdXJyZW50UGFzc3dvcmQ6IFwiXCIsIG5ld1Bhc3N3b3JkOiBcIlwiLCBjb25maXJtOiBcIlwiIH0pO1xuICBjb25zdCBbcHdFcnJvcnMsIHNldFB3RXJyb3JzXSA9IHVzZVN0YXRlKHt9KTtcbiAgY29uc3QgW3B3RXJyb3IsIHNldFB3RXJyb3JdID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFtzYXZpbmdQdywgc2V0U2F2aW5nUHddID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIGlmICghY3VycmVudFVzZXIpIHJldHVybiBudWxsO1xuXG4gIGFzeW5jIGZ1bmN0aW9uIHNhdmVQcm9maWxlKGUpIHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgc2V0UHJvZmlsZUVycm9yKFwiXCIpO1xuICAgIGNvbnN0IGVycm9ycyA9IHt9O1xuICAgIGlmICghcHJvZmlsZS5uYW1lLnRyaW0oKSB8fCBwcm9maWxlLm5hbWUudHJpbSgpLmxlbmd0aCA8IDIpIGVycm9ycy5uYW1lID0gXCJOYW1lIG11c3QgYmUgYXQgbGVhc3QgMiBjaGFyYWN0ZXJzIGxvbmcuXCI7XG4gICAgaWYgKHByb2ZpbGUuYXZhdGFyVXJsICYmICEvXmh0dHBzPzpcXC9cXC8vLnRlc3QocHJvZmlsZS5hdmF0YXJVcmwudHJpbSgpKSkgZXJyb3JzLmF2YXRhclVybCA9IFwiQXZhdGFyIFVSTCBtdXN0IHN0YXJ0IHdpdGggaHR0cDovLyBvciBodHRwczovLy5cIjtcbiAgICBzZXRQcm9maWxlRXJyb3JzKGVycm9ycyk7XG4gICAgaWYgKE9iamVjdC5rZXlzKGVycm9ycykubGVuZ3RoKSByZXR1cm47XG5cbiAgICBzZXRTYXZpbmdQcm9maWxlKHRydWUpO1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBhdXRoQXBpLnVwZGF0ZVByb2ZpbGUoeyBuYW1lOiBwcm9maWxlLm5hbWUudHJpbSgpLCBhdmF0YXJVcmw6IHByb2ZpbGUuYXZhdGFyVXJsLnRyaW0oKSB9KTtcbiAgICAgIGF3YWl0IHJlZnJlc2hVc2VyKCk7XG4gICAgICB0b2FzdC5zdWNjZXNzKFwiUHJvZmlsZSB1cGRhdGVkIHN1Y2Nlc3NmdWxseS5cIik7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBzZXRQcm9maWxlRXJyb3IoZXJyIGluc3RhbmNlb2YgQXBpRXJyb3IgJiYgZXJyLmRldGFpbHM/Lmxlbmd0aCA/IGAke2Vyci5tZXNzYWdlfSAke2Vyci5kZXRhaWxzLmpvaW4oXCIgXCIpfWAgOiBlcnIubWVzc2FnZSk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldFNhdmluZ1Byb2ZpbGUoZmFsc2UpO1xuICAgIH1cbiAgfVxuXG4gIGFzeW5jIGZ1bmN0aW9uIGNoYW5nZVBhc3N3b3JkKGUpIHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgc2V0UHdFcnJvcihcIlwiKTtcbiAgICBjb25zdCBlcnJvcnMgPSB7fTtcbiAgICBpZiAoIXB3LmN1cnJlbnRQYXNzd29yZCkgZXJyb3JzLmN1cnJlbnRQYXNzd29yZCA9IFwiQ3VycmVudCBwYXNzd29yZCBpcyByZXF1aXJlZC5cIjtcbiAgICBpZiAoIXB3Lm5ld1Bhc3N3b3JkIHx8IHB3Lm5ld1Bhc3N3b3JkLmxlbmd0aCA8IDggfHwgIS9bQS1aYS16XS8udGVzdChwdy5uZXdQYXNzd29yZCkgfHwgIS9cXGQvLnRlc3QocHcubmV3UGFzc3dvcmQpKVxuICAgICAgZXJyb3JzLm5ld1Bhc3N3b3JkID0gXCJOZXcgcGFzc3dvcmQgbmVlZHMgOCsgY2hhcmFjdGVycyB3aXRoIGF0IGxlYXN0IG9uZSBsZXR0ZXIgYW5kIG9uZSBudW1iZXIuXCI7XG4gICAgaWYgKHB3LmNvbmZpcm0gIT09IHB3Lm5ld1Bhc3N3b3JkKSBlcnJvcnMuY29uZmlybSA9IFwiUGFzc3dvcmRzIGRvIG5vdCBtYXRjaC5cIjtcbiAgICBzZXRQd0Vycm9ycyhlcnJvcnMpO1xuICAgIGlmIChPYmplY3Qua2V5cyhlcnJvcnMpLmxlbmd0aCkgcmV0dXJuO1xuXG4gICAgc2V0U2F2aW5nUHcodHJ1ZSk7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGF1dGhBcGkuY2hhbmdlUGFzc3dvcmQocHcuY3VycmVudFBhc3N3b3JkLCBwdy5uZXdQYXNzd29yZCk7XG4gICAgICB0b2FzdC5zdWNjZXNzKFwiUGFzc3dvcmQgY2hhbmdlZCBzdWNjZXNzZnVsbHkuXCIpO1xuICAgICAgc2V0UHcoeyBjdXJyZW50UGFzc3dvcmQ6IFwiXCIsIG5ld1Bhc3N3b3JkOiBcIlwiLCBjb25maXJtOiBcIlwiIH0pO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgc2V0UHdFcnJvcihlcnIubWVzc2FnZSk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldFNhdmluZ1B3KGZhbHNlKTtcbiAgICB9XG4gIH1cblxuICBjb25zdCBpbml0aWFscyA9IChjdXJyZW50VXNlci5uYW1lIHx8IFwiP1wiKS5zcGxpdCgvXFxzKy8pLnNsaWNlKDAsIDIpLm1hcCgodykgPT4gd1swXSkuam9pbihcIlwiKS50b1VwcGVyQ2FzZSgpO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWluZXIgcHktNFwiIHN0eWxlPXt7IG1heFdpZHRoOiA5MDAgfX0+XG4gICAgICA8aDQgY2xhc3NOYW1lPVwibWItMVwiPlByb2ZpbGU8L2g0PlxuICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1tdXRlZCBzbWFsbFwiPk1hbmFnZSB5b3VyIGFjY291bnQgZGV0YWlscyBhbmQgcGFzc3dvcmQuPC9wPlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdyBnLTRcIj5cbiAgICAgICAgey8qIElkZW50aXR5IGNhcmQgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLTEyIGNvbC1sZy00XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkIHNlY3Rpb24tY2FyZCBoLTEwMFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkLWJvZHkgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgICAge2N1cnJlbnRVc2VyLmF2YXRhclVybCA/IChcbiAgICAgICAgICAgICAgICA8aW1nIHNyYz17Y3VycmVudFVzZXIuYXZhdGFyVXJsfSBhbHQ9XCJBdmF0YXJcIiBjbGFzc05hbWU9XCJyb3VuZGVkLWNpcmNsZSBtYi0zXCIgc3R5bGU9e3sgd2lkdGg6IDk2LCBoZWlnaHQ6IDk2LCBvYmplY3RGaXQ6IFwiY292ZXJcIiB9fSAvPlxuICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtY2lyY2xlIG14LWF1dG8gbWItMyBkLWZsZXggYWxpZ24taXRlbXMtY2VudGVyIGp1c3RpZnktY29udGVudC1jZW50ZXIgYmctZGhhbml0aSB0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiA5NiwgaGVpZ2h0OiA5NiwgZm9udFNpemU6IDM0LCBmb250V2VpZ2h0OiA3MDAgfX1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICB7aW5pdGlhbHN9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDxoNSBjbGFzc05hbWU9XCJtYi0xXCI+e2N1cnJlbnRVc2VyLm5hbWV9PC9oNT5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1tdXRlZCBzbWFsbCBtYi0yXCI+e2N1cnJlbnRVc2VyLmVtYWlsfTwvcD5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmFkZ2UgdGV4dC1iZy1kYXJrXCI+e2N1cnJlbnRVc2VyLnJvbGV9PC9zcGFuPlxuICAgICAgICAgICAgICA8aHIgLz5cbiAgICAgICAgICAgICAgPGRsIGNsYXNzTmFtZT1cInRleHQtc3RhcnQgc21hbGwgbWItMFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZC1mbGV4IGp1c3RpZnktY29udGVudC1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPVwidGV4dC1tdXRlZCBmdy1ub3JtYWxcIj5TaWduLWluIG1ldGhvZDwvZHQ+XG4gICAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwibWItMVwiPntQUk9WSURFUl9MQUJFTFtjdXJyZW50VXNlci5vYXV0aFByb3ZpZGVyXSB8fCBjdXJyZW50VXNlci5vYXV0aFByb3ZpZGVyfTwvZGQ+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkLWZsZXgganVzdGlmeS1jb250ZW50LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9XCJ0ZXh0LW11dGVkIGZ3LW5vcm1hbFwiPkVtYWlsIHZlcmlmaWVkPC9kdD5cbiAgICAgICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJtYi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIHtjdXJyZW50VXNlci5pc1ZlcmlmaWVkID8gKFxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc3VjY2Vzc1wiPjxpIGNsYXNzTmFtZT1cImJpIGJpLWNoZWNrLWNpcmNsZS1maWxsIG1lLTFcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlllczwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXdhcm5pbmdcIj5QZW5kaW5nPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPC9kZD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImQtZmxleCBqdXN0aWZ5LWNvbnRlbnQtYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT1cInRleHQtbXV0ZWQgZnctbm9ybWFsXCI+VXNlciBJRDwvZHQ+XG4gICAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwibWItMCBmb250LW1vbm9zcGFjZVwiIHN0eWxlPXt7IGZvbnRTaXplOiBcIjAuNzJyZW1cIiB9fT57Y3VycmVudFVzZXIudXNlcklkfTwvZGQ+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGw+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIEVkaXQgcHJvZmlsZSArIHBhc3N3b3JkICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC0xMiBjb2wtbGctOFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZCBzZWN0aW9uLWNhcmQgbWItNFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkLWhlYWRlclwiPkVkaXQgcHJvZmlsZTwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkLWJvZHlcIj5cbiAgICAgICAgICAgICAge3Byb2ZpbGVFcnJvciAmJiA8ZGl2IGNsYXNzTmFtZT1cImFsZXJ0IGFsZXJ0LWRhbmdlciBweS0yXCI+e3Byb2ZpbGVFcnJvcn08L2Rpdj59XG4gICAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtzYXZlUHJvZmlsZX0gbm9WYWxpZGF0ZT5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTNcIj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwicC1uYW1lXCIgY2xhc3NOYW1lPVwiZm9ybS1sYWJlbFwiPkZ1bGwgbmFtZTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJwLW5hbWVcIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2Bmb3JtLWNvbnRyb2wgJHtwcm9maWxlRXJyb3JzLm5hbWUgPyBcImlzLWludmFsaWRcIiA6IFwiXCJ9YH1cbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3Byb2ZpbGUubmFtZX1cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRQcm9maWxlKChwKSA9PiAoeyAuLi5wLCBuYW1lOiBlLnRhcmdldC52YWx1ZSB9KSl9XG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtzYXZpbmdQcm9maWxlfVxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIHtwcm9maWxlRXJyb3JzLm5hbWUgJiYgPGRpdiBjbGFzc05hbWU9XCJpbnZhbGlkLWZlZWRiYWNrXCI+e3Byb2ZpbGVFcnJvcnMubmFtZX08L2Rpdj59XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0zXCI+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cInAtYXZhdGFyXCIgY2xhc3NOYW1lPVwiZm9ybS1sYWJlbFwiPkF2YXRhciBVUkwgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1tdXRlZCBzbWFsbFwiPihvcHRpb25hbCk8L3NwYW4+PC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICBpZD1cInAtYXZhdGFyXCJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZm9ybS1jb250cm9sICR7cHJvZmlsZUVycm9ycy5hdmF0YXJVcmwgPyBcImlzLWludmFsaWRcIiA6IFwiXCJ9YH1cbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3Byb2ZpbGUuYXZhdGFyVXJsfVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFByb2ZpbGUoKHApID0+ICh7IC4uLnAsIGF2YXRhclVybDogZS50YXJnZXQudmFsdWUgfSkpfVxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImh0dHBzOi8v4oCmXCJcbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3NhdmluZ1Byb2ZpbGV9XG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAge3Byb2ZpbGVFcnJvcnMuYXZhdGFyVXJsICYmIDxkaXYgY2xhc3NOYW1lPVwiaW52YWxpZC1mZWVkYmFja1wiPntwcm9maWxlRXJyb3JzLmF2YXRhclVybH08L2Rpdj59XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4gYnRuLWRoYW5pdGlcIiBkaXNhYmxlZD17c2F2aW5nUHJvZmlsZX0+XG4gICAgICAgICAgICAgICAgICB7c2F2aW5nUHJvZmlsZSA/IChcbiAgICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzcGlubmVyLWJvcmRlciBzcGlubmVyLWJvcmRlci1zbSBtZS0yXCIgcm9sZT1cInN0YXR1c1wiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgU2F2aW5n4oCmXG4gICAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICAgKSA6IFwiU2F2ZSBjaGFuZ2VzXCJ9XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAge2N1cnJlbnRVc2VyLmhhc1Bhc3N3b3JkICE9PSBmYWxzZSAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQgc2VjdGlvbi1jYXJkXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZC1oZWFkZXJcIj5DaGFuZ2UgcGFzc3dvcmQ8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkLWJvZHlcIj5cbiAgICAgICAgICAgICAgICB7cHdFcnJvciAmJiA8ZGl2IGNsYXNzTmFtZT1cImFsZXJ0IGFsZXJ0LWRhbmdlciBweS0yXCI+e3B3RXJyb3J9PC9kaXY+fVxuICAgICAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtjaGFuZ2VQYXNzd29yZH0gbm9WYWxpZGF0ZT5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItM1wiPlxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cImNwLWN1cnJlbnRcIiBjbGFzc05hbWU9XCJmb3JtLWxhYmVsXCI+Q3VycmVudCBwYXNzd29yZDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJwYXNzd29yZFwiXG4gICAgICAgICAgICAgICAgICAgICAgaWQ9XCJjcC1jdXJyZW50XCJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2Bmb3JtLWNvbnRyb2wgJHtwd0Vycm9ycy5jdXJyZW50UGFzc3dvcmQgPyBcImlzLWludmFsaWRcIiA6IFwiXCJ9YH1cbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cHcuY3VycmVudFBhc3N3b3JkfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UHcoKHApID0+ICh7IC4uLnAsIGN1cnJlbnRQYXNzd29yZDogZS50YXJnZXQudmFsdWUgfSkpfVxuICAgICAgICAgICAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cImN1cnJlbnQtcGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtzYXZpbmdQd31cbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAge3B3RXJyb3JzLmN1cnJlbnRQYXNzd29yZCAmJiA8ZGl2IGNsYXNzTmFtZT1cImludmFsaWQtZmVlZGJhY2tcIj57cHdFcnJvcnMuY3VycmVudFBhc3N3b3JkfTwvZGl2Pn1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3dcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtMTIgY29sLW1kLTYgbWItM1wiPlxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwiY3AtbmV3XCIgY2xhc3NOYW1lPVwiZm9ybS1sYWJlbFwiPk5ldyBwYXNzd29yZDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJjcC1uZXdcIlxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZm9ybS1jb250cm9sICR7cHdFcnJvcnMubmV3UGFzc3dvcmQgPyBcImlzLWludmFsaWRcIiA6IFwiXCJ9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwdy5uZXdQYXNzd29yZH1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UHcoKHApID0+ICh7IC4uLnAsIG5ld1Bhc3N3b3JkOiBlLnRhcmdldC52YWx1ZSB9KSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJuZXctcGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3NhdmluZ1B3fVxuICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAge3B3RXJyb3JzLm5ld1Bhc3N3b3JkICYmIDxkaXYgY2xhc3NOYW1lPVwiaW52YWxpZC1mZWVkYmFja1wiPntwd0Vycm9ycy5uZXdQYXNzd29yZH08L2Rpdj59XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC0xMiBjb2wtbWQtNiBtYi0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJjcC1jb25maXJtXCIgY2xhc3NOYW1lPVwiZm9ybS1sYWJlbFwiPkNvbmZpcm0gbmV3IHBhc3N3b3JkPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJwYXNzd29yZFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBpZD1cImNwLWNvbmZpcm1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZm9ybS1jb250cm9sICR7cHdFcnJvcnMuY29uZmlybSA/IFwiaXMtaW52YWxpZFwiIDogXCJcIn1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3B3LmNvbmZpcm19XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFB3KChwKSA9PiAoeyAuLi5wLCBjb25maXJtOiBlLnRhcmdldC52YWx1ZSB9KSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJuZXctcGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3NhdmluZ1B3fVxuICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAge3B3RXJyb3JzLmNvbmZpcm0gJiYgPGRpdiBjbGFzc05hbWU9XCJpbnZhbGlkLWZlZWRiYWNrXCI+e3B3RXJyb3JzLmNvbmZpcm19PC9kaXY+fVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4gYnRuLW91dGxpbmUtZGhhbml0aVwiIGRpc2FibGVkPXtzYXZpbmdQd30+XG4gICAgICAgICAgICAgICAgICAgIHtzYXZpbmdQdyA/IChcbiAgICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic3Bpbm5lci1ib3JkZXIgc3Bpbm5lci1ib3JkZXItc20gbWUtMlwiIHJvbGU9XCJzdGF0dXNcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgVXBkYXRpbmfigKZcbiAgICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICAgKSA6IFwiVXBkYXRlIHBhc3N3b3JkXCJ9XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiQzovVXNlcnMvdXNlci9Eb3dubG9hZHMvZGhhbml0aS1hcHAtdXBncmFkZWQvZGhhbml0aS1hcHAvZnJvbnRlbmQvc3JjL3BhZ2VzL1Byb2ZpbGUuanN4In0=