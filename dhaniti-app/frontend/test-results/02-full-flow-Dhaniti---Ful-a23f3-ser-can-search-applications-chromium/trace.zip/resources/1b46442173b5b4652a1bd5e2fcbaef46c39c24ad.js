import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Register.jsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport1_react_jsxDevRuntime["Fragment"];const React = __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"];import * as RefreshRuntime from "/@react-refresh";
var _jsxFileName = "C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/pages/Register.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=325d36c7";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
	if (!window.$RefreshReg$) {
		throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong.");
	}
	prevRefreshReg = window.$RefreshReg$;
	prevRefreshSig = window.$RefreshSig$;
	window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/pages/Register.jsx");
	window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=325d36c7";
import { Link, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=325d36c7";
import { authApi } from "/src/api/auth.js";
import { ApiError } from "/src/api/client.js";
import { useToast } from "/src/context/ToastContext.jsx";
const PASSWORD_RULES = [
	{
		id: "length",
		label: "At least 8 characters",
		test: (p) => p.length >= 8
	},
	{
		id: "letter",
		label: "At least one letter",
		test: (p) => /[A-Za-z]/.test(p)
	},
	{
		id: "number",
		label: "At least one number",
		test: (p) => /\d/.test(p)
	}
];
export default function Register() {
	_s();
	const navigate = useNavigate();
	const toast = useToast();
	const [form, setForm] = useState({
		name: "",
		email: "",
		password: "",
		confirm: ""
	});
	const [errors, setErrors] = useState({});
	const [apiError, setApiError] = useState("");
	const [loading, setLoading] = useState(false);
	const [showPassword, setShowPassword] = useState(false);
	const set = (key) => (e) => setForm((f) => ({
		...f,
		[key]: e.target.value
	}));
	function validate() {
		const next = {};
		if (!form.name.trim()) next.name = "Name is required.";
		else if (form.name.trim().length < 2) next.name = "Name must be at least 2 characters long.";
		if (!form.email.trim()) next.email = "Email address is required.";
		else if (!/^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$/.test(form.email.trim())) next.email = "Invalid email address.";
		if (!form.password) next.password = "Password is required.";
		else if (PASSWORD_RULES.some((r) => !r.test(form.password))) next.password = "Password must meet the required security rules.";
		if (form.confirm !== form.password) next.confirm = "Passwords do not match.";
		setErrors(next);
		return Object.keys(next).length === 0;
	}
	async function handleSubmit(e) {
		e.preventDefault();
		setApiError("");
		if (!validate()) return;
		setLoading(true);
		try {
			await authApi.register(form.name.trim(), form.email.trim(), form.password, form.confirm);
			toast.success("Account created — check your email for the verification code.");
			navigate("/verify-otp", { state: {
				email: form.email.trim(),
				purpose: "email_verification"
			} });
		} catch (err) {
			setApiError(err instanceof ApiError && err.details.length ? `${err.message} ${err.details.join(" ")}` : err.message);
		} finally {
			setLoading(false);
		}
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "login-wrapper",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "card login-card",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "card-header text-center",
				children: [/* @__PURE__ */ _jsxDEV("h4", {
					className: "mb-0 text-dhaniti",
					children: "Create your account"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 81,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-muted small mb-0 mt-1",
					children: "Join the Dhaniti Education Loan Dashboard"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 82,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 80,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "card-body p-4",
				children: [
					apiError && /* @__PURE__ */ _jsxDEV("div", {
						className: "alert alert-danger py-2",
						role: "alert",
						children: apiError
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 88,
						columnNumber: 24
					}, this),
					/* @__PURE__ */ _jsxDEV("form", {
						onSubmit: handleSubmit,
						noValidate: true,
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "mb-3",
								children: [
									/* @__PURE__ */ _jsxDEV("label", {
										htmlFor: "name",
										className: "form-label",
										children: "Full name"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 92,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										className: `form-control ${errors.name ? "is-invalid" : ""}`,
										id: "name",
										value: form.name,
										onChange: set("name"),
										autoComplete: "name",
										disabled: loading
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 93,
										columnNumber: 15
									}, this),
									errors.name && /* @__PURE__ */ _jsxDEV("div", {
										className: "invalid-feedback",
										children: errors.name
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 102,
										columnNumber: 31
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 91,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "mb-3",
								children: [
									/* @__PURE__ */ _jsxDEV("label", {
										htmlFor: "reg-email",
										className: "form-label",
										children: "Email"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 106,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("input", {
										type: "email",
										className: `form-control ${errors.email ? "is-invalid" : ""}`,
										id: "reg-email",
										value: form.email,
										onChange: set("email"),
										autoComplete: "username",
										disabled: loading
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 107,
										columnNumber: 15
									}, this),
									errors.email && /* @__PURE__ */ _jsxDEV("div", {
										className: "invalid-feedback",
										children: errors.email
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 116,
										columnNumber: 32
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 105,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "mb-3",
								children: [
									/* @__PURE__ */ _jsxDEV("label", {
										htmlFor: "reg-password",
										className: "form-label",
										children: "Password"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 120,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "input-group",
										children: [/* @__PURE__ */ _jsxDEV("input", {
											type: showPassword ? "text" : "password",
											className: `form-control ${errors.password ? "is-invalid" : ""}`,
											id: "reg-password",
											value: form.password,
											onChange: set("password"),
											autoComplete: "new-password",
											disabled: loading
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 122,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("button", {
											className: "btn btn-outline-secondary",
											type: "button",
											onClick: () => setShowPassword((s) => !s),
											tabIndex: -1,
											"aria-label": "Toggle password visibility",
											children: /* @__PURE__ */ _jsxDEV("i", {
												className: `bi ${showPassword ? "bi-eye-slash" : "bi-eye"}`,
												"aria-hidden": "true"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 138,
												columnNumber: 19
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 131,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 121,
										columnNumber: 15
									}, this),
									errors.password && /* @__PURE__ */ _jsxDEV("div", {
										className: "invalid-feedback d-block",
										children: errors.password
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 141,
										columnNumber: 35
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "password-rules mt-2",
										children: PASSWORD_RULES.map((rule) => /* @__PURE__ */ _jsxDEV("div", {
											className: `small ${rule.test(form.password) ? "text-success" : "text-muted"}`,
											children: [/* @__PURE__ */ _jsxDEV("i", {
												className: `bi ${rule.test(form.password) ? "bi-check-circle-fill" : "bi-circle"} me-1`,
												"aria-hidden": "true"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 145,
												columnNumber: 21
											}, this), rule.label]
										}, rule.id, true, {
											fileName: _jsxFileName,
											lineNumber: 144,
											columnNumber: 17
										}, this))
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 142,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 119,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "mb-4",
								children: [
									/* @__PURE__ */ _jsxDEV("label", {
										htmlFor: "reg-confirm",
										className: "form-label",
										children: "Confirm password"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 153,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("input", {
										type: showPassword ? "text" : "password",
										className: `form-control ${errors.confirm ? "is-invalid" : ""}`,
										id: "reg-confirm",
										value: form.confirm,
										onChange: set("confirm"),
										autoComplete: "new-password",
										disabled: loading
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 154,
										columnNumber: 15
									}, this),
									errors.confirm && /* @__PURE__ */ _jsxDEV("div", {
										className: "invalid-feedback",
										children: errors.confirm
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 163,
										columnNumber: 34
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 152,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "submit",
								className: "btn btn-dhaniti w-100",
								disabled: loading,
								children: loading ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "spinner-border spinner-border-sm me-2",
									role: "status",
									"aria-hidden": "true"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 169,
									columnNumber: 19
								}, this), "Creating account…"] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 168,
									columnNumber: 15
								}, this) : "Create account"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 166,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 90,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-center small mt-4 mb-0",
						children: ["Already have an account? ", /* @__PURE__ */ _jsxDEV(Link, {
							to: "/login",
							children: "Sign in"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 179,
							columnNumber: 38
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 178,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 87,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 79,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 78,
		columnNumber: 5
	}, this);
}
_s(Register, "Bu4Q1Tb3mlyBpFg88y2FVTpZOO8=", false, function() {
	return [useNavigate, useToast];
});
_c = Register;
var _c;
$RefreshReg$(_c, "Register");
if (import.meta.hot && !inWebWorker) {
	window.$RefreshReg$ = prevRefreshReg;
	window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
	RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
		RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/pages/Register.jsx", currentExports);
		import.meta.hot.accept((nextExports) => {
			if (!nextExports) return;
			const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/pages/Register.jsx", currentExports, nextExports);
			if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
		});
	});
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLE9BQU9BLFNBQVNDLGdCQUFnQjtBQUNoQyxTQUFTQyxNQUFNQyxtQkFBbUI7QUFDbEMsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsZ0JBQWdCO0FBRXpCLE1BQU1DLGlCQUFpQjtDQUNyQjtFQUFFQyxJQUFJO0VBQVVDLE9BQU87RUFBeUJDLE9BQU9DLE1BQU1BLEVBQUVDLFVBQVU7Q0FBRTtDQUMzRTtFQUFFSixJQUFJO0VBQVVDLE9BQU87RUFBdUJDLE9BQU9DLE1BQU0sV0FBV0QsS0FBS0MsQ0FBQztDQUFFO0NBQzlFO0VBQUVILElBQUk7RUFBVUMsT0FBTztFQUF1QkMsT0FBT0MsTUFBTSxLQUFLRCxLQUFLQyxDQUFDO0NBQUU7QUFBQztBQUczRSxlQUFlLFNBQVNFLFdBQVc7Q0FBQUMsR0FBQTtDQUNqQyxNQUFNQyxXQUFXWixZQUFZO0NBQzdCLE1BQU1hLFFBQVFWLFNBQVM7Q0FFdkIsTUFBTSxDQUFDVyxNQUFNQyxXQUFXakIsU0FBUztFQUFFa0IsTUFBTTtFQUFJQyxPQUFPO0VBQUlDLFVBQVU7RUFBSUMsU0FBUztDQUFHLENBQUM7Q0FDbkYsTUFBTSxDQUFDQyxRQUFRQyxhQUFhdkIsU0FBUyxDQUFDLENBQUM7Q0FDdkMsTUFBTSxDQUFDd0IsVUFBVUMsZUFBZXpCLFNBQVMsRUFBRTtDQUMzQyxNQUFNLENBQUMwQixTQUFTQyxjQUFjM0IsU0FBUyxLQUFLO0NBQzVDLE1BQU0sQ0FBQzRCLGNBQWNDLG1CQUFtQjdCLFNBQVMsS0FBSztDQUV0RCxNQUFNOEIsT0FBT0MsU0FBU0MsTUFBTWYsU0FBU2dCLE9BQU87RUFBRSxHQUFHQTtHQUFJRixNQUFNQyxFQUFFRSxPQUFPQztDQUFNLEVBQUU7Q0FFNUUsU0FBU0MsV0FBVztFQUNsQixNQUFNQyxPQUFPLENBQUM7RUFDZCxJQUFJLENBQUNyQixLQUFLRSxLQUFLb0IsS0FBSyxHQUFHRCxLQUFLbkIsT0FBTztPQUM5QixJQUFJRixLQUFLRSxLQUFLb0IsS0FBSyxDQUFDLENBQUMzQixTQUFTLEdBQUcwQixLQUFLbkIsT0FBTztFQUNsRCxJQUFJLENBQUNGLEtBQUtHLE1BQU1tQixLQUFLLEdBQUdELEtBQUtsQixRQUFRO09BQ2hDLElBQUksQ0FBQyxxREFBcURWLEtBQUtPLEtBQUtHLE1BQU1tQixLQUFLLENBQUMsR0FDbkZELEtBQUtsQixRQUFRO0VBQ2YsSUFBSSxDQUFDSCxLQUFLSSxVQUFVaUIsS0FBS2pCLFdBQVc7T0FDL0IsSUFBSWQsZUFBZWlDLE1BQU1DLE1BQU0sQ0FBQ0EsRUFBRS9CLEtBQUtPLEtBQUtJLFFBQVEsQ0FBQyxHQUN4RGlCLEtBQUtqQixXQUFXO0VBQ2xCLElBQUlKLEtBQUtLLFlBQVlMLEtBQUtJLFVBQVVpQixLQUFLaEIsVUFBVTtFQUNuREUsVUFBVWMsSUFBSTtFQUNkLE9BQU9JLE9BQU9DLEtBQUtMLElBQUksQ0FBQyxDQUFDMUIsV0FBVztDQUN0QztDQUVBLGVBQWVnQyxhQUFhWCxHQUFHO0VBQzdCQSxFQUFFWSxlQUFlO0VBQ2pCbkIsWUFBWSxFQUFFO0VBQ2QsSUFBSSxDQUFDVyxTQUFTLEdBQUc7RUFDakJULFdBQVcsSUFBSTtFQUNmLElBQUk7R0FDRixNQUFNeEIsUUFBUTBDLFNBQVM3QixLQUFLRSxLQUFLb0IsS0FBSyxHQUFHdEIsS0FBS0csTUFBTW1CLEtBQUssR0FBR3RCLEtBQUtJLFVBQVVKLEtBQUtLLE9BQU87R0FDdkZOLE1BQU0rQixRQUFRLCtEQUErRDtHQUM3RWhDLFNBQVMsZUFBZSxFQUN0QmlDLE9BQU87SUFBRTVCLE9BQU9ILEtBQUtHLE1BQU1tQixLQUFLO0lBQUdVLFNBQVM7R0FBcUIsRUFDbkUsQ0FBQztFQUNILFNBQVNDLEtBQUs7R0FDWnhCLFlBQVl3QixlQUFlN0MsWUFBWTZDLElBQUlDLFFBQVF2QyxTQUFTLEdBQUdzQyxJQUFJRSxRQUFPLEdBQUlGLElBQUlDLFFBQVFFLEtBQUssR0FBRyxNQUFNSCxJQUFJRSxPQUFPO0VBQ3JILFVBQVU7R0FDUnhCLFdBQVcsS0FBSztFQUNsQjtDQUNGO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUNiLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBb0I7SUFBdUI7Ozs7Y0FDekQsd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBNEI7SUFFdEM7Ozs7WUFDQTs7Ozs7YUFFTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBQ0dILFlBQVksd0JBQUMsT0FBRDtNQUFLLFdBQVU7TUFBMEIsTUFBSztnQkFBU0E7S0FBYzs7Ozs7S0FFbEYsd0JBQUMsUUFBRDtNQUFNLFVBQVVtQjtNQUFjO2dCQUE5QjtPQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsU0FBRDtVQUFPLFNBQVE7VUFBTyxXQUFVO29CQUFhO1NBQWdCOzs7OztTQUM3RCx3QkFBQyxTQUFEO1VBQ0UsTUFBSztVQUNMLFdBQVcsZ0JBQWdCckIsT0FBT0osT0FBTyxlQUFlO1VBQ3hELElBQUc7VUFDSCxPQUFPRixLQUFLRTtVQUNaLFVBQVVZLElBQUksTUFBTTtVQUNwQixjQUFhO1VBQ2IsVUFBVUo7U0FBUTs7Ozs7U0FFbkJKLE9BQU9KLFFBQVEsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQW9CSSxPQUFPSjtTQUFVOzs7OztRQUNqRTs7Ozs7O09BRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxTQUFEO1VBQU8sU0FBUTtVQUFZLFdBQVU7b0JBQWE7U0FBWTs7Ozs7U0FDOUQsd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxXQUFXLGdCQUFnQkksT0FBT0gsUUFBUSxlQUFlO1VBQ3pELElBQUc7VUFDSCxPQUFPSCxLQUFLRztVQUNaLFVBQVVXLElBQUksT0FBTztVQUNyQixjQUFhO1VBQ2IsVUFBVUo7U0FBUTs7Ozs7U0FFbkJKLE9BQU9ILFNBQVMsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQW9CRyxPQUFPSDtTQUFXOzs7OztRQUNuRTs7Ozs7O09BRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxTQUFEO1VBQU8sU0FBUTtVQUFlLFdBQVU7b0JBQWE7U0FBZTs7Ozs7U0FDcEUsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxTQUFEO1dBQ0UsTUFBTVMsZUFBZSxTQUFTO1dBQzlCLFdBQVcsZ0JBQWdCTixPQUFPRixXQUFXLGVBQWU7V0FDNUQsSUFBRztXQUNILE9BQU9KLEtBQUtJO1dBQ1osVUFBVVUsSUFBSSxVQUFVO1dBQ3hCLGNBQWE7V0FDYixVQUFVSjtVQUFROzs7O29CQUVwQix3QkFBQyxVQUFEO1dBQ0UsV0FBVTtXQUNWLE1BQUs7V0FDTCxlQUFlRyxpQkFBaUJ3QixNQUFNLENBQUNBLENBQUM7V0FDeEMsVUFBVSxDQUFDO1dBQ1gsY0FBVztxQkFFWCx3QkFBQyxLQUFEO1lBQUcsV0FBVyxNQUFNekIsZUFBZSxpQkFBaUI7WUFBWSxlQUFZO1dBQU07Ozs7O1VBQzVFOzs7O2tCQUNMOzs7Ozs7U0FDSk4sT0FBT0YsWUFBWSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBNEJFLE9BQU9GO1NBQWM7Ozs7O1NBQ3BGLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUNaZCxlQUFlZ0QsS0FBS0MsU0FDbkIsd0JBQUMsT0FBRDtXQUFtQixXQUFXLFNBQVNBLEtBQUs5QyxLQUFLTyxLQUFLSSxRQUFRLElBQUksaUJBQWlCO3FCQUFuRixDQUNFLHdCQUFDLEtBQUQ7WUFBRyxXQUFXLE1BQU1tQyxLQUFLOUMsS0FBS08sS0FBS0ksUUFBUSxJQUFJLHlCQUF5QixZQUFXO1lBQVMsZUFBWTtXQUFNOzs7O3FCQUM3R21DLEtBQUsvQyxLQUNIO2FBSEsrQyxLQUFLaEQ7Ozs7aUJBR1YsQ0FDTjtTQUNFOzs7OztRQUNGOzs7Ozs7T0FFTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLFNBQUQ7VUFBTyxTQUFRO1VBQWMsV0FBVTtvQkFBYTtTQUF1Qjs7Ozs7U0FDM0Usd0JBQUMsU0FBRDtVQUNFLE1BQU1xQixlQUFlLFNBQVM7VUFDOUIsV0FBVyxnQkFBZ0JOLE9BQU9ELFVBQVUsZUFBZTtVQUMzRCxJQUFHO1VBQ0gsT0FBT0wsS0FBS0s7VUFDWixVQUFVUyxJQUFJLFNBQVM7VUFDdkIsY0FBYTtVQUNiLFVBQVVKO1NBQVE7Ozs7O1NBRW5CSixPQUFPRCxXQUFXLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFvQkMsT0FBT0Q7U0FBYTs7Ozs7UUFDdkU7Ozs7OztPQUVMLHdCQUFDLFVBQUQ7UUFBUSxNQUFLO1FBQVMsV0FBVTtRQUF3QixVQUFVSztrQkFDL0RBLFVBQ0MsZ0RBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7U0FBd0MsTUFBSztTQUFTLGVBQVk7UUFBTTs7OztrQkFBQSxtQkFFMUY7Ozs7bUJBRUE7T0FFSTs7Ozs7TUFDSjs7Ozs7O0tBRU4sd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQWIsQ0FBMEMsNkJBQ2Ysd0JBQUMsTUFBRDtPQUFNLElBQUc7aUJBQVM7TUFBYTs7OztjQUN2RDs7Ozs7O0lBQ0E7Ozs7O1dBQ0Y7Ozs7OztDQUNGOzs7OztBQUVUO0FBQUNiLEdBekp1QkQsVUFBUTtDQUFBLFFBQ2JWLGFBQ0hHLFFBQVE7QUFBQTtBQUFBLEtBRkFPO0FBQVEsSUFBQTRDO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwidXNlU3RhdGUiLCJMaW5rIiwidXNlTmF2aWdhdGUiLCJhdXRoQXBpIiwiQXBpRXJyb3IiLCJ1c2VUb2FzdCIsIlBBU1NXT1JEX1JVTEVTIiwiaWQiLCJsYWJlbCIsInRlc3QiLCJwIiwibGVuZ3RoIiwiUmVnaXN0ZXIiLCJfcyIsIm5hdmlnYXRlIiwidG9hc3QiLCJmb3JtIiwic2V0Rm9ybSIsIm5hbWUiLCJlbWFpbCIsInBhc3N3b3JkIiwiY29uZmlybSIsImVycm9ycyIsInNldEVycm9ycyIsImFwaUVycm9yIiwic2V0QXBpRXJyb3IiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsInNob3dQYXNzd29yZCIsInNldFNob3dQYXNzd29yZCIsInNldCIsImtleSIsImUiLCJmIiwidGFyZ2V0IiwidmFsdWUiLCJ2YWxpZGF0ZSIsIm5leHQiLCJ0cmltIiwic29tZSIsInIiLCJPYmplY3QiLCJrZXlzIiwiaGFuZGxlU3VibWl0IiwicHJldmVudERlZmF1bHQiLCJyZWdpc3RlciIsInN1Y2Nlc3MiLCJzdGF0ZSIsInB1cnBvc2UiLCJlcnIiLCJkZXRhaWxzIiwibWVzc2FnZSIsImpvaW4iLCJzIiwibWFwIiwicnVsZSIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlJlZ2lzdGVyLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IExpbmssIHVzZU5hdmlnYXRlIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcbmltcG9ydCB7IGF1dGhBcGkgfSBmcm9tIFwiLi4vYXBpL2F1dGguanNcIjtcbmltcG9ydCB7IEFwaUVycm9yIH0gZnJvbSBcIi4uL2FwaS9jbGllbnQuanNcIjtcbmltcG9ydCB7IHVzZVRvYXN0IH0gZnJvbSBcIi4uL2NvbnRleHQvVG9hc3RDb250ZXh0LmpzeFwiO1xuXG5jb25zdCBQQVNTV09SRF9SVUxFUyA9IFtcbiAgeyBpZDogXCJsZW5ndGhcIiwgbGFiZWw6IFwiQXQgbGVhc3QgOCBjaGFyYWN0ZXJzXCIsIHRlc3Q6IChwKSA9PiBwLmxlbmd0aCA+PSA4IH0sXG4gIHsgaWQ6IFwibGV0dGVyXCIsIGxhYmVsOiBcIkF0IGxlYXN0IG9uZSBsZXR0ZXJcIiwgdGVzdDogKHApID0+IC9bQS1aYS16XS8udGVzdChwKSB9LFxuICB7IGlkOiBcIm51bWJlclwiLCBsYWJlbDogXCJBdCBsZWFzdCBvbmUgbnVtYmVyXCIsIHRlc3Q6IChwKSA9PiAvXFxkLy50ZXN0KHApIH0sXG5dO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBSZWdpc3RlcigpIHtcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuICBjb25zdCB0b2FzdCA9IHVzZVRvYXN0KCk7XG5cbiAgY29uc3QgW2Zvcm0sIHNldEZvcm1dID0gdXNlU3RhdGUoeyBuYW1lOiBcIlwiLCBlbWFpbDogXCJcIiwgcGFzc3dvcmQ6IFwiXCIsIGNvbmZpcm06IFwiXCIgfSk7XG4gIGNvbnN0IFtlcnJvcnMsIHNldEVycm9yc10gPSB1c2VTdGF0ZSh7fSk7XG4gIGNvbnN0IFthcGlFcnJvciwgc2V0QXBpRXJyb3JdID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3Nob3dQYXNzd29yZCwgc2V0U2hvd1Bhc3N3b3JkXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICBjb25zdCBzZXQgPSAoa2V5KSA9PiAoZSkgPT4gc2V0Rm9ybSgoZikgPT4gKHsgLi4uZiwgW2tleV06IGUudGFyZ2V0LnZhbHVlIH0pKTtcblxuICBmdW5jdGlvbiB2YWxpZGF0ZSgpIHtcbiAgICBjb25zdCBuZXh0ID0ge307XG4gICAgaWYgKCFmb3JtLm5hbWUudHJpbSgpKSBuZXh0Lm5hbWUgPSBcIk5hbWUgaXMgcmVxdWlyZWQuXCI7XG4gICAgZWxzZSBpZiAoZm9ybS5uYW1lLnRyaW0oKS5sZW5ndGggPCAyKSBuZXh0Lm5hbWUgPSBcIk5hbWUgbXVzdCBiZSBhdCBsZWFzdCAyIGNoYXJhY3RlcnMgbG9uZy5cIjtcbiAgICBpZiAoIWZvcm0uZW1haWwudHJpbSgpKSBuZXh0LmVtYWlsID0gXCJFbWFpbCBhZGRyZXNzIGlzIHJlcXVpcmVkLlwiO1xuICAgIGVsc2UgaWYgKCEvXltBLVphLXowLTkuXyUrXFwtXStAW0EtWmEtejAtOS5cXC1dK1xcLltBLVphLXpdezIsfSQvLnRlc3QoZm9ybS5lbWFpbC50cmltKCkpKVxuICAgICAgbmV4dC5lbWFpbCA9IFwiSW52YWxpZCBlbWFpbCBhZGRyZXNzLlwiO1xuICAgIGlmICghZm9ybS5wYXNzd29yZCkgbmV4dC5wYXNzd29yZCA9IFwiUGFzc3dvcmQgaXMgcmVxdWlyZWQuXCI7XG4gICAgZWxzZSBpZiAoUEFTU1dPUkRfUlVMRVMuc29tZSgocikgPT4gIXIudGVzdChmb3JtLnBhc3N3b3JkKSkpXG4gICAgICBuZXh0LnBhc3N3b3JkID0gXCJQYXNzd29yZCBtdXN0IG1lZXQgdGhlIHJlcXVpcmVkIHNlY3VyaXR5IHJ1bGVzLlwiO1xuICAgIGlmIChmb3JtLmNvbmZpcm0gIT09IGZvcm0ucGFzc3dvcmQpIG5leHQuY29uZmlybSA9IFwiUGFzc3dvcmRzIGRvIG5vdCBtYXRjaC5cIjtcbiAgICBzZXRFcnJvcnMobmV4dCk7XG4gICAgcmV0dXJuIE9iamVjdC5rZXlzKG5leHQpLmxlbmd0aCA9PT0gMDtcbiAgfVxuXG4gIGFzeW5jIGZ1bmN0aW9uIGhhbmRsZVN1Ym1pdChlKSB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIHNldEFwaUVycm9yKFwiXCIpO1xuICAgIGlmICghdmFsaWRhdGUoKSkgcmV0dXJuO1xuICAgIHNldExvYWRpbmcodHJ1ZSk7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGF1dGhBcGkucmVnaXN0ZXIoZm9ybS5uYW1lLnRyaW0oKSwgZm9ybS5lbWFpbC50cmltKCksIGZvcm0ucGFzc3dvcmQsIGZvcm0uY29uZmlybSk7XG4gICAgICB0b2FzdC5zdWNjZXNzKFwiQWNjb3VudCBjcmVhdGVkIOKAlCBjaGVjayB5b3VyIGVtYWlsIGZvciB0aGUgdmVyaWZpY2F0aW9uIGNvZGUuXCIpO1xuICAgICAgbmF2aWdhdGUoXCIvdmVyaWZ5LW90cFwiLCB7XG4gICAgICAgIHN0YXRlOiB7IGVtYWlsOiBmb3JtLmVtYWlsLnRyaW0oKSwgcHVycG9zZTogXCJlbWFpbF92ZXJpZmljYXRpb25cIiB9LFxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBzZXRBcGlFcnJvcihlcnIgaW5zdGFuY2VvZiBBcGlFcnJvciAmJiBlcnIuZGV0YWlscy5sZW5ndGggPyBgJHtlcnIubWVzc2FnZX0gJHtlcnIuZGV0YWlscy5qb2luKFwiIFwiKX1gIDogZXJyLm1lc3NhZ2UpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwibG9naW4td3JhcHBlclwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkIGxvZ2luLWNhcmRcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkLWhlYWRlciB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJtYi0wIHRleHQtZGhhbml0aVwiPkNyZWF0ZSB5b3VyIGFjY291bnQ8L2g0PlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbXV0ZWQgc21hbGwgbWItMCBtdC0xXCI+XG4gICAgICAgICAgICBKb2luIHRoZSBEaGFuaXRpIEVkdWNhdGlvbiBMb2FuIERhc2hib2FyZFxuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkLWJvZHkgcC00XCI+XG4gICAgICAgICAge2FwaUVycm9yICYmIDxkaXYgY2xhc3NOYW1lPVwiYWxlcnQgYWxlcnQtZGFuZ2VyIHB5LTJcIiByb2xlPVwiYWxlcnRcIj57YXBpRXJyb3J9PC9kaXY+fVxuXG4gICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0gbm9WYWxpZGF0ZT5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItM1wiPlxuICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cIm5hbWVcIiBjbGFzc05hbWU9XCJmb3JtLWxhYmVsXCI+RnVsbCBuYW1lPC9sYWJlbD5cbiAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZvcm0tY29udHJvbCAke2Vycm9ycy5uYW1lID8gXCJpcy1pbnZhbGlkXCIgOiBcIlwifWB9XG4gICAgICAgICAgICAgICAgaWQ9XCJuYW1lXCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybS5uYW1lfVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtzZXQoXCJuYW1lXCIpfVxuICAgICAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cIm5hbWVcIlxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXtsb2FkaW5nfVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICB7ZXJyb3JzLm5hbWUgJiYgPGRpdiBjbGFzc05hbWU9XCJpbnZhbGlkLWZlZWRiYWNrXCI+e2Vycm9ycy5uYW1lfTwvZGl2Pn1cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTNcIj5cbiAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJyZWctZW1haWxcIiBjbGFzc05hbWU9XCJmb3JtLWxhYmVsXCI+RW1haWw8L2xhYmVsPlxuICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICB0eXBlPVwiZW1haWxcIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZvcm0tY29udHJvbCAke2Vycm9ycy5lbWFpbCA/IFwiaXMtaW52YWxpZFwiIDogXCJcIn1gfVxuICAgICAgICAgICAgICAgIGlkPVwicmVnLWVtYWlsXCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybS5lbWFpbH1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17c2V0KFwiZW1haWxcIil9XG4gICAgICAgICAgICAgICAgYXV0b0NvbXBsZXRlPVwidXNlcm5hbWVcIlxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXtsb2FkaW5nfVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICB7ZXJyb3JzLmVtYWlsICYmIDxkaXYgY2xhc3NOYW1lPVwiaW52YWxpZC1mZWVkYmFja1wiPntlcnJvcnMuZW1haWx9PC9kaXY+fVxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItM1wiPlxuICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cInJlZy1wYXNzd29yZFwiIGNsYXNzTmFtZT1cImZvcm0tbGFiZWxcIj5QYXNzd29yZDwvbGFiZWw+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5wdXQtZ3JvdXBcIj5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9e3Nob3dQYXNzd29yZCA/IFwidGV4dFwiIDogXCJwYXNzd29yZFwifVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZm9ybS1jb250cm9sICR7ZXJyb3JzLnBhc3N3b3JkID8gXCJpcy1pbnZhbGlkXCIgOiBcIlwifWB9XG4gICAgICAgICAgICAgICAgICBpZD1cInJlZy1wYXNzd29yZFwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybS5wYXNzd29yZH1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtzZXQoXCJwYXNzd29yZFwiKX1cbiAgICAgICAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cIm5ldy1wYXNzd29yZFwiXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17bG9hZGluZ31cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJ0biBidG4tb3V0bGluZS1zZWNvbmRhcnlcIlxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93UGFzc3dvcmQoKHMpID0+ICFzKX1cbiAgICAgICAgICAgICAgICAgIHRhYkluZGV4PXstMX1cbiAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJUb2dnbGUgcGFzc3dvcmQgdmlzaWJpbGl0eVwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPGkgY2xhc3NOYW1lPXtgYmkgJHtzaG93UGFzc3dvcmQgPyBcImJpLWV5ZS1zbGFzaFwiIDogXCJiaS1leWVcIn1gfSBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAge2Vycm9ycy5wYXNzd29yZCAmJiA8ZGl2IGNsYXNzTmFtZT1cImludmFsaWQtZmVlZGJhY2sgZC1ibG9ja1wiPntlcnJvcnMucGFzc3dvcmR9PC9kaXY+fVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBhc3N3b3JkLXJ1bGVzIG10LTJcIj5cbiAgICAgICAgICAgICAgICB7UEFTU1dPUkRfUlVMRVMubWFwKChydWxlKSA9PiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IGtleT17cnVsZS5pZH0gY2xhc3NOYW1lPXtgc21hbGwgJHtydWxlLnRlc3QoZm9ybS5wYXNzd29yZCkgPyBcInRleHQtc3VjY2Vzc1wiIDogXCJ0ZXh0LW11dGVkXCJ9YH0+XG4gICAgICAgICAgICAgICAgICAgIDxpIGNsYXNzTmFtZT17YGJpICR7cnVsZS50ZXN0KGZvcm0ucGFzc3dvcmQpID8gXCJiaS1jaGVjay1jaXJjbGUtZmlsbFwiIDogXCJiaS1jaXJjbGVcIn0gbWUtMWB9IGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgICAgICAgICAgIHtydWxlLmxhYmVsfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNFwiPlxuICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cInJlZy1jb25maXJtXCIgY2xhc3NOYW1lPVwiZm9ybS1sYWJlbFwiPkNvbmZpcm0gcGFzc3dvcmQ8L2xhYmVsPlxuICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICB0eXBlPXtzaG93UGFzc3dvcmQgPyBcInRleHRcIiA6IFwicGFzc3dvcmRcIn1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2Bmb3JtLWNvbnRyb2wgJHtlcnJvcnMuY29uZmlybSA/IFwiaXMtaW52YWxpZFwiIDogXCJcIn1gfVxuICAgICAgICAgICAgICAgIGlkPVwicmVnLWNvbmZpcm1cIlxuICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtLmNvbmZpcm19XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9e3NldChcImNvbmZpcm1cIil9XG4gICAgICAgICAgICAgICAgYXV0b0NvbXBsZXRlPVwibmV3LXBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17bG9hZGluZ31cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAge2Vycm9ycy5jb25maXJtICYmIDxkaXYgY2xhc3NOYW1lPVwiaW52YWxpZC1mZWVkYmFja1wiPntlcnJvcnMuY29uZmlybX08L2Rpdj59XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCIgY2xhc3NOYW1lPVwiYnRuIGJ0bi1kaGFuaXRpIHctMTAwXCIgZGlzYWJsZWQ9e2xvYWRpbmd9PlxuICAgICAgICAgICAgICB7bG9hZGluZyA/IChcbiAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic3Bpbm5lci1ib3JkZXIgc3Bpbm5lci1ib3JkZXItc20gbWUtMlwiIHJvbGU9XCJzdGF0dXNcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgICAgICAgICAgQ3JlYXRpbmcgYWNjb3VudOKAplxuICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgIFwiQ3JlYXRlIGFjY291bnRcIlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9mb3JtPlxuXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgc21hbGwgbXQtNCBtYi0wXCI+XG4gICAgICAgICAgICBBbHJlYWR5IGhhdmUgYW4gYWNjb3VudD8gPExpbmsgdG89XCIvbG9naW5cIj5TaWduIGluPC9MaW5rPlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiQzovVXNlcnMvdXNlci9Eb3dubG9hZHMvZGhhbml0aS1hcHAtdXBncmFkZWQvZGhhbml0aS1hcHAvZnJvbnRlbmQvc3JjL3BhZ2VzL1JlZ2lzdGVyLmpzeCJ9