import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ItemViewModal.jsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];const React = __vite__cjsImport3_react;import * as RefreshRuntime from "/@react-refresh";
var _jsxFileName = "C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/components/ItemViewModal.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=325d36c7";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
	if (!window.$RefreshReg$) {
		throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong.");
	}
	prevRefreshReg = window.$RefreshReg$;
	prevRefreshSig = window.$RefreshSig$;
	window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/components/ItemViewModal.jsx");
	window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=325d36c7";
import { formatINR, statusClass, attentionClass } from "/src/api/items.js";
function Row({ label, value }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "col-12 col-md-6 mb-2",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "small text-muted",
			children: label
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 26,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "fw-medium",
			children: value ?? "—"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 27,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 25,
		columnNumber: 5
	}, this);
}
/** Read-only details modal for a loan application. */ _c = Row;
export default function ItemViewModal({ show, item, onClose, onEdit, canWrite }) {
	if (!show || !item) return null;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "modal fade show d-block",
		tabIndex: -1,
		role: "dialog",
		style: { background: "rgba(15,23,42,0.45)" },
		"aria-modal": "true",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable",
			role: "document",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "modal-content",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "modal-header",
						children: [/* @__PURE__ */ _jsxDEV("h5", {
							className: "modal-title d-flex align-items-center gap-2",
							children: [
								/* @__PURE__ */ _jsxDEV("i", {
									className: "bi bi-file-earmark-text text-dhaniti",
									"aria-hidden": "true"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 42,
									columnNumber: 15
								}, this),
								"Application ",
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-dhaniti",
									children: item.id
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 43,
									columnNumber: 27
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 41,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							className: "btn-close",
							"aria-label": "Close",
							onClick: onClose
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 45,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 40,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "modal-body",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "d-flex flex-wrap gap-2 mb-3",
							children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: `dq-pill ${statusClass(item.applicationStatus)}`,
									children: item.applicationStatus
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 50,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: `dq-pill ${attentionClass(item.attentionLevel)}`,
									children: item.attentionLevel
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 51,
									columnNumber: 15
								}, this),
								item.dataQualityFlags?.map((flag) => /* @__PURE__ */ _jsxDEV("span", {
									className: "dq-pill dq-flag",
									title: flag,
									children: flag.replaceAll("_", " ").toLowerCase()
								}, flag, false, {
									fileName: _jsxFileName,
									lineNumber: 53,
									columnNumber: 15
								}, this))
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 49,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "row",
							children: [
								/* @__PURE__ */ _jsxDEV(Row, {
									label: "Student name",
									value: item.studentName
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 58,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV(Row, {
									label: "Age",
									value: item.age
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 59,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV(Row, {
									label: "State",
									value: item.studentState
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 60,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV(Row, {
									label: "Employment type",
									value: item.employmentType
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 61,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV(Row, {
									label: "Institution",
									value: `${item.institutionName} (${item.institutionId})`
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 62,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV(Row, {
									label: "Course",
									value: `${item.courseName} — ${item.courseDomain} (${item.courseId})`
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 63,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV(Row, {
									label: "Course fee",
									value: formatINR(item.courseFeeInr)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 64,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV(Row, {
									label: "Loan requested",
									value: formatINR(item.loanAmountRequestedInr)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 65,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV(Row, {
									label: "Parent monthly income",
									value: formatINR(item.parentMonthlyIncomeInr)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 66,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV(Row, {
									label: "Existing obligations",
									value: formatINR(item.existingMonthlyObligationsInr)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 67,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV(Row, {
									label: "Credit score",
									value: item.creditScore ?? "N/A (missing)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 68,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV(Row, {
									label: "Debt-to-income ratio",
									value: item.debtToIncomeRatio !== null && item.debtToIncomeRatio !== undefined ? `${(item.debtToIncomeRatio * 100).toFixed(1)}%` : "—"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 69,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV(Row, {
									label: "Loan-to-fee ratio",
									value: item.loanToFeeRatio !== null && item.loanToFeeRatio !== undefined ? `${(item.loanToFeeRatio * 100).toFixed(1)}%` : "—"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 70,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV(Row, {
									label: "Application date",
									value: item.applicationDate
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 71,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV(Row, {
									label: "Channel",
									value: item.applicationChannel
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 72,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 57,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 48,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "modal-footer",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							className: "btn btn-outline-secondary",
							onClick: onClose,
							children: "Close"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 77,
							columnNumber: 13
						}, this), canWrite && /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							className: "btn btn-dhaniti",
							onClick: onEdit,
							children: [/* @__PURE__ */ _jsxDEV("i", {
								className: "bi bi-pencil-square me-1",
								"aria-hidden": "true"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 80,
								columnNumber: 17
							}, this), "Edit"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 79,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 76,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 39,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 38,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 37,
		columnNumber: 5
	}, this);
}
_c2 = ItemViewModal;
var _c, _c2;
$RefreshReg$(_c, "Row");
$RefreshReg$(_c2, "ItemViewModal");
if (import.meta.hot && !inWebWorker) {
	window.$RefreshReg$ = prevRefreshReg;
	window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
	RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
		RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/components/ItemViewModal.jsx", currentExports);
		import.meta.hot.accept((nextExports) => {
			if (!nextExports) return;
			const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/components/ItemViewModal.jsx", currentExports, nextExports);
			if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
		});
	});
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsT0FBT0EsV0FBVztBQUNsQixTQUFTQyxXQUFXQyxhQUFhQyxzQkFBc0I7QUFFdkQsU0FBU0MsSUFBSSxFQUFFQyxPQUFPQyxTQUFTO0NBQzdCLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZixDQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQW9CRDtFQUFXOzs7O1lBQzlDLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWFDLFNBQVM7RUFBUzs7OztVQUMzQzs7Ozs7O0FBRVQ7dURBRUFDLEtBVFNIO0FBVVQsZUFBZSxTQUFTSSxjQUFjLEVBQUVDLE1BQU1DLE1BQU1DLFNBQVNDLFFBQVFDLFlBQVk7Q0FDL0UsSUFBSSxDQUFDSixRQUFRLENBQUNDLE1BQU0sT0FBTztDQUUzQixPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO0VBQTBCLFVBQVUsQ0FBQztFQUFHLE1BQUs7RUFBUyxPQUFPLEVBQUVJLFlBQVksc0JBQXNCO0VBQUcsY0FBVztZQUM1SCx3QkFBQyxPQUFEO0dBQUssV0FBVTtHQUFzRSxNQUFLO2FBQ3hGLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFkO1FBQ0Usd0JBQUMsS0FBRDtTQUFHLFdBQVU7U0FBdUMsZUFBWTtRQUFNOzs7OztRQUFBO1FBQzFELHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFnQkosS0FBS0s7UUFBUzs7Ozs7T0FDeEQ7Ozs7O2dCQUNKLHdCQUFDLFVBQUQ7T0FBUSxNQUFLO09BQVMsV0FBVTtPQUFZLGNBQVc7T0FBUSxTQUFTSjtNQUFROzs7O2NBQzdFOzs7Ozs7S0FFTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVcsV0FBV1QsWUFBWVEsS0FBS00saUJBQWlCO21CQUFNTixLQUFLTTtRQUF3Qjs7Ozs7UUFDakcsd0JBQUMsUUFBRDtTQUFNLFdBQVcsV0FBV2IsZUFBZU8sS0FBS08sY0FBYzttQkFBTVAsS0FBS087UUFBcUI7Ozs7O1FBQzdGUCxLQUFLUSxrQkFBa0JDLEtBQUtDLFNBQzNCLHdCQUFDLFFBQUQ7U0FBaUIsV0FBVTtTQUFrQixPQUFPQTttQkFBT0EsS0FBS0MsV0FBVyxLQUFLLEdBQUcsQ0FBQyxDQUFDQyxZQUFZO1FBQVEsR0FBOUZGOzs7O2VBQThGLENBQzFHO09BQ0U7Ozs7O2dCQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsS0FBRDtTQUFLLE9BQU07U0FBZSxPQUFPVixLQUFLYTtRQUFZOzs7OztRQUNsRCx3QkFBQyxLQUFEO1NBQUssT0FBTTtTQUFNLE9BQU9iLEtBQUtjO1FBQUk7Ozs7O1FBQ2pDLHdCQUFDLEtBQUQ7U0FBSyxPQUFNO1NBQVEsT0FBT2QsS0FBS2U7UUFBYTs7Ozs7UUFDNUMsd0JBQUMsS0FBRDtTQUFLLE9BQU07U0FBa0IsT0FBT2YsS0FBS2dCO1FBQWU7Ozs7O1FBQ3hELHdCQUFDLEtBQUQ7U0FBSyxPQUFNO1NBQWMsT0FBTyxHQUFHaEIsS0FBS2lCLGdCQUFlLElBQUtqQixLQUFLa0IsY0FBYTtRQUFJOzs7OztRQUNsRix3QkFBQyxLQUFEO1NBQUssT0FBTTtTQUFTLE9BQU8sR0FBR2xCLEtBQUttQixXQUFVLEtBQU1uQixLQUFLb0IsYUFBWSxJQUFLcEIsS0FBS3FCLFNBQVE7UUFBSTs7Ozs7UUFDMUYsd0JBQUMsS0FBRDtTQUFLLE9BQU07U0FBYSxPQUFPOUIsVUFBVVMsS0FBS3NCLFlBQVk7UUFBRTs7Ozs7UUFDNUQsd0JBQUMsS0FBRDtTQUFLLE9BQU07U0FBaUIsT0FBTy9CLFVBQVVTLEtBQUt1QixzQkFBc0I7UUFBRTs7Ozs7UUFDMUUsd0JBQUMsS0FBRDtTQUFLLE9BQU07U0FBd0IsT0FBT2hDLFVBQVVTLEtBQUt3QixzQkFBc0I7UUFBRTs7Ozs7UUFDakYsd0JBQUMsS0FBRDtTQUFLLE9BQU07U0FBdUIsT0FBT2pDLFVBQVVTLEtBQUt5Qiw2QkFBNkI7UUFBRTs7Ozs7UUFDdkYsd0JBQUMsS0FBRDtTQUFLLE9BQU07U0FBZSxPQUFPekIsS0FBSzBCLGVBQWU7UUFBZ0I7Ozs7O1FBQ3JFLHdCQUFDLEtBQUQ7U0FBSyxPQUFNO1NBQXVCLE9BQU8xQixLQUFLMkIsc0JBQXNCLFFBQVEzQixLQUFLMkIsc0JBQXNCQyxZQUFZLElBQUk1QixLQUFLMkIsb0JBQW9CLElBQUcsQ0FBRUUsUUFBUSxDQUFDLEVBQUMsS0FBTTtRQUFJOzs7OztRQUN6Syx3QkFBQyxLQUFEO1NBQUssT0FBTTtTQUFvQixPQUFPN0IsS0FBSzhCLG1CQUFtQixRQUFROUIsS0FBSzhCLG1CQUFtQkYsWUFBWSxJQUFJNUIsS0FBSzhCLGlCQUFpQixJQUFHLENBQUVELFFBQVEsQ0FBQyxFQUFDLEtBQU07UUFBSTs7Ozs7UUFDN0osd0JBQUMsS0FBRDtTQUFLLE9BQU07U0FBbUIsT0FBTzdCLEtBQUsrQjtRQUFnQjs7Ozs7UUFDMUQsd0JBQUMsS0FBRDtTQUFLLE9BQU07U0FBVSxPQUFPL0IsS0FBS2dDO1FBQW1COzs7OztPQUNqRDs7Ozs7Y0FDRjs7Ozs7O0tBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxVQUFEO09BQVEsTUFBSztPQUFTLFdBQVU7T0FBNEIsU0FBUy9CO2lCQUFTO01BQWE7Ozs7Z0JBQzFGRSxZQUNDLHdCQUFDLFVBQUQ7T0FBUSxNQUFLO09BQVMsV0FBVTtPQUFrQixTQUFTRDtpQkFBM0QsQ0FDRSx3QkFBQyxLQUFEO1FBQUcsV0FBVTtRQUEyQixlQUFZO09BQU07Ozs7aUJBQUEsTUFFcEQ7Ozs7O2NBRVA7Ozs7OztJQUNGOzs7Ozs7RUFDRjs7Ozs7Q0FDRjs7Ozs7QUFFVDtBQUFDK0IsTUF4RHVCbkM7QUFBYSxJQUFBRCxJQUFBb0M7QUFBQSxhQUFBcEMsSUFBQTtBQUFBLGFBQUFvQyxLQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJmb3JtYXRJTlIiLCJzdGF0dXNDbGFzcyIsImF0dGVudGlvbkNsYXNzIiwiUm93IiwibGFiZWwiLCJ2YWx1ZSIsIl9jIiwiSXRlbVZpZXdNb2RhbCIsInNob3ciLCJpdGVtIiwib25DbG9zZSIsIm9uRWRpdCIsImNhbldyaXRlIiwiYmFja2dyb3VuZCIsImlkIiwiYXBwbGljYXRpb25TdGF0dXMiLCJhdHRlbnRpb25MZXZlbCIsImRhdGFRdWFsaXR5RmxhZ3MiLCJtYXAiLCJmbGFnIiwicmVwbGFjZUFsbCIsInRvTG93ZXJDYXNlIiwic3R1ZGVudE5hbWUiLCJhZ2UiLCJzdHVkZW50U3RhdGUiLCJlbXBsb3ltZW50VHlwZSIsImluc3RpdHV0aW9uTmFtZSIsImluc3RpdHV0aW9uSWQiLCJjb3Vyc2VOYW1lIiwiY291cnNlRG9tYWluIiwiY291cnNlSWQiLCJjb3Vyc2VGZWVJbnIiLCJsb2FuQW1vdW50UmVxdWVzdGVkSW5yIiwicGFyZW50TW9udGhseUluY29tZUluciIsImV4aXN0aW5nTW9udGhseU9ibGlnYXRpb25zSW5yIiwiY3JlZGl0U2NvcmUiLCJkZWJ0VG9JbmNvbWVSYXRpbyIsInVuZGVmaW5lZCIsInRvRml4ZWQiLCJsb2FuVG9GZWVSYXRpbyIsImFwcGxpY2F0aW9uRGF0ZSIsImFwcGxpY2F0aW9uQ2hhbm5lbCIsIl9jMiJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJJdGVtVmlld01vZGFsLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBmb3JtYXRJTlIsIHN0YXR1c0NsYXNzLCBhdHRlbnRpb25DbGFzcyB9IGZyb20gXCIuLi9hcGkvaXRlbXMuanNcIjtcblxuZnVuY3Rpb24gUm93KHsgbGFiZWwsIHZhbHVlIH0pIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC0xMiBjb2wtbWQtNiBtYi0yXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtYWxsIHRleHQtbXV0ZWRcIj57bGFiZWx9PC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZ3LW1lZGl1bVwiPnt2YWx1ZSA/PyBcIuKAlFwifTwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufVxuXG4vKiogUmVhZC1vbmx5IGRldGFpbHMgbW9kYWwgZm9yIGEgbG9hbiBhcHBsaWNhdGlvbi4gKi9cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEl0ZW1WaWV3TW9kYWwoeyBzaG93LCBpdGVtLCBvbkNsb3NlLCBvbkVkaXQsIGNhbldyaXRlIH0pIHtcbiAgaWYgKCFzaG93IHx8ICFpdGVtKSByZXR1cm4gbnVsbDtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwibW9kYWwgZmFkZSBzaG93IGQtYmxvY2tcIiB0YWJJbmRleD17LTF9IHJvbGU9XCJkaWFsb2dcIiBzdHlsZT17eyBiYWNrZ3JvdW5kOiBcInJnYmEoMTUsMjMsNDIsMC40NSlcIiB9fSBhcmlhLW1vZGFsPVwidHJ1ZVwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtb2RhbC1kaWFsb2cgbW9kYWwtbGcgbW9kYWwtZGlhbG9nLWNlbnRlcmVkIG1vZGFsLWRpYWxvZy1zY3JvbGxhYmxlXCIgcm9sZT1cImRvY3VtZW50XCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibW9kYWwtY29udGVudFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibW9kYWwtaGVhZGVyXCI+XG4gICAgICAgICAgICA8aDUgY2xhc3NOYW1lPVwibW9kYWwtdGl0bGUgZC1mbGV4IGFsaWduLWl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICA8aSBjbGFzc05hbWU9XCJiaSBiaS1maWxlLWVhcm1hcmstdGV4dCB0ZXh0LWRoYW5pdGlcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgICAgICBBcHBsaWNhdGlvbiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWRoYW5pdGlcIj57aXRlbS5pZH08L3NwYW4+XG4gICAgICAgICAgICA8L2g1PlxuICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwiYnRuLWNsb3NlXCIgYXJpYS1sYWJlbD1cIkNsb3NlXCIgb25DbGljaz17b25DbG9zZX0gLz5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibW9kYWwtYm9keVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkLWZsZXggZmxleC13cmFwIGdhcC0yIG1iLTNcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgZHEtcGlsbCAke3N0YXR1c0NsYXNzKGl0ZW0uYXBwbGljYXRpb25TdGF0dXMpfWB9PntpdGVtLmFwcGxpY2F0aW9uU3RhdHVzfTwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgZHEtcGlsbCAke2F0dGVudGlvbkNsYXNzKGl0ZW0uYXR0ZW50aW9uTGV2ZWwpfWB9PntpdGVtLmF0dGVudGlvbkxldmVsfTwvc3Bhbj5cbiAgICAgICAgICAgICAge2l0ZW0uZGF0YVF1YWxpdHlGbGFncz8ubWFwKChmbGFnKSA9PiAoXG4gICAgICAgICAgICAgICAgPHNwYW4ga2V5PXtmbGFnfSBjbGFzc05hbWU9XCJkcS1waWxsIGRxLWZsYWdcIiB0aXRsZT17ZmxhZ30+e2ZsYWcucmVwbGFjZUFsbChcIl9cIiwgXCIgXCIpLnRvTG93ZXJDYXNlKCl9PC9zcGFuPlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvd1wiPlxuICAgICAgICAgICAgICA8Um93IGxhYmVsPVwiU3R1ZGVudCBuYW1lXCIgdmFsdWU9e2l0ZW0uc3R1ZGVudE5hbWV9IC8+XG4gICAgICAgICAgICAgIDxSb3cgbGFiZWw9XCJBZ2VcIiB2YWx1ZT17aXRlbS5hZ2V9IC8+XG4gICAgICAgICAgICAgIDxSb3cgbGFiZWw9XCJTdGF0ZVwiIHZhbHVlPXtpdGVtLnN0dWRlbnRTdGF0ZX0gLz5cbiAgICAgICAgICAgICAgPFJvdyBsYWJlbD1cIkVtcGxveW1lbnQgdHlwZVwiIHZhbHVlPXtpdGVtLmVtcGxveW1lbnRUeXBlfSAvPlxuICAgICAgICAgICAgICA8Um93IGxhYmVsPVwiSW5zdGl0dXRpb25cIiB2YWx1ZT17YCR7aXRlbS5pbnN0aXR1dGlvbk5hbWV9ICgke2l0ZW0uaW5zdGl0dXRpb25JZH0pYH0gLz5cbiAgICAgICAgICAgICAgPFJvdyBsYWJlbD1cIkNvdXJzZVwiIHZhbHVlPXtgJHtpdGVtLmNvdXJzZU5hbWV9IOKAlCAke2l0ZW0uY291cnNlRG9tYWlufSAoJHtpdGVtLmNvdXJzZUlkfSlgfSAvPlxuICAgICAgICAgICAgICA8Um93IGxhYmVsPVwiQ291cnNlIGZlZVwiIHZhbHVlPXtmb3JtYXRJTlIoaXRlbS5jb3Vyc2VGZWVJbnIpfSAvPlxuICAgICAgICAgICAgICA8Um93IGxhYmVsPVwiTG9hbiByZXF1ZXN0ZWRcIiB2YWx1ZT17Zm9ybWF0SU5SKGl0ZW0ubG9hbkFtb3VudFJlcXVlc3RlZElucil9IC8+XG4gICAgICAgICAgICAgIDxSb3cgbGFiZWw9XCJQYXJlbnQgbW9udGhseSBpbmNvbWVcIiB2YWx1ZT17Zm9ybWF0SU5SKGl0ZW0ucGFyZW50TW9udGhseUluY29tZUlucil9IC8+XG4gICAgICAgICAgICAgIDxSb3cgbGFiZWw9XCJFeGlzdGluZyBvYmxpZ2F0aW9uc1wiIHZhbHVlPXtmb3JtYXRJTlIoaXRlbS5leGlzdGluZ01vbnRobHlPYmxpZ2F0aW9uc0lucil9IC8+XG4gICAgICAgICAgICAgIDxSb3cgbGFiZWw9XCJDcmVkaXQgc2NvcmVcIiB2YWx1ZT17aXRlbS5jcmVkaXRTY29yZSA/PyBcIk4vQSAobWlzc2luZylcIn0gLz5cbiAgICAgICAgICAgICAgPFJvdyBsYWJlbD1cIkRlYnQtdG8taW5jb21lIHJhdGlvXCIgdmFsdWU9e2l0ZW0uZGVidFRvSW5jb21lUmF0aW8gIT09IG51bGwgJiYgaXRlbS5kZWJ0VG9JbmNvbWVSYXRpbyAhPT0gdW5kZWZpbmVkID8gYCR7KGl0ZW0uZGVidFRvSW5jb21lUmF0aW8gKiAxMDApLnRvRml4ZWQoMSl9JWAgOiBcIuKAlFwifSAvPlxuICAgICAgICAgICAgICA8Um93IGxhYmVsPVwiTG9hbi10by1mZWUgcmF0aW9cIiB2YWx1ZT17aXRlbS5sb2FuVG9GZWVSYXRpbyAhPT0gbnVsbCAmJiBpdGVtLmxvYW5Ub0ZlZVJhdGlvICE9PSB1bmRlZmluZWQgPyBgJHsoaXRlbS5sb2FuVG9GZWVSYXRpbyAqIDEwMCkudG9GaXhlZCgxKX0lYCA6IFwi4oCUXCJ9IC8+XG4gICAgICAgICAgICAgIDxSb3cgbGFiZWw9XCJBcHBsaWNhdGlvbiBkYXRlXCIgdmFsdWU9e2l0ZW0uYXBwbGljYXRpb25EYXRlfSAvPlxuICAgICAgICAgICAgICA8Um93IGxhYmVsPVwiQ2hhbm5lbFwiIHZhbHVlPXtpdGVtLmFwcGxpY2F0aW9uQ2hhbm5lbH0gLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtb2RhbC1mb290ZXJcIj5cbiAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImJ0biBidG4tb3V0bGluZS1zZWNvbmRhcnlcIiBvbkNsaWNrPXtvbkNsb3NlfT5DbG9zZTwvYnV0dG9uPlxuICAgICAgICAgICAge2NhbldyaXRlICYmIChcbiAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwiYnRuIGJ0bi1kaGFuaXRpXCIgb25DbGljaz17b25FZGl0fT5cbiAgICAgICAgICAgICAgICA8aSBjbGFzc05hbWU9XCJiaSBiaS1wZW5jaWwtc3F1YXJlIG1lLTFcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgICAgICAgIEVkaXRcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiJDOi9Vc2Vycy91c2VyL0Rvd25sb2Fkcy9kaGFuaXRpLWFwcC11cGdyYWRlZC9kaGFuaXRpLWFwcC9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9JdGVtVmlld01vZGFsLmpzeCJ9