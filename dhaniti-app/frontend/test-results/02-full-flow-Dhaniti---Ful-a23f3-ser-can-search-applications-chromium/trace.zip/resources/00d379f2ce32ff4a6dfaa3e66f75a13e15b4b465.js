import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Login.jsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport1_react_jsxDevRuntime["Fragment"];const React = __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];import * as RefreshRuntime from "/@react-refresh";
var _jsxFileName = "C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/pages/Login.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=325d36c7";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
	if (!window.$RefreshReg$) {
		throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong.");
	}
	prevRefreshReg = window.$RefreshReg$;
	prevRefreshSig = window.$RefreshSig$;
	window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/pages/Login.jsx");
	window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=325d36c7";
import { Link, useLocation, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=325d36c7";
import { useAuth } from "/src/context/AuthContext.jsx";
import { useToast } from "/src/context/ToastContext.jsx";
import { authApi } from "/src/api/auth.js";
import { ApiError } from "/src/api/client.js";
export default function Login() {
	_s();
	const { login, notice, setNotice, isAuthenticated } = useAuth();
	const toast = useToast();
	const navigate = useNavigate();
	const location = useLocation();
	const [email, setEmail] = useState("");
	const [password, setPassword] = useState("");
	const [remember, setRemember] = useState(false);
	const [showPassword, setShowPassword] = useState(false);
	const [loading, setLoading] = useState(false);
	const [errors, setErrors] = useState({});
	const [apiError, setApiError] = useState("");
	const [providers, setProviders] = useState({
		google: false,
		github: false
	});
	useEffect(() => {
		authApi.oauthProviders().then(setProviders).catch(() => setProviders({
			google: false,
			github: false
		}));
	}, []);
	// Already signed in? Straight to the dashboard.
	useEffect(() => {
		if (isAuthenticated) {
			navigate(location.state?.from || "/dashboard", { replace: true });
		}
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [isAuthenticated]);
	useEffect(() => {
		if (notice) {
			setApiError(notice);
			setNotice("");
		}
	}, [notice, setNotice]);
	function validate() {
		const next = {};
		if (!email.trim()) next.email = "Email address is required.";
		else if (!/^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$/.test(email.trim())) next.email = "Invalid email address.";
		if (!password) next.password = "Password is required.";
		setErrors(next);
		return Object.keys(next).length === 0;
	}
	async function handleSubmit(e) {
		e.preventDefault();
		setApiError("");
		if (!validate()) return;
		setLoading(true);
		try {
			await login(email.trim(), password, remember);
			toast.success("Login successful. Welcome back!");
			navigate(location.state?.from || "/dashboard", { replace: true });
		} catch (err) {
			if (err instanceof ApiError && err.status === 403) {
				// Unverified email → the backend sent a fresh verification code.
				setApiError(err.message);
				setTimeout(() => navigate("/verify-otp", { state: {
					email: email.trim(),
					purpose: "email_verification"
				} }), 900);
			} else {
				setApiError(err.message || "Login failed. Please try again.");
			}
		} finally {
			setLoading(false);
		}
	}
	function handleOtpLogin() {
		if (!email.trim()) {
			setErrors({ email: "Enter your email above first, then use the code login." });
			return;
		}
		navigate("/verify-otp", { state: {
			email: email.trim(),
			purpose: "login",
			sendNow: true
		} });
	}
	const providerClick = (path) => {
		if (!window.location.origin.startsWith("http")) return;
		window.location.href = path;
	};
	const providerDisabled = (key) => !providers[key];
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "login-wrapper",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "card login-card",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "card-header text-center",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "d-flex align-items-center justify-content-center gap-2 mb-2",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								style: {
									display: "inline-flex",
									alignItems: "center",
									justifyContent: "center",
									width: 40,
									height: 40,
									borderRadius: 10,
									background: "linear-gradient(135deg, #0f766e 0%, #134e4a 100%)",
									color: "white",
									fontWeight: 700,
									fontSize: 20
								},
								children: "D"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 116,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("h4", {
								className: "mb-0 text-dhaniti",
								children: "Dhaniti"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 132,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 115,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-muted small mb-0",
							children: "Education Loan Dashboard"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 134,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("h5", {
							className: "mt-3 mb-0 fw-semibold",
							children: "Welcome Back"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 135,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-muted small",
							children: "Sign in to continue to your dashboard"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 136,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 114,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "card-body p-4",
					children: [
						apiError && /* @__PURE__ */ _jsxDEV("div", {
							className: "alert alert-danger py-2",
							role: "alert",
							"data-testid": "login-error",
							children: apiError
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 141,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("form", {
							onSubmit: handleSubmit,
							noValidate: true,
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "mb-3",
									children: [
										/* @__PURE__ */ _jsxDEV("label", {
											htmlFor: "email",
											className: "form-label",
											children: "Email"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 148,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("input", {
											type: "email",
											className: `form-control ${errors.email ? "is-invalid" : ""}`,
											id: "email",
											value: email,
											onChange: (e) => setEmail(e.target.value),
											autoComplete: "username",
											placeholder: "you@company.com",
											disabled: loading
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 149,
											columnNumber: 15
										}, this),
										errors.email && /* @__PURE__ */ _jsxDEV("div", {
											className: "invalid-feedback",
											children: errors.email
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 159,
											columnNumber: 32
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 147,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "mb-3",
									children: [/* @__PURE__ */ _jsxDEV("label", {
										htmlFor: "password",
										className: "form-label d-flex justify-content-between",
										children: "Password"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 163,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "input-group",
										children: [
											/* @__PURE__ */ _jsxDEV("input", {
												type: showPassword ? "text" : "password",
												className: `form-control ${errors.password ? "is-invalid" : ""}`,
												id: "password",
												value: password,
												onChange: (e) => setPassword(e.target.value),
												autoComplete: "current-password",
												placeholder: "Your password",
												disabled: loading
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 167,
												columnNumber: 17
											}, this),
											/* @__PURE__ */ _jsxDEV("button", {
												className: "btn btn-outline-secondary",
												type: "button",
												onClick: () => setShowPassword((s) => !s),
												"aria-label": showPassword ? "Hide password" : "Show password",
												tabIndex: -1,
												children: /* @__PURE__ */ _jsxDEV("i", {
													className: `bi ${showPassword ? "bi-eye-slash" : "bi-eye"}`,
													"aria-hidden": "true"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 184,
													columnNumber: 19
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 177,
												columnNumber: 17
											}, this),
											errors.password && /* @__PURE__ */ _jsxDEV("div", {
												className: "invalid-feedback d-block",
												children: errors.password
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 186,
												columnNumber: 37
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 166,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 162,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "d-flex justify-content-between align-items-center mb-4",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "form-check",
										children: [/* @__PURE__ */ _jsxDEV("input", {
											className: "form-check-input",
											type: "checkbox",
											id: "remember",
											checked: remember,
											onChange: (e) => setRemember(e.target.checked)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 192,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("label", {
											className: "form-check-label small",
											htmlFor: "remember",
											children: "Remember me"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 199,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 191,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV(Link, {
										to: "/forgot-password",
										className: "small",
										children: "Forgot password?"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 201,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 190,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "submit",
									className: "btn btn-dhaniti w-100",
									disabled: loading,
									children: loading ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "spinner-border spinner-border-sm me-2",
										role: "status",
										"aria-hidden": "true"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 207,
										columnNumber: 19
									}, this), "Logging in…"] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 206,
										columnNumber: 15
									}, this) : "LOGIN"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 204,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 146,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "d-flex align-items-center my-3",
							children: [
								/* @__PURE__ */ _jsxDEV("hr", { className: "flex-grow-1" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 217,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "px-2 text-muted small",
									children: "OR"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 218,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("hr", { className: "flex-grow-1" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 219,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 216,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "d-grid gap-2",
							children: [
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									className: "btn btn-outline-secondary",
									onClick: () => providerClick("/auth/google"),
									disabled: providerDisabled("google"),
									title: providerDisabled("google") ? "Google sign-in is not configured on this server" : "Continue with Google",
									children: [/* @__PURE__ */ _jsxDEV("svg", {
										width: "16",
										height: "16",
										viewBox: "0 0 18 18",
										"aria-hidden": "true",
										className: "me-2",
										children: [
											/* @__PURE__ */ _jsxDEV("path", {
												fill: "#4285F4",
												d: "M17.64 9.2c0-.64-.06-1.25-.16-1.84H9v3.48h4.84a4.14 4.14 0 0 1-1.8 2.72v2.26h2.92c1.7-1.57 2.68-3.88 2.68-6.62z"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 231,
												columnNumber: 17
											}, this),
											/* @__PURE__ */ _jsxDEV("path", {
												fill: "#34A853",
												d: "M9 18c2.43 0 4.47-.8 5.96-2.18l-2.92-2.26c-.8.54-1.84.86-3.04.86-2.34 0-4.32-1.58-5.03-3.7H.96v2.33A8.99 8.99 0 0 0 9 18z"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 232,
												columnNumber: 17
											}, this),
											/* @__PURE__ */ _jsxDEV("path", {
												fill: "#FBBC05",
												d: "M3.97 10.72a5.4 5.4 0 0 1 0-3.44V4.95H.96a9 9 0 0 0 0 8.1l3.01-2.33z"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 233,
												columnNumber: 17
											}, this),
											/* @__PURE__ */ _jsxDEV("path", {
												fill: "#EA4335",
												d: "M9 3.58c1.32 0 2.5.45 3.44 1.35l2.58-2.59C13.46.89 11.43 0 9 0A8.99 8.99 0 0 0 .96 4.95l3.01 2.33C4.68 5.16 6.66 3.58 9 3.58z"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 234,
												columnNumber: 17
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 230,
										columnNumber: 15
									}, this), "Continue with Google"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 223,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									className: "btn btn-outline-secondary",
									onClick: () => providerClick("/auth/github"),
									disabled: providerDisabled("github"),
									title: providerDisabled("github") ? "GitHub sign-in is not configured on this server" : "Continue with GitHub",
									children: [/* @__PURE__ */ _jsxDEV("i", {
										className: "bi bi-github me-2",
										"aria-hidden": "true"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 245,
										columnNumber: 15
									}, this), "Continue with GitHub"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 238,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									className: "btn btn-outline-dhaniti",
									onClick: handleOtpLogin,
									children: [/* @__PURE__ */ _jsxDEV("i", {
										className: "bi bi-shield-lock me-2",
										"aria-hidden": "true"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 249,
										columnNumber: 15
									}, this), "Login with OTP"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 248,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 222,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-center small mt-4 mb-0",
							children: ["Don't have an account? ", /* @__PURE__ */ _jsxDEV(Link, {
								to: "/register",
								children: "Register"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 255,
								columnNumber: 41
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 254,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 139,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "card-footer text-center text-muted small py-2",
					children: /* @__PURE__ */ _jsxDEV("details", {
						className: "text-start",
						children: [/* @__PURE__ */ _jsxDEV("summary", {
							className: "cursor-pointer",
							children: "Demo credentials (development)"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 261,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "mt-2",
							children: [
								/* @__PURE__ */ _jsxDEV("div", { children: [
									/* @__PURE__ */ _jsxDEV("code", { children: "admin@dhaniti.ai" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 263,
										columnNumber: 20
									}, this),
									" / ",
									/* @__PURE__ */ _jsxDEV("code", { children: "DhanitiAdmin@123" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 263,
										columnNumber: 52
									}, this),
									" — Admin"
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 263,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [
									/* @__PURE__ */ _jsxDEV("code", { children: "underwriter@dhaniti.ai" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 264,
										columnNumber: 20
									}, this),
									" / ",
									/* @__PURE__ */ _jsxDEV("code", { children: "Underwriter@123" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 264,
										columnNumber: 58
									}, this),
									" — Underwriter"
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 264,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [
									/* @__PURE__ */ _jsxDEV("code", { children: "analyst@dhaniti.ai" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 265,
										columnNumber: 20
									}, this),
									" / ",
									/* @__PURE__ */ _jsxDEV("code", { children: "Analyst@123" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 265,
										columnNumber: 54
									}, this),
									" — read-only"
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 265,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 262,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 260,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 259,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 113,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 112,
		columnNumber: 5
	}, this);
}
_s(Login, "RE12qZnPJlO9M/ELgABrfUt8Mrw=", false, function() {
	return [
		useAuth,
		useToast,
		useNavigate,
		useLocation
	];
});
_c = Login;
var _c;
$RefreshReg$(_c, "Login");
if (import.meta.hot && !inWebWorker) {
	window.$RefreshReg$ = prevRefreshReg;
	window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
	RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
		RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/pages/Login.jsx", currentExports);
		import.meta.hot.accept((nextExports) => {
			if (!nextExports) return;
			const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/pages/Login.jsx", currentExports, nextExports);
			if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
		});
	});
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLE9BQU9BLFNBQVNDLFdBQVdDLGdCQUFnQjtBQUMzQyxTQUFTQyxNQUFNQyxhQUFhQyxtQkFBbUI7QUFDL0MsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxnQkFBZ0I7QUFFekIsZUFBZSxTQUFTQyxRQUFRO0NBQUFDLEdBQUE7Q0FDOUIsTUFBTSxFQUFFQyxPQUFPQyxRQUFRQyxXQUFXQyxvQkFBb0JULFFBQVE7Q0FDOUQsTUFBTVUsUUFBUVQsU0FBUztDQUN2QixNQUFNVSxXQUFXWixZQUFZO0NBQzdCLE1BQU1hLFdBQVdkLFlBQVk7Q0FFN0IsTUFBTSxDQUFDZSxPQUFPQyxZQUFZbEIsU0FBUyxFQUFFO0NBQ3JDLE1BQU0sQ0FBQ21CLFVBQVVDLGVBQWVwQixTQUFTLEVBQUU7Q0FDM0MsTUFBTSxDQUFDcUIsVUFBVUMsZUFBZXRCLFNBQVMsS0FBSztDQUM5QyxNQUFNLENBQUN1QixjQUFjQyxtQkFBbUJ4QixTQUFTLEtBQUs7Q0FDdEQsTUFBTSxDQUFDeUIsU0FBU0MsY0FBYzFCLFNBQVMsS0FBSztDQUM1QyxNQUFNLENBQUMyQixRQUFRQyxhQUFhNUIsU0FBUyxDQUFDLENBQUM7Q0FDdkMsTUFBTSxDQUFDNkIsVUFBVUMsZUFBZTlCLFNBQVMsRUFBRTtDQUMzQyxNQUFNLENBQUMrQixXQUFXQyxnQkFBZ0JoQyxTQUFTO0VBQUVpQyxRQUFRO0VBQU9DLFFBQVE7Q0FBTSxDQUFDO0NBRTNFbkMsZ0JBQWdCO0VBQ2RPLFFBQ0c2QixlQUFlLENBQUMsQ0FDaEJDLEtBQUtKLFlBQVksQ0FBQyxDQUNsQkssWUFBWUwsYUFBYTtHQUFFQyxRQUFRO0dBQU9DLFFBQVE7RUFBTSxDQUFDLENBQUM7Q0FDL0QsR0FBRyxFQUFFOztDQUdMbkMsZ0JBQWdCO0VBQ2QsSUFBSWMsaUJBQWlCO0dBQ25CRSxTQUFTQyxTQUFTc0IsT0FBT0MsUUFBUSxjQUFjLEVBQUVDLFNBQVMsS0FBSyxDQUFDO0VBQ2xFOztDQUVGLEdBQUcsQ0FBQzNCLGVBQWUsQ0FBQztDQUVwQmQsZ0JBQWdCO0VBQ2QsSUFBSVksUUFBUTtHQUNWbUIsWUFBWW5CLE1BQU07R0FDbEJDLFVBQVUsRUFBRTtFQUNkO0NBQ0YsR0FBRyxDQUFDRCxRQUFRQyxTQUFTLENBQUM7Q0FFdEIsU0FBUzZCLFdBQVc7RUFDbEIsTUFBTUMsT0FBTyxDQUFDO0VBQ2QsSUFBSSxDQUFDekIsTUFBTTBCLEtBQUssR0FBR0QsS0FBS3pCLFFBQVE7T0FDM0IsSUFBSSxDQUFDLHFEQUFxRDJCLEtBQUszQixNQUFNMEIsS0FBSyxDQUFDLEdBQzlFRCxLQUFLekIsUUFBUTtFQUNmLElBQUksQ0FBQ0UsVUFBVXVCLEtBQUt2QixXQUFXO0VBQy9CUyxVQUFVYyxJQUFJO0VBQ2QsT0FBT0csT0FBT0MsS0FBS0osSUFBSSxDQUFDLENBQUNLLFdBQVc7Q0FDdEM7Q0FFQSxlQUFlQyxhQUFhQyxHQUFHO0VBQzdCQSxFQUFFQyxlQUFlO0VBQ2pCcEIsWUFBWSxFQUFFO0VBQ2QsSUFBSSxDQUFDVyxTQUFTLEdBQUc7RUFDakJmLFdBQVcsSUFBSTtFQUNmLElBQUk7R0FDRixNQUFNaEIsTUFBTU8sTUFBTTBCLEtBQUssR0FBR3hCLFVBQVVFLFFBQVE7R0FDNUNQLE1BQU1xQyxRQUFRLGlDQUFpQztHQUMvQ3BDLFNBQVNDLFNBQVNzQixPQUFPQyxRQUFRLGNBQWMsRUFBRUMsU0FBUyxLQUFLLENBQUM7RUFDbEUsU0FBU1ksS0FBSztHQUNaLElBQUlBLGVBQWU3QyxZQUFZNkMsSUFBSUMsV0FBVyxLQUFLOztJQUVqRHZCLFlBQVlzQixJQUFJRSxPQUFPO0lBQ3ZCQyxpQkFBaUJ4QyxTQUFTLGVBQWUsRUFBRXVCLE9BQU87S0FBRXJCLE9BQU9BLE1BQU0wQixLQUFLO0tBQUdhLFNBQVM7SUFBcUIsRUFBRSxDQUFDLEdBQUcsR0FBRztHQUNsSCxPQUFPO0lBQ0wxQixZQUFZc0IsSUFBSUUsV0FBVyxpQ0FBaUM7R0FDOUQ7RUFDRixVQUFVO0dBQ1I1QixXQUFXLEtBQUs7RUFDbEI7Q0FDRjtDQUVBLFNBQVMrQixpQkFBaUI7RUFDeEIsSUFBSSxDQUFDeEMsTUFBTTBCLEtBQUssR0FBRztHQUNqQmYsVUFBVSxFQUFFWCxPQUFPLHlEQUF5RCxDQUFDO0dBQzdFO0VBQ0Y7RUFDQUYsU0FBUyxlQUFlLEVBQUV1QixPQUFPO0dBQUVyQixPQUFPQSxNQUFNMEIsS0FBSztHQUFHYSxTQUFTO0dBQVNFLFNBQVM7RUFBSyxFQUFFLENBQUM7Q0FDN0Y7Q0FFQSxNQUFNQyxpQkFBaUJDLFNBQVM7RUFDOUIsSUFBSSxDQUFDQyxPQUFPN0MsU0FBUzhDLE9BQU9DLFdBQVcsTUFBTSxHQUFHO0VBQ2hERixPQUFPN0MsU0FBU2dELE9BQU9KO0NBQ3pCO0NBRUEsTUFBTUssb0JBQW9CQyxRQUFRLENBQUNuQyxVQUFVbUM7Q0FFN0MsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUNiLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1FBQ0UsT0FBTztTQUNMQyxTQUFTO1NBQ1RDLFlBQVk7U0FDWkMsZ0JBQWdCO1NBQ2hCQyxPQUFPO1NBQ1BDLFFBQVE7U0FDUkMsY0FBYztTQUNkQyxZQUFZO1NBQ1pDLE9BQU87U0FDUEMsWUFBWTtTQUNaQyxVQUFVO1FBQ1o7a0JBQUU7T0FHRTs7OztpQkFDTix3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBb0I7T0FBVzs7OztlQUMxQzs7Ozs7O01BQ0wsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQXdCO01BQTJCOzs7OztNQUNoRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBd0I7TUFBZ0I7Ozs7O01BQ3RELHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFtQjtNQUF3Qzs7Ozs7S0FDckU7Ozs7OztJQUVMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRy9DLFlBQ0Msd0JBQUMsT0FBRDtPQUFLLFdBQVU7T0FBMEIsTUFBSztPQUFRLGVBQVk7aUJBQy9EQTtNQUNFOzs7OztNQUdQLHdCQUFDLFFBQUQ7T0FBTSxVQUFVbUI7T0FBYztpQkFBOUI7UUFDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUNFLHdCQUFDLFNBQUQ7V0FBTyxTQUFRO1dBQVEsV0FBVTtxQkFBYTtVQUFZOzs7OztVQUMxRCx3QkFBQyxTQUFEO1dBQ0UsTUFBSztXQUNMLFdBQVcsZ0JBQWdCckIsT0FBT1YsUUFBUSxlQUFlO1dBQ3pELElBQUc7V0FDSCxPQUFPQTtXQUNQLFdBQVdnQyxNQUFNL0IsU0FBUytCLEVBQUU0QixPQUFPQyxLQUFLO1dBQ3hDLGNBQWE7V0FDYixhQUFZO1dBQ1osVUFBVXJEO1VBQVE7Ozs7O1VBRW5CRSxPQUFPVixTQUFTLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFvQlUsT0FBT1Y7VUFBVzs7Ozs7U0FDbkU7Ozs7OztRQUVMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsU0FBRDtVQUFPLFNBQVE7VUFBVyxXQUFVO29CQUEyQztTQUV4RTs7OzttQkFDUCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZjtXQUNFLHdCQUFDLFNBQUQ7WUFDRSxNQUFNTSxlQUFlLFNBQVM7WUFDOUIsV0FBVyxnQkFBZ0JJLE9BQU9SLFdBQVcsZUFBZTtZQUM1RCxJQUFHO1lBQ0gsT0FBT0E7WUFDUCxXQUFXOEIsTUFBTTdCLFlBQVk2QixFQUFFNEIsT0FBT0MsS0FBSztZQUMzQyxjQUFhO1lBQ2IsYUFBWTtZQUNaLFVBQVVyRDtXQUFROzs7OztXQUVwQix3QkFBQyxVQUFEO1lBQ0UsV0FBVTtZQUNWLE1BQUs7WUFDTCxlQUFlRCxpQkFBaUJ1RCxNQUFNLENBQUNBLENBQUM7WUFDeEMsY0FBWXhELGVBQWUsa0JBQWtCO1lBQzdDLFVBQVUsQ0FBQztzQkFFWCx3QkFBQyxLQUFEO2FBQUcsV0FBVyxNQUFNQSxlQUFlLGlCQUFpQjthQUFZLGVBQVk7WUFBTTs7Ozs7V0FDNUU7Ozs7O1dBQ1BJLE9BQU9SLFlBQVksd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQTRCUSxPQUFPUjtXQUFjOzs7OztVQUNqRjs7Ozs7aUJBQ0Y7Ozs7OztRQUVMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxTQUFEO1dBQ0UsV0FBVTtXQUNWLE1BQUs7V0FDTCxJQUFHO1dBQ0gsU0FBU0U7V0FDVCxXQUFXNEIsTUFBTTNCLFlBQVkyQixFQUFFNEIsT0FBT0csT0FBTztVQUFFOzs7O29CQUVqRCx3QkFBQyxTQUFEO1dBQU8sV0FBVTtXQUF5QixTQUFRO3FCQUFXO1VBQWtCOzs7O2tCQUM1RTs7Ozs7bUJBQ0wsd0JBQUMsTUFBRDtVQUFNLElBQUc7VUFBbUIsV0FBVTtvQkFBUTtTQUFzQjs7OztpQkFDakU7Ozs7OztRQUVMLHdCQUFDLFVBQUQ7U0FBUSxNQUFLO1NBQVMsV0FBVTtTQUF3QixVQUFVdkQ7bUJBQy9EQSxVQUNDLGdEQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO1VBQXdDLE1BQUs7VUFBUyxlQUFZO1NBQU07Ozs7bUJBQUEsYUFFMUY7Ozs7b0JBRUE7UUFFSTs7Ozs7T0FDSjs7Ozs7O01BRU4sd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxNQUFELEVBQUksV0FBVSxjQUFhOzs7OztRQUMzQix3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBd0I7UUFBUTs7Ozs7UUFDaEQsd0JBQUMsTUFBRCxFQUFJLFdBQVUsY0FBYTs7Ozs7T0FDeEI7Ozs7OztNQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsVUFBRDtTQUNFLE1BQUs7U0FDTCxXQUFVO1NBQ1YsZUFBZWtDLGNBQWMsY0FBYztTQUMzQyxVQUFVTSxpQkFBaUIsUUFBUTtTQUNuQyxPQUFPQSxpQkFBaUIsUUFBUSxJQUFJLG9EQUFvRDttQkFMMUYsQ0FPRSx3QkFBQyxPQUFEO1VBQUssT0FBTTtVQUFLLFFBQU87VUFBSyxTQUFRO1VBQVksZUFBWTtVQUFPLFdBQVU7b0JBQTdFO1dBQ0Usd0JBQUMsUUFBRDtZQUFNLE1BQUs7WUFBVSxHQUFFO1dBQWlIOzs7OztXQUN4SSx3QkFBQyxRQUFEO1lBQU0sTUFBSztZQUFVLEdBQUU7V0FBMkg7Ozs7O1dBQ2xKLHdCQUFDLFFBQUQ7WUFBTSxNQUFLO1lBQVUsR0FBRTtXQUFzRTs7Ozs7V0FDN0Ysd0JBQUMsUUFBRDtZQUFNLE1BQUs7WUFBVSxHQUFFO1dBQStIOzs7OztVQUNuSjs7Ozs7bUJBQUEsc0JBRUM7Ozs7OztRQUNSLHdCQUFDLFVBQUQ7U0FDRSxNQUFLO1NBQ0wsV0FBVTtTQUNWLGVBQWVOLGNBQWMsY0FBYztTQUMzQyxVQUFVTSxpQkFBaUIsUUFBUTtTQUNuQyxPQUFPQSxpQkFBaUIsUUFBUSxJQUFJLG9EQUFvRDttQkFMMUYsQ0FPRSx3QkFBQyxLQUFEO1VBQUcsV0FBVTtVQUFvQixlQUFZO1NBQU07Ozs7bUJBQUEsc0JBRTdDOzs7Ozs7UUFDUix3QkFBQyxVQUFEO1NBQVEsTUFBSztTQUFTLFdBQVU7U0FBMEIsU0FBU1I7bUJBQW5FLENBQ0Usd0JBQUMsS0FBRDtVQUFHLFdBQVU7VUFBeUIsZUFBWTtTQUFNOzs7O21CQUFBLGdCQUVsRDs7Ozs7O09BQ0w7Ozs7OztNQUVMLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFiLENBQTBDLDJCQUNaLHdCQUFDLE1BQUQ7UUFBTSxJQUFHO2tCQUFZO09BQWM7Ozs7ZUFDOUQ7Ozs7OztLQUNBOzs7Ozs7SUFFTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLFdBQUQ7TUFBUyxXQUFVO2dCQUFuQixDQUNFLHdCQUFDLFdBQUQ7T0FBUyxXQUFVO2lCQUFpQjtNQUF1Qzs7OztnQkFDM0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxPQUFEO1NBQUssd0JBQUMsUUFBRCxZQUFNLG1CQUFzQjs7Ozs7U0FBQztTQUFHLHdCQUFDLFFBQUQsWUFBTSxtQkFBc0I7Ozs7O1NBQUM7UUFBYTs7Ozs7UUFDL0Usd0JBQUMsT0FBRDtTQUFLLHdCQUFDLFFBQUQsWUFBTSx5QkFBNEI7Ozs7O1NBQUM7U0FBRyx3QkFBQyxRQUFELFlBQU0sa0JBQXFCOzs7OztTQUFDO1FBQW1COzs7OztRQUMxRix3QkFBQyxPQUFEO1NBQUssd0JBQUMsUUFBRCxZQUFNLHFCQUF3Qjs7Ozs7U0FBQztTQUFHLHdCQUFDLFFBQUQsWUFBTSxjQUFpQjs7Ozs7U0FBQztRQUFpQjs7Ozs7T0FDN0U7Ozs7O2NBQ0U7Ozs7OztJQUNOOzs7OztHQUNGOzs7Ozs7Q0FDRjs7Ozs7QUFFVDtBQUFDaEQsR0FyUHVCRCxPQUFLO0NBQUE7RUFDMkJKO0VBQ3hDQztFQUNHRjtFQUNBRDtDQUFXO0FBQUE7QUFBQSxLQUpOTTtBQUFLLElBQUF5RTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiTGluayIsInVzZUxvY2F0aW9uIiwidXNlTmF2aWdhdGUiLCJ1c2VBdXRoIiwidXNlVG9hc3QiLCJhdXRoQXBpIiwiQXBpRXJyb3IiLCJMb2dpbiIsIl9zIiwibG9naW4iLCJub3RpY2UiLCJzZXROb3RpY2UiLCJpc0F1dGhlbnRpY2F0ZWQiLCJ0b2FzdCIsIm5hdmlnYXRlIiwibG9jYXRpb24iLCJlbWFpbCIsInNldEVtYWlsIiwicGFzc3dvcmQiLCJzZXRQYXNzd29yZCIsInJlbWVtYmVyIiwic2V0UmVtZW1iZXIiLCJzaG93UGFzc3dvcmQiLCJzZXRTaG93UGFzc3dvcmQiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsImVycm9ycyIsInNldEVycm9ycyIsImFwaUVycm9yIiwic2V0QXBpRXJyb3IiLCJwcm92aWRlcnMiLCJzZXRQcm92aWRlcnMiLCJnb29nbGUiLCJnaXRodWIiLCJvYXV0aFByb3ZpZGVycyIsInRoZW4iLCJjYXRjaCIsInN0YXRlIiwiZnJvbSIsInJlcGxhY2UiLCJ2YWxpZGF0ZSIsIm5leHQiLCJ0cmltIiwidGVzdCIsIk9iamVjdCIsImtleXMiLCJsZW5ndGgiLCJoYW5kbGVTdWJtaXQiLCJlIiwicHJldmVudERlZmF1bHQiLCJzdWNjZXNzIiwiZXJyIiwic3RhdHVzIiwibWVzc2FnZSIsInNldFRpbWVvdXQiLCJwdXJwb3NlIiwiaGFuZGxlT3RwTG9naW4iLCJzZW5kTm93IiwicHJvdmlkZXJDbGljayIsInBhdGgiLCJ3aW5kb3ciLCJvcmlnaW4iLCJzdGFydHNXaXRoIiwiaHJlZiIsInByb3ZpZGVyRGlzYWJsZWQiLCJrZXkiLCJkaXNwbGF5IiwiYWxpZ25JdGVtcyIsImp1c3RpZnlDb250ZW50Iiwid2lkdGgiLCJoZWlnaHQiLCJib3JkZXJSYWRpdXMiLCJiYWNrZ3JvdW5kIiwiY29sb3IiLCJmb250V2VpZ2h0IiwiZm9udFNpemUiLCJ0YXJnZXQiLCJ2YWx1ZSIsInMiLCJjaGVja2VkIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTG9naW4uanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBMaW5rLCB1c2VMb2NhdGlvbiwgdXNlTmF2aWdhdGUgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gXCIuLi9jb250ZXh0L0F1dGhDb250ZXh0LmpzeFwiO1xuaW1wb3J0IHsgdXNlVG9hc3QgfSBmcm9tIFwiLi4vY29udGV4dC9Ub2FzdENvbnRleHQuanN4XCI7XG5pbXBvcnQgeyBhdXRoQXBpIH0gZnJvbSBcIi4uL2FwaS9hdXRoLmpzXCI7XG5pbXBvcnQgeyBBcGlFcnJvciB9IGZyb20gXCIuLi9hcGkvY2xpZW50LmpzXCI7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIExvZ2luKCkge1xuICBjb25zdCB7IGxvZ2luLCBub3RpY2UsIHNldE5vdGljZSwgaXNBdXRoZW50aWNhdGVkIH0gPSB1c2VBdXRoKCk7XG4gIGNvbnN0IHRvYXN0ID0gdXNlVG9hc3QoKTtcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuICBjb25zdCBsb2NhdGlvbiA9IHVzZUxvY2F0aW9uKCk7XG5cbiAgY29uc3QgW2VtYWlsLCBzZXRFbWFpbF0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW3Bhc3N3b3JkLCBzZXRQYXNzd29yZF0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW3JlbWVtYmVyLCBzZXRSZW1lbWJlcl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtzaG93UGFzc3dvcmQsIHNldFNob3dQYXNzd29yZF0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2Vycm9ycywgc2V0RXJyb3JzXSA9IHVzZVN0YXRlKHt9KTtcbiAgY29uc3QgW2FwaUVycm9yLCBzZXRBcGlFcnJvcl0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW3Byb3ZpZGVycywgc2V0UHJvdmlkZXJzXSA9IHVzZVN0YXRlKHsgZ29vZ2xlOiBmYWxzZSwgZ2l0aHViOiBmYWxzZSB9KTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGF1dGhBcGlcbiAgICAgIC5vYXV0aFByb3ZpZGVycygpXG4gICAgICAudGhlbihzZXRQcm92aWRlcnMpXG4gICAgICAuY2F0Y2goKCkgPT4gc2V0UHJvdmlkZXJzKHsgZ29vZ2xlOiBmYWxzZSwgZ2l0aHViOiBmYWxzZSB9KSk7XG4gIH0sIFtdKTtcblxuICAvLyBBbHJlYWR5IHNpZ25lZCBpbj8gU3RyYWlnaHQgdG8gdGhlIGRhc2hib2FyZC5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoaXNBdXRoZW50aWNhdGVkKSB7XG4gICAgICBuYXZpZ2F0ZShsb2NhdGlvbi5zdGF0ZT8uZnJvbSB8fCBcIi9kYXNoYm9hcmRcIiwgeyByZXBsYWNlOiB0cnVlIH0pO1xuICAgIH1cbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgcmVhY3QtaG9va3MvZXhoYXVzdGl2ZS1kZXBzXG4gIH0sIFtpc0F1dGhlbnRpY2F0ZWRdKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChub3RpY2UpIHtcbiAgICAgIHNldEFwaUVycm9yKG5vdGljZSk7XG4gICAgICBzZXROb3RpY2UoXCJcIik7XG4gICAgfVxuICB9LCBbbm90aWNlLCBzZXROb3RpY2VdKTtcblxuICBmdW5jdGlvbiB2YWxpZGF0ZSgpIHtcbiAgICBjb25zdCBuZXh0ID0ge307XG4gICAgaWYgKCFlbWFpbC50cmltKCkpIG5leHQuZW1haWwgPSBcIkVtYWlsIGFkZHJlc3MgaXMgcmVxdWlyZWQuXCI7XG4gICAgZWxzZSBpZiAoIS9eW0EtWmEtejAtOS5fJStcXC1dK0BbQS1aYS16MC05LlxcLV0rXFwuW0EtWmEtel17Mix9JC8udGVzdChlbWFpbC50cmltKCkpKVxuICAgICAgbmV4dC5lbWFpbCA9IFwiSW52YWxpZCBlbWFpbCBhZGRyZXNzLlwiO1xuICAgIGlmICghcGFzc3dvcmQpIG5leHQucGFzc3dvcmQgPSBcIlBhc3N3b3JkIGlzIHJlcXVpcmVkLlwiO1xuICAgIHNldEVycm9ycyhuZXh0KTtcbiAgICByZXR1cm4gT2JqZWN0LmtleXMobmV4dCkubGVuZ3RoID09PSAwO1xuICB9XG5cbiAgYXN5bmMgZnVuY3Rpb24gaGFuZGxlU3VibWl0KGUpIHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgc2V0QXBpRXJyb3IoXCJcIik7XG4gICAgaWYgKCF2YWxpZGF0ZSgpKSByZXR1cm47XG4gICAgc2V0TG9hZGluZyh0cnVlKTtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgbG9naW4oZW1haWwudHJpbSgpLCBwYXNzd29yZCwgcmVtZW1iZXIpO1xuICAgICAgdG9hc3Quc3VjY2VzcyhcIkxvZ2luIHN1Y2Nlc3NmdWwuIFdlbGNvbWUgYmFjayFcIik7XG4gICAgICBuYXZpZ2F0ZShsb2NhdGlvbi5zdGF0ZT8uZnJvbSB8fCBcIi9kYXNoYm9hcmRcIiwgeyByZXBsYWNlOiB0cnVlIH0pO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgaWYgKGVyciBpbnN0YW5jZW9mIEFwaUVycm9yICYmIGVyci5zdGF0dXMgPT09IDQwMykge1xuICAgICAgICAvLyBVbnZlcmlmaWVkIGVtYWlsIOKGkiB0aGUgYmFja2VuZCBzZW50IGEgZnJlc2ggdmVyaWZpY2F0aW9uIGNvZGUuXG4gICAgICAgIHNldEFwaUVycm9yKGVyci5tZXNzYWdlKTtcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiBuYXZpZ2F0ZShcIi92ZXJpZnktb3RwXCIsIHsgc3RhdGU6IHsgZW1haWw6IGVtYWlsLnRyaW0oKSwgcHVycG9zZTogXCJlbWFpbF92ZXJpZmljYXRpb25cIiB9IH0pLCA5MDApO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgc2V0QXBpRXJyb3IoZXJyLm1lc3NhZ2UgfHwgXCJMb2dpbiBmYWlsZWQuIFBsZWFzZSB0cnkgYWdhaW4uXCIpO1xuICAgICAgfVxuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcbiAgICB9XG4gIH1cblxuICBmdW5jdGlvbiBoYW5kbGVPdHBMb2dpbigpIHtcbiAgICBpZiAoIWVtYWlsLnRyaW0oKSkge1xuICAgICAgc2V0RXJyb3JzKHsgZW1haWw6IFwiRW50ZXIgeW91ciBlbWFpbCBhYm92ZSBmaXJzdCwgdGhlbiB1c2UgdGhlIGNvZGUgbG9naW4uXCIgfSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIG5hdmlnYXRlKFwiL3ZlcmlmeS1vdHBcIiwgeyBzdGF0ZTogeyBlbWFpbDogZW1haWwudHJpbSgpLCBwdXJwb3NlOiBcImxvZ2luXCIsIHNlbmROb3c6IHRydWUgfSB9KTtcbiAgfVxuXG4gIGNvbnN0IHByb3ZpZGVyQ2xpY2sgPSAocGF0aCkgPT4ge1xuICAgIGlmICghd2luZG93LmxvY2F0aW9uLm9yaWdpbi5zdGFydHNXaXRoKFwiaHR0cFwiKSkgcmV0dXJuO1xuICAgIHdpbmRvdy5sb2NhdGlvbi5ocmVmID0gcGF0aDtcbiAgfTtcblxuICBjb25zdCBwcm92aWRlckRpc2FibGVkID0gKGtleSkgPT4gIXByb3ZpZGVyc1trZXldO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJsb2dpbi13cmFwcGVyXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQgbG9naW4tY2FyZFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQtaGVhZGVyIHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkLWZsZXggYWxpZ24taXRlbXMtY2VudGVyIGp1c3RpZnktY29udGVudC1jZW50ZXIgZ2FwLTIgbWItMlwiPlxuICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBcImlubGluZS1mbGV4XCIsXG4gICAgICAgICAgICAgICAgYWxpZ25JdGVtczogXCJjZW50ZXJcIixcbiAgICAgICAgICAgICAgICBqdXN0aWZ5Q29udGVudDogXCJjZW50ZXJcIixcbiAgICAgICAgICAgICAgICB3aWR0aDogNDAsXG4gICAgICAgICAgICAgICAgaGVpZ2h0OiA0MCxcbiAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6IDEwLFxuICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IFwibGluZWFyLWdyYWRpZW50KDEzNWRlZywgIzBmNzY2ZSAwJSwgIzEzNGU0YSAxMDAlKVwiLFxuICAgICAgICAgICAgICAgIGNvbG9yOiBcIndoaXRlXCIsXG4gICAgICAgICAgICAgICAgZm9udFdlaWdodDogNzAwLFxuICAgICAgICAgICAgICAgIGZvbnRTaXplOiAyMCxcbiAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgRFxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cIm1iLTAgdGV4dC1kaGFuaXRpXCI+RGhhbml0aTwvaDQ+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1tdXRlZCBzbWFsbCBtYi0wXCI+RWR1Y2F0aW9uIExvYW4gRGFzaGJvYXJkPC9wPlxuICAgICAgICAgIDxoNSBjbGFzc05hbWU9XCJtdC0zIG1iLTAgZnctc2VtaWJvbGRcIj5XZWxjb21lIEJhY2s8L2g1PlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbXV0ZWQgc21hbGxcIj5TaWduIGluIHRvIGNvbnRpbnVlIHRvIHlvdXIgZGFzaGJvYXJkPC9wPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQtYm9keSBwLTRcIj5cbiAgICAgICAgICB7YXBpRXJyb3IgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhbGVydCBhbGVydC1kYW5nZXIgcHktMlwiIHJvbGU9XCJhbGVydFwiIGRhdGEtdGVzdGlkPVwibG9naW4tZXJyb3JcIj5cbiAgICAgICAgICAgICAge2FwaUVycm9yfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9IG5vVmFsaWRhdGU+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTNcIj5cbiAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJlbWFpbFwiIGNsYXNzTmFtZT1cImZvcm0tbGFiZWxcIj5FbWFpbDwvbGFiZWw+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHR5cGU9XCJlbWFpbFwiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZm9ybS1jb250cm9sICR7ZXJyb3JzLmVtYWlsID8gXCJpcy1pbnZhbGlkXCIgOiBcIlwifWB9XG4gICAgICAgICAgICAgICAgaWQ9XCJlbWFpbFwiXG4gICAgICAgICAgICAgICAgdmFsdWU9e2VtYWlsfVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RW1haWwoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cInVzZXJuYW1lXCJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cInlvdUBjb21wYW55LmNvbVwiXG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2xvYWRpbmd9XG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIHtlcnJvcnMuZW1haWwgJiYgPGRpdiBjbGFzc05hbWU9XCJpbnZhbGlkLWZlZWRiYWNrXCI+e2Vycm9ycy5lbWFpbH08L2Rpdj59XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0zXCI+XG4gICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwicGFzc3dvcmRcIiBjbGFzc05hbWU9XCJmb3JtLWxhYmVsIGQtZmxleCBqdXN0aWZ5LWNvbnRlbnQtYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgIFBhc3N3b3JkXG4gICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5wdXQtZ3JvdXBcIj5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9e3Nob3dQYXNzd29yZCA/IFwidGV4dFwiIDogXCJwYXNzd29yZFwifVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZm9ybS1jb250cm9sICR7ZXJyb3JzLnBhc3N3b3JkID8gXCJpcy1pbnZhbGlkXCIgOiBcIlwifWB9XG4gICAgICAgICAgICAgICAgICBpZD1cInBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtwYXNzd29yZH1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UGFzc3dvcmQoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgYXV0b0NvbXBsZXRlPVwiY3VycmVudC1wYXNzd29yZFwiXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIllvdXIgcGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2xvYWRpbmd9XG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJidG4gYnRuLW91dGxpbmUtc2Vjb25kYXJ5XCJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd1Bhc3N3b3JkKChzKSA9PiAhcyl9XG4gICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPXtzaG93UGFzc3dvcmQgPyBcIkhpZGUgcGFzc3dvcmRcIiA6IFwiU2hvdyBwYXNzd29yZFwifVxuICAgICAgICAgICAgICAgICAgdGFiSW5kZXg9ey0xfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxpIGNsYXNzTmFtZT17YGJpICR7c2hvd1Bhc3N3b3JkID8gXCJiaS1leWUtc2xhc2hcIiA6IFwiYmktZXllXCJ9YH0gYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICB7ZXJyb3JzLnBhc3N3b3JkICYmIDxkaXYgY2xhc3NOYW1lPVwiaW52YWxpZC1mZWVkYmFjayBkLWJsb2NrXCI+e2Vycm9ycy5wYXNzd29yZH08L2Rpdj59XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZC1mbGV4IGp1c3RpZnktY29udGVudC1iZXR3ZWVuIGFsaWduLWl0ZW1zLWNlbnRlciBtYi00XCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1jaGVja1wiPlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9ybS1jaGVjay1pbnB1dFwiXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxuICAgICAgICAgICAgICAgICAgaWQ9XCJyZW1lbWJlclwiXG4gICAgICAgICAgICAgICAgICBjaGVja2VkPXtyZW1lbWJlcn1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UmVtZW1iZXIoZS50YXJnZXQuY2hlY2tlZCl9XG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZm9ybS1jaGVjay1sYWJlbCBzbWFsbFwiIGh0bWxGb3I9XCJyZW1lbWJlclwiPlJlbWVtYmVyIG1lPC9sYWJlbD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxMaW5rIHRvPVwiL2ZvcmdvdC1wYXNzd29yZFwiIGNsYXNzTmFtZT1cInNtYWxsXCI+Rm9yZ290IHBhc3N3b3JkPzwvTGluaz5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBjbGFzc05hbWU9XCJidG4gYnRuLWRoYW5pdGkgdy0xMDBcIiBkaXNhYmxlZD17bG9hZGluZ30+XG4gICAgICAgICAgICAgIHtsb2FkaW5nID8gKFxuICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzcGlubmVyLWJvcmRlciBzcGlubmVyLWJvcmRlci1zbSBtZS0yXCIgcm9sZT1cInN0YXR1c1wiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgICAgICAgICBMb2dnaW5nIGlu4oCmXG4gICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgXCJMT0dJTlwiXG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Zvcm0+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImQtZmxleCBhbGlnbi1pdGVtcy1jZW50ZXIgbXktM1wiPlxuICAgICAgICAgICAgPGhyIGNsYXNzTmFtZT1cImZsZXgtZ3Jvdy0xXCIgLz5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTIgdGV4dC1tdXRlZCBzbWFsbFwiPk9SPC9zcGFuPlxuICAgICAgICAgICAgPGhyIGNsYXNzTmFtZT1cImZsZXgtZ3Jvdy0xXCIgLz5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZC1ncmlkIGdhcC0yXCI+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJidG4gYnRuLW91dGxpbmUtc2Vjb25kYXJ5XCJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gcHJvdmlkZXJDbGljayhcIi9hdXRoL2dvb2dsZVwiKX1cbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e3Byb3ZpZGVyRGlzYWJsZWQoXCJnb29nbGVcIil9XG4gICAgICAgICAgICAgIHRpdGxlPXtwcm92aWRlckRpc2FibGVkKFwiZ29vZ2xlXCIpID8gXCJHb29nbGUgc2lnbi1pbiBpcyBub3QgY29uZmlndXJlZCBvbiB0aGlzIHNlcnZlclwiIDogXCJDb250aW51ZSB3aXRoIEdvb2dsZVwifVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8c3ZnIHdpZHRoPVwiMTZcIiBoZWlnaHQ9XCIxNlwiIHZpZXdCb3g9XCIwIDAgMTggMThcIiBhcmlhLWhpZGRlbj1cInRydWVcIiBjbGFzc05hbWU9XCJtZS0yXCI+XG4gICAgICAgICAgICAgICAgPHBhdGggZmlsbD1cIiM0Mjg1RjRcIiBkPVwiTTE3LjY0IDkuMmMwLS42NC0uMDYtMS4yNS0uMTYtMS44NEg5djMuNDhoNC44NGE0LjE0IDQuMTQgMCAwIDEtMS44IDIuNzJ2Mi4yNmgyLjkyYzEuNy0xLjU3IDIuNjgtMy44OCAyLjY4LTYuNjJ6XCIvPlxuICAgICAgICAgICAgICAgIDxwYXRoIGZpbGw9XCIjMzRBODUzXCIgZD1cIk05IDE4YzIuNDMgMCA0LjQ3LS44IDUuOTYtMi4xOGwtMi45Mi0yLjI2Yy0uOC41NC0xLjg0Ljg2LTMuMDQuODYtMi4zNCAwLTQuMzItMS41OC01LjAzLTMuN0guOTZ2Mi4zM0E4Ljk5IDguOTkgMCAwIDAgOSAxOHpcIi8+XG4gICAgICAgICAgICAgICAgPHBhdGggZmlsbD1cIiNGQkJDMDVcIiBkPVwiTTMuOTcgMTAuNzJhNS40IDUuNCAwIDAgMSAwLTMuNDRWNC45NUguOTZhOSA5IDAgMCAwIDAgOC4xbDMuMDEtMi4zM3pcIi8+XG4gICAgICAgICAgICAgICAgPHBhdGggZmlsbD1cIiNFQTQzMzVcIiBkPVwiTTkgMy41OGMxLjMyIDAgMi41LjQ1IDMuNDQgMS4zNWwyLjU4LTIuNTlDMTMuNDYuODkgMTEuNDMgMCA5IDBBOC45OSA4Ljk5IDAgMCAwIC45NiA0Ljk1bDMuMDEgMi4zM0M0LjY4IDUuMTYgNi42NiAzLjU4IDkgMy41OHpcIi8+XG4gICAgICAgICAgICAgIDwvc3ZnPlxuICAgICAgICAgICAgICBDb250aW51ZSB3aXRoIEdvb2dsZVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJidG4gYnRuLW91dGxpbmUtc2Vjb25kYXJ5XCJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gcHJvdmlkZXJDbGljayhcIi9hdXRoL2dpdGh1YlwiKX1cbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e3Byb3ZpZGVyRGlzYWJsZWQoXCJnaXRodWJcIil9XG4gICAgICAgICAgICAgIHRpdGxlPXtwcm92aWRlckRpc2FibGVkKFwiZ2l0aHViXCIpID8gXCJHaXRIdWIgc2lnbi1pbiBpcyBub3QgY29uZmlndXJlZCBvbiB0aGlzIHNlcnZlclwiIDogXCJDb250aW51ZSB3aXRoIEdpdEh1YlwifVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8aSBjbGFzc05hbWU9XCJiaSBiaS1naXRodWIgbWUtMlwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgICAgIENvbnRpbnVlIHdpdGggR2l0SHViXG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImJ0biBidG4tb3V0bGluZS1kaGFuaXRpXCIgb25DbGljaz17aGFuZGxlT3RwTG9naW59PlxuICAgICAgICAgICAgICA8aSBjbGFzc05hbWU9XCJiaSBiaS1zaGllbGQtbG9jayBtZS0yXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICAgICAgTG9naW4gd2l0aCBPVFBcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgc21hbGwgbXQtNCBtYi0wXCI+XG4gICAgICAgICAgICBEb24mYXBvczt0IGhhdmUgYW4gYWNjb3VudD8gPExpbmsgdG89XCIvcmVnaXN0ZXJcIj5SZWdpc3RlcjwvTGluaz5cbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZC1mb290ZXIgdGV4dC1jZW50ZXIgdGV4dC1tdXRlZCBzbWFsbCBweS0yXCI+XG4gICAgICAgICAgPGRldGFpbHMgY2xhc3NOYW1lPVwidGV4dC1zdGFydFwiPlxuICAgICAgICAgICAgPHN1bW1hcnkgY2xhc3NOYW1lPVwiY3Vyc29yLXBvaW50ZXJcIj5EZW1vIGNyZWRlbnRpYWxzIChkZXZlbG9wbWVudCk8L3N1bW1hcnk+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTJcIj5cbiAgICAgICAgICAgICAgPGRpdj48Y29kZT5hZG1pbkBkaGFuaXRpLmFpPC9jb2RlPiAvIDxjb2RlPkRoYW5pdGlBZG1pbkAxMjM8L2NvZGU+IOKAlCBBZG1pbjwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2Pjxjb2RlPnVuZGVyd3JpdGVyQGRoYW5pdGkuYWk8L2NvZGU+IC8gPGNvZGU+VW5kZXJ3cml0ZXJAMTIzPC9jb2RlPiDigJQgVW5kZXJ3cml0ZXI8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdj48Y29kZT5hbmFseXN0QGRoYW5pdGkuYWk8L2NvZGU+IC8gPGNvZGU+QW5hbHlzdEAxMjM8L2NvZGU+IOKAlCByZWFkLW9ubHk8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGV0YWlscz5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiQzovVXNlcnMvdXNlci9Eb3dubG9hZHMvZGhhbml0aS1hcHAtdXBncmFkZWQvZGhhbml0aS1hcHAvZnJvbnRlbmQvc3JjL3BhZ2VzL0xvZ2luLmpzeCJ9