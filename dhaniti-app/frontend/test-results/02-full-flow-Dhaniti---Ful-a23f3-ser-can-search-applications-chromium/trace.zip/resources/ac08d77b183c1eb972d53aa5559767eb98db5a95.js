import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ProtectedRoute.jsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];const React = __vite__cjsImport3_react;import * as RefreshRuntime from "/@react-refresh";
var _jsxFileName = "C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/components/ProtectedRoute.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=325d36c7";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
	if (!window.$RefreshReg$) {
		throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong.");
	}
	prevRefreshReg = window.$RefreshReg$;
	prevRefreshSig = window.$RefreshSig$;
	window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/components/ProtectedRoute.jsx");
	window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=325d36c7";
import { Navigate, useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=325d36c7";
import { useAuth } from "/src/context/AuthContext.jsx";
/**
* Route guard: unauthenticated users are redirected to /login (keeping
* the attempted route so we can send them back after signing in).
*/
export default function ProtectedRoute({ children }) {
	_s();
	const { isAuthenticated, loading } = useAuth();
	const location = useLocation();
	if (loading) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "d-flex flex-column align-items-center justify-content-center",
			style: { minHeight: "60vh" },
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "spinner-border text-dhaniti",
				role: "status",
				"aria-hidden": "true"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 35,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: "text-muted mt-3 mb-0",
				children: "Checking your session…"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 36,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 34,
			columnNumber: 7
		}, this);
	}
	if (!isAuthenticated) {
		return /* @__PURE__ */ _jsxDEV(Navigate, {
			to: "/login",
			state: { from: location.pathname + location.search },
			replace: true
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 42,
			columnNumber: 12
		}, this);
	}
	return children;
}
_s(ProtectedRoute, "fNj96oVmPd4sFazcimgf9N7S8ao=", false, function() {
	return [useAuth, useLocation];
});
_c = ProtectedRoute;
var _c;
$RefreshReg$(_c, "ProtectedRoute");
if (import.meta.hot && !inWebWorker) {
	window.$RefreshReg$ = prevRefreshReg;
	window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
	RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
		RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/components/ProtectedRoute.jsx", currentExports);
		import.meta.hot.accept((nextExports) => {
			if (!nextExports) return;
			const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/components/ProtectedRoute.jsx", currentExports, nextExports);
			if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
		});
	});
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLE9BQU9BLFdBQVc7QUFDbEIsU0FBU0MsVUFBVUMsbUJBQW1CO0FBQ3RDLFNBQVNDLGVBQWU7Ozs7O0FBTXhCLGVBQWUsU0FBU0MsZUFBZSxFQUFFQyxZQUFZO0NBQUFDLEdBQUE7Q0FDbkQsTUFBTSxFQUFFQyxpQkFBaUJDLFlBQVlMLFFBQVE7Q0FDN0MsTUFBTU0sV0FBV1AsWUFBWTtDQUU3QixJQUFJTSxTQUFTO0VBQ1gsT0FDRSx3QkFBQyxPQUFEO0dBQUssV0FBVTtHQUErRCxPQUFPLEVBQUVFLFdBQVcsT0FBTzthQUF6RyxDQUNFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO0lBQThCLE1BQUs7SUFBUyxlQUFZO0dBQU07Ozs7YUFDN0Usd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBdUI7R0FBeUI7Ozs7V0FDMUQ7Ozs7OztDQUVUO0NBRUEsSUFBSSxDQUFDSCxpQkFBaUI7RUFDcEIsT0FBTyx3QkFBQyxVQUFEO0dBQVUsSUFBRztHQUFTLE9BQU8sRUFBRUksTUFBTUYsU0FBU0csV0FBV0gsU0FBU0ksT0FBTztHQUFHO0VBQU87Ozs7O0NBQzVGO0NBQ0EsT0FBT1I7QUFDVDtBQUFDQyxHQWpCdUJGLGdCQUFjO0NBQUEsUUFDQ0QsU0FDcEJELFdBQVc7QUFBQTtBQUFBLEtBRk5FO0FBQWMsSUFBQVU7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJOYXZpZ2F0ZSIsInVzZUxvY2F0aW9uIiwidXNlQXV0aCIsIlByb3RlY3RlZFJvdXRlIiwiY2hpbGRyZW4iLCJfcyIsImlzQXV0aGVudGljYXRlZCIsImxvYWRpbmciLCJsb2NhdGlvbiIsIm1pbkhlaWdodCIsImZyb20iLCJwYXRobmFtZSIsInNlYXJjaCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlByb3RlY3RlZFJvdXRlLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBOYXZpZ2F0ZSwgdXNlTG9jYXRpb24gfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gXCIuLi9jb250ZXh0L0F1dGhDb250ZXh0LmpzeFwiO1xuXG4vKipcbiAqIFJvdXRlIGd1YXJkOiB1bmF1dGhlbnRpY2F0ZWQgdXNlcnMgYXJlIHJlZGlyZWN0ZWQgdG8gL2xvZ2luIChrZWVwaW5nXG4gKiB0aGUgYXR0ZW1wdGVkIHJvdXRlIHNvIHdlIGNhbiBzZW5kIHRoZW0gYmFjayBhZnRlciBzaWduaW5nIGluKS5cbiAqL1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUHJvdGVjdGVkUm91dGUoeyBjaGlsZHJlbiB9KSB7XG4gIGNvbnN0IHsgaXNBdXRoZW50aWNhdGVkLCBsb2FkaW5nIH0gPSB1c2VBdXRoKCk7XG4gIGNvbnN0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKTtcblxuICBpZiAobG9hZGluZykge1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImQtZmxleCBmbGV4LWNvbHVtbiBhbGlnbi1pdGVtcy1jZW50ZXIganVzdGlmeS1jb250ZW50LWNlbnRlclwiIHN0eWxlPXt7IG1pbkhlaWdodDogXCI2MHZoXCIgfX0+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3Bpbm5lci1ib3JkZXIgdGV4dC1kaGFuaXRpXCIgcm9sZT1cInN0YXR1c1wiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbXV0ZWQgbXQtMyBtYi0wXCI+Q2hlY2tpbmcgeW91ciBzZXNzaW9u4oCmPC9wPlxuICAgICAgPC9kaXY+XG4gICAgKTtcbiAgfVxuXG4gIGlmICghaXNBdXRoZW50aWNhdGVkKSB7XG4gICAgcmV0dXJuIDxOYXZpZ2F0ZSB0bz1cIi9sb2dpblwiIHN0YXRlPXt7IGZyb206IGxvY2F0aW9uLnBhdGhuYW1lICsgbG9jYXRpb24uc2VhcmNoIH19IHJlcGxhY2UgLz47XG4gIH1cbiAgcmV0dXJuIGNoaWxkcmVuO1xufVxuIl0sImZpbGUiOiJDOi9Vc2Vycy91c2VyL0Rvd25sb2Fkcy9kaGFuaXRpLWFwcC11cGdyYWRlZC9kaGFuaXRpLWFwcC9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9Qcm90ZWN0ZWRSb3V0ZS5qc3gifQ==