import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/context/AuthContext.jsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];const React = __vite__cjsImport3_react; const createContext = __vite__cjsImport3_react["createContext"]; const useCallback = __vite__cjsImport3_react["useCallback"]; const useContext = __vite__cjsImport3_react["useContext"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];import * as RefreshRuntime from "/@react-refresh";
var _jsxFileName = "C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/context/AuthContext.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=325d36c7";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
	if (!window.$RefreshReg$) {
		throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong.");
	}
	prevRefreshReg = window.$RefreshReg$;
	prevRefreshSig = window.$RefreshSig$;
	window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/context/AuthContext.jsx");
	window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=325d36c7";
import { authApi } from "/src/api/auth.js";
import { clearAuth, getToken, getUser, setAuth } from "/src/api/client.js";
const AuthContext = createContext(null);
/**
* Central authentication state:
*   currentUser, isAuthenticated, loading,
*   login(), logout(), refreshUser(), applySession()
*/
export function AuthProvider({ children }) {
	_s();
	const [currentUser, setCurrentUser] = useState(() => getUser());
	const [loading, setLoading] = useState(() => Boolean(getToken()));
	const [notice, setNotice] = useState("");
	const applySession = useCallback((token, user) => {
		setAuth(token, user);
		setCurrentUser(user);
	}, []);
	const login = useCallback(async (email, password, remember = false) => {
		const { token, user } = await authApi.login(email, password, remember);
		applySession(token, user);
		return user;
	}, [applySession]);
	const logout = useCallback(async () => {
		try {
			await authApi.logout();
		} catch {}
		clearAuth();
		setCurrentUser(null);
	}, []);
	const refreshUser = useCallback(async () => {
		if (!getToken()) {
			setCurrentUser(null);
			return null;
		}
		try {
			const user = await authApi.me();
			setCurrentUser(user);
			// Keep localStorage in sync with the server truth.
			setAuth(getToken(), user);
			return user;
		} catch {
			clearAuth();
			setCurrentUser(null);
			return null;
		}
	}, []);
	// On mount: verify the stored token against the backend.
	useEffect(() => {
		let cancelled = false;
		(async () => {
			if (getToken()) {
				try {
					const user = await authApi.me();
					if (!cancelled) {
						setCurrentUser(user);
						setAuth(getToken(), user);
					}
				} catch {
					if (!cancelled) {
						clearAuth();
						setCurrentUser(null);
						setNotice("Your session has expired. Please sign in again.");
					}
				} finally {
					if (!cancelled) setLoading(false);
				}
			} else {
				setLoading(false);
			}
		})();
		return () => {
			cancelled = true;
		};
	}, []);
	// React to 401s raised anywhere in the app (client.js dispatches this).
	useEffect(() => {
		const onUnauthorized = () => {
			setCurrentUser(null);
			setNotice("Your session has expired. Please sign in again.");
		};
		window.addEventListener("dhaniti:unauthorized", onUnauthorized);
		return () => window.removeEventListener("dhaniti:unauthorized", onUnauthorized);
	}, []);
	const value = useMemo(() => ({
		currentUser,
		isAuthenticated: Boolean(currentUser),
		loading,
		notice,
		setNotice,
		login,
		logout,
		refreshUser,
		applySession,
		// Role helpers used by the UI to hide write controls.
		canWrite: Boolean(currentUser && !["Credit Analyst"].includes(currentUser.role))
	}), [
		currentUser,
		loading,
		notice,
		login,
		logout,
		refreshUser,
		applySession
	]);
	return /* @__PURE__ */ _jsxDEV(AuthContext.Provider, {
		value,
		children
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 134,
		columnNumber: 10
	}, this);
}
_s(AuthProvider, "n3PNQapubQk5HjUS8+VBG/yWTPQ=");
_c = AuthProvider;
export function useAuth() {
	_s2();
	const ctx = useContext(AuthContext);
	if (!ctx) throw new Error("useAuth must be used inside <AuthProvider>");
	return ctx;
}
_s2(useAuth, "/dMy7t63NXD4eYACoT93CePwGrg=");
var _c;
$RefreshReg$(_c, "AuthProvider");
if (import.meta.hot && !inWebWorker) {
	window.$RefreshReg$ = prevRefreshReg;
	window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
	RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
		RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/context/AuthContext.jsx", currentExports);
		import.meta.hot.accept((nextExports) => {
			if (!nextExports) return;
			const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/context/AuthContext.jsx", currentExports, nextExports);
			if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
		});
	});
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLE9BQU9BLFNBQVNDLGVBQWVDLGFBQWFDLFlBQVlDLFdBQVdDLFNBQVNDLGdCQUFnQjtBQUM1RixTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLFdBQVdDLFVBQVVDLFNBQVNDLGVBQWU7QUFFdEQsTUFBTUMsY0FBY1gsY0FBYyxJQUFJOzs7Ozs7QUFPdEMsT0FBTyxTQUFTWSxhQUFhLEVBQUVDLFlBQVk7Q0FBQUMsR0FBQTtDQUN6QyxNQUFNLENBQUNDLGFBQWFDLGtCQUFrQlgsZUFBZUksUUFBUSxDQUFDO0NBQzlELE1BQU0sQ0FBQ1EsU0FBU0MsY0FBY2IsZUFBZWMsUUFBUVgsU0FBUyxDQUFDLENBQUM7Q0FDaEUsTUFBTSxDQUFDWSxRQUFRQyxhQUFhaEIsU0FBUyxFQUFFO0NBRXZDLE1BQU1pQixlQUFlckIsYUFBYXNCLE9BQU9DLFNBQVM7RUFDaERkLFFBQVFhLE9BQU9DLElBQUk7RUFDbkJSLGVBQWVRLElBQUk7Q0FDckIsR0FBRyxFQUFFO0NBRUwsTUFBTUMsUUFBUXhCLFlBQ1osT0FBT3lCLE9BQU9DLFVBQVVDLFdBQVcsVUFBVTtFQUMzQyxNQUFNLEVBQUVMLE9BQU9DLFNBQVMsTUFBTWxCLFFBQVFtQixNQUFNQyxPQUFPQyxVQUFVQyxRQUFRO0VBQ3JFTixhQUFhQyxPQUFPQyxJQUFJO0VBQ3hCLE9BQU9BO0NBQ1QsR0FDQSxDQUFDRixZQUFZLENBQ2Y7Q0FFQSxNQUFNTyxTQUFTNUIsWUFBWSxZQUFZO0VBQ3JDLElBQUk7R0FDRixNQUFNSyxRQUFRdUIsT0FBTztFQUN2QixRQUFRLENBQ047RUFFRnRCLFVBQVU7RUFDVlMsZUFBZSxJQUFJO0NBQ3JCLEdBQUcsRUFBRTtDQUVMLE1BQU1jLGNBQWM3QixZQUFZLFlBQVk7RUFDMUMsSUFBSSxDQUFDTyxTQUFTLEdBQUc7R0FDZlEsZUFBZSxJQUFJO0dBQ25CLE9BQU87RUFDVDtFQUNBLElBQUk7R0FDRixNQUFNUSxPQUFPLE1BQU1sQixRQUFReUIsR0FBRztHQUM5QmYsZUFBZVEsSUFBSTs7R0FFbkJkLFFBQVFGLFNBQVMsR0FBR2dCLElBQUk7R0FDeEIsT0FBT0E7RUFDVCxRQUFRO0dBQ05qQixVQUFVO0dBQ1ZTLGVBQWUsSUFBSTtHQUNuQixPQUFPO0VBQ1Q7Q0FDRixHQUFHLEVBQUU7O0NBR0xiLGdCQUFnQjtFQUNkLElBQUk2QixZQUFZO0VBQ2hCLENBQUMsWUFBWTtHQUNYLElBQUl4QixTQUFTLEdBQUc7SUFDZCxJQUFJO0tBQ0YsTUFBTWdCLE9BQU8sTUFBTWxCLFFBQVF5QixHQUFHO0tBQzlCLElBQUksQ0FBQ0MsV0FBVztNQUNkaEIsZUFBZVEsSUFBSTtNQUNuQmQsUUFBUUYsU0FBUyxHQUFHZ0IsSUFBSTtLQUMxQjtJQUNGLFFBQVE7S0FDTixJQUFJLENBQUNRLFdBQVc7TUFDZHpCLFVBQVU7TUFDVlMsZUFBZSxJQUFJO01BQ25CSyxVQUFVLGlEQUFpRDtLQUM3RDtJQUNGLFVBQVU7S0FDUixJQUFJLENBQUNXLFdBQVdkLFdBQVcsS0FBSztJQUNsQztHQUNGLE9BQU87SUFDTEEsV0FBVyxLQUFLO0dBQ2xCO0VBQ0YsRUFBQyxDQUFFO0VBQ0gsYUFBYTtHQUNYYyxZQUFZO0VBQ2Q7Q0FDRixHQUFHLEVBQUU7O0NBR0w3QixnQkFBZ0I7RUFDZCxNQUFNOEIsdUJBQXVCO0dBQzNCakIsZUFBZSxJQUFJO0dBQ25CSyxVQUFVLGlEQUFpRDtFQUM3RDtFQUNBYSxPQUFPQyxpQkFBaUIsd0JBQXdCRixjQUFjO0VBQzlELGFBQWFDLE9BQU9FLG9CQUFvQix3QkFBd0JILGNBQWM7Q0FDaEYsR0FBRyxFQUFFO0NBRUwsTUFBTUksUUFBUWpDLGVBQ0w7RUFDTFc7RUFDQXVCLGlCQUFpQm5CLFFBQVFKLFdBQVc7RUFDcENFO0VBQ0FHO0VBQ0FDO0VBQ0FJO0VBQ0FJO0VBQ0FDO0VBQ0FSOztFQUVBaUIsVUFBVXBCLFFBQVFKLGVBQWUsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUN5QixTQUFTekIsWUFBWTBCLElBQUksQ0FBQztDQUNqRixJQUNBO0VBQUMxQjtFQUFhRTtFQUFTRztFQUFRSztFQUFPSTtFQUFRQztFQUFhUjtDQUFZLENBQ3pFO0NBRUEsT0FBTyx3QkFBQyxZQUFZLFVBQWI7RUFBNkJlO0VBQVF4QjtDQUErQjs7Ozs7QUFDN0U7QUFBQ0MsR0F4R2VGLGNBQVk7QUFBQSxLQUFaQTtBQTBHaEIsT0FBTyxTQUFTOEIsVUFBVTtDQUFBQyxJQUFBO0NBQ3hCLE1BQU1DLE1BQU0xQyxXQUFXUyxXQUFXO0NBQ2xDLElBQUksQ0FBQ2lDLEtBQUssTUFBTSxJQUFJQyxNQUFNLDRDQUE0QztDQUN0RSxPQUFPRDtBQUNUO0FBQUNELElBSmVELFNBQU87QUFBQSxJQUFBSTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsImNyZWF0ZUNvbnRleHQiLCJ1c2VDYWxsYmFjayIsInVzZUNvbnRleHQiLCJ1c2VFZmZlY3QiLCJ1c2VNZW1vIiwidXNlU3RhdGUiLCJhdXRoQXBpIiwiY2xlYXJBdXRoIiwiZ2V0VG9rZW4iLCJnZXRVc2VyIiwic2V0QXV0aCIsIkF1dGhDb250ZXh0IiwiQXV0aFByb3ZpZGVyIiwiY2hpbGRyZW4iLCJfcyIsImN1cnJlbnRVc2VyIiwic2V0Q3VycmVudFVzZXIiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsIkJvb2xlYW4iLCJub3RpY2UiLCJzZXROb3RpY2UiLCJhcHBseVNlc3Npb24iLCJ0b2tlbiIsInVzZXIiLCJsb2dpbiIsImVtYWlsIiwicGFzc3dvcmQiLCJyZW1lbWJlciIsImxvZ291dCIsInJlZnJlc2hVc2VyIiwibWUiLCJjYW5jZWxsZWQiLCJvblVuYXV0aG9yaXplZCIsIndpbmRvdyIsImFkZEV2ZW50TGlzdGVuZXIiLCJyZW1vdmVFdmVudExpc3RlbmVyIiwidmFsdWUiLCJpc0F1dGhlbnRpY2F0ZWQiLCJjYW5Xcml0ZSIsImluY2x1ZGVzIiwicm9sZSIsInVzZUF1dGgiLCJfczIiLCJjdHgiLCJFcnJvciIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkF1dGhDb250ZXh0LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgY3JlYXRlQ29udGV4dCwgdXNlQ2FsbGJhY2ssIHVzZUNvbnRleHQsIHVzZUVmZmVjdCwgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGF1dGhBcGkgfSBmcm9tIFwiLi4vYXBpL2F1dGguanNcIjtcbmltcG9ydCB7IGNsZWFyQXV0aCwgZ2V0VG9rZW4sIGdldFVzZXIsIHNldEF1dGggfSBmcm9tIFwiLi4vYXBpL2NsaWVudC5qc1wiO1xuXG5jb25zdCBBdXRoQ29udGV4dCA9IGNyZWF0ZUNvbnRleHQobnVsbCk7XG5cbi8qKlxuICogQ2VudHJhbCBhdXRoZW50aWNhdGlvbiBzdGF0ZTpcbiAqICAgY3VycmVudFVzZXIsIGlzQXV0aGVudGljYXRlZCwgbG9hZGluZyxcbiAqICAgbG9naW4oKSwgbG9nb3V0KCksIHJlZnJlc2hVc2VyKCksIGFwcGx5U2Vzc2lvbigpXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBBdXRoUHJvdmlkZXIoeyBjaGlsZHJlbiB9KSB7XG4gIGNvbnN0IFtjdXJyZW50VXNlciwgc2V0Q3VycmVudFVzZXJdID0gdXNlU3RhdGUoKCkgPT4gZ2V0VXNlcigpKTtcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoKCkgPT4gQm9vbGVhbihnZXRUb2tlbigpKSk7IC8vIHZlcmlmeSB0b2tlbiBvbiBib290XG4gIGNvbnN0IFtub3RpY2UsIHNldE5vdGljZV0gPSB1c2VTdGF0ZShcIlwiKTsgLy8gZS5nLiBcInNlc3Npb24gZXhwaXJlZFwiIGJhbm5lciBvbiBsb2dpbiBwYWdlXG5cbiAgY29uc3QgYXBwbHlTZXNzaW9uID0gdXNlQ2FsbGJhY2soKHRva2VuLCB1c2VyKSA9PiB7XG4gICAgc2V0QXV0aCh0b2tlbiwgdXNlcik7XG4gICAgc2V0Q3VycmVudFVzZXIodXNlcik7XG4gIH0sIFtdKTtcblxuICBjb25zdCBsb2dpbiA9IHVzZUNhbGxiYWNrKFxuICAgIGFzeW5jIChlbWFpbCwgcGFzc3dvcmQsIHJlbWVtYmVyID0gZmFsc2UpID0+IHtcbiAgICAgIGNvbnN0IHsgdG9rZW4sIHVzZXIgfSA9IGF3YWl0IGF1dGhBcGkubG9naW4oZW1haWwsIHBhc3N3b3JkLCByZW1lbWJlcik7XG4gICAgICBhcHBseVNlc3Npb24odG9rZW4sIHVzZXIpO1xuICAgICAgcmV0dXJuIHVzZXI7XG4gICAgfSxcbiAgICBbYXBwbHlTZXNzaW9uXVxuICApO1xuXG4gIGNvbnN0IGxvZ291dCA9IHVzZUNhbGxiYWNrKGFzeW5jICgpID0+IHtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgYXV0aEFwaS5sb2dvdXQoKTsgLy8gc2VydmVyLXNpZGUgc2Vzc2lvbiByZXZvY2F0aW9uXG4gICAgfSBjYXRjaCB7XG4gICAgICAvLyBFdmVuIGlmIHRoZSBjYWxsIGZhaWxzIChleHBpcmVkIHRva2VuIC8gb2ZmbGluZSkgY2xlYXIgbG9jYWwgc3RhdGUuXG4gICAgfVxuICAgIGNsZWFyQXV0aCgpO1xuICAgIHNldEN1cnJlbnRVc2VyKG51bGwpO1xuICB9LCBbXSk7XG5cbiAgY29uc3QgcmVmcmVzaFVzZXIgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XG4gICAgaWYgKCFnZXRUb2tlbigpKSB7XG4gICAgICBzZXRDdXJyZW50VXNlcihudWxsKTtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICB0cnkge1xuICAgICAgY29uc3QgdXNlciA9IGF3YWl0IGF1dGhBcGkubWUoKTtcbiAgICAgIHNldEN1cnJlbnRVc2VyKHVzZXIpO1xuICAgICAgLy8gS2VlcCBsb2NhbFN0b3JhZ2UgaW4gc3luYyB3aXRoIHRoZSBzZXJ2ZXIgdHJ1dGguXG4gICAgICBzZXRBdXRoKGdldFRva2VuKCksIHVzZXIpO1xuICAgICAgcmV0dXJuIHVzZXI7XG4gICAgfSBjYXRjaCB7XG4gICAgICBjbGVhckF1dGgoKTtcbiAgICAgIHNldEN1cnJlbnRVc2VyKG51bGwpO1xuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICB9LCBbXSk7XG5cbiAgLy8gT24gbW91bnQ6IHZlcmlmeSB0aGUgc3RvcmVkIHRva2VuIGFnYWluc3QgdGhlIGJhY2tlbmQuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgbGV0IGNhbmNlbGxlZCA9IGZhbHNlO1xuICAgIChhc3luYyAoKSA9PiB7XG4gICAgICBpZiAoZ2V0VG9rZW4oKSkge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IHVzZXIgPSBhd2FpdCBhdXRoQXBpLm1lKCk7XG4gICAgICAgICAgaWYgKCFjYW5jZWxsZWQpIHtcbiAgICAgICAgICAgIHNldEN1cnJlbnRVc2VyKHVzZXIpO1xuICAgICAgICAgICAgc2V0QXV0aChnZXRUb2tlbigpLCB1c2VyKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgIGlmICghY2FuY2VsbGVkKSB7XG4gICAgICAgICAgICBjbGVhckF1dGgoKTtcbiAgICAgICAgICAgIHNldEN1cnJlbnRVc2VyKG51bGwpO1xuICAgICAgICAgICAgc2V0Tm90aWNlKFwiWW91ciBzZXNzaW9uIGhhcyBleHBpcmVkLiBQbGVhc2Ugc2lnbiBpbiBhZ2Fpbi5cIik7XG4gICAgICAgICAgfVxuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgIGlmICghY2FuY2VsbGVkKSBzZXRMb2FkaW5nKGZhbHNlKTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgICB9XG4gICAgfSkoKTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgY2FuY2VsbGVkID0gdHJ1ZTtcbiAgICB9O1xuICB9LCBbXSk7XG5cbiAgLy8gUmVhY3QgdG8gNDAxcyByYWlzZWQgYW55d2hlcmUgaW4gdGhlIGFwcCAoY2xpZW50LmpzIGRpc3BhdGNoZXMgdGhpcykuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3Qgb25VbmF1dGhvcml6ZWQgPSAoKSA9PiB7XG4gICAgICBzZXRDdXJyZW50VXNlcihudWxsKTtcbiAgICAgIHNldE5vdGljZShcIllvdXIgc2Vzc2lvbiBoYXMgZXhwaXJlZC4gUGxlYXNlIHNpZ24gaW4gYWdhaW4uXCIpO1xuICAgIH07XG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJkaGFuaXRpOnVuYXV0aG9yaXplZFwiLCBvblVuYXV0aG9yaXplZCk7XG4gICAgcmV0dXJuICgpID0+IHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwiZGhhbml0aTp1bmF1dGhvcml6ZWRcIiwgb25VbmF1dGhvcml6ZWQpO1xuICB9LCBbXSk7XG5cbiAgY29uc3QgdmFsdWUgPSB1c2VNZW1vKFxuICAgICgpID0+ICh7XG4gICAgICBjdXJyZW50VXNlcixcbiAgICAgIGlzQXV0aGVudGljYXRlZDogQm9vbGVhbihjdXJyZW50VXNlciksXG4gICAgICBsb2FkaW5nLFxuICAgICAgbm90aWNlLFxuICAgICAgc2V0Tm90aWNlLFxuICAgICAgbG9naW4sXG4gICAgICBsb2dvdXQsXG4gICAgICByZWZyZXNoVXNlcixcbiAgICAgIGFwcGx5U2Vzc2lvbixcbiAgICAgIC8vIFJvbGUgaGVscGVycyB1c2VkIGJ5IHRoZSBVSSB0byBoaWRlIHdyaXRlIGNvbnRyb2xzLlxuICAgICAgY2FuV3JpdGU6IEJvb2xlYW4oY3VycmVudFVzZXIgJiYgIVtcIkNyZWRpdCBBbmFseXN0XCJdLmluY2x1ZGVzKGN1cnJlbnRVc2VyLnJvbGUpKSxcbiAgICB9KSxcbiAgICBbY3VycmVudFVzZXIsIGxvYWRpbmcsIG5vdGljZSwgbG9naW4sIGxvZ291dCwgcmVmcmVzaFVzZXIsIGFwcGx5U2Vzc2lvbl1cbiAgKTtcblxuICByZXR1cm4gPEF1dGhDb250ZXh0LlByb3ZpZGVyIHZhbHVlPXt2YWx1ZX0+e2NoaWxkcmVufTwvQXV0aENvbnRleHQuUHJvdmlkZXI+O1xufVxuXG5leHBvcnQgZnVuY3Rpb24gdXNlQXV0aCgpIHtcbiAgY29uc3QgY3R4ID0gdXNlQ29udGV4dChBdXRoQ29udGV4dCk7XG4gIGlmICghY3R4KSB0aHJvdyBuZXcgRXJyb3IoXCJ1c2VBdXRoIG11c3QgYmUgdXNlZCBpbnNpZGUgPEF1dGhQcm92aWRlcj5cIik7XG4gIHJldHVybiBjdHg7XG59XG4iXSwiZmlsZSI6IkM6L1VzZXJzL3VzZXIvRG93bmxvYWRzL2RoYW5pdGktYXBwLXVwZ3JhZGVkL2RoYW5pdGktYXBwL2Zyb250ZW5kL3NyYy9jb250ZXh0L0F1dGhDb250ZXh0LmpzeCJ9