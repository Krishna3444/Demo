import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/DataQuality.jsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];const React = __vite__cjsImport3_react;import * as RefreshRuntime from "/@react-refresh";
var _jsxFileName = "C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/components/DataQuality.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=325d36c7";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
	if (!window.$RefreshReg$) {
		throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong.");
	}
	prevRefreshReg = window.$RefreshReg$;
	prevRefreshSig = window.$RefreshSig$;
	window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/components/DataQuality.jsx");
	window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=325d36c7";
import { attentionClass } from "/src/api.js";
export default function DataQuality({ dq }) {
	if (!dq) return null;
	return /* @__PURE__ */ _jsxDEV("div", { children: [
		/* @__PURE__ */ _jsxDEV("div", {
			className: "d-flex gap-2 flex-wrap mb-3",
			children: [
				/* @__PURE__ */ _jsxDEV("span", {
					className: "dq-pill dq-flag",
					children: [dq.affectedApplications, " applications affected"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 28,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("span", {
					className: "dq-pill dq-flag",
					children: [dq.totalIssues, " total flags"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 29,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("span", {
					className: "small text-muted align-self-center",
					children: [
						"All issues were detected and either cleaned or flagged during load (see ",
						/* @__PURE__ */ _jsxDEV("code", { children: "load_data.py" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 31,
							columnNumber: 83
						}, this),
						")."
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 30,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 27,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("div", {
			className: "table-responsive",
			style: { maxHeight: 480 },
			children: /* @__PURE__ */ _jsxDEV("table", {
				className: "table table-sm table-bordered table-apps mb-0",
				children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", { children: [
					/* @__PURE__ */ _jsxDEV("th", { children: "Application ID" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 38,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("th", { children: "Student" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 39,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("th", { children: "Flag" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 40,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("th", { children: "Description" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 41,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("th", { children: "Raw value" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 42,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("th", { children: "Cleaned / stored" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 43,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("th", { children: "Attention" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 44,
						columnNumber: 15
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 37,
					columnNumber: 13
				}, this) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 36,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("tbody", { children: dq.issues.length === 0 ? /* @__PURE__ */ _jsxDEV("tr", { children: /* @__PURE__ */ _jsxDEV("td", {
					colSpan: 7,
					className: "text-center text-muted fst-italic py-4",
					children: "No data-quality issues detected."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 50,
					columnNumber: 17
				}, this) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 49,
					columnNumber: 13
				}, this) : dq.issues.map((i, idx) => /* @__PURE__ */ _jsxDEV("tr", { children: [
					/* @__PURE__ */ _jsxDEV("td", { children: /* @__PURE__ */ _jsxDEV("strong", { children: i.applicationId }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 57,
						columnNumber: 23
					}, this) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 57,
						columnNumber: 19
					}, this),
					/* @__PURE__ */ _jsxDEV("td", { children: i.studentName }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 58,
						columnNumber: 19
					}, this),
					/* @__PURE__ */ _jsxDEV("td", { children: /* @__PURE__ */ _jsxDEV("code", { children: i.flag }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 59,
						columnNumber: 23
					}, this) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 59,
						columnNumber: 19
					}, this),
					/* @__PURE__ */ _jsxDEV("td", { children: i.description }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 60,
						columnNumber: 19
					}, this),
					/* @__PURE__ */ _jsxDEV("td", { children: /* @__PURE__ */ _jsxDEV("code", { children: i.rawValue || "—" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 61,
						columnNumber: 23
					}, this) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 61,
						columnNumber: 19
					}, this),
					/* @__PURE__ */ _jsxDEV("td", { children: /* @__PURE__ */ _jsxDEV("code", { children: i.cleanedValue || "—" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 62,
						columnNumber: 23
					}, this) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 62,
						columnNumber: 19
					}, this),
					/* @__PURE__ */ _jsxDEV("td", { children: /* @__PURE__ */ _jsxDEV("span", {
						className: `dq-pill ${attentionClass(i.attentionLevel)}`,
						children: i.attentionLevel
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 63,
						columnNumber: 23
					}, this) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 63,
						columnNumber: 19
					}, this)
				] }, idx, true, {
					fileName: _jsxFileName,
					lineNumber: 56,
					columnNumber: 13
				}, this)) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 47,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 35,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 34,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("div", {
			className: "mt-3 p-3 bg-light rounded border",
			children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Flag legend" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 71,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "row mt-2",
				children: dq.flagLegend.map((f, i) => /* @__PURE__ */ _jsxDEV("div", {
					className: "col-12 col-md-6 mb-2",
					children: [/* @__PURE__ */ _jsxDEV("code", {
						className: "me-2",
						children: f.code
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 75,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "small text-muted",
						children: f.description
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 76,
						columnNumber: 15
					}, this)]
				}, i, true, {
					fileName: _jsxFileName,
					lineNumber: 74,
					columnNumber: 11
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 72,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 70,
			columnNumber: 7
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 26,
		columnNumber: 5
	}, this);
}
_c = DataQuality;
var _c;
$RefreshReg$(_c, "DataQuality");
if (import.meta.hot && !inWebWorker) {
	window.$RefreshReg$ = prevRefreshReg;
	window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
	RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
		RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/components/DataQuality.jsx", currentExports);
		import.meta.hot.accept((nextExports) => {
			if (!nextExports) return;
			const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/components/DataQuality.jsx", currentExports, nextExports);
			if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
		});
	});
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsT0FBT0EsV0FBVztBQUNsQixTQUFTQyxzQkFBc0I7QUFFL0IsZUFBZSxTQUFTQyxZQUFZLEVBQUVDLE1BQU07Q0FDMUMsSUFBSSxDQUFDQSxJQUFJLE9BQU87Q0FDaEIsT0FDRSx3QkFBQyxPQUFEO0VBQ0Usd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUNFLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQWhCLENBQW1DQSxHQUFHQyxzQkFBcUIsd0JBQTRCOzs7Ozs7SUFDdkYsd0JBQUMsUUFBRDtLQUFNLFdBQVU7ZUFBaEIsQ0FBbUNELEdBQUdFLGFBQVksY0FBa0I7Ozs7OztJQUNwRSx3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUFoQjtNQUFvRDtNQUNzQix3QkFBQyxRQUFELFlBQU0sZUFBa0I7Ozs7O01BQUM7S0FDN0Y7Ozs7OztHQUNIOzs7Ozs7RUFDTCx3QkFBQyxPQUFEO0dBQUssV0FBVTtHQUFtQixPQUFPLEVBQUVDLFdBQVcsSUFBSTthQUN4RCx3QkFBQyxTQUFEO0lBQU8sV0FBVTtjQUFqQixDQUNFLHdCQUFDLFNBQUQsWUFDRSx3QkFBQyxNQUFEO0tBQ0Usd0JBQUMsTUFBRCxZQUFJLGlCQUFrQjs7Ozs7S0FDdEIsd0JBQUMsTUFBRCxZQUFJLFVBQVc7Ozs7O0tBQ2Ysd0JBQUMsTUFBRCxZQUFJLE9BQVE7Ozs7O0tBQ1osd0JBQUMsTUFBRCxZQUFJLGNBQWU7Ozs7O0tBQ25CLHdCQUFDLE1BQUQsWUFBSSxZQUFhOzs7OztLQUNqQix3QkFBQyxNQUFELFlBQUksbUJBQW9COzs7OztLQUN4Qix3QkFBQyxNQUFELFlBQUksWUFBYTs7Ozs7SUFDZjs7OzthQUNDOzs7O2NBQ1Asd0JBQUMsU0FBRCxZQUNHSCxHQUFHSSxPQUFPQyxXQUFXLElBQ3BCLHdCQUFDLE1BQUQsWUFDRSx3QkFBQyxNQUFEO0tBQUksU0FBUztLQUFHLFdBQVU7ZUFBd0M7SUFFOUQ7Ozs7YUFDRjs7OztlQUVKTCxHQUFHSSxPQUFPRSxLQUFLQyxHQUFHQyxRQUNoQix3QkFBQyxNQUFEO0tBQ0Usd0JBQUMsTUFBRCxZQUFJLHdCQUFDLFVBQUQsWUFBU0QsRUFBRUUsY0FBc0I7Ozs7Y0FBSzs7Ozs7S0FDMUMsd0JBQUMsTUFBRCxZQUFLRixFQUFFRyxZQUFnQjs7Ozs7S0FDdkIsd0JBQUMsTUFBRCxZQUFJLHdCQUFDLFFBQUQsWUFBT0gsRUFBRUksS0FBVzs7OztjQUFLOzs7OztLQUM3Qix3QkFBQyxNQUFELFlBQUtKLEVBQUVLLFlBQWdCOzs7OztLQUN2Qix3QkFBQyxNQUFELFlBQUksd0JBQUMsUUFBRCxZQUFPTCxFQUFFTSxZQUFZLElBQWU7Ozs7Y0FBSzs7Ozs7S0FDN0Msd0JBQUMsTUFBRCxZQUFJLHdCQUFDLFFBQUQsWUFBT04sRUFBRU8sZ0JBQWdCLElBQWU7Ozs7Y0FBSzs7Ozs7S0FDakQsd0JBQUMsTUFBRCxZQUFJLHdCQUFDLFFBQUQ7TUFBTSxXQUFXLFdBQVdoQixlQUFlUyxFQUFFUSxjQUFjO2dCQUFNUixFQUFFUTtLQUFxQjs7OztjQUFLOzs7OztJQUMvRixLQVJLUDs7OztXQVFMLENBQ0wsRUFFRTs7OztZQUNGOzs7Ozs7RUFDSjs7Ozs7RUFDTCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsVUFBRCxZQUFRLGNBQW1COzs7O2FBQzNCLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ1pSLEdBQUdnQixXQUFXVixLQUFLVyxHQUFHVixNQUNyQix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQVFVLEVBQUVDO0tBQVc7Ozs7ZUFDckMsd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQW9CRCxFQUFFTDtLQUFrQjs7OzthQUNyRDtPQUhzQ0w7Ozs7V0FHdEMsQ0FDTjtHQUNFOzs7O1dBQ0Y7Ozs7OztDQUNGOzs7OztBQUVUO0FBQUNZLEtBNUR1QnBCO0FBQVcsSUFBQW9CO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwiYXR0ZW50aW9uQ2xhc3MiLCJEYXRhUXVhbGl0eSIsImRxIiwiYWZmZWN0ZWRBcHBsaWNhdGlvbnMiLCJ0b3RhbElzc3VlcyIsIm1heEhlaWdodCIsImlzc3VlcyIsImxlbmd0aCIsIm1hcCIsImkiLCJpZHgiLCJhcHBsaWNhdGlvbklkIiwic3R1ZGVudE5hbWUiLCJmbGFnIiwiZGVzY3JpcHRpb24iLCJyYXdWYWx1ZSIsImNsZWFuZWRWYWx1ZSIsImF0dGVudGlvbkxldmVsIiwiZmxhZ0xlZ2VuZCIsImYiLCJjb2RlIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiRGF0YVF1YWxpdHkuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGF0dGVudGlvbkNsYXNzIH0gZnJvbSBcIi4uL2FwaS5qc1wiO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBEYXRhUXVhbGl0eSh7IGRxIH0pIHtcbiAgaWYgKCFkcSkgcmV0dXJuIG51bGw7XG4gIHJldHVybiAoXG4gICAgPGRpdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZC1mbGV4IGdhcC0yIGZsZXgtd3JhcCBtYi0zXCI+XG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImRxLXBpbGwgZHEtZmxhZ1wiPntkcS5hZmZlY3RlZEFwcGxpY2F0aW9uc30gYXBwbGljYXRpb25zIGFmZmVjdGVkPC9zcGFuPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJkcS1waWxsIGRxLWZsYWdcIj57ZHEudG90YWxJc3N1ZXN9IHRvdGFsIGZsYWdzPC9zcGFuPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzbWFsbCB0ZXh0LW11dGVkIGFsaWduLXNlbGYtY2VudGVyXCI+XG4gICAgICAgICAgQWxsIGlzc3VlcyB3ZXJlIGRldGVjdGVkIGFuZCBlaXRoZXIgY2xlYW5lZCBvciBmbGFnZ2VkIGR1cmluZyBsb2FkIChzZWUgPGNvZGU+bG9hZF9kYXRhLnB5PC9jb2RlPikuXG4gICAgICAgIDwvc3Bhbj5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0YWJsZS1yZXNwb25zaXZlXCIgc3R5bGU9e3sgbWF4SGVpZ2h0OiA0ODAgfX0+XG4gICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJ0YWJsZSB0YWJsZS1zbSB0YWJsZS1ib3JkZXJlZCB0YWJsZS1hcHBzIG1iLTBcIj5cbiAgICAgICAgICA8dGhlYWQ+XG4gICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgIDx0aD5BcHBsaWNhdGlvbiBJRDwvdGg+XG4gICAgICAgICAgICAgIDx0aD5TdHVkZW50PC90aD5cbiAgICAgICAgICAgICAgPHRoPkZsYWc8L3RoPlxuICAgICAgICAgICAgICA8dGg+RGVzY3JpcHRpb248L3RoPlxuICAgICAgICAgICAgICA8dGg+UmF3IHZhbHVlPC90aD5cbiAgICAgICAgICAgICAgPHRoPkNsZWFuZWQgLyBzdG9yZWQ8L3RoPlxuICAgICAgICAgICAgICA8dGg+QXR0ZW50aW9uPC90aD5cbiAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICA8dGJvZHk+XG4gICAgICAgICAgICB7ZHEuaXNzdWVzLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgIDx0ZCBjb2xTcGFuPXs3fSBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciB0ZXh0LW11dGVkIGZzdC1pdGFsaWMgcHktNFwiPlxuICAgICAgICAgICAgICAgICAgTm8gZGF0YS1xdWFsaXR5IGlzc3VlcyBkZXRlY3RlZC5cbiAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgZHEuaXNzdWVzLm1hcCgoaSwgaWR4KSA9PiAoXG4gICAgICAgICAgICAgICAgPHRyIGtleT17aWR4fT5cbiAgICAgICAgICAgICAgICAgIDx0ZD48c3Ryb25nPntpLmFwcGxpY2F0aW9uSWR9PC9zdHJvbmc+PC90ZD5cbiAgICAgICAgICAgICAgICAgIDx0ZD57aS5zdHVkZW50TmFtZX08L3RkPlxuICAgICAgICAgICAgICAgICAgPHRkPjxjb2RlPntpLmZsYWd9PC9jb2RlPjwvdGQ+XG4gICAgICAgICAgICAgICAgICA8dGQ+e2kuZGVzY3JpcHRpb259PC90ZD5cbiAgICAgICAgICAgICAgICAgIDx0ZD48Y29kZT57aS5yYXdWYWx1ZSB8fCBcIlxcdTIwMTRcIn08L2NvZGU+PC90ZD5cbiAgICAgICAgICAgICAgICAgIDx0ZD48Y29kZT57aS5jbGVhbmVkVmFsdWUgfHwgXCJcXHUyMDE0XCJ9PC9jb2RlPjwvdGQ+XG4gICAgICAgICAgICAgICAgICA8dGQ+PHNwYW4gY2xhc3NOYW1lPXtgZHEtcGlsbCAke2F0dGVudGlvbkNsYXNzKGkuYXR0ZW50aW9uTGV2ZWwpfWB9PntpLmF0dGVudGlvbkxldmVsfTwvc3Bhbj48L3RkPlxuICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICkpXG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgIDwvdGFibGU+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMyBwLTMgYmctbGlnaHQgcm91bmRlZCBib3JkZXJcIj5cbiAgICAgICAgPHN0cm9uZz5GbGFnIGxlZ2VuZDwvc3Ryb25nPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdyBtdC0yXCI+XG4gICAgICAgICAge2RxLmZsYWdMZWdlbmQubWFwKChmLCBpKSA9PiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC0xMiBjb2wtbWQtNiBtYi0yXCIga2V5PXtpfT5cbiAgICAgICAgICAgICAgPGNvZGUgY2xhc3NOYW1lPVwibWUtMlwiPntmLmNvZGV9PC9jb2RlPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzbWFsbCB0ZXh0LW11dGVkXCI+e2YuZGVzY3JpcHRpb259PC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6IkM6L1VzZXJzL3VzZXIvRG93bmxvYWRzL2RoYW5pdGktYXBwLXVwZ3JhZGVkL2RoYW5pdGktYXBwL2Zyb250ZW5kL3NyYy9jb21wb25lbnRzL0RhdGFRdWFsaXR5LmpzeCJ9