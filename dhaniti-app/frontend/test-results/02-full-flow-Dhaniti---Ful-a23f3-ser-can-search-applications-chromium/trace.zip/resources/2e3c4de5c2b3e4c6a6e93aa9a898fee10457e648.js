import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ApplicationsTable.jsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport1_react_jsxDevRuntime["Fragment"];const React = __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];import * as RefreshRuntime from "/@react-refresh";
var _jsxFileName = "C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/components/ApplicationsTable.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=325d36c7";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
	if (!window.$RefreshReg$) {
		throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong.");
	}
	prevRefreshReg = window.$RefreshReg$;
	prevRefreshSig = window.$RefreshSig$;
	window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/components/ApplicationsTable.jsx");
	window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=325d36c7";
import { itemsApi, formatINR, statusClass, attentionClass } from "/src/api/items.js";
import { useAuth } from "/src/context/AuthContext.jsx";
import { useToast } from "/src/context/ToastContext.jsx";
import ConfirmModal from "/src/components/ConfirmModal.jsx";
import ItemFormModal from "/src/components/ItemFormModal.jsx";
import ItemViewModal from "/src/components/ItemViewModal.jsx";
const STATUS_OPTIONS = [
	"Submitted",
	"Under Review",
	"Approved",
	"Rejected"
];
const PAGE_SIZE = 10;
export default function ApplicationsTable({ filters }) {
	_s();
	const toast = useToast();
	const { canWrite } = useAuth();
	const [apps, setApps] = useState([]);
	const [total, setTotal] = useState(0);
	const [page, setPage] = useState(1);
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState("");
	const [search, setSearch] = useState("");
	const [status, setStatus] = useState("all");
	const [course, setCourse] = useState("all");
	const [inst, setInst] = useState("all");
	const [att, setAtt] = useState("all");
	const [sortBy, setSortBy] = useState("applicationDate");
	const [sortDir, setSortDir] = useState("desc");
	const [editingId, setEditingId] = useState(null);
	const [editStatus, setEditStatus] = useState("");
	const [statusSaving, setStatusSaving] = useState(false);
	// Modals
	const [viewItem, setViewItem] = useState(null);
	const [formModal, setFormModal] = useState({
		show: false,
		mode: "create",
		item: null
	});
	const [deleteTarget, setDeleteTarget] = useState(null);
	const [deleting, setDeleting] = useState(false);
	function buildQuery(extra = {}) {
		const params = {
			search,
			status,
			courseId: course,
			institutionId: inst,
			attentionLevel: att,
			sortBy,
			sortDir,
			page: extra.page ?? page,
			pageSize: PAGE_SIZE,
			...extra
		};
		const search_ = new URLSearchParams();
		Object.entries(params).forEach(([key, value]) => {
			if (value !== undefined && value !== null && value !== "" && value !== "all") {
				search_.set(key, value);
			}
		});
		return search_.toString();
	}
	async function loadRows(queryString = buildQuery()) {
		setLoading(true);
		try {
			const res = await itemsApi.getItems(Object.fromEntries(new URLSearchParams(queryString)));
			setApps(res.data || []);
			setTotal(res.count ?? (res.data || []).length);
			setError("");
		} catch (e) {
			setError(e.message);
		} finally {
			setLoading(false);
		}
	}
	useEffect(() => {
		const timer = setTimeout(() => {
			setPage(1);
			loadRows(buildQuery({ page: 1 }));
		}, 250);
		return () => clearTimeout(timer);
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [
		search,
		status,
		course,
		inst,
		att,
		sortBy,
		sortDir
	]);
	useEffect(() => {
		if (page > 1) loadRows();
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [page]);
	function toggleSort(col) {
		if (sortBy === col) {
			setSortDir(sortDir === "asc" ? "desc" : "asc");
		} else {
			setSortBy(col);
			setSortDir("desc");
		}
	}
	async function saveStatus(app) {
		setStatusSaving(true);
		try {
			await itemsApi.updateStatus(app.id, editStatus);
			toast.success(`Updated ${app.id} \u2192 ${editStatus}`);
			setEditingId(null);
			await loadRows();
		} catch (e) {
			toast.error(`Error updating status: ${e.message}`);
		} finally {
			setStatusSaving(false);
		}
	}
	async function handleDelete() {
		if (!deleteTarget) return;
		setDeleting(true);
		try {
			await itemsApi.deleteItem(deleteTarget.id);
			toast.success(`Record ${deleteTarget.id} deleted successfully.`);
			setDeleteTarget(null);
			// If we deleted the last row on the last page, step back one page.
			if (apps.length === 1 && page > 1) {
				setPage(page - 1);
			} else {
				await loadRows();
			}
		} catch (e) {
			toast.error(`Error deleting record: ${e.message}`);
		} finally {
			setDeleting(false);
		}
	}
	const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
	const from = total === 0 ? 0 : (page - 1) * PAGE_SIZE + 1;
	const to = Math.min(page * PAGE_SIZE, total);
	return /* @__PURE__ */ _jsxDEV("div", { children: [
		/* @__PURE__ */ _jsxDEV("div", {
			className: "row g-2 mb-3 align-items-center",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "col-12 col-md-3",
					children: /* @__PURE__ */ _jsxDEV("div", {
						className: "input-group input-group-sm",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "input-group-text",
							children: /* @__PURE__ */ _jsxDEV("i", {
								className: "bi bi-search",
								"aria-hidden": "true"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 164,
								columnNumber: 48
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 164,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							type: "search",
							className: "form-control",
							placeholder: "Search by App ID or student name…",
							value: search,
							onChange: (e) => setSearch(e.target.value),
							"aria-label": "Search applications"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 165,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 163,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 162,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "col-6 col-md-2",
					children: /* @__PURE__ */ _jsxDEV("select", {
						className: "form-select form-select-sm",
						value: status,
						onChange: (e) => setStatus(e.target.value),
						"aria-label": "Filter by status",
						children: [/* @__PURE__ */ _jsxDEV("option", {
							value: "all",
							children: "All statuses"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 177,
							columnNumber: 13
						}, this), STATUS_OPTIONS.map((s) => /* @__PURE__ */ _jsxDEV("option", {
							value: s,
							children: s
						}, s, false, {
							fileName: _jsxFileName,
							lineNumber: 178,
							columnNumber: 40
						}, this))]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 176,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 175,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "col-6 col-md-2",
					children: /* @__PURE__ */ _jsxDEV("select", {
						className: "form-select form-select-sm",
						value: course,
						onChange: (e) => setCourse(e.target.value),
						"aria-label": "Filter by course",
						children: [/* @__PURE__ */ _jsxDEV("option", {
							value: "all",
							children: "All courses"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 183,
							columnNumber: 13
						}, this), filters?.courses?.map((c) => /* @__PURE__ */ _jsxDEV("option", {
							value: c.id,
							children: c.name
						}, c.id, false, {
							fileName: _jsxFileName,
							lineNumber: 184,
							columnNumber: 43
						}, this))]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 182,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 181,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "col-6 col-md-2",
					children: /* @__PURE__ */ _jsxDEV("select", {
						className: "form-select form-select-sm",
						value: inst,
						onChange: (e) => setInst(e.target.value),
						"aria-label": "Filter by institution",
						children: [/* @__PURE__ */ _jsxDEV("option", {
							value: "all",
							children: "All institutions"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 189,
							columnNumber: 13
						}, this), filters?.institutions?.map((i) => /* @__PURE__ */ _jsxDEV("option", {
							value: i.id,
							children: i.name
						}, i.id, false, {
							fileName: _jsxFileName,
							lineNumber: 190,
							columnNumber: 48
						}, this))]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 188,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 187,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "col-6 col-md-2",
					children: /* @__PURE__ */ _jsxDEV("select", {
						className: "form-select form-select-sm",
						value: att,
						onChange: (e) => setAtt(e.target.value),
						"aria-label": "Filter by attention level",
						children: [
							/* @__PURE__ */ _jsxDEV("option", {
								value: "all",
								children: "All attention levels"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 195,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("option", {
								value: "Low Attention",
								children: "Low Attention"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 196,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("option", {
								value: "Review Required",
								children: "Review Required"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 197,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("option", {
								value: "High Attention",
								children: "High Attention"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 198,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 194,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 193,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "col-12 col-md-1 d-flex gap-1",
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							className: `sort-btn ${sortBy === "loanAmountRequestedInr" ? "active" : ""}`,
							onClick: () => toggleSort("loanAmountRequestedInr"),
							title: "Sort by loan amount",
							children: ["Loan ", sortBy === "loanAmountRequestedInr" ? sortDir === "asc" ? "↑" : "↓" : "↕"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 202,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							className: `sort-btn ${sortBy === "creditScore" ? "active" : ""}`,
							onClick: () => toggleSort("creditScore"),
							title: "Sort by credit score",
							children: ["Credit ", sortBy === "creditScore" ? sortDir === "asc" ? "↑" : "↓" : "↕"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 205,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							className: `sort-btn ${sortBy === "applicationDate" ? "active" : ""}`,
							onClick: () => toggleSort("applicationDate"),
							title: "Sort by application date",
							children: ["Date ", sortBy === "applicationDate" ? sortDir === "asc" ? "↑" : "↓" : "↕"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 208,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 201,
					columnNumber: 9
				}, this),
				canWrite && /* @__PURE__ */ _jsxDEV("div", {
					className: "col-12 col-md-12 text-md-end",
					children: /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: "btn btn-sm btn-dhaniti",
						onClick: () => setFormModal({
							show: true,
							mode: "create",
							item: null
						}),
						children: [/* @__PURE__ */ _jsxDEV("i", {
							className: "bi bi-plus-circle me-1",
							"aria-hidden": "true"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 215,
							columnNumber: 15
						}, this), "Add Record"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 214,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 213,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 161,
			columnNumber: 7
		}, this),
		error && /* @__PURE__ */ _jsxDEV("div", {
			className: "alert alert-danger py-2 mb-3",
			children: ["Error: ", error]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 222,
			columnNumber: 17
		}, this),
		/* @__PURE__ */ _jsxDEV("div", {
			className: "text-muted small mb-2",
			"data-testid": "rows-summary",
			children: loading ? "Loading records…" : `Showing ${from}\u2013${to} of ${total} applications`
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 224,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("div", {
			className: "table-responsive",
			style: { maxHeight: 560 },
			children: /* @__PURE__ */ _jsxDEV("table", {
				className: "table table-sm table-hover table-apps align-middle",
				children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", { children: [
					/* @__PURE__ */ _jsxDEV("th", { children: "App ID" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 232,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("th", { children: "Student" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 233,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("th", {
						className: "d-none d-md-table-cell",
						children: "Institution"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 234,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("th", {
						className: "d-none d-lg-table-cell",
						children: "Course"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 235,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("th", {
						className: "text-num",
						children: "Loan (\\u20b9)"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 236,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("th", {
						className: "text-num d-none d-md-table-cell",
						children: "Credit"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 237,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("th", { children: "Status" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 238,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("th", {
						className: "d-none d-lg-table-cell",
						children: "Attention"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 239,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("th", {
						className: "d-none d-lg-table-cell",
						children: "Date"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 240,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("th", {
						className: "text-center",
						style: { width: 130 },
						children: "Actions"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 241,
						columnNumber: 15
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 231,
					columnNumber: 13
				}, this) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 230,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("tbody", { children: apps.length === 0 && !loading ? /* @__PURE__ */ _jsxDEV("tr", { children: /* @__PURE__ */ _jsxDEV("td", {
					colSpan: 10,
					className: "text-center text-muted fst-italic py-4",
					children: "No applications match the current filters."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 247,
					columnNumber: 17
				}, this) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 246,
					columnNumber: 13
				}, this) : apps.map((a) => /* @__PURE__ */ _jsxDEV("tr", { children: [
					/* @__PURE__ */ _jsxDEV("td", { children: /* @__PURE__ */ _jsxDEV("strong", { children: a.id }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 254,
						columnNumber: 23
					}, this) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 254,
						columnNumber: 19
					}, this),
					/* @__PURE__ */ _jsxDEV("td", { children: [/* @__PURE__ */ _jsxDEV("div", { children: a.studentName }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 256,
						columnNumber: 21
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "small text-muted d-md-none",
						children: a.institutionName
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 257,
						columnNumber: 21
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 255,
						columnNumber: 19
					}, this),
					/* @__PURE__ */ _jsxDEV("td", {
						className: "d-none d-md-table-cell",
						children: a.institutionName
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 259,
						columnNumber: 19
					}, this),
					/* @__PURE__ */ _jsxDEV("td", {
						className: "d-none d-lg-table-cell",
						children: a.courseName
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 260,
						columnNumber: 19
					}, this),
					/* @__PURE__ */ _jsxDEV("td", {
						className: "text-num",
						children: formatINR(a.loanAmountRequestedInr)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 261,
						columnNumber: 19
					}, this),
					/* @__PURE__ */ _jsxDEV("td", {
						className: "text-num d-none d-md-table-cell",
						children: a.creditScore !== null ? a.creditScore : /* @__PURE__ */ _jsxDEV("em", {
							style: { color: "#9ca3af" },
							children: "N/A"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 263,
							columnNumber: 63
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 262,
						columnNumber: 19
					}, this),
					/* @__PURE__ */ _jsxDEV("td", { children: editingId === a.id ? /* @__PURE__ */ _jsxDEV("div", {
						className: "d-flex align-items-center gap-1",
						children: [
							/* @__PURE__ */ _jsxDEV("select", {
								className: "form-select form-select-sm py-0",
								style: { width: 110 },
								value: editStatus,
								onChange: (e) => setEditStatus(e.target.value),
								disabled: statusSaving,
								children: STATUS_OPTIONS.map((s) => /* @__PURE__ */ _jsxDEV("option", {
									value: s,
									children: s
								}, s, false, {
									fileName: _jsxFileName,
									lineNumber: 275,
									columnNumber: 54
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 268,
								columnNumber: 25
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								className: "btn btn-sm btn-success py-0 px-1",
								onClick: () => saveStatus(a),
								disabled: statusSaving,
								title: "Save",
								children: /* @__PURE__ */ _jsxDEV("i", {
									className: "bi bi-check",
									"aria-hidden": "true"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 278,
									columnNumber: 27
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 277,
								columnNumber: 25
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								className: "btn btn-sm btn-secondary py-0 px-1",
								onClick: () => setEditingId(null),
								disabled: statusSaving,
								title: "Cancel",
								children: /* @__PURE__ */ _jsxDEV("i", {
									className: "bi bi-x",
									"aria-hidden": "true"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 281,
									columnNumber: 27
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 280,
								columnNumber: 25
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 267,
						columnNumber: 17
					}, this) : /* @__PURE__ */ _jsxDEV("span", {
						className: `dq-pill ${statusClass(a.applicationStatus)}`,
						style: { cursor: canWrite ? "pointer" : "default" },
						onClick: () => {
							if (!canWrite) return;
							setEditingId(a.id);
							setEditStatus(a.applicationStatus);
						},
						title: canWrite ? "Click to update status" : "Read-only role",
						children: a.applicationStatus
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 285,
						columnNumber: 17
					}, this) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 265,
						columnNumber: 19
					}, this),
					/* @__PURE__ */ _jsxDEV("td", {
						className: "d-none d-lg-table-cell",
						children: /* @__PURE__ */ _jsxDEV("span", {
							className: `dq-pill ${attentionClass(a.attentionLevel)}`,
							children: a.attentionLevel
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 300,
							columnNumber: 21
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 299,
						columnNumber: 19
					}, this),
					/* @__PURE__ */ _jsxDEV("td", {
						className: "d-none d-lg-table-cell",
						children: a.applicationDate
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 302,
						columnNumber: 19
					}, this),
					/* @__PURE__ */ _jsxDEV("td", {
						className: "text-center",
						children: /* @__PURE__ */ _jsxDEV("div", {
							className: "btn-group btn-group-sm",
							role: "group",
							"aria-label": `Actions for ${a.id}`,
							children: [/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								className: "btn btn-outline-secondary",
								onClick: () => setViewItem(a),
								title: "View details",
								children: /* @__PURE__ */ _jsxDEV("i", {
									className: "bi bi-eye",
									"aria-hidden": "true"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 306,
									columnNumber: 25
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 305,
								columnNumber: 23
							}, this), canWrite && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								className: "btn btn-outline-primary",
								onClick: () => setFormModal({
									show: true,
									mode: "edit",
									item: a
								}),
								title: "Edit record",
								children: /* @__PURE__ */ _jsxDEV("i", {
									className: "bi bi-pencil",
									"aria-hidden": "true"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 311,
									columnNumber: 29
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 310,
								columnNumber: 27
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								className: "btn btn-outline-danger",
								onClick: () => setDeleteTarget(a),
								title: "Delete record",
								children: /* @__PURE__ */ _jsxDEV("i", {
									className: "bi bi-trash",
									"aria-hidden": "true"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 314,
									columnNumber: 29
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 313,
								columnNumber: 27
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 309,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 304,
							columnNumber: 21
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 303,
						columnNumber: 19
					}, this)
				] }, a.id, true, {
					fileName: _jsxFileName,
					lineNumber: 253,
					columnNumber: 13
				}, this)) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 244,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 229,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 228,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("nav", {
			"aria-label": "Applications pagination",
			className: "mt-3",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "d-flex flex-wrap justify-content-between align-items-center gap-2",
				children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "text-muted small",
					children: [
						"Page ",
						page,
						" of ",
						totalPages
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 330,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("ul", {
					className: "pagination pagination-sm mb-0",
					children: [
						/* @__PURE__ */ _jsxDEV("li", {
							className: `page-item ${page <= 1 ? "disabled" : ""}`,
							children: /* @__PURE__ */ _jsxDEV("button", {
								className: "page-link",
								onClick: () => setPage((p) => Math.max(1, p - 1)),
								disabled: page <= 1,
								"aria-label": "Previous page",
								children: /* @__PURE__ */ _jsxDEV("i", {
									className: "bi bi-chevron-left",
									"aria-hidden": "true"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 336,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 335,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 334,
							columnNumber: 13
						}, this),
						Array.from({ length: totalPages }, (_, i) => i + 1).filter((p) => p === 1 || p === totalPages || Math.abs(p - page) <= 2).map((p, idx, arr) => /* @__PURE__ */ _jsxDEV(React.Fragment, { children: [idx > 0 && arr[idx - 1] !== p - 1 && /* @__PURE__ */ _jsxDEV("li", {
							className: "page-item disabled",
							children: /* @__PURE__ */ _jsxDEV("span", {
								className: "page-link",
								children: "…"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 344,
								columnNumber: 50
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 344,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("li", {
							className: `page-item ${p === page ? "active" : ""}`,
							children: /* @__PURE__ */ _jsxDEV("button", {
								className: "page-link",
								onClick: () => setPage(p),
								"aria-current": p === page ? "page" : undefined,
								children: p
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 347,
								columnNumber: 21
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 346,
							columnNumber: 19
						}, this)] }, p, true, {
							fileName: _jsxFileName,
							lineNumber: 342,
							columnNumber: 13
						}, this)),
						/* @__PURE__ */ _jsxDEV("li", {
							className: `page-item ${page >= totalPages ? "disabled" : ""}`,
							children: /* @__PURE__ */ _jsxDEV("button", {
								className: "page-link",
								onClick: () => setPage((p2) => Math.min(totalPages, p2 + 1)),
								disabled: page >= totalPages,
								"aria-label": "Next page",
								children: /* @__PURE__ */ _jsxDEV("i", {
									className: "bi bi-chevron-right",
									"aria-hidden": "true"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 355,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 354,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 353,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 333,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 329,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 328,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(ItemViewModal, {
			show: Boolean(viewItem),
			item: viewItem,
			onClose: () => setViewItem(null),
			onEdit: () => {
				const item = viewItem;
				setViewItem(null);
				setFormModal({
					show: true,
					mode: "edit",
					item
				});
			},
			canWrite
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 363,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(ItemFormModal, {
			show: formModal.show,
			mode: formModal.mode,
			item: formModal.item,
			filters,
			onClose: () => setFormModal({
				show: false,
				mode: "create",
				item: null
			}),
			onSaved: async () => {
				setFormModal({
					show: false,
					mode: "create",
					item: null
				});
				await loadRows();
			}
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 375,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(ConfirmModal, {
			show: Boolean(deleteTarget),
			title: "Delete Application?",
			message: deleteTarget ? `Are you sure you want to permanently delete application ${deleteTarget.id} (${deleteTarget.studentName})? This cannot be undone.` : "",
			confirmLabel: "Delete",
			loading: deleting,
			onConfirm: handleDelete,
			onCancel: () => setDeleteTarget(null)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 387,
			columnNumber: 7
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 159,
		columnNumber: 5
	}, this);
}
_s(ApplicationsTable, "NzEKxt1NIb8wasQVzZgALkTirss=", false, function() {
	return [useToast, useAuth];
});
_c = ApplicationsTable;
var _c;
$RefreshReg$(_c, "ApplicationsTable");
if (import.meta.hot && !inWebWorker) {
	window.$RefreshReg$ = prevRefreshReg;
	window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
	RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
		RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/components/ApplicationsTable.jsx", currentExports);
		import.meta.hot.accept((nextExports) => {
			if (!nextExports) return;
			const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/components/ApplicationsTable.jsx", currentExports, nextExports);
			if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
		});
	});
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLE9BQU9BLFNBQVNDLFdBQVdDLGdCQUFnQjtBQUMzQyxTQUFTQyxVQUFVQyxXQUFXQyxhQUFhQyxzQkFBc0I7QUFDakUsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxnQkFBZ0I7QUFDekIsT0FBT0Msa0JBQWtCO0FBQ3pCLE9BQU9DLG1CQUFtQjtBQUMxQixPQUFPQyxtQkFBbUI7QUFFMUIsTUFBTUMsaUJBQWlCO0NBQUM7Q0FBYTtDQUFnQjtDQUFZO0FBQVU7QUFDM0UsTUFBTUMsWUFBWTtBQUVsQixlQUFlLFNBQVNDLGtCQUFrQixFQUFFQyxXQUFXO0NBQUFDLEdBQUE7Q0FDckQsTUFBTUMsUUFBUVQsU0FBUztDQUN2QixNQUFNLEVBQUVVLGFBQWFYLFFBQVE7Q0FFN0IsTUFBTSxDQUFDWSxNQUFNQyxXQUFXbEIsU0FBUyxFQUFFO0NBQ25DLE1BQU0sQ0FBQ21CLE9BQU9DLFlBQVlwQixTQUFTLENBQUM7Q0FDcEMsTUFBTSxDQUFDcUIsTUFBTUMsV0FBV3RCLFNBQVMsQ0FBQztDQUNsQyxNQUFNLENBQUN1QixTQUFTQyxjQUFjeEIsU0FBUyxJQUFJO0NBQzNDLE1BQU0sQ0FBQ3lCLE9BQU9DLFlBQVkxQixTQUFTLEVBQUU7Q0FFckMsTUFBTSxDQUFDMkIsUUFBUUMsYUFBYTVCLFNBQVMsRUFBRTtDQUN2QyxNQUFNLENBQUM2QixRQUFRQyxhQUFhOUIsU0FBUyxLQUFLO0NBQzFDLE1BQU0sQ0FBQytCLFFBQVFDLGFBQWFoQyxTQUFTLEtBQUs7Q0FDMUMsTUFBTSxDQUFDaUMsTUFBTUMsV0FBV2xDLFNBQVMsS0FBSztDQUN0QyxNQUFNLENBQUNtQyxLQUFLQyxVQUFVcEMsU0FBUyxLQUFLO0NBQ3BDLE1BQU0sQ0FBQ3FDLFFBQVFDLGFBQWF0QyxTQUFTLGlCQUFpQjtDQUN0RCxNQUFNLENBQUN1QyxTQUFTQyxjQUFjeEMsU0FBUyxNQUFNO0NBRTdDLE1BQU0sQ0FBQ3lDLFdBQVdDLGdCQUFnQjFDLFNBQVMsSUFBSTtDQUMvQyxNQUFNLENBQUMyQyxZQUFZQyxpQkFBaUI1QyxTQUFTLEVBQUU7Q0FDL0MsTUFBTSxDQUFDNkMsY0FBY0MsbUJBQW1COUMsU0FBUyxLQUFLOztDQUd0RCxNQUFNLENBQUMrQyxVQUFVQyxlQUFlaEQsU0FBUyxJQUFJO0NBQzdDLE1BQU0sQ0FBQ2lELFdBQVdDLGdCQUFnQmxELFNBQVM7RUFBRW1ELE1BQU07RUFBT0MsTUFBTTtFQUFVQyxNQUFNO0NBQUssQ0FBQztDQUN0RixNQUFNLENBQUNDLGNBQWNDLG1CQUFtQnZELFNBQVMsSUFBSTtDQUNyRCxNQUFNLENBQUN3RCxVQUFVQyxlQUFlekQsU0FBUyxLQUFLO0NBRTlDLFNBQVMwRCxXQUFXQyxRQUFRLENBQUMsR0FBRztFQUM5QixNQUFNQyxTQUFTO0dBQ2JqQztHQUNBRTtHQUNBZ0MsVUFBVTlCO0dBQ1YrQixlQUFlN0I7R0FDZjhCLGdCQUFnQjVCO0dBQ2hCRTtHQUNBRTtHQUNBbEIsTUFBTXNDLE1BQU10QyxRQUFRQTtHQUNwQjJDLFVBQVVyRDtHQUNWLEdBQUdnRDtFQUNMO0VBQ0EsTUFBTU0sVUFBVSxJQUFJQyxnQkFBZ0I7RUFDcENDLE9BQU9DLFFBQVFSLE1BQU0sQ0FBQyxDQUFDUyxTQUFTLENBQUNDLEtBQUtDLFdBQVc7R0FDL0MsSUFBSUEsVUFBVUMsYUFBYUQsVUFBVSxRQUFRQSxVQUFVLE1BQU1BLFVBQVUsT0FBTztJQUM1RU4sUUFBUVEsSUFBSUgsS0FBS0MsS0FBSztHQUN4QjtFQUNGLENBQUM7RUFDRCxPQUFPTixRQUFRUyxTQUFTO0NBQzFCO0NBRUEsZUFBZUMsU0FBU0MsY0FBY2xCLFdBQVcsR0FBRztFQUNsRGxDLFdBQVcsSUFBSTtFQUNmLElBQUk7R0FDRixNQUFNcUQsTUFBTSxNQUFNNUUsU0FBUzZFLFNBQ3pCWCxPQUFPWSxZQUFZLElBQUliLGdCQUFnQlUsV0FBVyxDQUFDLENBQ3JEO0dBQ0ExRCxRQUFRMkQsSUFBSUcsUUFBUSxFQUFFO0dBQ3RCNUQsU0FBU3lELElBQUlJLFVBQVVKLElBQUlHLFFBQVEsR0FBRSxDQUFFRSxNQUFNO0dBQzdDeEQsU0FBUyxFQUFFO0VBQ2IsU0FBU3lELEdBQUc7R0FDVnpELFNBQVN5RCxFQUFFQyxPQUFPO0VBQ3BCLFVBQVU7R0FDUjVELFdBQVcsS0FBSztFQUNsQjtDQUNGO0NBRUF6QixnQkFBZ0I7RUFDZCxNQUFNc0YsUUFBUUMsaUJBQWlCO0dBQzdCaEUsUUFBUSxDQUFDO0dBQ1RxRCxTQUFTakIsV0FBVyxFQUFFckMsTUFBTSxFQUFFLENBQUMsQ0FBQztFQUNsQyxHQUFHLEdBQUc7RUFDTixhQUFha0UsYUFBYUYsS0FBSzs7Q0FFakMsR0FBRztFQUFDMUQ7RUFBUUU7RUFBUUU7RUFBUUU7RUFBTUU7RUFBS0U7RUFBUUU7Q0FBTyxDQUFDO0NBRXZEeEMsZ0JBQWdCO0VBQ2QsSUFBSXNCLE9BQU8sR0FBR3NELFNBQVM7O0NBRXpCLEdBQUcsQ0FBQ3RELElBQUksQ0FBQztDQUVULFNBQVNtRSxXQUFXQyxLQUFLO0VBQ3ZCLElBQUlwRCxXQUFXb0QsS0FBSztHQUNsQmpELFdBQVdELFlBQVksUUFBUSxTQUFTLEtBQUs7RUFDL0MsT0FBTztHQUNMRCxVQUFVbUQsR0FBRztHQUNiakQsV0FBVyxNQUFNO0VBQ25CO0NBQ0Y7Q0FFQSxlQUFla0QsV0FBV0MsS0FBSztFQUM3QjdDLGdCQUFnQixJQUFJO0VBQ3BCLElBQUk7R0FDRixNQUFNN0MsU0FBUzJGLGFBQWFELElBQUlFLElBQUlsRCxVQUFVO0dBQzlDNUIsTUFBTStFLFFBQVEsV0FBV0gsSUFBSUUsR0FBRSxVQUFXbEQsWUFBWTtHQUN0REQsYUFBYSxJQUFJO0dBQ2pCLE1BQU1pQyxTQUFTO0VBQ2pCLFNBQVNRLEdBQUc7R0FDVnBFLE1BQU1VLE1BQU0sMEJBQTBCMEQsRUFBRUMsU0FBUztFQUNuRCxVQUFVO0dBQ1J0QyxnQkFBZ0IsS0FBSztFQUN2QjtDQUNGO0NBRUEsZUFBZWlELGVBQWU7RUFDNUIsSUFBSSxDQUFDekMsY0FBYztFQUNuQkcsWUFBWSxJQUFJO0VBQ2hCLElBQUk7R0FDRixNQUFNeEQsU0FBUytGLFdBQVcxQyxhQUFhdUMsRUFBRTtHQUN6QzlFLE1BQU0rRSxRQUFRLFVBQVV4QyxhQUFhdUMsR0FBRSx1QkFBd0I7R0FDL0R0QyxnQkFBZ0IsSUFBSTs7R0FFcEIsSUFBSXRDLEtBQUtpRSxXQUFXLEtBQUs3RCxPQUFPLEdBQUc7SUFDakNDLFFBQVFELE9BQU8sQ0FBQztHQUNsQixPQUFPO0lBQ0wsTUFBTXNELFNBQVM7R0FDakI7RUFDRixTQUFTUSxHQUFHO0dBQ1ZwRSxNQUFNVSxNQUFNLDBCQUEwQjBELEVBQUVDLFNBQVM7RUFDbkQsVUFBVTtHQUNSM0IsWUFBWSxLQUFLO0VBQ25CO0NBQ0Y7Q0FFQSxNQUFNd0MsYUFBYUMsS0FBS0MsSUFBSSxHQUFHRCxLQUFLRSxLQUFLakYsUUFBUVIsU0FBUyxDQUFDO0NBQzNELE1BQU0wRixPQUFPbEYsVUFBVSxJQUFJLEtBQUtFLE9BQU8sS0FBS1YsWUFBWTtDQUN4RCxNQUFNMkYsS0FBS0osS0FBS0ssSUFBSWxGLE9BQU9WLFdBQVdRLEtBQUs7Q0FFM0MsT0FDRSx3QkFBQyxPQUFEO0VBRUUsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ2Isd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBbUIsd0JBQUMsS0FBRDtRQUFHLFdBQVU7UUFBZSxlQUFZO09BQU07Ozs7O01BQVM7Ozs7Z0JBQzFGLHdCQUFDLFNBQUQ7T0FDRSxNQUFLO09BQ0wsV0FBVTtPQUNWLGFBQVk7T0FDWixPQUFPUTtPQUNQLFdBQVd3RCxNQUFNdkQsVUFBVXVELEVBQUVxQixPQUFPakMsS0FBSztPQUN6QyxjQUFXO01BQXFCOzs7O2NBRS9COzs7Ozs7SUFDRjs7Ozs7SUFDTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLFVBQUQ7TUFBUSxXQUFVO01BQTZCLE9BQU8xQztNQUFRLFdBQVdzRCxNQUFNckQsVUFBVXFELEVBQUVxQixPQUFPakMsS0FBSztNQUFHLGNBQVc7Z0JBQXJILENBQ0Usd0JBQUMsVUFBRDtPQUFRLE9BQU07aUJBQU07TUFBb0I7Ozs7Z0JBQ3ZDN0QsZUFBZStGLEtBQUtDLE1BQU0sd0JBQUMsVUFBRDtPQUFnQixPQUFPQTtpQkFBSUE7TUFBVSxHQUF4QkE7Ozs7YUFBd0IsQ0FBQyxDQUMzRDs7Ozs7O0lBQ0w7Ozs7O0lBQ0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDYix3QkFBQyxVQUFEO01BQVEsV0FBVTtNQUE2QixPQUFPM0U7TUFBUSxXQUFXb0QsTUFBTW5ELFVBQVVtRCxFQUFFcUIsT0FBT2pDLEtBQUs7TUFBRyxjQUFXO2dCQUFySCxDQUNFLHdCQUFDLFVBQUQ7T0FBUSxPQUFNO2lCQUFNO01BQW1COzs7O2dCQUN0QzFELFNBQVM4RixTQUFTRixLQUFLRyxNQUFNLHdCQUFDLFVBQUQ7T0FBbUIsT0FBT0EsRUFBRWY7aUJBQUtlLEVBQUVDO01BQWEsR0FBbkNELEVBQUVmOzs7O2FBQWlDLENBQUMsQ0FDekU7Ozs7OztJQUNMOzs7OztJQUNMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ2Isd0JBQUMsVUFBRDtNQUFRLFdBQVU7TUFBNkIsT0FBTzVEO01BQU0sV0FBV2tELE1BQU1qRCxRQUFRaUQsRUFBRXFCLE9BQU9qQyxLQUFLO01BQUcsY0FBVztnQkFBakgsQ0FDRSx3QkFBQyxVQUFEO09BQVEsT0FBTTtpQkFBTTtNQUF3Qjs7OztnQkFDM0MxRCxTQUFTaUcsY0FBY0wsS0FBS00sTUFBTSx3QkFBQyxVQUFEO09BQW1CLE9BQU9BLEVBQUVsQjtpQkFBS2tCLEVBQUVGO01BQWEsR0FBbkNFLEVBQUVsQjs7OzthQUFpQyxDQUFDLENBQzlFOzs7Ozs7SUFDTDs7Ozs7SUFDTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLFVBQUQ7TUFBUSxXQUFVO01BQTZCLE9BQU8xRDtNQUFLLFdBQVdnRCxNQUFNL0MsT0FBTytDLEVBQUVxQixPQUFPakMsS0FBSztNQUFHLGNBQVc7Z0JBQS9HO09BQ0Usd0JBQUMsVUFBRDtRQUFRLE9BQU07a0JBQU07T0FBNEI7Ozs7O09BQ2hELHdCQUFDLFVBQUQ7UUFBUSxPQUFNO2tCQUFnQjtPQUFxQjs7Ozs7T0FDbkQsd0JBQUMsVUFBRDtRQUFRLE9BQU07a0JBQWtCO09BQXVCOzs7OztPQUN2RCx3QkFBQyxVQUFEO1FBQVEsT0FBTTtrQkFBaUI7T0FBc0I7Ozs7O01BQy9DOzs7Ozs7SUFDTDs7Ozs7SUFDTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsVUFBRDtPQUFRLE1BQUs7T0FBUyxXQUFXLFlBQVlsQyxXQUFXLDJCQUEyQixXQUFXO09BQU0sZUFBZW1ELFdBQVcsd0JBQXdCO09BQUcsT0FBTTtpQkFBL0osQ0FBb0wsU0FDNUtuRCxXQUFXLDJCQUE0QkUsWUFBWSxRQUFRLE1BQVcsTUFBWSxHQUNsRjs7Ozs7O01BQ1Isd0JBQUMsVUFBRDtPQUFRLE1BQUs7T0FBUyxXQUFXLFlBQVlGLFdBQVcsZ0JBQWdCLFdBQVc7T0FBTSxlQUFlbUQsV0FBVyxhQUFhO09BQUcsT0FBTTtpQkFBekksQ0FBK0osV0FDckpuRCxXQUFXLGdCQUFpQkUsWUFBWSxRQUFRLE1BQVcsTUFBWSxHQUN6RTs7Ozs7O01BQ1Isd0JBQUMsVUFBRDtPQUFRLE1BQUs7T0FBUyxXQUFXLFlBQVlGLFdBQVcsb0JBQW9CLFdBQVc7T0FBTSxlQUFlbUQsV0FBVyxpQkFBaUI7T0FBRyxPQUFNO2lCQUFqSixDQUEySyxTQUNuS25ELFdBQVcsb0JBQXFCRSxZQUFZLFFBQVEsTUFBVyxNQUFZLEdBQzNFOzs7Ozs7S0FDTDs7Ozs7O0lBQ0p2QixZQUNDLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ2Isd0JBQUMsVUFBRDtNQUFRLE1BQUs7TUFBUyxXQUFVO01BQXlCLGVBQWVrQyxhQUFhO09BQUVDLE1BQU07T0FBTUMsTUFBTTtPQUFVQyxNQUFNO01BQUssQ0FBQztnQkFBL0gsQ0FDRSx3QkFBQyxLQUFEO09BQUcsV0FBVTtPQUF5QixlQUFZO01BQU07Ozs7Z0JBQUEsWUFFbEQ7Ozs7OztJQUNMOzs7OztHQUVKOzs7Ozs7RUFFSjVCLFNBQVMsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUE4QyxXQUFRQSxLQUFXOzs7Ozs7RUFFM0Usd0JBQUMsT0FBRDtHQUFLLFdBQVU7R0FBd0IsZUFBWTthQUNoREYsVUFBVSxxQkFBcUIsV0FBVzhFLEtBQUksUUFBU0MsR0FBRSxNQUFPbkYsTUFBSztFQUNuRTs7Ozs7RUFFTCx3QkFBQyxPQUFEO0dBQUssV0FBVTtHQUFtQixPQUFPLEVBQUU2RixXQUFXLElBQUk7YUFDeEQsd0JBQUMsU0FBRDtJQUFPLFdBQVU7Y0FBakIsQ0FDRSx3QkFBQyxTQUFELFlBQ0Usd0JBQUMsTUFBRDtLQUNFLHdCQUFDLE1BQUQsWUFBSSxTQUFVOzs7OztLQUNkLHdCQUFDLE1BQUQsWUFBSSxVQUFXOzs7OztLQUNmLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUF5QjtLQUFlOzs7OztLQUN0RCx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBeUI7S0FBVTs7Ozs7S0FDakQsd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQVc7S0FBaUI7Ozs7O0tBQzFDLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFrQztLQUFVOzs7OztLQUMxRCx3QkFBQyxNQUFELFlBQUksU0FBVTs7Ozs7S0FDZCx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBeUI7S0FBYTs7Ozs7S0FDcEQsd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQXlCO0tBQVE7Ozs7O0tBQy9DLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO01BQWMsT0FBTyxFQUFFQyxPQUFPLElBQUk7Z0JBQUc7S0FBVzs7Ozs7SUFDNUQ7Ozs7YUFDQzs7OztjQUNQLHdCQUFDLFNBQUQsWUFDR2hHLEtBQUtpRSxXQUFXLEtBQUssQ0FBQzNELFVBQ3JCLHdCQUFDLE1BQUQsWUFDRSx3QkFBQyxNQUFEO0tBQUksU0FBUztLQUFJLFdBQVU7ZUFBd0M7SUFFL0Q7Ozs7YUFDRjs7OztlQUVKTixLQUFLd0YsS0FBS1MsTUFDUix3QkFBQyxNQUFEO0tBQ0Usd0JBQUMsTUFBRCxZQUFJLHdCQUFDLFVBQUQsWUFBU0EsRUFBRXJCLEdBQVc7Ozs7Y0FBSzs7Ozs7S0FDL0Isd0JBQUMsTUFBRCxhQUNFLHdCQUFDLE9BQUQsWUFBTXFCLEVBQUVDLFlBQWlCOzs7O2VBQ3pCLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUE4QkQsRUFBRUU7S0FBcUI7Ozs7YUFDbEU7Ozs7O0tBQ0osd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQTBCRixFQUFFRTtLQUFvQjs7Ozs7S0FDOUQsd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQTBCRixFQUFFRztLQUFlOzs7OztLQUN6RCx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBWW5ILFVBQVVnSCxFQUFFSSxzQkFBc0I7S0FBTTs7Ozs7S0FDbEUsd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQ1hKLEVBQUVLLGdCQUFnQixPQUFPTCxFQUFFSyxjQUFjLHdCQUFDLE1BQUQ7T0FBSSxPQUFPLEVBQUVDLE9BQU8sVUFBVTtpQkFBRztNQUFPOzs7OztLQUNoRjs7Ozs7S0FDSix3QkFBQyxNQUFELFlBQ0cvRSxjQUFjeUUsRUFBRXJCLEtBQ2Ysd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxVQUFEO1FBQ0UsV0FBVTtRQUNWLE9BQU8sRUFBRW9CLE9BQU8sSUFBSTtRQUNwQixPQUFPdEU7UUFDUCxXQUFXd0MsTUFBTXZDLGNBQWN1QyxFQUFFcUIsT0FBT2pDLEtBQUs7UUFDN0MsVUFBVTFCO2tCQUVUbkMsZUFBZStGLEtBQUtDLE1BQU0sd0JBQUMsVUFBRDtTQUFnQixPQUFPQTttQkFBSUE7UUFBVSxHQUF4QkE7Ozs7ZUFBd0IsQ0FBQztPQUMzRDs7Ozs7T0FDUix3QkFBQyxVQUFEO1FBQVEsTUFBSztRQUFTLFdBQVU7UUFBbUMsZUFBZWhCLFdBQVd3QixDQUFDO1FBQUcsVUFBVXJFO1FBQWMsT0FBTTtrQkFDN0gsd0JBQUMsS0FBRDtTQUFHLFdBQVU7U0FBYyxlQUFZO1FBQU07Ozs7O09BQ3ZDOzs7OztPQUNSLHdCQUFDLFVBQUQ7UUFBUSxNQUFLO1FBQVMsV0FBVTtRQUFxQyxlQUFlSCxhQUFhLElBQUk7UUFBRyxVQUFVRztRQUFjLE9BQU07a0JBQ3BJLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO1NBQVUsZUFBWTtRQUFNOzs7OztPQUNuQzs7Ozs7TUFDTDs7Ozs7Z0JBRUwsd0JBQUMsUUFBRDtNQUNFLFdBQVcsV0FBVzFDLFlBQVkrRyxFQUFFTyxpQkFBaUI7TUFDckQsT0FBTyxFQUFFQyxRQUFRMUcsV0FBVyxZQUFZLFVBQVU7TUFDbEQsZUFBZTtPQUNiLElBQUksQ0FBQ0EsVUFBVTtPQUNmMEIsYUFBYXdFLEVBQUVyQixFQUFFO09BQ2pCakQsY0FBY3NFLEVBQUVPLGlCQUFpQjtNQUNuQztNQUNBLE9BQU96RyxXQUFXLDJCQUEyQjtnQkFFNUNrRyxFQUFFTztLQUNDOzs7O2NBRU47Ozs7O0tBQ0osd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQ1osd0JBQUMsUUFBRDtPQUFNLFdBQVcsV0FBV3JILGVBQWU4RyxFQUFFbkQsY0FBYztpQkFBTW1ELEVBQUVuRDtNQUFxQjs7Ozs7S0FDdEY7Ozs7O0tBQ0osd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQTBCbUQsRUFBRVM7S0FBb0I7Ozs7O0tBQzlELHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUNaLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO09BQXlCLE1BQUs7T0FBUSxjQUFZLGVBQWVULEVBQUVyQjtpQkFBbEYsQ0FDRSx3QkFBQyxVQUFEO1FBQVEsTUFBSztRQUFTLFdBQVU7UUFBNEIsZUFBZTdDLFlBQVlrRSxDQUFDO1FBQUcsT0FBTTtrQkFDL0Ysd0JBQUMsS0FBRDtTQUFHLFdBQVU7U0FBWSxlQUFZO1FBQU07Ozs7O09BQ3JDOzs7O2lCQUNQbEcsWUFDQyxnREFDRSx3QkFBQyxVQUFEO1FBQVEsTUFBSztRQUFTLFdBQVU7UUFBMEIsZUFBZWtDLGFBQWE7U0FBRUMsTUFBTTtTQUFNQyxNQUFNO1NBQVFDLE1BQU02RDtRQUFFLENBQUM7UUFBRyxPQUFNO2tCQUNsSSx3QkFBQyxLQUFEO1NBQUcsV0FBVTtTQUFlLGVBQVk7UUFBTTs7Ozs7T0FDeEM7Ozs7aUJBQ1Isd0JBQUMsVUFBRDtRQUFRLE1BQUs7UUFBUyxXQUFVO1FBQXlCLGVBQWUzRCxnQkFBZ0IyRCxDQUFDO1FBQUcsT0FBTTtrQkFDaEcsd0JBQUMsS0FBRDtTQUFHLFdBQVU7U0FBYyxlQUFZO1FBQU07Ozs7O09BQ3ZDOzs7O2VBQ1Y7Ozs7ZUFFQzs7Ozs7O0tBQ0g7Ozs7O0lBQ0YsS0FuRUtBLEVBQUVyQjs7OztXQW1FUCxDQUNMLEVBRUU7Ozs7WUFDRjs7Ozs7O0VBQ0o7Ozs7O0VBR0wsd0JBQUMsT0FBRDtHQUFLLGNBQVc7R0FBMEIsV0FBVTthQUNsRCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsUUFBRDtLQUFNLFdBQVU7ZUFBaEI7TUFBa0M7TUFDMUJ4RTtNQUFLO01BQUs0RTtLQUNaOzs7OztjQUNOLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQWQ7TUFDRSx3QkFBQyxNQUFEO09BQUksV0FBVyxhQUFhNUUsUUFBUSxJQUFJLGFBQWE7aUJBQ25ELHdCQUFDLFVBQUQ7UUFBUSxXQUFVO1FBQVksZUFBZUMsU0FBU3NHLE1BQU0xQixLQUFLQyxJQUFJLEdBQUd5QixJQUFJLENBQUMsQ0FBQztRQUFHLFVBQVV2RyxRQUFRO1FBQUcsY0FBVztrQkFDL0csd0JBQUMsS0FBRDtTQUFHLFdBQVU7U0FBcUIsZUFBWTtRQUFNOzs7OztPQUM5Qzs7Ozs7TUFDTjs7Ozs7TUFDSHdHLE1BQU14QixLQUFLLEVBQUVuQixRQUFRZSxXQUFXLElBQUk2QixHQUFHZixNQUFNQSxJQUFJLENBQUMsQ0FBQyxDQUNqRGdCLFFBQVFILE1BQU1BLE1BQU0sS0FBS0EsTUFBTTNCLGNBQWNDLEtBQUs4QixJQUFJSixJQUFJdkcsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUNyRW9GLEtBQUttQixHQUFHSyxLQUFLQyxRQUNaLHdCQUFDLE1BQU0sVUFBUCxhQUNHRCxNQUFNLEtBQUtDLElBQUlELE1BQU0sT0FBT0wsSUFBSSxLQUMvQix3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBcUIsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQVk7T0FBTzs7Ozs7TUFBSzs7OztnQkFFN0Usd0JBQUMsTUFBRDtPQUFJLFdBQVcsYUFBYUEsTUFBTXZHLE9BQU8sV0FBVztpQkFDbEQsd0JBQUMsVUFBRDtRQUFRLFdBQVU7UUFBWSxlQUFlQyxRQUFRc0csQ0FBQztRQUFHLGdCQUFjQSxNQUFNdkcsT0FBTyxTQUFTbUQ7a0JBQzFGb0Q7T0FDSzs7Ozs7TUFDTjs7OztjQUNVLEtBVEtBOzs7O2FBU0wsQ0FDakI7TUFDSCx3QkFBQyxNQUFEO09BQUksV0FBVyxhQUFhdkcsUUFBUTRFLGFBQWEsYUFBYTtpQkFDNUQsd0JBQUMsVUFBRDtRQUFRLFdBQVU7UUFBWSxlQUFlM0UsU0FBUzZHLE9BQU9qQyxLQUFLSyxJQUFJTixZQUFZa0MsS0FBSyxDQUFDLENBQUM7UUFBRyxVQUFVOUcsUUFBUTRFO1FBQVksY0FBVztrQkFDbkksd0JBQUMsS0FBRDtTQUFHLFdBQVU7U0FBc0IsZUFBWTtRQUFNOzs7OztPQUMvQzs7Ozs7TUFDTjs7Ozs7S0FDRjs7Ozs7WUFDRDs7Ozs7O0VBQ0Y7Ozs7O0VBR0wsd0JBQUMsZUFBRDtHQUNFLE1BQU1tQyxRQUFRckYsUUFBUTtHQUN0QixNQUFNQTtHQUNOLGVBQWVDLFlBQVksSUFBSTtHQUMvQixjQUFjO0lBQ1osTUFBTUssT0FBT047SUFDYkMsWUFBWSxJQUFJO0lBQ2hCRSxhQUFhO0tBQUVDLE1BQU07S0FBTUMsTUFBTTtLQUFRQztJQUFLLENBQUM7R0FDakQ7R0FDVXJDO0VBQVM7Ozs7O0VBR3JCLHdCQUFDLGVBQUQ7R0FDRSxNQUFNaUMsVUFBVUU7R0FDaEIsTUFBTUYsVUFBVUc7R0FDaEIsTUFBTUgsVUFBVUk7R0FDUHhDO0dBQ1QsZUFBZXFDLGFBQWE7SUFBRUMsTUFBTTtJQUFPQyxNQUFNO0lBQVVDLE1BQU07R0FBSyxDQUFDO0dBQ3ZFLFNBQVMsWUFBWTtJQUNuQkgsYUFBYTtLQUFFQyxNQUFNO0tBQU9DLE1BQU07S0FBVUMsTUFBTTtJQUFLLENBQUM7SUFDeEQsTUFBTXNCLFNBQVM7R0FDakI7RUFBRTs7Ozs7RUFHSix3QkFBQyxjQUFEO0dBQ0UsTUFBTXlELFFBQVE5RSxZQUFZO0dBQzFCLE9BQU07R0FDTixTQUNFQSxlQUNJLDJEQUEyREEsYUFBYXVDLEdBQUUsSUFBS3ZDLGFBQWE2RCxZQUFXLDZCQUN2RztHQUVOLGNBQWE7R0FDYixTQUFTM0Q7R0FDVCxXQUFXdUM7R0FDWCxnQkFBZ0J4QyxnQkFBZ0IsSUFBSTtFQUFFOzs7OztDQUVyQzs7Ozs7QUFFVDtBQUFDekMsR0FuWHVCRixtQkFBaUI7Q0FBQSxRQUN6Qk4sVUFDT0QsT0FBTztBQUFBO0FBQUEsS0FGTk87QUFBaUIsSUFBQXlIO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJpdGVtc0FwaSIsImZvcm1hdElOUiIsInN0YXR1c0NsYXNzIiwiYXR0ZW50aW9uQ2xhc3MiLCJ1c2VBdXRoIiwidXNlVG9hc3QiLCJDb25maXJtTW9kYWwiLCJJdGVtRm9ybU1vZGFsIiwiSXRlbVZpZXdNb2RhbCIsIlNUQVRVU19PUFRJT05TIiwiUEFHRV9TSVpFIiwiQXBwbGljYXRpb25zVGFibGUiLCJmaWx0ZXJzIiwiX3MiLCJ0b2FzdCIsImNhbldyaXRlIiwiYXBwcyIsInNldEFwcHMiLCJ0b3RhbCIsInNldFRvdGFsIiwicGFnZSIsInNldFBhZ2UiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsImVycm9yIiwic2V0RXJyb3IiLCJzZWFyY2giLCJzZXRTZWFyY2giLCJzdGF0dXMiLCJzZXRTdGF0dXMiLCJjb3Vyc2UiLCJzZXRDb3Vyc2UiLCJpbnN0Iiwic2V0SW5zdCIsImF0dCIsInNldEF0dCIsInNvcnRCeSIsInNldFNvcnRCeSIsInNvcnREaXIiLCJzZXRTb3J0RGlyIiwiZWRpdGluZ0lkIiwic2V0RWRpdGluZ0lkIiwiZWRpdFN0YXR1cyIsInNldEVkaXRTdGF0dXMiLCJzdGF0dXNTYXZpbmciLCJzZXRTdGF0dXNTYXZpbmciLCJ2aWV3SXRlbSIsInNldFZpZXdJdGVtIiwiZm9ybU1vZGFsIiwic2V0Rm9ybU1vZGFsIiwic2hvdyIsIm1vZGUiLCJpdGVtIiwiZGVsZXRlVGFyZ2V0Iiwic2V0RGVsZXRlVGFyZ2V0IiwiZGVsZXRpbmciLCJzZXREZWxldGluZyIsImJ1aWxkUXVlcnkiLCJleHRyYSIsInBhcmFtcyIsImNvdXJzZUlkIiwiaW5zdGl0dXRpb25JZCIsImF0dGVudGlvbkxldmVsIiwicGFnZVNpemUiLCJzZWFyY2hfIiwiVVJMU2VhcmNoUGFyYW1zIiwiT2JqZWN0IiwiZW50cmllcyIsImZvckVhY2giLCJrZXkiLCJ2YWx1ZSIsInVuZGVmaW5lZCIsInNldCIsInRvU3RyaW5nIiwibG9hZFJvd3MiLCJxdWVyeVN0cmluZyIsInJlcyIsImdldEl0ZW1zIiwiZnJvbUVudHJpZXMiLCJkYXRhIiwiY291bnQiLCJsZW5ndGgiLCJlIiwibWVzc2FnZSIsInRpbWVyIiwic2V0VGltZW91dCIsImNsZWFyVGltZW91dCIsInRvZ2dsZVNvcnQiLCJjb2wiLCJzYXZlU3RhdHVzIiwiYXBwIiwidXBkYXRlU3RhdHVzIiwiaWQiLCJzdWNjZXNzIiwiaGFuZGxlRGVsZXRlIiwiZGVsZXRlSXRlbSIsInRvdGFsUGFnZXMiLCJNYXRoIiwibWF4IiwiY2VpbCIsImZyb20iLCJ0byIsIm1pbiIsInRhcmdldCIsIm1hcCIsInMiLCJjb3Vyc2VzIiwiYyIsIm5hbWUiLCJpbnN0aXR1dGlvbnMiLCJpIiwibWF4SGVpZ2h0Iiwid2lkdGgiLCJhIiwic3R1ZGVudE5hbWUiLCJpbnN0aXR1dGlvbk5hbWUiLCJjb3Vyc2VOYW1lIiwibG9hbkFtb3VudFJlcXVlc3RlZEluciIsImNyZWRpdFNjb3JlIiwiY29sb3IiLCJhcHBsaWNhdGlvblN0YXR1cyIsImN1cnNvciIsImFwcGxpY2F0aW9uRGF0ZSIsInAiLCJBcnJheSIsIl8iLCJmaWx0ZXIiLCJhYnMiLCJpZHgiLCJhcnIiLCJwMiIsIkJvb2xlYW4iLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBcHBsaWNhdGlvbnNUYWJsZS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGl0ZW1zQXBpLCBmb3JtYXRJTlIsIHN0YXR1c0NsYXNzLCBhdHRlbnRpb25DbGFzcyB9IGZyb20gXCIuLi9hcGkvaXRlbXMuanNcIjtcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tIFwiLi4vY29udGV4dC9BdXRoQ29udGV4dC5qc3hcIjtcbmltcG9ydCB7IHVzZVRvYXN0IH0gZnJvbSBcIi4uL2NvbnRleHQvVG9hc3RDb250ZXh0LmpzeFwiO1xuaW1wb3J0IENvbmZpcm1Nb2RhbCBmcm9tIFwiLi9Db25maXJtTW9kYWwuanN4XCI7XG5pbXBvcnQgSXRlbUZvcm1Nb2RhbCBmcm9tIFwiLi9JdGVtRm9ybU1vZGFsLmpzeFwiO1xuaW1wb3J0IEl0ZW1WaWV3TW9kYWwgZnJvbSBcIi4vSXRlbVZpZXdNb2RhbC5qc3hcIjtcblxuY29uc3QgU1RBVFVTX09QVElPTlMgPSBbXCJTdWJtaXR0ZWRcIiwgXCJVbmRlciBSZXZpZXdcIiwgXCJBcHByb3ZlZFwiLCBcIlJlamVjdGVkXCJdO1xuY29uc3QgUEFHRV9TSVpFID0gMTA7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFwcGxpY2F0aW9uc1RhYmxlKHsgZmlsdGVycyB9KSB7XG4gIGNvbnN0IHRvYXN0ID0gdXNlVG9hc3QoKTtcbiAgY29uc3QgeyBjYW5Xcml0ZSB9ID0gdXNlQXV0aCgpO1xuXG4gIGNvbnN0IFthcHBzLCBzZXRBcHBzXSA9IHVzZVN0YXRlKFtdKTtcbiAgY29uc3QgW3RvdGFsLCBzZXRUb3RhbF0gPSB1c2VTdGF0ZSgwKTtcbiAgY29uc3QgW3BhZ2UsIHNldFBhZ2VdID0gdXNlU3RhdGUoMSk7XG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpO1xuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKFwiXCIpO1xuXG4gIGNvbnN0IFtzZWFyY2gsIHNldFNlYXJjaF0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW3N0YXR1cywgc2V0U3RhdHVzXSA9IHVzZVN0YXRlKFwiYWxsXCIpO1xuICBjb25zdCBbY291cnNlLCBzZXRDb3Vyc2VdID0gdXNlU3RhdGUoXCJhbGxcIik7XG4gIGNvbnN0IFtpbnN0LCBzZXRJbnN0XSA9IHVzZVN0YXRlKFwiYWxsXCIpO1xuICBjb25zdCBbYXR0LCBzZXRBdHRdID0gdXNlU3RhdGUoXCJhbGxcIik7XG4gIGNvbnN0IFtzb3J0QnksIHNldFNvcnRCeV0gPSB1c2VTdGF0ZShcImFwcGxpY2F0aW9uRGF0ZVwiKTtcbiAgY29uc3QgW3NvcnREaXIsIHNldFNvcnREaXJdID0gdXNlU3RhdGUoXCJkZXNjXCIpO1xuXG4gIGNvbnN0IFtlZGl0aW5nSWQsIHNldEVkaXRpbmdJZF0gPSB1c2VTdGF0ZShudWxsKTtcbiAgY29uc3QgW2VkaXRTdGF0dXMsIHNldEVkaXRTdGF0dXNdID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFtzdGF0dXNTYXZpbmcsIHNldFN0YXR1c1NhdmluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgLy8gTW9kYWxzXG4gIGNvbnN0IFt2aWV3SXRlbSwgc2V0Vmlld0l0ZW1dID0gdXNlU3RhdGUobnVsbCk7XG4gIGNvbnN0IFtmb3JtTW9kYWwsIHNldEZvcm1Nb2RhbF0gPSB1c2VTdGF0ZSh7IHNob3c6IGZhbHNlLCBtb2RlOiBcImNyZWF0ZVwiLCBpdGVtOiBudWxsIH0pO1xuICBjb25zdCBbZGVsZXRlVGFyZ2V0LCBzZXREZWxldGVUYXJnZXRdID0gdXNlU3RhdGUobnVsbCk7XG4gIGNvbnN0IFtkZWxldGluZywgc2V0RGVsZXRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIGZ1bmN0aW9uIGJ1aWxkUXVlcnkoZXh0cmEgPSB7fSkge1xuICAgIGNvbnN0IHBhcmFtcyA9IHtcbiAgICAgIHNlYXJjaCxcbiAgICAgIHN0YXR1cyxcbiAgICAgIGNvdXJzZUlkOiBjb3Vyc2UsXG4gICAgICBpbnN0aXR1dGlvbklkOiBpbnN0LFxuICAgICAgYXR0ZW50aW9uTGV2ZWw6IGF0dCxcbiAgICAgIHNvcnRCeSxcbiAgICAgIHNvcnREaXIsXG4gICAgICBwYWdlOiBleHRyYS5wYWdlID8/IHBhZ2UsXG4gICAgICBwYWdlU2l6ZTogUEFHRV9TSVpFLFxuICAgICAgLi4uZXh0cmEsXG4gICAgfTtcbiAgICBjb25zdCBzZWFyY2hfID0gbmV3IFVSTFNlYXJjaFBhcmFtcygpO1xuICAgIE9iamVjdC5lbnRyaWVzKHBhcmFtcykuZm9yRWFjaCgoW2tleSwgdmFsdWVdKSA9PiB7XG4gICAgICBpZiAodmFsdWUgIT09IHVuZGVmaW5lZCAmJiB2YWx1ZSAhPT0gbnVsbCAmJiB2YWx1ZSAhPT0gXCJcIiAmJiB2YWx1ZSAhPT0gXCJhbGxcIikge1xuICAgICAgICBzZWFyY2hfLnNldChrZXksIHZhbHVlKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgICByZXR1cm4gc2VhcmNoXy50b1N0cmluZygpO1xuICB9XG5cbiAgYXN5bmMgZnVuY3Rpb24gbG9hZFJvd3MocXVlcnlTdHJpbmcgPSBidWlsZFF1ZXJ5KCkpIHtcbiAgICBzZXRMb2FkaW5nKHRydWUpO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBpdGVtc0FwaS5nZXRJdGVtcyhcbiAgICAgICAgT2JqZWN0LmZyb21FbnRyaWVzKG5ldyBVUkxTZWFyY2hQYXJhbXMocXVlcnlTdHJpbmcpKVxuICAgICAgKTtcbiAgICAgIHNldEFwcHMocmVzLmRhdGEgfHwgW10pO1xuICAgICAgc2V0VG90YWwocmVzLmNvdW50ID8/IChyZXMuZGF0YSB8fCBbXSkubGVuZ3RoKTtcbiAgICAgIHNldEVycm9yKFwiXCIpO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIHNldEVycm9yKGUubWVzc2FnZSk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgIH1cbiAgfVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgdGltZXIgPSBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIHNldFBhZ2UoMSk7XG4gICAgICBsb2FkUm93cyhidWlsZFF1ZXJ5KHsgcGFnZTogMSB9KSk7XG4gICAgfSwgMjUwKTsgLy8gZGVib3VuY2Ugc2VhcmNoIHR5cGluZ1xuICAgIHJldHVybiAoKSA9PiBjbGVhclRpbWVvdXQodGltZXIpO1xuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9leGhhdXN0aXZlLWRlcHNcbiAgfSwgW3NlYXJjaCwgc3RhdHVzLCBjb3Vyc2UsIGluc3QsIGF0dCwgc29ydEJ5LCBzb3J0RGlyXSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAocGFnZSA+IDEpIGxvYWRSb3dzKCk7XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LWhvb2tzL2V4aGF1c3RpdmUtZGVwc1xuICB9LCBbcGFnZV0pO1xuXG4gIGZ1bmN0aW9uIHRvZ2dsZVNvcnQoY29sKSB7XG4gICAgaWYgKHNvcnRCeSA9PT0gY29sKSB7XG4gICAgICBzZXRTb3J0RGlyKHNvcnREaXIgPT09IFwiYXNjXCIgPyBcImRlc2NcIiA6IFwiYXNjXCIpO1xuICAgIH0gZWxzZSB7XG4gICAgICBzZXRTb3J0QnkoY29sKTtcbiAgICAgIHNldFNvcnREaXIoXCJkZXNjXCIpO1xuICAgIH1cbiAgfVxuXG4gIGFzeW5jIGZ1bmN0aW9uIHNhdmVTdGF0dXMoYXBwKSB7XG4gICAgc2V0U3RhdHVzU2F2aW5nKHRydWUpO1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBpdGVtc0FwaS51cGRhdGVTdGF0dXMoYXBwLmlkLCBlZGl0U3RhdHVzKTtcbiAgICAgIHRvYXN0LnN1Y2Nlc3MoYFVwZGF0ZWQgJHthcHAuaWR9IFxcdTIxOTIgJHtlZGl0U3RhdHVzfWApO1xuICAgICAgc2V0RWRpdGluZ0lkKG51bGwpO1xuICAgICAgYXdhaXQgbG9hZFJvd3MoKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICB0b2FzdC5lcnJvcihgRXJyb3IgdXBkYXRpbmcgc3RhdHVzOiAke2UubWVzc2FnZX1gKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0U3RhdHVzU2F2aW5nKGZhbHNlKTtcbiAgICB9XG4gIH1cblxuICBhc3luYyBmdW5jdGlvbiBoYW5kbGVEZWxldGUoKSB7XG4gICAgaWYgKCFkZWxldGVUYXJnZXQpIHJldHVybjtcbiAgICBzZXREZWxldGluZyh0cnVlKTtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgaXRlbXNBcGkuZGVsZXRlSXRlbShkZWxldGVUYXJnZXQuaWQpO1xuICAgICAgdG9hc3Quc3VjY2VzcyhgUmVjb3JkICR7ZGVsZXRlVGFyZ2V0LmlkfSBkZWxldGVkIHN1Y2Nlc3NmdWxseS5gKTtcbiAgICAgIHNldERlbGV0ZVRhcmdldChudWxsKTtcbiAgICAgIC8vIElmIHdlIGRlbGV0ZWQgdGhlIGxhc3Qgcm93IG9uIHRoZSBsYXN0IHBhZ2UsIHN0ZXAgYmFjayBvbmUgcGFnZS5cbiAgICAgIGlmIChhcHBzLmxlbmd0aCA9PT0gMSAmJiBwYWdlID4gMSkge1xuICAgICAgICBzZXRQYWdlKHBhZ2UgLSAxKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGF3YWl0IGxvYWRSb3dzKCk7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgdG9hc3QuZXJyb3IoYEVycm9yIGRlbGV0aW5nIHJlY29yZDogJHtlLm1lc3NhZ2V9YCk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldERlbGV0aW5nKGZhbHNlKTtcbiAgICB9XG4gIH1cblxuICBjb25zdCB0b3RhbFBhZ2VzID0gTWF0aC5tYXgoMSwgTWF0aC5jZWlsKHRvdGFsIC8gUEFHRV9TSVpFKSk7XG4gIGNvbnN0IGZyb20gPSB0b3RhbCA9PT0gMCA/IDAgOiAocGFnZSAtIDEpICogUEFHRV9TSVpFICsgMTtcbiAgY29uc3QgdG8gPSBNYXRoLm1pbihwYWdlICogUEFHRV9TSVpFLCB0b3RhbCk7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAgey8qIFRvb2xiYXIgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdyBnLTIgbWItMyBhbGlnbi1pdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtMTIgY29sLW1kLTNcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImlucHV0LWdyb3VwIGlucHV0LWdyb3VwLXNtXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbnB1dC1ncm91cC10ZXh0XCI+PGkgY2xhc3NOYW1lPVwiYmkgYmktc2VhcmNoXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz48L3NwYW4+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgdHlwZT1cInNlYXJjaFwiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvcm0tY29udHJvbFwiXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIGJ5IEFwcCBJRCBvciBzdHVkZW50IG5hbWXigKZcIlxuICAgICAgICAgICAgICB2YWx1ZT17c2VhcmNofVxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlYXJjaChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJTZWFyY2ggYXBwbGljYXRpb25zXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC02IGNvbC1tZC0yXCI+XG4gICAgICAgICAgPHNlbGVjdCBjbGFzc05hbWU9XCJmb3JtLXNlbGVjdCBmb3JtLXNlbGVjdC1zbVwiIHZhbHVlPXtzdGF0dXN9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0U3RhdHVzKGUudGFyZ2V0LnZhbHVlKX0gYXJpYS1sYWJlbD1cIkZpbHRlciBieSBzdGF0dXNcIj5cbiAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJhbGxcIj5BbGwgc3RhdHVzZXM8L29wdGlvbj5cbiAgICAgICAgICAgIHtTVEFUVVNfT1BUSU9OUy5tYXAoKHMpID0+IDxvcHRpb24ga2V5PXtzfSB2YWx1ZT17c30+e3N9PC9vcHRpb24+KX1cbiAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLTYgY29sLW1kLTJcIj5cbiAgICAgICAgICA8c2VsZWN0IGNsYXNzTmFtZT1cImZvcm0tc2VsZWN0IGZvcm0tc2VsZWN0LXNtXCIgdmFsdWU9e2NvdXJzZX0gb25DaGFuZ2U9eyhlKSA9PiBzZXRDb3Vyc2UoZS50YXJnZXQudmFsdWUpfSBhcmlhLWxhYmVsPVwiRmlsdGVyIGJ5IGNvdXJzZVwiPlxuICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImFsbFwiPkFsbCBjb3Vyc2VzPC9vcHRpb24+XG4gICAgICAgICAgICB7ZmlsdGVycz8uY291cnNlcz8ubWFwKChjKSA9PiA8b3B0aW9uIGtleT17Yy5pZH0gdmFsdWU9e2MuaWR9PntjLm5hbWV9PC9vcHRpb24+KX1cbiAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLTYgY29sLW1kLTJcIj5cbiAgICAgICAgICA8c2VsZWN0IGNsYXNzTmFtZT1cImZvcm0tc2VsZWN0IGZvcm0tc2VsZWN0LXNtXCIgdmFsdWU9e2luc3R9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0SW5zdChlLnRhcmdldC52YWx1ZSl9IGFyaWEtbGFiZWw9XCJGaWx0ZXIgYnkgaW5zdGl0dXRpb25cIj5cbiAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJhbGxcIj5BbGwgaW5zdGl0dXRpb25zPC9vcHRpb24+XG4gICAgICAgICAgICB7ZmlsdGVycz8uaW5zdGl0dXRpb25zPy5tYXAoKGkpID0+IDxvcHRpb24ga2V5PXtpLmlkfSB2YWx1ZT17aS5pZH0+e2kubmFtZX08L29wdGlvbj4pfVxuICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtNiBjb2wtbWQtMlwiPlxuICAgICAgICAgIDxzZWxlY3QgY2xhc3NOYW1lPVwiZm9ybS1zZWxlY3QgZm9ybS1zZWxlY3Qtc21cIiB2YWx1ZT17YXR0fSBvbkNoYW5nZT17KGUpID0+IHNldEF0dChlLnRhcmdldC52YWx1ZSl9IGFyaWEtbGFiZWw9XCJGaWx0ZXIgYnkgYXR0ZW50aW9uIGxldmVsXCI+XG4gICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiYWxsXCI+QWxsIGF0dGVudGlvbiBsZXZlbHM8L29wdGlvbj5cbiAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJMb3cgQXR0ZW50aW9uXCI+TG93IEF0dGVudGlvbjwvb3B0aW9uPlxuICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlJldmlldyBSZXF1aXJlZFwiPlJldmlldyBSZXF1aXJlZDwvb3B0aW9uPlxuICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkhpZ2ggQXR0ZW50aW9uXCI+SGlnaCBBdHRlbnRpb248L29wdGlvbj5cbiAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLTEyIGNvbC1tZC0xIGQtZmxleCBnYXAtMVwiPlxuICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT17YHNvcnQtYnRuICR7c29ydEJ5ID09PSBcImxvYW5BbW91bnRSZXF1ZXN0ZWRJbnJcIiA/IFwiYWN0aXZlXCIgOiBcIlwifWB9IG9uQ2xpY2s9eygpID0+IHRvZ2dsZVNvcnQoXCJsb2FuQW1vdW50UmVxdWVzdGVkSW5yXCIpfSB0aXRsZT1cIlNvcnQgYnkgbG9hbiBhbW91bnRcIj5cbiAgICAgICAgICAgIExvYW4ge3NvcnRCeSA9PT0gXCJsb2FuQW1vdW50UmVxdWVzdGVkSW5yXCIgPyAoc29ydERpciA9PT0gXCJhc2NcIiA/IFwiXFx1MjE5MVwiIDogXCJcXHUyMTkzXCIpIDogXCJcXHUyMTk1XCJ9XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPXtgc29ydC1idG4gJHtzb3J0QnkgPT09IFwiY3JlZGl0U2NvcmVcIiA/IFwiYWN0aXZlXCIgOiBcIlwifWB9IG9uQ2xpY2s9eygpID0+IHRvZ2dsZVNvcnQoXCJjcmVkaXRTY29yZVwiKX0gdGl0bGU9XCJTb3J0IGJ5IGNyZWRpdCBzY29yZVwiPlxuICAgICAgICAgICAgQ3JlZGl0IHtzb3J0QnkgPT09IFwiY3JlZGl0U2NvcmVcIiA/IChzb3J0RGlyID09PSBcImFzY1wiID8gXCJcXHUyMTkxXCIgOiBcIlxcdTIxOTNcIikgOiBcIlxcdTIxOTVcIn1cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9e2Bzb3J0LWJ0biAke3NvcnRCeSA9PT0gXCJhcHBsaWNhdGlvbkRhdGVcIiA/IFwiYWN0aXZlXCIgOiBcIlwifWB9IG9uQ2xpY2s9eygpID0+IHRvZ2dsZVNvcnQoXCJhcHBsaWNhdGlvbkRhdGVcIil9IHRpdGxlPVwiU29ydCBieSBhcHBsaWNhdGlvbiBkYXRlXCI+XG4gICAgICAgICAgICBEYXRlIHtzb3J0QnkgPT09IFwiYXBwbGljYXRpb25EYXRlXCIgPyAoc29ydERpciA9PT0gXCJhc2NcIiA/IFwiXFx1MjE5MVwiIDogXCJcXHUyMTkzXCIpIDogXCJcXHUyMTk1XCJ9XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICB7Y2FuV3JpdGUgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLTEyIGNvbC1tZC0xMiB0ZXh0LW1kLWVuZFwiPlxuICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwiYnRuIGJ0bi1zbSBidG4tZGhhbml0aVwiIG9uQ2xpY2s9eygpID0+IHNldEZvcm1Nb2RhbCh7IHNob3c6IHRydWUsIG1vZGU6IFwiY3JlYXRlXCIsIGl0ZW06IG51bGwgfSl9PlxuICAgICAgICAgICAgICA8aSBjbGFzc05hbWU9XCJiaSBiaS1wbHVzLWNpcmNsZSBtZS0xXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICAgICAgQWRkIFJlY29yZFxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG4gICAgICA8L2Rpdj5cblxuICAgICAge2Vycm9yICYmIDxkaXYgY2xhc3NOYW1lPVwiYWxlcnQgYWxlcnQtZGFuZ2VyIHB5LTIgbWItM1wiPkVycm9yOiB7ZXJyb3J9PC9kaXY+fVxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtbXV0ZWQgc21hbGwgbWItMlwiIGRhdGEtdGVzdGlkPVwicm93cy1zdW1tYXJ5XCI+XG4gICAgICAgIHtsb2FkaW5nID8gXCJMb2FkaW5nIHJlY29yZHPigKZcIiA6IGBTaG93aW5nICR7ZnJvbX1cXHUyMDEzJHt0b30gb2YgJHt0b3RhbH0gYXBwbGljYXRpb25zYH1cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInRhYmxlLXJlc3BvbnNpdmVcIiBzdHlsZT17eyBtYXhIZWlnaHQ6IDU2MCB9fT5cbiAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInRhYmxlIHRhYmxlLXNtIHRhYmxlLWhvdmVyIHRhYmxlLWFwcHMgYWxpZ24tbWlkZGxlXCI+XG4gICAgICAgICAgPHRoZWFkPlxuICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICA8dGg+QXBwIElEPC90aD5cbiAgICAgICAgICAgICAgPHRoPlN0dWRlbnQ8L3RoPlxuICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwiZC1ub25lIGQtbWQtdGFibGUtY2VsbFwiPkluc3RpdHV0aW9uPC90aD5cbiAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cImQtbm9uZSBkLWxnLXRhYmxlLWNlbGxcIj5Db3Vyc2U8L3RoPlxuICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwidGV4dC1udW1cIj5Mb2FuIChcXHUyMGI5KTwvdGg+XG4gICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJ0ZXh0LW51bSBkLW5vbmUgZC1tZC10YWJsZS1jZWxsXCI+Q3JlZGl0PC90aD5cbiAgICAgICAgICAgICAgPHRoPlN0YXR1czwvdGg+XG4gICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJkLW5vbmUgZC1sZy10YWJsZS1jZWxsXCI+QXR0ZW50aW9uPC90aD5cbiAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cImQtbm9uZSBkLWxnLXRhYmxlLWNlbGxcIj5EYXRlPC90aD5cbiAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInRleHQtY2VudGVyXCIgc3R5bGU9e3sgd2lkdGg6IDEzMCB9fT5BY3Rpb25zPC90aD5cbiAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICA8dGJvZHk+XG4gICAgICAgICAgICB7YXBwcy5sZW5ndGggPT09IDAgJiYgIWxvYWRpbmcgPyAoXG4gICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICA8dGQgY29sU3Bhbj17MTB9IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHRleHQtbXV0ZWQgZnN0LWl0YWxpYyBweS00XCI+XG4gICAgICAgICAgICAgICAgICBObyBhcHBsaWNhdGlvbnMgbWF0Y2ggdGhlIGN1cnJlbnQgZmlsdGVycy5cbiAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgYXBwcy5tYXAoKGEpID0+IChcbiAgICAgICAgICAgICAgICA8dHIga2V5PXthLmlkfT5cbiAgICAgICAgICAgICAgICAgIDx0ZD48c3Ryb25nPnthLmlkfTwvc3Ryb25nPjwvdGQ+XG4gICAgICAgICAgICAgICAgICA8dGQ+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+e2Euc3R1ZGVudE5hbWV9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic21hbGwgdGV4dC1tdXRlZCBkLW1kLW5vbmVcIj57YS5pbnN0aXR1dGlvbk5hbWV9PC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cImQtbm9uZSBkLW1kLXRhYmxlLWNlbGxcIj57YS5pbnN0aXR1dGlvbk5hbWV9PC90ZD5cbiAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJkLW5vbmUgZC1sZy10YWJsZS1jZWxsXCI+e2EuY291cnNlTmFtZX08L3RkPlxuICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInRleHQtbnVtXCI+e2Zvcm1hdElOUihhLmxvYW5BbW91bnRSZXF1ZXN0ZWRJbnIpfTwvdGQ+XG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwidGV4dC1udW0gZC1ub25lIGQtbWQtdGFibGUtY2VsbFwiPlxuICAgICAgICAgICAgICAgICAgICB7YS5jcmVkaXRTY29yZSAhPT0gbnVsbCA/IGEuY3JlZGl0U2NvcmUgOiA8ZW0gc3R5bGU9e3sgY29sb3I6IFwiIzljYTNhZlwiIH19Pk4vQTwvZW0+fVxuICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgIDx0ZD5cbiAgICAgICAgICAgICAgICAgICAge2VkaXRpbmdJZCA9PT0gYS5pZCA/IChcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImQtZmxleCBhbGlnbi1pdGVtcy1jZW50ZXIgZ2FwLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9ybS1zZWxlY3QgZm9ybS1zZWxlY3Qtc20gcHktMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiAxMTAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2VkaXRTdGF0dXN9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RWRpdFN0YXR1cyhlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtzdGF0dXNTYXZpbmd9XG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtTVEFUVVNfT1BUSU9OUy5tYXAoKHMpID0+IDxvcHRpb24ga2V5PXtzfSB2YWx1ZT17c30+e3N9PC9vcHRpb24+KX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwiYnRuIGJ0bi1zbSBidG4tc3VjY2VzcyBweS0wIHB4LTFcIiBvbkNsaWNrPXsoKSA9PiBzYXZlU3RhdHVzKGEpfSBkaXNhYmxlZD17c3RhdHVzU2F2aW5nfSB0aXRsZT1cIlNhdmVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGkgY2xhc3NOYW1lPVwiYmkgYmktY2hlY2tcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJidG4gYnRuLXNtIGJ0bi1zZWNvbmRhcnkgcHktMCBweC0xXCIgb25DbGljaz17KCkgPT4gc2V0RWRpdGluZ0lkKG51bGwpfSBkaXNhYmxlZD17c3RhdHVzU2F2aW5nfSB0aXRsZT1cIkNhbmNlbFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8aSBjbGFzc05hbWU9XCJiaSBiaS14XCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BkcS1waWxsICR7c3RhdHVzQ2xhc3MoYS5hcHBsaWNhdGlvblN0YXR1cyl9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IGN1cnNvcjogY2FuV3JpdGUgPyBcInBvaW50ZXJcIiA6IFwiZGVmYXVsdFwiIH19XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghY2FuV3JpdGUpIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0RWRpdGluZ0lkKGEuaWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRFZGl0U3RhdHVzKGEuYXBwbGljYXRpb25TdGF0dXMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPXtjYW5Xcml0ZSA/IFwiQ2xpY2sgdG8gdXBkYXRlIHN0YXR1c1wiIDogXCJSZWFkLW9ubHkgcm9sZVwifVxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIHthLmFwcGxpY2F0aW9uU3RhdHVzfVxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwiZC1ub25lIGQtbGctdGFibGUtY2VsbFwiPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BkcS1waWxsICR7YXR0ZW50aW9uQ2xhc3MoYS5hdHRlbnRpb25MZXZlbCl9YH0+e2EuYXR0ZW50aW9uTGV2ZWx9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJkLW5vbmUgZC1sZy10YWJsZS1jZWxsXCI+e2EuYXBwbGljYXRpb25EYXRlfTwvdGQ+XG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJidG4tZ3JvdXAgYnRuLWdyb3VwLXNtXCIgcm9sZT1cImdyb3VwXCIgYXJpYS1sYWJlbD17YEFjdGlvbnMgZm9yICR7YS5pZH1gfT5cbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJidG4gYnRuLW91dGxpbmUtc2Vjb25kYXJ5XCIgb25DbGljaz17KCkgPT4gc2V0Vmlld0l0ZW0oYSl9IHRpdGxlPVwiVmlldyBkZXRhaWxzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aSBjbGFzc05hbWU9XCJiaSBiaS1leWVcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgIHtjYW5Xcml0ZSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJidG4gYnRuLW91dGxpbmUtcHJpbWFyeVwiIG9uQ2xpY2s9eygpID0+IHNldEZvcm1Nb2RhbCh7IHNob3c6IHRydWUsIG1vZGU6IFwiZWRpdFwiLCBpdGVtOiBhIH0pfSB0aXRsZT1cIkVkaXQgcmVjb3JkXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGkgY2xhc3NOYW1lPVwiYmkgYmktcGVuY2lsXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImJ0biBidG4tb3V0bGluZS1kYW5nZXJcIiBvbkNsaWNrPXsoKSA9PiBzZXREZWxldGVUYXJnZXQoYSl9IHRpdGxlPVwiRGVsZXRlIHJlY29yZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpIGNsYXNzTmFtZT1cImJpIGJpLXRyYXNoXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgKSlcbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgPC90YWJsZT5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogUGFnaW5hdGlvbiAqL31cbiAgICAgIDxuYXYgYXJpYS1sYWJlbD1cIkFwcGxpY2F0aW9ucyBwYWdpbmF0aW9uXCIgY2xhc3NOYW1lPVwibXQtM1wiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImQtZmxleCBmbGV4LXdyYXAganVzdGlmeS1jb250ZW50LWJldHdlZW4gYWxpZ24taXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1tdXRlZCBzbWFsbFwiPlxuICAgICAgICAgICAgUGFnZSB7cGFnZX0gb2Yge3RvdGFsUGFnZXN9XG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJwYWdpbmF0aW9uIHBhZ2luYXRpb24tc20gbWItMFwiPlxuICAgICAgICAgICAgPGxpIGNsYXNzTmFtZT17YHBhZ2UtaXRlbSAke3BhZ2UgPD0gMSA/IFwiZGlzYWJsZWRcIiA6IFwiXCJ9YH0+XG4gICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwicGFnZS1saW5rXCIgb25DbGljaz17KCkgPT4gc2V0UGFnZSgocCkgPT4gTWF0aC5tYXgoMSwgcCAtIDEpKX0gZGlzYWJsZWQ9e3BhZ2UgPD0gMX0gYXJpYS1sYWJlbD1cIlByZXZpb3VzIHBhZ2VcIj5cbiAgICAgICAgICAgICAgICA8aSBjbGFzc05hbWU9XCJiaSBiaS1jaGV2cm9uLWxlZnRcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICB7QXJyYXkuZnJvbSh7IGxlbmd0aDogdG90YWxQYWdlcyB9LCAoXywgaSkgPT4gaSArIDEpXG4gICAgICAgICAgICAgIC5maWx0ZXIoKHApID0+IHAgPT09IDEgfHwgcCA9PT0gdG90YWxQYWdlcyB8fCBNYXRoLmFicyhwIC0gcGFnZSkgPD0gMilcbiAgICAgICAgICAgICAgLm1hcCgocCwgaWR4LCBhcnIpID0+IChcbiAgICAgICAgICAgICAgICA8UmVhY3QuRnJhZ21lbnQga2V5PXtwfT5cbiAgICAgICAgICAgICAgICAgIHtpZHggPiAwICYmIGFycltpZHggLSAxXSAhPT0gcCAtIDEgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8bGkgY2xhc3NOYW1lPVwicGFnZS1pdGVtIGRpc2FibGVkXCI+PHNwYW4gY2xhc3NOYW1lPVwicGFnZS1saW5rXCI+4oCmPC9zcGFuPjwvbGk+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPGxpIGNsYXNzTmFtZT17YHBhZ2UtaXRlbSAke3AgPT09IHBhZ2UgPyBcImFjdGl2ZVwiIDogXCJcIn1gfT5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJwYWdlLWxpbmtcIiBvbkNsaWNrPXsoKSA9PiBzZXRQYWdlKHApfSBhcmlhLWN1cnJlbnQ9e3AgPT09IHBhZ2UgPyBcInBhZ2VcIiA6IHVuZGVmaW5lZH0+XG4gICAgICAgICAgICAgICAgICAgICAge3B9XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICA8L1JlYWN0LkZyYWdtZW50PlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDxsaSBjbGFzc05hbWU9e2BwYWdlLWl0ZW0gJHtwYWdlID49IHRvdGFsUGFnZXMgPyBcImRpc2FibGVkXCIgOiBcIlwifWB9PlxuICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cInBhZ2UtbGlua1wiIG9uQ2xpY2s9eygpID0+IHNldFBhZ2UoKHAyKSA9PiBNYXRoLm1pbih0b3RhbFBhZ2VzLCBwMiArIDEpKX0gZGlzYWJsZWQ9e3BhZ2UgPj0gdG90YWxQYWdlc30gYXJpYS1sYWJlbD1cIk5leHQgcGFnZVwiPlxuICAgICAgICAgICAgICAgIDxpIGNsYXNzTmFtZT1cImJpIGJpLWNoZXZyb24tcmlnaHRcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgPC91bD5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L25hdj5cblxuICAgICAgey8qIE1vZGFscyAqL31cbiAgICAgIDxJdGVtVmlld01vZGFsXG4gICAgICAgIHNob3c9e0Jvb2xlYW4odmlld0l0ZW0pfVxuICAgICAgICBpdGVtPXt2aWV3SXRlbX1cbiAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0Vmlld0l0ZW0obnVsbCl9XG4gICAgICAgIG9uRWRpdD17KCkgPT4ge1xuICAgICAgICAgIGNvbnN0IGl0ZW0gPSB2aWV3SXRlbTtcbiAgICAgICAgICBzZXRWaWV3SXRlbShudWxsKTtcbiAgICAgICAgICBzZXRGb3JtTW9kYWwoeyBzaG93OiB0cnVlLCBtb2RlOiBcImVkaXRcIiwgaXRlbSB9KTtcbiAgICAgICAgfX1cbiAgICAgICAgY2FuV3JpdGU9e2NhbldyaXRlfVxuICAgICAgLz5cblxuICAgICAgPEl0ZW1Gb3JtTW9kYWxcbiAgICAgICAgc2hvdz17Zm9ybU1vZGFsLnNob3d9XG4gICAgICAgIG1vZGU9e2Zvcm1Nb2RhbC5tb2RlfVxuICAgICAgICBpdGVtPXtmb3JtTW9kYWwuaXRlbX1cbiAgICAgICAgZmlsdGVycz17ZmlsdGVyc31cbiAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0Rm9ybU1vZGFsKHsgc2hvdzogZmFsc2UsIG1vZGU6IFwiY3JlYXRlXCIsIGl0ZW06IG51bGwgfSl9XG4gICAgICAgIG9uU2F2ZWQ9e2FzeW5jICgpID0+IHtcbiAgICAgICAgICBzZXRGb3JtTW9kYWwoeyBzaG93OiBmYWxzZSwgbW9kZTogXCJjcmVhdGVcIiwgaXRlbTogbnVsbCB9KTtcbiAgICAgICAgICBhd2FpdCBsb2FkUm93cygpO1xuICAgICAgICB9fVxuICAgICAgLz5cblxuICAgICAgPENvbmZpcm1Nb2RhbFxuICAgICAgICBzaG93PXtCb29sZWFuKGRlbGV0ZVRhcmdldCl9XG4gICAgICAgIHRpdGxlPVwiRGVsZXRlIEFwcGxpY2F0aW9uP1wiXG4gICAgICAgIG1lc3NhZ2U9e1xuICAgICAgICAgIGRlbGV0ZVRhcmdldFxuICAgICAgICAgICAgPyBgQXJlIHlvdSBzdXJlIHlvdSB3YW50IHRvIHBlcm1hbmVudGx5IGRlbGV0ZSBhcHBsaWNhdGlvbiAke2RlbGV0ZVRhcmdldC5pZH0gKCR7ZGVsZXRlVGFyZ2V0LnN0dWRlbnROYW1lfSk/IFRoaXMgY2Fubm90IGJlIHVuZG9uZS5gXG4gICAgICAgICAgICA6IFwiXCJcbiAgICAgICAgfVxuICAgICAgICBjb25maXJtTGFiZWw9XCJEZWxldGVcIlxuICAgICAgICBsb2FkaW5nPXtkZWxldGluZ31cbiAgICAgICAgb25Db25maXJtPXtoYW5kbGVEZWxldGV9XG4gICAgICAgIG9uQ2FuY2VsPXsoKSA9PiBzZXREZWxldGVUYXJnZXQobnVsbCl9XG4gICAgICAvPlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiJDOi9Vc2Vycy91c2VyL0Rvd25sb2Fkcy9kaGFuaXRpLWFwcC11cGdyYWRlZC9kaGFuaXRpLWFwcC9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9BcHBsaWNhdGlvbnNUYWJsZS5qc3gifQ==