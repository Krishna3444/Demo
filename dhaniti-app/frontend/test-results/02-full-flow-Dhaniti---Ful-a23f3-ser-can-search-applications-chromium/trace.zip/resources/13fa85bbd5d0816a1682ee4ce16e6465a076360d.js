import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/NotFound.jsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];const React = __vite__cjsImport3_react;import * as RefreshRuntime from "/@react-refresh";
var _jsxFileName = "C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/pages/NotFound.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=325d36c7";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
	if (!window.$RefreshReg$) {
		throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong.");
	}
	prevRefreshReg = window.$RefreshReg$;
	prevRefreshSig = window.$RefreshSig$;
	window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/pages/NotFound.jsx");
	window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=325d36c7";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=325d36c7";
export default function NotFound() {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "d-flex flex-column align-items-center justify-content-center text-center",
		style: { minHeight: "70vh" },
		children: [
			/* @__PURE__ */ _jsxDEV("h1", {
				className: "display-1 fw-bold text-dhaniti mb-0",
				children: "404"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 26,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("h4", {
				className: "mb-2",
				children: "Page not found"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 27,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "text-muted mb-4",
				style: { maxWidth: 420 },
				children: "The page you are looking for doesn't exist or may have been moved. Check the address or head back to your dashboard."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 28,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "d-flex gap-2",
				children: [/* @__PURE__ */ _jsxDEV(Link, {
					to: "/dashboard",
					className: "btn btn-dhaniti",
					children: [/* @__PURE__ */ _jsxDEV("i", {
						className: "bi bi-house-door me-1",
						"aria-hidden": "true"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 34,
						columnNumber: 11
					}, this), "Go to dashboard"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 33,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV(Link, {
					to: "/login",
					className: "btn btn-outline-secondary",
					children: "Sign in"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 37,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 32,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 25,
		columnNumber: 5
	}, this);
}
_c = NotFound;
var _c;
$RefreshReg$(_c, "NotFound");
if (import.meta.hot && !inWebWorker) {
	window.$RefreshReg$ = prevRefreshReg;
	window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
	RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
		RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/pages/NotFound.jsx", currentExports);
		import.meta.hot.accept((nextExports) => {
			if (!nextExports) return;
			const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/pages/NotFound.jsx", currentExports, nextExports);
			if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
		});
	});
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsT0FBT0EsV0FBVztBQUNsQixTQUFTQyxZQUFZO0FBRXJCLGVBQWUsU0FBU0MsV0FBVztDQUNqQyxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO0VBQTJFLE9BQU8sRUFBRUMsV0FBVyxPQUFPO1lBQXJIO0dBQ0Usd0JBQUMsTUFBRDtJQUFJLFdBQVU7Y0FBc0M7R0FBTzs7Ozs7R0FDM0Qsd0JBQUMsTUFBRDtJQUFJLFdBQVU7Y0FBTztHQUFrQjs7Ozs7R0FDdkMsd0JBQUMsS0FBRDtJQUFHLFdBQVU7SUFBa0IsT0FBTyxFQUFFQyxVQUFVLElBQUk7Y0FBRTtHQUdyRDs7Ozs7R0FDSCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsTUFBRDtLQUFNLElBQUc7S0FBYSxXQUFVO2VBQWhDLENBQ0Usd0JBQUMsS0FBRDtNQUFHLFdBQVU7TUFBd0IsZUFBWTtLQUFNOzs7O2VBQUEsaUJBRW5EOzs7OztjQUNOLHdCQUFDLE1BQUQ7S0FBTSxJQUFHO0tBQVMsV0FBVTtlQUE0QjtJQUFhOzs7O1lBQ2xFOzs7Ozs7RUFDRjs7Ozs7O0FBRVQ7QUFBQ0MsS0FsQnVCSDtBQUFRLElBQUFHO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwiTGluayIsIk5vdEZvdW5kIiwibWluSGVpZ2h0IiwibWF4V2lkdGgiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJOb3RGb3VuZC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgTGluayB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE5vdEZvdW5kKCkge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZC1mbGV4IGZsZXgtY29sdW1uIGFsaWduLWl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNvbnRlbnQtY2VudGVyIHRleHQtY2VudGVyXCIgc3R5bGU9e3sgbWluSGVpZ2h0OiBcIjcwdmhcIiB9fT5cbiAgICAgIDxoMSBjbGFzc05hbWU9XCJkaXNwbGF5LTEgZnctYm9sZCB0ZXh0LWRoYW5pdGkgbWItMFwiPjQwNDwvaDE+XG4gICAgICA8aDQgY2xhc3NOYW1lPVwibWItMlwiPlBhZ2Ugbm90IGZvdW5kPC9oND5cbiAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbXV0ZWQgbWItNFwiIHN0eWxlPXt7IG1heFdpZHRoOiA0MjAgfX0+XG4gICAgICAgIFRoZSBwYWdlIHlvdSBhcmUgbG9va2luZyBmb3IgZG9lc24mYXBvczt0IGV4aXN0IG9yIG1heSBoYXZlIGJlZW4gbW92ZWQuXG4gICAgICAgIENoZWNrIHRoZSBhZGRyZXNzIG9yIGhlYWQgYmFjayB0byB5b3VyIGRhc2hib2FyZC5cbiAgICAgIDwvcD5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZC1mbGV4IGdhcC0yXCI+XG4gICAgICAgIDxMaW5rIHRvPVwiL2Rhc2hib2FyZFwiIGNsYXNzTmFtZT1cImJ0biBidG4tZGhhbml0aVwiPlxuICAgICAgICAgIDxpIGNsYXNzTmFtZT1cImJpIGJpLWhvdXNlLWRvb3IgbWUtMVwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgR28gdG8gZGFzaGJvYXJkXG4gICAgICAgIDwvTGluaz5cbiAgICAgICAgPExpbmsgdG89XCIvbG9naW5cIiBjbGFzc05hbWU9XCJidG4gYnRuLW91dGxpbmUtc2Vjb25kYXJ5XCI+U2lnbiBpbjwvTGluaz5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiJDOi9Vc2Vycy91c2VyL0Rvd25sb2Fkcy9kaGFuaXRpLWFwcC11cGdyYWRlZC9kaGFuaXRpLWFwcC9mcm9udGVuZC9zcmMvcGFnZXMvTm90Rm91bmQuanN4In0=