import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Dashboard.jsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport1_react_jsxDevRuntime["Fragment"];const React = __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];import * as RefreshRuntime from "/@react-refresh";
var _jsxFileName = "C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/pages/Dashboard.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=325d36c7";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
	if (!window.$RefreshReg$) {
		throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong.");
	}
	prevRefreshReg = window.$RefreshReg$;
	prevRefreshSig = window.$RefreshSig$;
	window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/pages/Dashboard.jsx");
	window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=325d36c7";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=325d36c7";
import { itemsApi } from "/src/api/items.js";
import { useAuth } from "/src/context/AuthContext.jsx";
import KpiCards from "/src/components/KpiCards.jsx";
import Charts from "/src/components/Charts.jsx";
import Insights from "/src/components/Insights.jsx";
import DataQuality from "/src/components/DataQuality.jsx";
import ApplicationsTable from "/src/components/ApplicationsTable.jsx";
export default function Dashboard() {
	_s();
	const { currentUser, canWrite } = useAuth();
	const [tab, setTab] = useState("overview");
	const [kpis, setKpis] = useState(null);
	const [charts, setCharts] = useState(null);
	const [insights, setInsights] = useState(null);
	const [dq, setDq] = useState(null);
	const [filters, setFilters] = useState(null);
	const [error, setError] = useState("");
	useEffect(() => {
		Promise.all([
			itemsApi.kpis(),
			itemsApi.charts(),
			itemsApi.insights(),
			itemsApi.dataQuality(),
			itemsApi.filters()
		]).then(([k, c, i, d, f]) => {
			setKpis(k);
			setCharts(c);
			setInsights(i);
			setDq(d);
			setFilters(f);
		}).catch((e) => setError(e.message));
	}, []);
	const firstName = (currentUser?.name || "there").split(/[\s(]/)[0];
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
		/* @__PURE__ */ _jsxDEV("div", {
			className: "container-fluid px-3 px-md-4 pt-3",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h4", {
					className: "mb-0",
					children: ["Welcome, ", firstName]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 63,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-muted small mb-0",
					children: "Here is what is happening with the education-loan portfolio today."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 64,
					columnNumber: 13
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 62,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV(Link, {
					to: "/applications",
					className: "btn btn-sm btn-outline-dhaniti",
					children: [/* @__PURE__ */ _jsxDEV("i", {
						className: "bi bi-table me-1",
						"aria-hidden": "true"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 69,
						columnNumber: 13
					}, this), "Manage applications"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 68,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 61,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 60,
			columnNumber: 7
		}, this),
		error && /* @__PURE__ */ _jsxDEV("div", {
			className: "container-fluid px-3 px-md-4",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "alert alert-danger mt-2",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 77,
				columnNumber: 11
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 76,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("ul", {
			className: "nav nav-tabs mb-3 px-3 px-md-4 pt-2",
			children: [
				/* @__PURE__ */ _jsxDEV("li", {
					className: "nav-item",
					children: /* @__PURE__ */ _jsxDEV("button", {
						className: `nav-link ${tab === "overview" ? "active" : ""}`,
						onClick: () => setTab("overview"),
						children: "Overview"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 83,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 82,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("li", {
					className: "nav-item",
					children: /* @__PURE__ */ _jsxDEV("button", {
						className: `nav-link ${tab === "applications" ? "active" : ""}`,
						onClick: () => setTab("applications"),
						children: ["Applications", kpis && /* @__PURE__ */ _jsxDEV("span", {
							className: "badge bg-secondary ms-2",
							children: kpis.totalApplications
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 90,
							columnNumber: 22
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 88,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 87,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("li", {
					className: "nav-item",
					children: /* @__PURE__ */ _jsxDEV("button", {
						className: `nav-link ${tab === "insights" ? "active" : ""}`,
						onClick: () => setTab("insights"),
						children: ["Insights", insights && /* @__PURE__ */ _jsxDEV("span", {
							className: "badge bg-secondary ms-2",
							children: insights.length
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 96,
							columnNumber: 26
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 94,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 93,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("li", {
					className: "nav-item",
					children: /* @__PURE__ */ _jsxDEV("button", {
						className: `nav-link ${tab === "data-quality" ? "active" : ""}`,
						onClick: () => setTab("data-quality"),
						children: ["Data Quality", dq && /* @__PURE__ */ _jsxDEV("span", {
							className: "badge bg-warning text-dark ms-2",
							children: dq.totalIssues
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 102,
							columnNumber: 20
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 100,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 99,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 81,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("div", {
			className: "container-fluid px-3 px-md-4",
			children: [
				tab === "overview" && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "card section-card",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "card-header",
						children: ["Key Metrics", kpis && /* @__PURE__ */ _jsxDEV("span", {
							className: "badge bg-secondary ms-2",
							children: kpis.totalApplications
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 113,
							columnNumber: 26
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 111,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "card-body",
						children: kpis ? /* @__PURE__ */ _jsxDEV(KpiCards, { kpis }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 116,
							columnNumber: 25
						}, this) : /* @__PURE__ */ _jsxDEV("div", {
							className: "text-center text-muted py-4",
							children: /* @__PURE__ */ _jsxDEV("div", {
								className: "spinner-border",
								role: "status"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 118,
								columnNumber: 21
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 117,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 115,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 110,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "card section-card",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "card-header",
						children: "Distribution Charts"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 125,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "card-body",
						children: charts ? /* @__PURE__ */ _jsxDEV(Charts, { charts }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 127,
							columnNumber: 27
						}, this) : /* @__PURE__ */ _jsxDEV("div", {
							className: "text-center text-muted py-4",
							children: /* @__PURE__ */ _jsxDEV("div", {
								className: "spinner-border",
								role: "status"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 129,
								columnNumber: 21
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 128,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 126,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 124,
					columnNumber: 13
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 109,
					columnNumber: 9
				}, this),
				tab === "applications" && /* @__PURE__ */ _jsxDEV("div", {
					className: "card section-card",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "card-header d-flex flex-wrap justify-content-between align-items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV("span", { children: ["Applications", kpis && /* @__PURE__ */ _jsxDEV("span", {
							className: "badge bg-secondary ms-2",
							children: kpis.totalApplications
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 142,
							columnNumber: 26
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 140,
							columnNumber: 15
						}, this), !canWrite && /* @__PURE__ */ _jsxDEV("span", {
							className: "badge text-bg-secondary",
							children: "Read-only role"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 144,
							columnNumber: 29
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 139,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "card-body",
						children: /* @__PURE__ */ _jsxDEV(ApplicationsTable, { filters }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 147,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 146,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 138,
					columnNumber: 9
				}, this),
				tab === "insights" && /* @__PURE__ */ _jsxDEV("div", {
					className: "card section-card",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "card-header",
						children: ["Business Insights", insights && /* @__PURE__ */ _jsxDEV("span", {
							className: "badge bg-secondary ms-2",
							children: insights.length
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 156,
							columnNumber: 28
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 154,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "card-body",
						children: insights ? /* @__PURE__ */ _jsxDEV(Insights, { insights }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 159,
							columnNumber: 27
						}, this) : /* @__PURE__ */ _jsxDEV("div", {
							className: "text-center text-muted py-4",
							children: /* @__PURE__ */ _jsxDEV("div", {
								className: "spinner-border",
								role: "status"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 161,
								columnNumber: 19
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 160,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 158,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 153,
					columnNumber: 9
				}, this),
				tab === "data-quality" && /* @__PURE__ */ _jsxDEV("div", {
					className: "card section-card",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "card-header",
						children: ["Data-Quality Issues", dq && /* @__PURE__ */ _jsxDEV("span", {
							className: "badge bg-warning text-dark ms-2",
							children: dq.totalIssues
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 172,
							columnNumber: 22
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 170,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "card-body",
						children: dq ? /* @__PURE__ */ _jsxDEV(DataQuality, { dq }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 175,
							columnNumber: 21
						}, this) : /* @__PURE__ */ _jsxDEV("div", {
							className: "text-center text-muted py-4",
							children: /* @__PURE__ */ _jsxDEV("div", {
								className: "spinner-border",
								role: "status"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 177,
								columnNumber: 19
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 176,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 174,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 169,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 107,
			columnNumber: 7
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 59,
		columnNumber: 5
	}, this);
}
_s(Dashboard, "1HFBPSYdUW0sZJxFOYFx0OmeG6w=", false, function() {
	return [useAuth];
});
_c = Dashboard;
var _c;
$RefreshReg$(_c, "Dashboard");
if (import.meta.hot && !inWebWorker) {
	window.$RefreshReg$ = prevRefreshReg;
	window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
	RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
		RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/pages/Dashboard.jsx", currentExports);
		import.meta.hot.accept((nextExports) => {
			if (!nextExports) return;
			const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/pages/Dashboard.jsx", currentExports, nextExports);
			if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
		});
	});
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLE9BQU9BLFNBQVNDLFdBQVdDLGdCQUFnQjtBQUMzQyxTQUFTQyxZQUFZO0FBQ3JCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxlQUFlO0FBQ3hCLE9BQU9DLGNBQWM7QUFDckIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxjQUFjO0FBQ3JCLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyx1QkFBdUI7QUFFOUIsZUFBZSxTQUFTQyxZQUFZO0NBQUFDLEdBQUE7Q0FDbEMsTUFBTSxFQUFFQyxhQUFhQyxhQUFhVCxRQUFRO0NBQzFDLE1BQU0sQ0FBQ1UsS0FBS0MsVUFBVWQsU0FBUyxVQUFVO0NBQ3pDLE1BQU0sQ0FBQ2UsTUFBTUMsV0FBV2hCLFNBQVMsSUFBSTtDQUNyQyxNQUFNLENBQUNpQixRQUFRQyxhQUFhbEIsU0FBUyxJQUFJO0NBQ3pDLE1BQU0sQ0FBQ21CLFVBQVVDLGVBQWVwQixTQUFTLElBQUk7Q0FDN0MsTUFBTSxDQUFDcUIsSUFBSUMsU0FBU3RCLFNBQVMsSUFBSTtDQUNqQyxNQUFNLENBQUN1QixTQUFTQyxjQUFjeEIsU0FBUyxJQUFJO0NBQzNDLE1BQU0sQ0FBQ3lCLE9BQU9DLFlBQVkxQixTQUFTLEVBQUU7Q0FFckNELGdCQUFnQjtFQUNkNEIsUUFBUUMsSUFBSTtHQUNWMUIsU0FBU2EsS0FBSztHQUNkYixTQUFTZSxPQUFPO0dBQ2hCZixTQUFTaUIsU0FBUztHQUNsQmpCLFNBQVMyQixZQUFZO0dBQ3JCM0IsU0FBU3FCLFFBQVE7RUFBQyxDQUNuQixDQUFDLENBQUNPLE1BQU0sQ0FBQ0MsR0FBR0MsR0FBR0MsR0FBR0MsR0FBR0MsT0FBTztHQUMzQm5CLFFBQVFlLENBQUM7R0FDVGIsVUFBVWMsQ0FBQztHQUNYWixZQUFZYSxDQUFDO0dBQ2JYLE1BQU1ZLENBQUM7R0FDUFYsV0FBV1csQ0FBQztFQUNkLENBQUMsQ0FBQyxDQUFDQyxPQUFPQyxNQUFNWCxTQUFTVyxFQUFFQyxPQUFPLENBQUM7Q0FDckMsR0FBRyxFQUFFO0NBRUwsTUFBTUMsYUFBYTVCLGFBQWE2QixRQUFRLFFBQU8sQ0FBRUMsTUFBTSxPQUFPLENBQUMsQ0FBQztDQUVoRSxPQUNFO0VBQ0Usd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFDYix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQWQsQ0FBcUIsYUFBVUYsU0FBYzs7Ozs7Y0FDN0Msd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBdUI7SUFFakM7Ozs7WUFDQTs7OztjQUNMLHdCQUFDLE1BQUQ7S0FBTSxJQUFHO0tBQWdCLFdBQVU7ZUFBbkMsQ0FDRSx3QkFBQyxLQUFEO01BQUcsV0FBVTtNQUFtQixlQUFZO0tBQU07Ozs7ZUFBQSxxQkFFOUM7Ozs7O1lBQ0g7Ozs7OztFQUNGOzs7OztFQUVKZCxTQUNDLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQ2Isd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBMkJBO0dBQVc7Ozs7O0VBQ2xEOzs7OztFQUdQLHdCQUFDLE1BQUQ7R0FBSSxXQUFVO2FBQWQ7SUFDRSx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUNaLHdCQUFDLFVBQUQ7TUFBUSxXQUFXLFlBQVlaLFFBQVEsYUFBYSxXQUFXO01BQU0sZUFBZUMsT0FBTyxVQUFVO2dCQUFFO0tBRS9GOzs7OztJQUNOOzs7OztJQUNKLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQ1osd0JBQUMsVUFBRDtNQUFRLFdBQVcsWUFBWUQsUUFBUSxpQkFBaUIsV0FBVztNQUFNLGVBQWVDLE9BQU8sY0FBYztnQkFBN0csQ0FBK0csZ0JBRTVHQyxRQUFRLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUEyQkEsS0FBSzJCO01BQXdCOzs7O2NBQzNFOzs7Ozs7SUFDTjs7Ozs7SUFDSix3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUNaLHdCQUFDLFVBQUQ7TUFBUSxXQUFXLFlBQVk3QixRQUFRLGFBQWEsV0FBVztNQUFNLGVBQWVDLE9BQU8sVUFBVTtnQkFBckcsQ0FBdUcsWUFFcEdLLFlBQVksd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQTJCQSxTQUFTd0I7TUFBYTs7OztjQUN4RTs7Ozs7O0lBQ047Ozs7O0lBQ0osd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFDWix3QkFBQyxVQUFEO01BQVEsV0FBVyxZQUFZOUIsUUFBUSxpQkFBaUIsV0FBVztNQUFNLGVBQWVDLE9BQU8sY0FBYztnQkFBN0csQ0FBK0csZ0JBRTVHTyxNQUFNLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFtQ0EsR0FBR3VCO01BQWtCOzs7O2NBQ3pFOzs7Ozs7SUFDTjs7Ozs7R0FDRjs7Ozs7O0VBRUosd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUNHL0IsUUFBUSxjQUNQLGdEQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUE0QixlQUV6QkUsUUFBUSx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBMkJBLEtBQUsyQjtNQUF3Qjs7OztjQUM5RTs7Ozs7ZUFDTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDWjNCLE9BQU8sd0JBQUMsVUFBRCxFQUFnQkEsS0FBSzs7OztpQkFDM0Isd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ2Isd0JBQUMsT0FBRDtRQUFLLFdBQVU7UUFBaUIsTUFBSztPQUFjOzs7OztNQUNoRDs7Ozs7S0FFSjs7OzthQUNGOzs7OztjQUVMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBYztLQUF3Qjs7OztlQUNyRCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDWkUsU0FBUyx3QkFBQyxRQUFELEVBQWdCQSxPQUFPOzs7O2lCQUMvQix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQyxPQUFEO1FBQUssV0FBVTtRQUFpQixNQUFLO09BQWM7Ozs7O01BQ2hEOzs7OztLQUVKOzs7O2FBQ0Y7Ozs7O1lBQ1A7Ozs7O0lBR0RKLFFBQVEsa0JBQ1Asd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsUUFBRCxhQUFLLGdCQUVGRSxRQUFRLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUEyQkEsS0FBSzJCO01BQXdCOzs7O2NBQzdFOzs7O2dCQUNMLENBQUM5QixZQUFZLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUEwQjtNQUFvQjs7OztjQUN6RTs7Ozs7ZUFDTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDYix3QkFBQyxtQkFBRCxFQUE0QlcsUUFBUTs7Ozs7S0FDakM7Ozs7YUFDRjs7Ozs7O0lBR05WLFFBQVEsY0FDUCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FBNEIscUJBRXpCTSxZQUFZLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUEyQkEsU0FBU3dCO01BQWE7Ozs7Y0FDM0U7Ozs7O2VBQ0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ1p4QixXQUFXLHdCQUFDLFVBQUQsRUFBb0JBLFNBQVM7Ozs7aUJBQ3ZDLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO1FBQWlCLE1BQUs7T0FBYzs7Ozs7TUFDaEQ7Ozs7O0tBRUo7Ozs7YUFDRjs7Ozs7O0lBR05OLFFBQVEsa0JBQ1Asd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQTRCLHVCQUV6QlEsTUFBTSx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBbUNBLEdBQUd1QjtNQUFrQjs7OztjQUM1RTs7Ozs7ZUFDTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDWnZCLEtBQUssd0JBQUMsYUFBRCxFQUFpQkEsR0FBRzs7OztpQkFDeEIsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ2Isd0JBQUMsT0FBRDtRQUFLLFdBQVU7UUFBaUIsTUFBSztPQUFjOzs7OztNQUNoRDs7Ozs7S0FFSjs7OzthQUNGOzs7Ozs7R0FFSjs7Ozs7O0NBQ1A7Ozs7O0FBRUo7QUFBQ1gsR0E1SnVCRCxXQUFTO0NBQUEsUUFDR04sT0FBTztBQUFBO0FBQUEsS0FEbkJNO0FBQVMsSUFBQW9DO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJMaW5rIiwiaXRlbXNBcGkiLCJ1c2VBdXRoIiwiS3BpQ2FyZHMiLCJDaGFydHMiLCJJbnNpZ2h0cyIsIkRhdGFRdWFsaXR5IiwiQXBwbGljYXRpb25zVGFibGUiLCJEYXNoYm9hcmQiLCJfcyIsImN1cnJlbnRVc2VyIiwiY2FuV3JpdGUiLCJ0YWIiLCJzZXRUYWIiLCJrcGlzIiwic2V0S3BpcyIsImNoYXJ0cyIsInNldENoYXJ0cyIsImluc2lnaHRzIiwic2V0SW5zaWdodHMiLCJkcSIsInNldERxIiwiZmlsdGVycyIsInNldEZpbHRlcnMiLCJlcnJvciIsInNldEVycm9yIiwiUHJvbWlzZSIsImFsbCIsImRhdGFRdWFsaXR5IiwidGhlbiIsImsiLCJjIiwiaSIsImQiLCJmIiwiY2F0Y2giLCJlIiwibWVzc2FnZSIsImZpcnN0TmFtZSIsIm5hbWUiLCJzcGxpdCIsInRvdGFsQXBwbGljYXRpb25zIiwibGVuZ3RoIiwidG90YWxJc3N1ZXMiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJEYXNoYm9hcmQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBMaW5rIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcbmltcG9ydCB7IGl0ZW1zQXBpIH0gZnJvbSBcIi4uL2FwaS9pdGVtcy5qc1wiO1xuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gXCIuLi9jb250ZXh0L0F1dGhDb250ZXh0LmpzeFwiO1xuaW1wb3J0IEtwaUNhcmRzIGZyb20gXCIuLi9jb21wb25lbnRzL0twaUNhcmRzLmpzeFwiO1xuaW1wb3J0IENoYXJ0cyBmcm9tIFwiLi4vY29tcG9uZW50cy9DaGFydHMuanN4XCI7XG5pbXBvcnQgSW5zaWdodHMgZnJvbSBcIi4uL2NvbXBvbmVudHMvSW5zaWdodHMuanN4XCI7XG5pbXBvcnQgRGF0YVF1YWxpdHkgZnJvbSBcIi4uL2NvbXBvbmVudHMvRGF0YVF1YWxpdHkuanN4XCI7XG5pbXBvcnQgQXBwbGljYXRpb25zVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvQXBwbGljYXRpb25zVGFibGUuanN4XCI7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIERhc2hib2FyZCgpIHtcbiAgY29uc3QgeyBjdXJyZW50VXNlciwgY2FuV3JpdGUgfSA9IHVzZUF1dGgoKTtcbiAgY29uc3QgW3RhYiwgc2V0VGFiXSA9IHVzZVN0YXRlKFwib3ZlcnZpZXdcIik7XG4gIGNvbnN0IFtrcGlzLCBzZXRLcGlzXSA9IHVzZVN0YXRlKG51bGwpO1xuICBjb25zdCBbY2hhcnRzLCBzZXRDaGFydHNdID0gdXNlU3RhdGUobnVsbCk7XG4gIGNvbnN0IFtpbnNpZ2h0cywgc2V0SW5zaWdodHNdID0gdXNlU3RhdGUobnVsbCk7XG4gIGNvbnN0IFtkcSwgc2V0RHFdID0gdXNlU3RhdGUobnVsbCk7XG4gIGNvbnN0IFtmaWx0ZXJzLCBzZXRGaWx0ZXJzXSA9IHVzZVN0YXRlKG51bGwpO1xuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKFwiXCIpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgUHJvbWlzZS5hbGwoW1xuICAgICAgaXRlbXNBcGkua3BpcygpLFxuICAgICAgaXRlbXNBcGkuY2hhcnRzKCksXG4gICAgICBpdGVtc0FwaS5pbnNpZ2h0cygpLFxuICAgICAgaXRlbXNBcGkuZGF0YVF1YWxpdHkoKSxcbiAgICAgIGl0ZW1zQXBpLmZpbHRlcnMoKSxcbiAgICBdKS50aGVuKChbaywgYywgaSwgZCwgZl0pID0+IHtcbiAgICAgIHNldEtwaXMoayk7XG4gICAgICBzZXRDaGFydHMoYyk7XG4gICAgICBzZXRJbnNpZ2h0cyhpKTtcbiAgICAgIHNldERxKGQpO1xuICAgICAgc2V0RmlsdGVycyhmKTtcbiAgICB9KS5jYXRjaCgoZSkgPT4gc2V0RXJyb3IoZS5tZXNzYWdlKSk7XG4gIH0sIFtdKTtcblxuICBjb25zdCBmaXJzdE5hbWUgPSAoY3VycmVudFVzZXI/Lm5hbWUgfHwgXCJ0aGVyZVwiKS5zcGxpdCgvW1xccyhdLylbMF07XG5cbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWluZXItZmx1aWQgcHgtMyBweC1tZC00IHB0LTNcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkLWZsZXggZmxleC13cmFwIGp1c3RpZnktY29udGVudC1iZXR3ZWVuIGFsaWduLWl0ZW1zLWNlbnRlciBnYXAtMiBtYi0zXCI+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJtYi0wXCI+V2VsY29tZSwge2ZpcnN0TmFtZX08L2g0PlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1tdXRlZCBzbWFsbCBtYi0wXCI+XG4gICAgICAgICAgICAgIEhlcmUgaXMgd2hhdCBpcyBoYXBwZW5pbmcgd2l0aCB0aGUgZWR1Y2F0aW9uLWxvYW4gcG9ydGZvbGlvIHRvZGF5LlxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxMaW5rIHRvPVwiL2FwcGxpY2F0aW9uc1wiIGNsYXNzTmFtZT1cImJ0biBidG4tc20gYnRuLW91dGxpbmUtZGhhbml0aVwiPlxuICAgICAgICAgICAgPGkgY2xhc3NOYW1lPVwiYmkgYmktdGFibGUgbWUtMVwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgICBNYW5hZ2UgYXBwbGljYXRpb25zXG4gICAgICAgICAgPC9MaW5rPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7ZXJyb3IgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lci1mbHVpZCBweC0zIHB4LW1kLTRcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFsZXJ0IGFsZXJ0LWRhbmdlciBtdC0yXCI+e2Vycm9yfTwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIDx1bCBjbGFzc05hbWU9XCJuYXYgbmF2LXRhYnMgbWItMyBweC0zIHB4LW1kLTQgcHQtMlwiPlxuICAgICAgICA8bGkgY2xhc3NOYW1lPVwibmF2LWl0ZW1cIj5cbiAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT17YG5hdi1saW5rICR7dGFiID09PSBcIm92ZXJ2aWV3XCIgPyBcImFjdGl2ZVwiIDogXCJcIn1gfSBvbkNsaWNrPXsoKSA9PiBzZXRUYWIoXCJvdmVydmlld1wiKX0+XG4gICAgICAgICAgICBPdmVydmlld1xuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2xpPlxuICAgICAgICA8bGkgY2xhc3NOYW1lPVwibmF2LWl0ZW1cIj5cbiAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT17YG5hdi1saW5rICR7dGFiID09PSBcImFwcGxpY2F0aW9uc1wiID8gXCJhY3RpdmVcIiA6IFwiXCJ9YH0gb25DbGljaz17KCkgPT4gc2V0VGFiKFwiYXBwbGljYXRpb25zXCIpfT5cbiAgICAgICAgICAgIEFwcGxpY2F0aW9uc1xuICAgICAgICAgICAge2twaXMgJiYgPHNwYW4gY2xhc3NOYW1lPVwiYmFkZ2UgYmctc2Vjb25kYXJ5IG1zLTJcIj57a3Bpcy50b3RhbEFwcGxpY2F0aW9uc308L3NwYW4+fVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2xpPlxuICAgICAgICA8bGkgY2xhc3NOYW1lPVwibmF2LWl0ZW1cIj5cbiAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT17YG5hdi1saW5rICR7dGFiID09PSBcImluc2lnaHRzXCIgPyBcImFjdGl2ZVwiIDogXCJcIn1gfSBvbkNsaWNrPXsoKSA9PiBzZXRUYWIoXCJpbnNpZ2h0c1wiKX0+XG4gICAgICAgICAgICBJbnNpZ2h0c1xuICAgICAgICAgICAge2luc2lnaHRzICYmIDxzcGFuIGNsYXNzTmFtZT1cImJhZGdlIGJnLXNlY29uZGFyeSBtcy0yXCI+e2luc2lnaHRzLmxlbmd0aH08L3NwYW4+fVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2xpPlxuICAgICAgICA8bGkgY2xhc3NOYW1lPVwibmF2LWl0ZW1cIj5cbiAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT17YG5hdi1saW5rICR7dGFiID09PSBcImRhdGEtcXVhbGl0eVwiID8gXCJhY3RpdmVcIiA6IFwiXCJ9YH0gb25DbGljaz17KCkgPT4gc2V0VGFiKFwiZGF0YS1xdWFsaXR5XCIpfT5cbiAgICAgICAgICAgIERhdGEgUXVhbGl0eVxuICAgICAgICAgICAge2RxICYmIDxzcGFuIGNsYXNzTmFtZT1cImJhZGdlIGJnLXdhcm5pbmcgdGV4dC1kYXJrIG1zLTJcIj57ZHEudG90YWxJc3N1ZXN9PC9zcGFuPn1cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9saT5cbiAgICAgIDwvdWw+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyLWZsdWlkIHB4LTMgcHgtbWQtNFwiPlxuICAgICAgICB7dGFiID09PSBcIm92ZXJ2aWV3XCIgJiYgKFxuICAgICAgICAgIDw+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQgc2VjdGlvbi1jYXJkXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZC1oZWFkZXJcIj5cbiAgICAgICAgICAgICAgICBLZXkgTWV0cmljc1xuICAgICAgICAgICAgICAgIHtrcGlzICYmIDxzcGFuIGNsYXNzTmFtZT1cImJhZGdlIGJnLXNlY29uZGFyeSBtcy0yXCI+e2twaXMudG90YWxBcHBsaWNhdGlvbnN9PC9zcGFuPn1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZC1ib2R5XCI+XG4gICAgICAgICAgICAgICAge2twaXMgPyA8S3BpQ2FyZHMga3Bpcz17a3Bpc30gLz4gOiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHRleHQtbXV0ZWQgcHktNFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwaW5uZXItYm9yZGVyXCIgcm9sZT1cInN0YXR1c1wiPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkIHNlY3Rpb24tY2FyZFwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQtaGVhZGVyXCI+RGlzdHJpYnV0aW9uIENoYXJ0czwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQtYm9keVwiPlxuICAgICAgICAgICAgICAgIHtjaGFydHMgPyA8Q2hhcnRzIGNoYXJ0cz17Y2hhcnRzfSAvPiA6IChcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgdGV4dC1tdXRlZCBweS00XCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3Bpbm5lci1ib3JkZXJcIiByb2xlPVwic3RhdHVzXCI+PC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvPlxuICAgICAgICApfVxuXG4gICAgICAgIHt0YWIgPT09IFwiYXBwbGljYXRpb25zXCIgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZCBzZWN0aW9uLWNhcmRcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZC1oZWFkZXIgZC1mbGV4IGZsZXgtd3JhcCBqdXN0aWZ5LWNvbnRlbnQtYmV0d2VlbiBhbGlnbi1pdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPHNwYW4+XG4gICAgICAgICAgICAgICAgQXBwbGljYXRpb25zXG4gICAgICAgICAgICAgICAge2twaXMgJiYgPHNwYW4gY2xhc3NOYW1lPVwiYmFkZ2UgYmctc2Vjb25kYXJ5IG1zLTJcIj57a3Bpcy50b3RhbEFwcGxpY2F0aW9uc308L3NwYW4+fVxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIHshY2FuV3JpdGUgJiYgPHNwYW4gY2xhc3NOYW1lPVwiYmFkZ2UgdGV4dC1iZy1zZWNvbmRhcnlcIj5SZWFkLW9ubHkgcm9sZTwvc3Bhbj59XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZC1ib2R5XCI+XG4gICAgICAgICAgICAgIDxBcHBsaWNhdGlvbnNUYWJsZSBmaWx0ZXJzPXtmaWx0ZXJzfSAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgICAge3RhYiA9PT0gXCJpbnNpZ2h0c1wiICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQgc2VjdGlvbi1jYXJkXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQtaGVhZGVyXCI+XG4gICAgICAgICAgICAgIEJ1c2luZXNzIEluc2lnaHRzXG4gICAgICAgICAgICAgIHtpbnNpZ2h0cyAmJiA8c3BhbiBjbGFzc05hbWU9XCJiYWRnZSBiZy1zZWNvbmRhcnkgbXMtMlwiPntpbnNpZ2h0cy5sZW5ndGh9PC9zcGFuPn1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkLWJvZHlcIj5cbiAgICAgICAgICAgICAge2luc2lnaHRzID8gPEluc2lnaHRzIGluc2lnaHRzPXtpbnNpZ2h0c30gLz4gOiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciB0ZXh0LW11dGVkIHB5LTRcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3Bpbm5lci1ib3JkZXJcIiByb2xlPVwic3RhdHVzXCI+PC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cblxuICAgICAgICB7dGFiID09PSBcImRhdGEtcXVhbGl0eVwiICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQgc2VjdGlvbi1jYXJkXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQtaGVhZGVyXCI+XG4gICAgICAgICAgICAgIERhdGEtUXVhbGl0eSBJc3N1ZXNcbiAgICAgICAgICAgICAge2RxICYmIDxzcGFuIGNsYXNzTmFtZT1cImJhZGdlIGJnLXdhcm5pbmcgdGV4dC1kYXJrIG1zLTJcIj57ZHEudG90YWxJc3N1ZXN9PC9zcGFuPn1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkLWJvZHlcIj5cbiAgICAgICAgICAgICAge2RxID8gPERhdGFRdWFsaXR5IGRxPXtkcX0gLz4gOiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciB0ZXh0LW11dGVkIHB5LTRcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3Bpbm5lci1ib3JkZXJcIiByb2xlPVwic3RhdHVzXCI+PC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cbiAgICAgIDwvZGl2PlxuICAgIDwvPlxuICApO1xufVxuIl0sImZpbGUiOiJDOi9Vc2Vycy91c2VyL0Rvd25sb2Fkcy9kaGFuaXRpLWFwcC11cGdyYWRlZC9kaGFuaXRpLWFwcC9mcm9udGVuZC9zcmMvcGFnZXMvRGFzaGJvYXJkLmpzeCJ9