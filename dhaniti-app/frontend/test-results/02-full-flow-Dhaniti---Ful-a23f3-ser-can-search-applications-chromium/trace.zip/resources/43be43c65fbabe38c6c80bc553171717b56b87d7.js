import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Navbar.jsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport1_react_jsxDevRuntime["Fragment"];const React = __vite__cjsImport3_react;import * as RefreshRuntime from "/@react-refresh";
var _jsxFileName = "C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/components/Navbar.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=325d36c7";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
	if (!window.$RefreshReg$) {
		throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong.");
	}
	prevRefreshReg = window.$RefreshReg$;
	prevRefreshSig = window.$RefreshSig$;
	window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/components/Navbar.jsx");
	window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=325d36c7";
import { NavLink, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=325d36c7";
import { useAuth } from "/src/context/AuthContext.jsx";
const ROLE_BADGE = {
	Admin: "text-bg-danger",
	Underwriter: "text-bg-info",
	"Risk Officer": "text-bg-warning",
	"Credit Analyst": "text-bg-secondary"
};
export default function Navbar() {
	_s();
	const { currentUser, logout } = useAuth();
	const navigate = useNavigate();
	async function handleLogout() {
		await logout();
		navigate("/login", { replace: true });
	}
	const initials = (currentUser?.name || "?").split(/\s+/).slice(0, 2).map((w) => w[0]).join("").toUpperCase();
	return /* @__PURE__ */ _jsxDEV("nav", {
		className: "navbar navbar-expand-lg navbar-dark bg-dhaniti app-navbar sticky-top",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "container-fluid px-3 px-md-4",
			children: [
				/* @__PURE__ */ _jsxDEV(NavLink, {
					className: "navbar-brand d-flex align-items-center gap-2",
					to: "/dashboard",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						style: {
							display: "inline-flex",
							alignItems: "center",
							justifyContent: "center",
							width: 34,
							height: 34,
							borderRadius: 9,
							background: "rgba(255,255,255,0.15)",
							fontWeight: 700,
							fontSize: 17
						},
						children: "D"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 51,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "d-none d-sm-inline",
						children: "Dhaniti"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 66,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 50,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					className: "navbar-toggler",
					type: "button",
					"data-bs-toggle": "collapse",
					"data-bs-target": "#mainNav",
					"aria-controls": "mainNav",
					"aria-expanded": "false",
					"aria-label": "Toggle navigation",
					children: /* @__PURE__ */ _jsxDEV("span", { className: "navbar-toggler-icon" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 78,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 69,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "collapse navbar-collapse",
					id: "mainNav",
					children: [/* @__PURE__ */ _jsxDEV("ul", {
						className: "navbar-nav me-auto mb-2 mb-lg-0",
						children: [
							/* @__PURE__ */ _jsxDEV("li", {
								className: "nav-item",
								children: /* @__PURE__ */ _jsxDEV(NavLink, {
									className: "nav-link",
									to: "/dashboard",
									children: "Dashboard"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 84,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 83,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("li", {
								className: "nav-item",
								children: /* @__PURE__ */ _jsxDEV(NavLink, {
									className: "nav-link",
									to: "/applications",
									children: "Applications"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 87,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 86,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("li", {
								className: "nav-item",
								children: /* @__PURE__ */ _jsxDEV(NavLink, {
									className: "nav-link",
									to: "/profile",
									children: "Profile"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 90,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 89,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 82,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "d-flex align-items-center gap-2 flex-wrap",
						children: currentUser && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: `badge ${ROLE_BADGE[currentUser.role] || "text-bg-secondary"}`,
								children: currentUser.role
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 97,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "d-none d-md-inline text-white-50 small",
								children: currentUser.name
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 100,
								columnNumber: 17
							}, this),
							currentUser.avatarUrl ? /* @__PURE__ */ _jsxDEV("img", {
								src: currentUser.avatarUrl,
								alt: "",
								className: "rounded-circle",
								style: {
									width: 32,
									height: 32,
									objectFit: "cover"
								}
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 104,
								columnNumber: 15
							}, this) : /* @__PURE__ */ _jsxDEV("span", {
								className: "rounded-circle d-inline-flex align-items-center justify-content-center",
								style: {
									width: 32,
									height: 32,
									background: "rgba(255,255,255,0.18)",
									fontWeight: 600
								},
								title: currentUser.name,
								children: initials
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 111,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								className: "btn btn-sm btn-outline-light",
								onClick: handleLogout,
								children: [/* @__PURE__ */ _jsxDEV("i", {
									className: "bi bi-box-arrow-right me-1",
									"aria-hidden": "true"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 120,
									columnNumber: 19
								}, this), "Logout"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 119,
								columnNumber: 17
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 96,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 94,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 81,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 49,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 48,
		columnNumber: 5
	}, this);
}
_s(Navbar, "4DZsToCtU4DQEBtHPiO9TdnOfS0=", false, function() {
	return [useAuth, useNavigate];
});
_c = Navbar;
var _c;
$RefreshReg$(_c, "Navbar");
if (import.meta.hot && !inWebWorker) {
	window.$RefreshReg$ = prevRefreshReg;
	window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
	RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
		RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/components/Navbar.jsx", currentExports);
		import.meta.hot.accept((nextExports) => {
			if (!nextExports) return;
			const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/components/Navbar.jsx", currentExports, nextExports);
			if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
		});
	});
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLE9BQU9BLFdBQVc7QUFDbEIsU0FBU0MsU0FBU0MsbUJBQW1CO0FBQ3JDLFNBQVNDLGVBQWU7QUFFeEIsTUFBTUMsYUFBYTtDQUNqQkMsT0FBTztDQUNQQyxhQUFhO0NBQ2IsZ0JBQWdCO0NBQ2hCLGtCQUFrQjtBQUNwQjtBQUVBLGVBQWUsU0FBU0MsU0FBUztDQUFBQyxHQUFBO0NBQy9CLE1BQU0sRUFBRUMsYUFBYUMsV0FBV1AsUUFBUTtDQUN4QyxNQUFNUSxXQUFXVCxZQUFZO0NBRTdCLGVBQWVVLGVBQWU7RUFDNUIsTUFBTUYsT0FBTztFQUNiQyxTQUFTLFVBQVUsRUFBRUUsU0FBUyxLQUFLLENBQUM7Q0FDdEM7Q0FFQSxNQUFNQyxZQUFZTCxhQUFhTSxRQUFRLElBQUcsQ0FDdkNDLE1BQU0sS0FBSyxDQUFDLENBQ1pDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FDWEMsS0FBS0MsTUFBTUEsRUFBRSxFQUFFLENBQUMsQ0FDaEJDLEtBQUssRUFBRSxDQUFDLENBQ1JDLFlBQVk7Q0FFZixPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQ2Isd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUNFLHdCQUFDLFNBQUQ7S0FBUyxXQUFVO0tBQStDLElBQUc7ZUFBckUsQ0FDRSx3QkFBQyxRQUFEO01BQ0UsT0FBTztPQUNMQyxTQUFTO09BQ1RDLFlBQVk7T0FDWkMsZ0JBQWdCO09BQ2hCQyxPQUFPO09BQ1BDLFFBQVE7T0FDUkMsY0FBYztPQUNkQyxZQUFZO09BQ1pDLFlBQVk7T0FDWkMsVUFBVTtNQUNaO2dCQUFFO0tBR0U7Ozs7ZUFDTix3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBcUI7S0FBYTs7OzthQUMzQzs7Ozs7O0lBRVQsd0JBQUMsVUFBRDtLQUNFLFdBQVU7S0FDVixNQUFLO0tBQ0wsa0JBQWU7S0FDZixrQkFBZTtLQUNmLGlCQUFjO0tBQ2QsaUJBQWM7S0FDZCxjQUFXO2VBRVgsd0JBQUMsUUFBRCxFQUFNLFdBQVUsc0JBQXFCOzs7OztJQUMvQjs7Ozs7SUFFUix3QkFBQyxPQUFEO0tBQUssV0FBVTtLQUEyQixJQUFHO2VBQTdDLENBQ0Usd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQWQ7T0FDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFDWix3QkFBQyxTQUFEO1NBQVMsV0FBVTtTQUFXLElBQUc7bUJBQWE7UUFBa0I7Ozs7O09BQzlEOzs7OztPQUNKLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUNaLHdCQUFDLFNBQUQ7U0FBUyxXQUFVO1NBQVcsSUFBRzttQkFBZ0I7UUFBcUI7Ozs7O09BQ3BFOzs7OztPQUNKLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUNaLHdCQUFDLFNBQUQ7U0FBUyxXQUFVO1NBQVcsSUFBRzttQkFBVztRQUFnQjs7Ozs7T0FDMUQ7Ozs7O01BQ0Y7Ozs7O2VBRUosd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ1pyQixlQUNDO09BQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVcsU0FBU0wsV0FBV0ssWUFBWXNCLFNBQVM7a0JBQ3ZEdEIsWUFBWXNCO09BQ1Q7Ozs7O09BQ04sd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQ2J0QixZQUFZTTtPQUNUOzs7OztPQUNMTixZQUFZdUIsWUFDWCx3QkFBQyxPQUFEO1FBQ0UsS0FBS3ZCLFlBQVl1QjtRQUNqQixLQUFJO1FBQ0osV0FBVTtRQUNWLE9BQU87U0FBRVAsT0FBTztTQUFJQyxRQUFRO1NBQUlPLFdBQVc7UUFBUTtPQUFFOzs7O2tCQUd2RCx3QkFBQyxRQUFEO1FBQ0UsV0FBVTtRQUNWLE9BQU87U0FBRVIsT0FBTztTQUFJQyxRQUFRO1NBQUlFLFlBQVk7U0FBMEJDLFlBQVk7UUFBSTtRQUN0RixPQUFPcEIsWUFBWU07a0JBRWxCRDtPQUNHOzs7OztPQUVSLHdCQUFDLFVBQUQ7UUFBUSxXQUFVO1FBQStCLFNBQVNGO2tCQUExRCxDQUNFLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO1NBQTZCLGVBQVk7UUFBTTs7OztrQkFBQSxRQUV0RDs7Ozs7O01BQ1Y7Ozs7O0tBRUM7Ozs7YUFDRjs7Ozs7O0dBQ0Y7Ozs7OztDQUNGOzs7OztBQUVUO0FBQUNKLEdBbkd1QkQsUUFBTTtDQUFBLFFBQ0lKLFNBQ2ZELFdBQVc7QUFBQTtBQUFBLEtBRk5LO0FBQU0sSUFBQTJCO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwiTmF2TGluayIsInVzZU5hdmlnYXRlIiwidXNlQXV0aCIsIlJPTEVfQkFER0UiLCJBZG1pbiIsIlVuZGVyd3JpdGVyIiwiTmF2YmFyIiwiX3MiLCJjdXJyZW50VXNlciIsImxvZ291dCIsIm5hdmlnYXRlIiwiaGFuZGxlTG9nb3V0IiwicmVwbGFjZSIsImluaXRpYWxzIiwibmFtZSIsInNwbGl0Iiwic2xpY2UiLCJtYXAiLCJ3Iiwiam9pbiIsInRvVXBwZXJDYXNlIiwiZGlzcGxheSIsImFsaWduSXRlbXMiLCJqdXN0aWZ5Q29udGVudCIsIndpZHRoIiwiaGVpZ2h0IiwiYm9yZGVyUmFkaXVzIiwiYmFja2dyb3VuZCIsImZvbnRXZWlnaHQiLCJmb250U2l6ZSIsInJvbGUiLCJhdmF0YXJVcmwiLCJvYmplY3RGaXQiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJOYXZiYXIuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IE5hdkxpbmssIHVzZU5hdmlnYXRlIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tIFwiLi4vY29udGV4dC9BdXRoQ29udGV4dC5qc3hcIjtcblxuY29uc3QgUk9MRV9CQURHRSA9IHtcbiAgQWRtaW46IFwidGV4dC1iZy1kYW5nZXJcIixcbiAgVW5kZXJ3cml0ZXI6IFwidGV4dC1iZy1pbmZvXCIsXG4gIFwiUmlzayBPZmZpY2VyXCI6IFwidGV4dC1iZy13YXJuaW5nXCIsXG4gIFwiQ3JlZGl0IEFuYWx5c3RcIjogXCJ0ZXh0LWJnLXNlY29uZGFyeVwiLFxufTtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTmF2YmFyKCkge1xuICBjb25zdCB7IGN1cnJlbnRVc2VyLCBsb2dvdXQgfSA9IHVzZUF1dGgoKTtcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuXG4gIGFzeW5jIGZ1bmN0aW9uIGhhbmRsZUxvZ291dCgpIHtcbiAgICBhd2FpdCBsb2dvdXQoKTtcbiAgICBuYXZpZ2F0ZShcIi9sb2dpblwiLCB7IHJlcGxhY2U6IHRydWUgfSk7XG4gIH1cblxuICBjb25zdCBpbml0aWFscyA9IChjdXJyZW50VXNlcj8ubmFtZSB8fCBcIj9cIilcbiAgICAuc3BsaXQoL1xccysvKVxuICAgIC5zbGljZSgwLCAyKVxuICAgIC5tYXAoKHcpID0+IHdbMF0pXG4gICAgLmpvaW4oXCJcIilcbiAgICAudG9VcHBlckNhc2UoKTtcblxuICByZXR1cm4gKFxuICAgIDxuYXYgY2xhc3NOYW1lPVwibmF2YmFyIG5hdmJhci1leHBhbmQtbGcgbmF2YmFyLWRhcmsgYmctZGhhbml0aSBhcHAtbmF2YmFyIHN0aWNreS10b3BcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyLWZsdWlkIHB4LTMgcHgtbWQtNFwiPlxuICAgICAgICA8TmF2TGluayBjbGFzc05hbWU9XCJuYXZiYXItYnJhbmQgZC1mbGV4IGFsaWduLWl0ZW1zLWNlbnRlciBnYXAtMlwiIHRvPVwiL2Rhc2hib2FyZFwiPlxuICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICBkaXNwbGF5OiBcImlubGluZS1mbGV4XCIsXG4gICAgICAgICAgICAgIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsXG4gICAgICAgICAgICAgIGp1c3RpZnlDb250ZW50OiBcImNlbnRlclwiLFxuICAgICAgICAgICAgICB3aWR0aDogMzQsXG4gICAgICAgICAgICAgIGhlaWdodDogMzQsXG4gICAgICAgICAgICAgIGJvcmRlclJhZGl1czogOSxcbiAgICAgICAgICAgICAgYmFja2dyb3VuZDogXCJyZ2JhKDI1NSwyNTUsMjU1LDAuMTUpXCIsXG4gICAgICAgICAgICAgIGZvbnRXZWlnaHQ6IDcwMCxcbiAgICAgICAgICAgICAgZm9udFNpemU6IDE3LFxuICAgICAgICAgICAgfX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICBEXG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImQtbm9uZSBkLXNtLWlubGluZVwiPkRoYW5pdGk8L3NwYW4+XG4gICAgICAgIDwvTmF2TGluaz5cblxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgY2xhc3NOYW1lPVwibmF2YmFyLXRvZ2dsZXJcIlxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgIGRhdGEtYnMtdG9nZ2xlPVwiY29sbGFwc2VcIlxuICAgICAgICAgIGRhdGEtYnMtdGFyZ2V0PVwiI21haW5OYXZcIlxuICAgICAgICAgIGFyaWEtY29udHJvbHM9XCJtYWluTmF2XCJcbiAgICAgICAgICBhcmlhLWV4cGFuZGVkPVwiZmFsc2VcIlxuICAgICAgICAgIGFyaWEtbGFiZWw9XCJUb2dnbGUgbmF2aWdhdGlvblwiXG4gICAgICAgID5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJuYXZiYXItdG9nZ2xlci1pY29uXCIgLz5cbiAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2xsYXBzZSBuYXZiYXItY29sbGFwc2VcIiBpZD1cIm1haW5OYXZcIj5cbiAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwibmF2YmFyLW5hdiBtZS1hdXRvIG1iLTIgbWItbGctMFwiPlxuICAgICAgICAgICAgPGxpIGNsYXNzTmFtZT1cIm5hdi1pdGVtXCI+XG4gICAgICAgICAgICAgIDxOYXZMaW5rIGNsYXNzTmFtZT1cIm5hdi1saW5rXCIgdG89XCIvZGFzaGJvYXJkXCI+RGFzaGJvYXJkPC9OYXZMaW5rPlxuICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgIDxsaSBjbGFzc05hbWU9XCJuYXYtaXRlbVwiPlxuICAgICAgICAgICAgICA8TmF2TGluayBjbGFzc05hbWU9XCJuYXYtbGlua1wiIHRvPVwiL2FwcGxpY2F0aW9uc1wiPkFwcGxpY2F0aW9uczwvTmF2TGluaz5cbiAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICA8bGkgY2xhc3NOYW1lPVwibmF2LWl0ZW1cIj5cbiAgICAgICAgICAgICAgPE5hdkxpbmsgY2xhc3NOYW1lPVwibmF2LWxpbmtcIiB0bz1cIi9wcm9maWxlXCI+UHJvZmlsZTwvTmF2TGluaz5cbiAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgPC91bD5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZC1mbGV4IGFsaWduLWl0ZW1zLWNlbnRlciBnYXAtMiBmbGV4LXdyYXBcIj5cbiAgICAgICAgICAgIHtjdXJyZW50VXNlciAmJiAoXG4gICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgYmFkZ2UgJHtST0xFX0JBREdFW2N1cnJlbnRVc2VyLnJvbGVdIHx8IFwidGV4dC1iZy1zZWNvbmRhcnlcIn1gfT5cbiAgICAgICAgICAgICAgICAgIHtjdXJyZW50VXNlci5yb2xlfVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJkLW5vbmUgZC1tZC1pbmxpbmUgdGV4dC13aGl0ZS01MCBzbWFsbFwiPlxuICAgICAgICAgICAgICAgICAge2N1cnJlbnRVc2VyLm5hbWV9XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIHtjdXJyZW50VXNlci5hdmF0YXJVcmwgPyAoXG4gICAgICAgICAgICAgICAgICA8aW1nXG4gICAgICAgICAgICAgICAgICAgIHNyYz17Y3VycmVudFVzZXIuYXZhdGFyVXJsfVxuICAgICAgICAgICAgICAgICAgICBhbHQ9XCJcIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLWNpcmNsZVwiXG4gICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiAzMiwgaGVpZ2h0OiAzMiwgb2JqZWN0Rml0OiBcImNvdmVyXCIgfX1cbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtY2lyY2xlIGQtaW5saW5lLWZsZXggYWxpZ24taXRlbXMtY2VudGVyIGp1c3RpZnktY29udGVudC1jZW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogMzIsIGhlaWdodDogMzIsIGJhY2tncm91bmQ6IFwicmdiYSgyNTUsMjU1LDI1NSwwLjE4KVwiLCBmb250V2VpZ2h0OiA2MDAgfX1cbiAgICAgICAgICAgICAgICAgICAgdGl0bGU9e2N1cnJlbnRVc2VyLm5hbWV9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIHtpbml0aWFsc31cbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuIGJ0bi1zbSBidG4tb3V0bGluZS1saWdodFwiIG9uQ2xpY2s9e2hhbmRsZUxvZ291dH0+XG4gICAgICAgICAgICAgICAgICA8aSBjbGFzc05hbWU9XCJiaSBiaS1ib3gtYXJyb3ctcmlnaHQgbWUtMVwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgICAgICAgICBMb2dvdXRcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvbmF2PlxuICApO1xufVxuIl0sImZpbGUiOiJDOi9Vc2Vycy91c2VyL0Rvd25sb2Fkcy9kaGFuaXRpLWFwcC11cGdyYWRlZC9kaGFuaXRpLWFwcC9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9OYXZiYXIuanN4In0=