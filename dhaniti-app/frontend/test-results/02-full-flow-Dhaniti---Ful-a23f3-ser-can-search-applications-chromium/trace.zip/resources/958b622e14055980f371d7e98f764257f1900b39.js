import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/KpiCards.jsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];const React = __vite__cjsImport3_react;import * as RefreshRuntime from "/@react-refresh";
var _jsxFileName = "C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/components/KpiCards.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=325d36c7";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
	if (!window.$RefreshReg$) {
		throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong.");
	}
	prevRefreshReg = window.$RefreshReg$;
	prevRefreshSig = window.$RefreshSig$;
	window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/components/KpiCards.jsx");
	window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=325d36c7";
import { formatINRCompact } from "/src/api.js";
export default function KpiCards({ kpis }) {
	if (!kpis) return null;
	const total = kpis.totalApplications || 0;
	const cards = [
		{
			label: "Total Applications",
			value: total.toLocaleString("en-IN"),
			sub: "All records in dataset",
			cls: "accent-total"
		},
		{
			label: "Approved",
			value: kpis.approved,
			sub: `${kpis.approvalRate}% approval rate`,
			cls: "accent-approved"
		},
		{
			label: "Under Review",
			value: kpis.underReview,
			sub: "Active in pipeline",
			cls: "accent-review"
		},
		{
			label: "Rejected",
			value: kpis.rejected,
			sub: "Declined by rule",
			cls: "accent-rejected"
		},
		{
			label: "Submitted",
			value: kpis.submitted,
			sub: "Awaiting first review",
			cls: "accent-total"
		},
		{
			label: "Total Loan Requested",
			value: formatINRCompact(kpis.totalLoanAmountRequested),
			sub: "Sum of loan_amount_requested_inr",
			cls: "accent-amount"
		},
		{
			label: "Avg Loan Amount",
			value: formatINRCompact(kpis.averageLoanAmount),
			sub: "Per application",
			cls: "accent-amount"
		},
		{
			label: "Avg Credit Score",
			value: kpis.averageCreditScore !== null ? kpis.averageCreditScore : "—",
			sub: "Excludes missing",
			cls: "accent-total"
		}
	];
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "row g-3",
		children: cards.map((c, i) => /* @__PURE__ */ _jsxDEV("div", {
			className: "col-6 col-md-4 col-lg-3 col-xl-2",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: `card kpi-card ${c.cls}`,
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "card-body p-3",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "kpi-label",
							children: c.label
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 43,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "kpi-value",
							children: c.value
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 44,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "kpi-sub",
							children: c.sub
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 45,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 42,
					columnNumber: 13
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 41,
				columnNumber: 11
			}, this)
		}, i, false, {
			fileName: _jsxFileName,
			lineNumber: 40,
			columnNumber: 7
		}, this))
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 38,
		columnNumber: 5
	}, this);
}
_c = KpiCards;
var _c;
$RefreshReg$(_c, "KpiCards");
if (import.meta.hot && !inWebWorker) {
	window.$RefreshReg$ = prevRefreshReg;
	window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
	RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
		RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/components/KpiCards.jsx", currentExports);
		import.meta.hot.accept((nextExports) => {
			if (!nextExports) return;
			const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/components/KpiCards.jsx", currentExports, nextExports);
			if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
		});
	});
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsT0FBT0EsV0FBVztBQUNsQixTQUFTQyx3QkFBd0I7QUFFakMsZUFBZSxTQUFTQyxTQUFTLEVBQUVDLFFBQVE7Q0FDekMsSUFBSSxDQUFDQSxNQUFNLE9BQU87Q0FDbEIsTUFBTUMsUUFBUUQsS0FBS0UscUJBQXFCO0NBQ3hDLE1BQU1DLFFBQVE7RUFDWjtHQUFFQyxPQUFPO0dBQXNCQyxPQUFPSixNQUFNSyxlQUFlLE9BQU87R0FBR0MsS0FBSztHQUEwQkMsS0FBSztFQUFlO0VBQ3hIO0dBQUVKLE9BQU87R0FBWUMsT0FBT0wsS0FBS1M7R0FBVUYsS0FBSyxHQUFHUCxLQUFLVSxhQUFZO0dBQW1CRixLQUFLO0VBQWtCO0VBQzlHO0dBQUVKLE9BQU87R0FBZ0JDLE9BQU9MLEtBQUtXO0dBQWFKLEtBQUs7R0FBc0JDLEtBQUs7RUFBZ0I7RUFDbEc7R0FBRUosT0FBTztHQUFZQyxPQUFPTCxLQUFLWTtHQUFVTCxLQUFLO0dBQW9CQyxLQUFLO0VBQWtCO0VBQzNGO0dBQUVKLE9BQU87R0FBYUMsT0FBT0wsS0FBS2E7R0FBV04sS0FBSztHQUF5QkMsS0FBSztFQUFlO0VBQy9GO0dBQUVKLE9BQU87R0FBd0JDLE9BQU9QLGlCQUFpQkUsS0FBS2Msd0JBQXdCO0dBQUdQLEtBQUs7R0FBb0NDLEtBQUs7RUFBZ0I7RUFDdko7R0FBRUosT0FBTztHQUFtQkMsT0FBT1AsaUJBQWlCRSxLQUFLZSxpQkFBaUI7R0FBR1IsS0FBSztHQUFtQkMsS0FBSztFQUFnQjtFQUMxSDtHQUFFSixPQUFPO0dBQW9CQyxPQUFPTCxLQUFLZ0IsdUJBQXVCLE9BQU9oQixLQUFLZ0IscUJBQXFCO0dBQVVULEtBQUs7R0FBb0JDLEtBQUs7RUFBZTtDQUFDO0NBRzNKLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFDWkwsTUFBTWMsS0FBS0MsR0FBR0MsTUFDYix3QkFBQyxPQUFEO0dBQUssV0FBVTthQUNiLHdCQUFDLE9BQUQ7SUFBSyxXQUFXLGlCQUFpQkQsRUFBRVY7Y0FDakMsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFhVSxFQUFFZDtNQUFXOzs7OztNQUN6Qyx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBYWMsRUFBRWI7TUFBVzs7Ozs7TUFDekMsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQVdhLEVBQUVYO01BQVM7Ozs7O0tBQ2xDOzs7Ozs7R0FDRjs7Ozs7RUFDRixHQVJrRFk7Ozs7U0FRbEQsQ0FDTjtDQUNFOzs7OztBQUVUO0FBQUNDLEtBN0J1QnJCO0FBQVEsSUFBQXFCO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwiZm9ybWF0SU5SQ29tcGFjdCIsIktwaUNhcmRzIiwia3BpcyIsInRvdGFsIiwidG90YWxBcHBsaWNhdGlvbnMiLCJjYXJkcyIsImxhYmVsIiwidmFsdWUiLCJ0b0xvY2FsZVN0cmluZyIsInN1YiIsImNscyIsImFwcHJvdmVkIiwiYXBwcm92YWxSYXRlIiwidW5kZXJSZXZpZXciLCJyZWplY3RlZCIsInN1Ym1pdHRlZCIsInRvdGFsTG9hbkFtb3VudFJlcXVlc3RlZCIsImF2ZXJhZ2VMb2FuQW1vdW50IiwiYXZlcmFnZUNyZWRpdFNjb3JlIiwibWFwIiwiYyIsImkiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJLcGlDYXJkcy5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgZm9ybWF0SU5SQ29tcGFjdCB9IGZyb20gXCIuLi9hcGkuanNcIjtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gS3BpQ2FyZHMoeyBrcGlzIH0pIHtcbiAgaWYgKCFrcGlzKSByZXR1cm4gbnVsbDtcbiAgY29uc3QgdG90YWwgPSBrcGlzLnRvdGFsQXBwbGljYXRpb25zIHx8IDA7XG4gIGNvbnN0IGNhcmRzID0gW1xuICAgIHsgbGFiZWw6IFwiVG90YWwgQXBwbGljYXRpb25zXCIsIHZhbHVlOiB0b3RhbC50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpLCBzdWI6IFwiQWxsIHJlY29yZHMgaW4gZGF0YXNldFwiLCBjbHM6IFwiYWNjZW50LXRvdGFsXCIgfSxcbiAgICB7IGxhYmVsOiBcIkFwcHJvdmVkXCIsIHZhbHVlOiBrcGlzLmFwcHJvdmVkLCBzdWI6IGAke2twaXMuYXBwcm92YWxSYXRlfSUgYXBwcm92YWwgcmF0ZWAsIGNsczogXCJhY2NlbnQtYXBwcm92ZWRcIiB9LFxuICAgIHsgbGFiZWw6IFwiVW5kZXIgUmV2aWV3XCIsIHZhbHVlOiBrcGlzLnVuZGVyUmV2aWV3LCBzdWI6IFwiQWN0aXZlIGluIHBpcGVsaW5lXCIsIGNsczogXCJhY2NlbnQtcmV2aWV3XCIgfSxcbiAgICB7IGxhYmVsOiBcIlJlamVjdGVkXCIsIHZhbHVlOiBrcGlzLnJlamVjdGVkLCBzdWI6IFwiRGVjbGluZWQgYnkgcnVsZVwiLCBjbHM6IFwiYWNjZW50LXJlamVjdGVkXCIgfSxcbiAgICB7IGxhYmVsOiBcIlN1Ym1pdHRlZFwiLCB2YWx1ZToga3Bpcy5zdWJtaXR0ZWQsIHN1YjogXCJBd2FpdGluZyBmaXJzdCByZXZpZXdcIiwgY2xzOiBcImFjY2VudC10b3RhbFwiIH0sXG4gICAgeyBsYWJlbDogXCJUb3RhbCBMb2FuIFJlcXVlc3RlZFwiLCB2YWx1ZTogZm9ybWF0SU5SQ29tcGFjdChrcGlzLnRvdGFsTG9hbkFtb3VudFJlcXVlc3RlZCksIHN1YjogXCJTdW0gb2YgbG9hbl9hbW91bnRfcmVxdWVzdGVkX2luclwiLCBjbHM6IFwiYWNjZW50LWFtb3VudFwiIH0sXG4gICAgeyBsYWJlbDogXCJBdmcgTG9hbiBBbW91bnRcIiwgdmFsdWU6IGZvcm1hdElOUkNvbXBhY3Qoa3Bpcy5hdmVyYWdlTG9hbkFtb3VudCksIHN1YjogXCJQZXIgYXBwbGljYXRpb25cIiwgY2xzOiBcImFjY2VudC1hbW91bnRcIiB9LFxuICAgIHsgbGFiZWw6IFwiQXZnIENyZWRpdCBTY29yZVwiLCB2YWx1ZToga3Bpcy5hdmVyYWdlQ3JlZGl0U2NvcmUgIT09IG51bGwgPyBrcGlzLmF2ZXJhZ2VDcmVkaXRTY29yZSA6IFwiXFx1MjAxNFwiLCBzdWI6IFwiRXhjbHVkZXMgbWlzc2luZ1wiLCBjbHM6IFwiYWNjZW50LXRvdGFsXCIgfSxcbiAgXTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGctM1wiPlxuICAgICAge2NhcmRzLm1hcCgoYywgaSkgPT4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC02IGNvbC1tZC00IGNvbC1sZy0zIGNvbC14bC0yXCIga2V5PXtpfT5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YGNhcmQga3BpLWNhcmQgJHtjLmNsc31gfT5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZC1ib2R5IHAtM1wiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImtwaS1sYWJlbFwiPntjLmxhYmVsfTwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImtwaS12YWx1ZVwiPntjLnZhbHVlfTwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImtwaS1zdWJcIj57Yy5zdWJ9PC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiQzovVXNlcnMvdXNlci9Eb3dubG9hZHMvZGhhbml0aS1hcHAtdXBncmFkZWQvZGhhbml0aS1hcHAvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvS3BpQ2FyZHMuanN4In0=