import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Applications.jsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];const React = __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];import * as RefreshRuntime from "/@react-refresh";
var _jsxFileName = "C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/pages/Applications.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=325d36c7";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
	if (!window.$RefreshReg$) {
		throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong.");
	}
	prevRefreshReg = window.$RefreshReg$;
	prevRefreshSig = window.$RefreshSig$;
	window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/pages/Applications.jsx");
	window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=325d36c7";
import { itemsApi } from "/src/api/items.js";
import { useAuth } from "/src/context/AuthContext.jsx";
import ApplicationsTable from "/src/components/ApplicationsTable.jsx";
/** Dedicated CRUD page for loan applications. */
export default function Applications() {
	_s();
	const { canWrite } = useAuth();
	const [filters, setFilters] = useState(null);
	const [error, setError] = useState("");
	useEffect(() => {
		itemsApi.filters().then(setFilters).catch((e) => setError(e.message));
	}, []);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "container-fluid px-3 px-md-4 py-3",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3",
				children: /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h4", {
					className: "mb-0",
					children: ["Loan Applications", !canWrite && /* @__PURE__ */ _jsxDEV("span", {
						className: "badge text-bg-secondary ms-2",
						children: "Read-only role"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 44,
						columnNumber: 27
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 42,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-muted small mb-0",
					children: "Create, view, update and delete education-loan applications."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 46,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 41,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 40,
				columnNumber: 7
			}, this),
			error && /* @__PURE__ */ _jsxDEV("div", {
				className: "alert alert-danger py-2",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 52,
				columnNumber: 17
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "card section-card",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "card-body",
					children: filters ? /* @__PURE__ */ _jsxDEV(ApplicationsTable, { filters }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 57,
						columnNumber: 11
					}, this) : !error && /* @__PURE__ */ _jsxDEV("div", {
						className: "text-center text-muted py-5",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "spinner-border",
							role: "status"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 61,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "mt-2 mb-0",
							children: "Loading filters…"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 62,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 60,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 55,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 54,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 39,
		columnNumber: 5
	}, this);
}
_s(Applications, "u9sVNWh/SCmrCUVKJuxGD39FYoI=", false, function() {
	return [useAuth];
});
_c = Applications;
var _c;
$RefreshReg$(_c, "Applications");
if (import.meta.hot && !inWebWorker) {
	window.$RefreshReg$ = prevRefreshReg;
	window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
	RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
		RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/pages/Applications.jsx", currentExports);
		import.meta.hot.accept((nextExports) => {
			if (!nextExports) return;
			const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/pages/Applications.jsx", currentExports, nextExports);
			if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
		});
	});
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLE9BQU9BLFNBQVNDLFdBQVdDLGdCQUFnQjtBQUMzQyxTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsZUFBZTtBQUN4QixPQUFPQyx1QkFBdUI7O0FBRzlCLGVBQWUsU0FBU0MsZUFBZTtDQUFBQyxHQUFBO0NBQ3JDLE1BQU0sRUFBRUMsYUFBYUosUUFBUTtDQUM3QixNQUFNLENBQUNLLFNBQVNDLGNBQWNSLFNBQVMsSUFBSTtDQUMzQyxNQUFNLENBQUNTLE9BQU9DLFlBQVlWLFNBQVMsRUFBRTtDQUVyQ0QsZ0JBQWdCO0VBQ2RFLFNBQ0dNLFFBQVEsQ0FBQyxDQUNUSSxLQUFLSCxVQUFVLENBQUMsQ0FDaEJJLE9BQU9DLE1BQU1ILFNBQVNHLEVBQUVDLE9BQU8sQ0FBQztDQUNyQyxHQUFHLEVBQUU7Q0FFTCxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FDRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNiLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUFkLENBQW9CLHFCQUVqQixDQUFDUixZQUFZLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUErQjtLQUFvQjs7OzthQUMvRTs7Ozs7Y0FDSix3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUF1QjtJQUVqQzs7OztZQUNBOzs7OztHQUNGOzs7OztHQUVKRyxTQUFTLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQTJCQTtHQUFXOzs7OztHQUUvRCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNiLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ1pGLFVBQ0Msd0JBQUMsbUJBQUQsRUFBNEJBLFFBQVE7Ozs7Z0JBRXBDLENBQUNFLFNBQ0Msd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtPQUFpQixNQUFLO01BQWM7Ozs7Z0JBQ25ELHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFZO01BQW1COzs7O2NBQ3pDOzs7Ozs7SUFHTjs7Ozs7R0FDRjs7Ozs7RUFDRjs7Ozs7O0FBRVQ7QUFBQ0osR0E1Q3VCRCxjQUFZO0NBQUEsUUFDYkYsT0FBTztBQUFBO0FBQUEsS0FETkU7QUFBWSxJQUFBVztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiaXRlbXNBcGkiLCJ1c2VBdXRoIiwiQXBwbGljYXRpb25zVGFibGUiLCJBcHBsaWNhdGlvbnMiLCJfcyIsImNhbldyaXRlIiwiZmlsdGVycyIsInNldEZpbHRlcnMiLCJlcnJvciIsInNldEVycm9yIiwidGhlbiIsImNhdGNoIiwiZSIsIm1lc3NhZ2UiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBcHBsaWNhdGlvbnMuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBpdGVtc0FwaSB9IGZyb20gXCIuLi9hcGkvaXRlbXMuanNcIjtcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tIFwiLi4vY29udGV4dC9BdXRoQ29udGV4dC5qc3hcIjtcbmltcG9ydCBBcHBsaWNhdGlvbnNUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9BcHBsaWNhdGlvbnNUYWJsZS5qc3hcIjtcblxuLyoqIERlZGljYXRlZCBDUlVEIHBhZ2UgZm9yIGxvYW4gYXBwbGljYXRpb25zLiAqL1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQXBwbGljYXRpb25zKCkge1xuICBjb25zdCB7IGNhbldyaXRlIH0gPSB1c2VBdXRoKCk7XG4gIGNvbnN0IFtmaWx0ZXJzLCBzZXRGaWx0ZXJzXSA9IHVzZVN0YXRlKG51bGwpO1xuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKFwiXCIpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaXRlbXNBcGlcbiAgICAgIC5maWx0ZXJzKClcbiAgICAgIC50aGVuKHNldEZpbHRlcnMpXG4gICAgICAuY2F0Y2goKGUpID0+IHNldEVycm9yKGUubWVzc2FnZSkpO1xuICB9LCBbXSk7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lci1mbHVpZCBweC0zIHB4LW1kLTQgcHktM1wiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJkLWZsZXggZmxleC13cmFwIGp1c3RpZnktY29udGVudC1iZXR3ZWVuIGFsaWduLWl0ZW1zLWNlbnRlciBnYXAtMiBtYi0zXCI+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPGg0IGNsYXNzTmFtZT1cIm1iLTBcIj5cbiAgICAgICAgICAgIExvYW4gQXBwbGljYXRpb25zXG4gICAgICAgICAgICB7IWNhbldyaXRlICYmIDxzcGFuIGNsYXNzTmFtZT1cImJhZGdlIHRleHQtYmctc2Vjb25kYXJ5IG1zLTJcIj5SZWFkLW9ubHkgcm9sZTwvc3Bhbj59XG4gICAgICAgICAgPC9oND5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LW11dGVkIHNtYWxsIG1iLTBcIj5cbiAgICAgICAgICAgIENyZWF0ZSwgdmlldywgdXBkYXRlIGFuZCBkZWxldGUgZWR1Y2F0aW9uLWxvYW4gYXBwbGljYXRpb25zLlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAge2Vycm9yICYmIDxkaXYgY2xhc3NOYW1lPVwiYWxlcnQgYWxlcnQtZGFuZ2VyIHB5LTJcIj57ZXJyb3J9PC9kaXY+fVxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQgc2VjdGlvbi1jYXJkXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZC1ib2R5XCI+XG4gICAgICAgICAge2ZpbHRlcnMgPyAoXG4gICAgICAgICAgICA8QXBwbGljYXRpb25zVGFibGUgZmlsdGVycz17ZmlsdGVyc30gLz5cbiAgICAgICAgICApIDogKFxuICAgICAgICAgICAgIWVycm9yICYmIChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciB0ZXh0LW11dGVkIHB5LTVcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwaW5uZXItYm9yZGVyXCIgcm9sZT1cInN0YXR1c1wiPjwvZGl2PlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgbWItMFwiPkxvYWRpbmcgZmlsdGVyc+KApjwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApXG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiQzovVXNlcnMvdXNlci9Eb3dubG9hZHMvZGhhbml0aS1hcHAtdXBncmFkZWQvZGhhbml0aS1hcHAvZnJvbnRlbmQvc3JjL3BhZ2VzL0FwcGxpY2F0aW9ucy5qc3gifQ==