import { t as __commonJSMin } from "/node_modules/.vite/deps/rolldown-runtime-BPOCksWG.js?v=325d36c7";
import { t as require_react_dom } from "/node_modules/.vite/deps/react-dom-B8FZrn-n.js?v=325d36c7";
//#region node_modules/react-dom/client.js
var require_client = /* @__PURE__ */ __commonJSMin(((exports) => {
	var m = require_react_dom();
	var i = m.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED;
	exports.createRoot = function(c, o) {
		i.usingClientEntryPoint = true;
		try {
			return m.createRoot(c, o);
		} finally {
			i.usingClientEntryPoint = false;
		}
	};
	exports.hydrateRoot = function(c, h, o) {
		i.usingClientEntryPoint = true;
		try {
			return m.hydrateRoot(c, h, o);
		} finally {
			i.usingClientEntryPoint = false;
		}
	};
}));
//#endregion
export default require_client();

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVhY3QtZG9tX2NsaWVudC5qcyIsIm5hbWVzIjpbXSwic291cmNlcyI6WyIuLi8uLi9yZWFjdC1kb20vY2xpZW50LmpzIl0sInNvdXJjZXNDb250ZW50IjpbIid1c2Ugc3RyaWN0JztcblxudmFyIG0gPSByZXF1aXJlKCdyZWFjdC1kb20nKTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gJ3Byb2R1Y3Rpb24nKSB7XG4gIGV4cG9ydHMuY3JlYXRlUm9vdCA9IG0uY3JlYXRlUm9vdDtcbiAgZXhwb3J0cy5oeWRyYXRlUm9vdCA9IG0uaHlkcmF0ZVJvb3Q7XG59IGVsc2Uge1xuICB2YXIgaSA9IG0uX19TRUNSRVRfSU5URVJOQUxTX0RPX05PVF9VU0VfT1JfWU9VX1dJTExfQkVfRklSRUQ7XG4gIGV4cG9ydHMuY3JlYXRlUm9vdCA9IGZ1bmN0aW9uKGMsIG8pIHtcbiAgICBpLnVzaW5nQ2xpZW50RW50cnlQb2ludCA9IHRydWU7XG4gICAgdHJ5IHtcbiAgICAgIHJldHVybiBtLmNyZWF0ZVJvb3QoYywgbyk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIGkudXNpbmdDbGllbnRFbnRyeVBvaW50ID0gZmFsc2U7XG4gICAgfVxuICB9O1xuICBleHBvcnRzLmh5ZHJhdGVSb290ID0gZnVuY3Rpb24oYywgaCwgbykge1xuICAgIGkudXNpbmdDbGllbnRFbnRyeVBvaW50ID0gdHJ1ZTtcbiAgICB0cnkge1xuICAgICAgcmV0dXJuIG0uaHlkcmF0ZVJvb3QoYywgaCwgbyk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIGkudXNpbmdDbGllbnRFbnRyeVBvaW50ID0gZmFsc2U7XG4gICAgfVxuICB9O1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7O0NBRUEsSUFBSSxJQUFBLGtCQUFBO0NBS0YsSUFBSSxJQUFJLEVBQUU7Q0FDVixRQUFRLGFBQWEsU0FBUyxHQUFHLEdBQUc7RUFDbEMsRUFBRSx3QkFBd0I7RUFDMUIsSUFBSTtHQUNGLE9BQU8sRUFBRSxXQUFXLEdBQUcsQ0FBQztFQUMxQixVQUFVO0dBQ1IsRUFBRSx3QkFBd0I7RUFDNUI7Q0FDRjtDQUNBLFFBQVEsY0FBYyxTQUFTLEdBQUcsR0FBRyxHQUFHO0VBQ3RDLEVBQUUsd0JBQXdCO0VBQzFCLElBQUk7R0FDRixPQUFPLEVBQUUsWUFBWSxHQUFHLEdBQUcsQ0FBQztFQUM5QixVQUFVO0dBQ1IsRUFBRSx3QkFBd0I7RUFDNUI7Q0FDRiIsInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswXX0=