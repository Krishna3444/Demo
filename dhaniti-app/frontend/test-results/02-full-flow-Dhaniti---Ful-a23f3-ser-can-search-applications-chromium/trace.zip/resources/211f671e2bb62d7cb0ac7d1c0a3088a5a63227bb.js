import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ItemFormModal.jsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport1_react_jsxDevRuntime["Fragment"];const React = __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];import * as RefreshRuntime from "/@react-refresh";
var _jsxFileName = "C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/components/ItemFormModal.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=325d36c7";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
	if (!window.$RefreshReg$) {
		throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong.");
	}
	prevRefreshReg = window.$RefreshReg$;
	prevRefreshSig = window.$RefreshSig$;
	window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/components/ItemFormModal.jsx");
	window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=325d36c7";
import { itemsApi, formatINR } from "/src/api/items.js";
import { ApiError } from "/src/api/client.js";
import { useToast } from "/src/context/ToastContext.jsx";
const STATES = [
	"Andhra Pradesh",
	"Delhi",
	"Karnataka",
	"Kerala",
	"Maharashtra",
	"Rajasthan",
	"Tamil Nadu",
	"Telangana",
	"Gujarat",
	"Uttar Pradesh",
	"West Bengal",
	"Bihar",
	"Madhya Pradesh",
	"Punjab",
	"Haryana",
	"Odisha",
	"Assam",
	"Jharkhand",
	"Chhattisgarh",
	"Uttarakhand",
	"Himachal Pradesh",
	"Goa",
	"Jammu and Kashmir"
];
const EMPLOYMENT = [
	"Salaried",
	"Self-Employed",
	"Business",
	"Pensioner"
];
const CHANNELS = [
	"Website",
	"Online",
	"Branch",
	"Agent",
	"Campus Drive",
	"Counsellor",
	"Institution Referral",
	"Partner Referral"
];
const STATUSES = [
	"Submitted",
	"Under Review",
	"Approved",
	"Rejected"
];
const EMPTY_FORM = {
	studentName: "",
	age: "",
	studentState: "Karnataka",
	institutionId: "",
	courseId: "",
	loanAmountRequestedInr: "",
	parentMonthlyIncomeInr: "",
	existingMonthlyObligationsInr: "",
	creditScore: "",
	employmentType: "Salaried",
	applicationChannel: "Website",
	applicationStatus: "Submitted",
	applicationDate: ""
};
/**
* Create / Edit modal for loan applications.
*   mode === "create"  → POST /api/applications
*   mode === "edit"    → PUT  /api/applications/:id (pre-filled)
*/
export default function ItemFormModal({ show, mode, item, filters, onClose, onSaved }) {
	_s();
	const toast = useToast();
	const [form, setForm] = useState(EMPTY_FORM);
	const [errors, setErrors] = useState({});
	const [apiError, setApiError] = useState("");
	const [saving, setSaving] = useState(false);
	const isEdit = mode === "edit";
	useEffect(() => {
		if (!show) return;
		setApiError("");
		setErrors({});
		if (isEdit && item) {
			setForm({
				studentName: item.studentName || "",
				age: item.age ?? "",
				studentState: item.studentState || "",
				institutionId: item.institutionId || "",
				courseId: item.courseId || "",
				loanAmountRequestedInr: item.loanAmountRequestedInr ?? "",
				parentMonthlyIncomeInr: item.parentMonthlyIncomeInr ?? "",
				existingMonthlyObligationsInr: item.existingMonthlyObligationsInr ?? "",
				creditScore: item.creditScore ?? "",
				employmentType: item.employmentType || "Salaried",
				applicationChannel: item.applicationChannel || "Website",
				applicationStatus: item.applicationStatus || "Submitted",
				applicationDate: item.applicationDate || ""
			});
		} else {
			setForm({
				...EMPTY_FORM,
				institutionId: filters?.institutions?.[0]?.id || "",
				courseId: filters?.courses?.[0]?.id || ""
			});
		}
	}, [
		show,
		isEdit,
		item,
		filters
	]);
	const selectedCourse = useMemo(() => (filters?.courses || []).find((c) => c.id === form.courseId), [filters, form.courseId]);
	const set = (key) => (e) => {
		const value = e.target.value;
		setForm((f) => ({
			...f,
			[key]: value
		}));
		setErrors((prev) => ({
			...prev,
			[key]: undefined
		}));
	};
	function validate() {
		const next = {};
		if (!form.studentName.trim() || form.studentName.trim().length < 2) next.studentName = "Student name is required (min 2 characters).";
		const age = Number(form.age);
		if (!form.age || Number.isNaN(age) || age < 16 || age > 100) next.age = "Age must be between 16 and 100.";
		if (!form.studentState) next.studentState = "State is required.";
		if (!form.institutionId) next.institutionId = "Select an institution.";
		if (!form.courseId) next.courseId = "Select a course.";
		const loan = Number(form.loanAmountRequestedInr);
		if (!form.loanAmountRequestedInr || Number.isNaN(loan) || loan < 1e4) next.loanAmountRequestedInr = "Loan amount must be at least ₹10,000.";
		const income = Number(form.parentMonthlyIncomeInr);
		if (form.parentMonthlyIncomeInr === "" || Number.isNaN(income) || income < 0) next.parentMonthlyIncomeInr = "Parent monthly income is required.";
		const obligations = Number(form.existingMonthlyObligationsInr);
		if (form.existingMonthlyObligationsInr === "" || Number.isNaN(obligations) || obligations < 0) next.existingMonthlyObligationsInr = "Existing obligations are required.";
		if (form.creditScore !== "" && form.creditScore !== null && form.creditScore !== undefined) {
			const score = Number(form.creditScore);
			if (Number.isNaN(score) || score < 300 || score > 900) next.creditScore = "Credit score must be between 300 and 900 (or leave blank).";
		}
		if (!form.employmentType) next.employmentType = "Employment type is required.";
		if (!form.applicationChannel) next.applicationChannel = "Application channel is required.";
		if (isEdit) {
			if (!form.applicationStatus || !STATUSES.includes(form.applicationStatus)) next.applicationStatus = "Select a valid status.";
			if (!form.applicationDate || !/^\d{4}-\d{2}-\d{2}$/.test(form.applicationDate)) next.applicationDate = "Application date must be YYYY-MM-DD.";
		}
		setErrors(next);
		return Object.keys(next).length === 0;
	}
	function buildPayload() {
		const payload = {
			studentName: form.studentName.trim(),
			age: Number(form.age),
			studentState: form.studentState,
			institutionId: form.institutionId,
			courseId: form.courseId,
			loanAmountRequestedInr: Number(form.loanAmountRequestedInr),
			parentMonthlyIncomeInr: Number(form.parentMonthlyIncomeInr),
			existingMonthlyObligationsInr: Number(form.existingMonthlyObligationsInr),
			creditScore: form.creditScore === "" || form.creditScore === null ? null : Number(form.creditScore),
			employmentType: form.employmentType,
			applicationChannel: form.applicationChannel
		};
		if (isEdit) {
			payload.applicationStatus = form.applicationStatus;
			payload.applicationDate = form.applicationDate;
		}
		return payload;
	}
	async function handleSubmit(e) {
		e.preventDefault();
		setApiError("");
		if (!validate()) return;
		setSaving(true);
		try {
			if (isEdit) {
				await itemsApi.updateItem(item.id, buildPayload());
				toast.success(`Record ${item.id} updated successfully.`);
			} else {
				const created = await itemsApi.createItem(buildPayload());
				toast.success(`Record ${created.id} created successfully.`);
			}
			onSaved();
		} catch (err) {
			if (err instanceof ApiError && err.details?.length) {
				setApiError(`${err.message} ${err.details.join(" ")}`);
			} else {
				setApiError(err.message || "Unable to save record.");
			}
		} finally {
			setSaving(false);
		}
	}
	if (!show) return null;
	const invalid = (field) => errors[field] ? "is-invalid" : "";
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "modal fade show d-block",
		tabIndex: -1,
		role: "dialog",
		style: { background: "rgba(15,23,42,0.45)" },
		"aria-modal": "true",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable",
			role: "document",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "modal-content",
				children: /* @__PURE__ */ _jsxDEV("form", {
					onSubmit: handleSubmit,
					noValidate: true,
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "modal-header",
							children: [/* @__PURE__ */ _jsxDEV("h5", {
								className: "modal-title",
								children: [/* @__PURE__ */ _jsxDEV("i", {
									className: `bi ${isEdit ? "bi-pencil-square" : "bi-plus-circle"} text-dhaniti me-2`,
									"aria-hidden": "true"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 181,
									columnNumber: 17
								}, this), isEdit ? `Edit Application ${item?.id}` : "New Loan Application"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 180,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								className: "btn-close",
								"aria-label": "Close",
								onClick: onClose,
								disabled: saving
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 184,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 179,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "modal-body",
							children: [apiError && /* @__PURE__ */ _jsxDEV("div", {
								className: "alert alert-danger py-2",
								role: "alert",
								children: apiError
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 188,
								columnNumber: 28
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "row g-3",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "col-12 col-md-6",
										children: [
											/* @__PURE__ */ _jsxDEV("label", {
												className: "form-label",
												htmlFor: "f-name",
												children: "Student name *"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 192,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("input", {
												id: "f-name",
												className: `form-control ${invalid("studentName")}`,
												value: form.studentName,
												onChange: set("studentName"),
												disabled: saving
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 193,
												columnNumber: 19
											}, this),
											errors.studentName && /* @__PURE__ */ _jsxDEV("div", {
												className: "invalid-feedback",
												children: errors.studentName
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 194,
												columnNumber: 42
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 191,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "col-6 col-md-3",
										children: [
											/* @__PURE__ */ _jsxDEV("label", {
												className: "form-label",
												htmlFor: "f-age",
												children: "Age *"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 198,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("input", {
												id: "f-age",
												type: "number",
												min: 16,
												max: 100,
												className: `form-control ${invalid("age")}`,
												value: form.age,
												onChange: set("age"),
												disabled: saving
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 199,
												columnNumber: 19
											}, this),
											errors.age && /* @__PURE__ */ _jsxDEV("div", {
												className: "invalid-feedback",
												children: errors.age
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 200,
												columnNumber: 34
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 197,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "col-6 col-md-3",
										children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "form-label",
											htmlFor: "f-state",
											children: "State *"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 204,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("select", {
											id: "f-state",
											className: `form-select ${invalid("studentState")}`,
											value: form.studentState,
											onChange: set("studentState"),
											disabled: saving,
											children: STATES.map((s) => /* @__PURE__ */ _jsxDEV("option", {
												value: s,
												children: s
											}, s, false, {
												fileName: _jsxFileName,
												lineNumber: 206,
												columnNumber: 40
											}, this))
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 205,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 203,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "col-12 col-md-6",
										children: [
											/* @__PURE__ */ _jsxDEV("label", {
												className: "form-label",
												htmlFor: "f-inst",
												children: "Institution *"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 211,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("select", {
												id: "f-inst",
												className: `form-select ${invalid("institutionId")}`,
												value: form.institutionId,
												onChange: set("institutionId"),
												disabled: saving,
												children: [/* @__PURE__ */ _jsxDEV("option", {
													value: "",
													children: "Select institution…"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 213,
													columnNumber: 21
												}, this), (filters?.institutions || []).map((i) => /* @__PURE__ */ _jsxDEV("option", {
													value: i.id,
													children: [
														i.name,
														" (",
														i.id,
														")"
													]
												}, i.id, true, {
													fileName: _jsxFileName,
													lineNumber: 214,
													columnNumber: 63
												}, this))]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 212,
												columnNumber: 19
											}, this),
											errors.institutionId && /* @__PURE__ */ _jsxDEV("div", {
												className: "invalid-feedback",
												children: errors.institutionId
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 216,
												columnNumber: 44
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 210,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "col-12 col-md-6",
										children: [
											/* @__PURE__ */ _jsxDEV("label", {
												className: "form-label",
												htmlFor: "f-course",
												children: "Course *"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 220,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("select", {
												id: "f-course",
												className: `form-select ${invalid("courseId")}`,
												value: form.courseId,
												onChange: set("courseId"),
												disabled: saving,
												children: [/* @__PURE__ */ _jsxDEV("option", {
													value: "",
													children: "Select course…"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 222,
													columnNumber: 21
												}, this), (filters?.courses || []).map((c) => /* @__PURE__ */ _jsxDEV("option", {
													value: c.id,
													children: [
														c.name,
														" — ",
														c.domain,
														c.typicalFeeInr ? ` (fee ${formatINR(c.typicalFeeInr)})` : ""
													]
												}, c.id, true, {
													fileName: _jsxFileName,
													lineNumber: 223,
													columnNumber: 58
												}, this))]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 221,
												columnNumber: 19
											}, this),
											errors.courseId && /* @__PURE__ */ _jsxDEV("div", {
												className: "invalid-feedback",
												children: errors.courseId
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 225,
												columnNumber: 39
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 219,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "col-6 col-md-4",
										children: [
											/* @__PURE__ */ _jsxDEV("label", {
												className: "form-label",
												htmlFor: "f-loan",
												children: "Loan requested (₹) *"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 229,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("input", {
												id: "f-loan",
												type: "number",
												min: 1e4,
												step: 1e4,
												className: `form-control ${invalid("loanAmountRequestedInr")}`,
												value: form.loanAmountRequestedInr,
												onChange: set("loanAmountRequestedInr"),
												disabled: saving
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 230,
												columnNumber: 19
											}, this),
											errors.loanAmountRequestedInr && /* @__PURE__ */ _jsxDEV("div", {
												className: "invalid-feedback",
												children: errors.loanAmountRequestedInr
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 231,
												columnNumber: 53
											}, this),
											selectedCourse?.typicalFeeInr && Number(form.loanAmountRequestedInr) > selectedCourse.typicalFeeInr && /* @__PURE__ */ _jsxDEV("div", {
												className: "form-text text-warning",
												children: [
													/* @__PURE__ */ _jsxDEV("i", {
														className: "bi bi-exclamation-triangle me-1",
														"aria-hidden": "true"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 233,
														columnNumber: 59
													}, this),
													"Exceeds typical fee (",
													formatINR(selectedCourse.typicalFeeInr),
													") — will be flagged."
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 233,
												columnNumber: 19
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 228,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "col-6 col-md-4",
										children: [
											/* @__PURE__ */ _jsxDEV("label", {
												className: "form-label",
												htmlFor: "f-income",
												children: "Parent income (₹/mo) *"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 238,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("input", {
												id: "f-income",
												type: "number",
												min: 0,
												step: 1e3,
												className: `form-control ${invalid("parentMonthlyIncomeInr")}`,
												value: form.parentMonthlyIncomeInr,
												onChange: set("parentMonthlyIncomeInr"),
												disabled: saving
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 239,
												columnNumber: 19
											}, this),
											errors.parentMonthlyIncomeInr && /* @__PURE__ */ _jsxDEV("div", {
												className: "invalid-feedback",
												children: errors.parentMonthlyIncomeInr
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 240,
												columnNumber: 53
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 237,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "col-6 col-md-4",
										children: [
											/* @__PURE__ */ _jsxDEV("label", {
												className: "form-label",
												htmlFor: "f-obl",
												children: "Existing obligations (₹/mo) *"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 244,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("input", {
												id: "f-obl",
												type: "number",
												min: 0,
												step: 500,
												className: `form-control ${invalid("existingMonthlyObligationsInr")}`,
												value: form.existingMonthlyObligationsInr,
												onChange: set("existingMonthlyObligationsInr"),
												disabled: saving
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 245,
												columnNumber: 19
											}, this),
											errors.existingMonthlyObligationsInr && /* @__PURE__ */ _jsxDEV("div", {
												className: "invalid-feedback",
												children: errors.existingMonthlyObligationsInr
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 246,
												columnNumber: 60
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 243,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "col-6 col-md-4",
										children: [
											/* @__PURE__ */ _jsxDEV("label", {
												className: "form-label",
												htmlFor: "f-score",
												children: "Credit score"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 250,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("input", {
												id: "f-score",
												type: "number",
												min: 300,
												max: 900,
												placeholder: "300–900 (optional)",
												className: `form-control ${invalid("creditScore")}`,
												value: form.creditScore ?? "",
												onChange: set("creditScore"),
												disabled: saving
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 251,
												columnNumber: 19
											}, this),
											errors.creditScore && /* @__PURE__ */ _jsxDEV("div", {
												className: "invalid-feedback",
												children: errors.creditScore
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 252,
												columnNumber: 42
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 249,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "col-6 col-md-4",
										children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "form-label",
											htmlFor: "f-emp",
											children: "Employment type *"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 256,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("select", {
											id: "f-emp",
											className: `form-select ${invalid("employmentType")}`,
											value: form.employmentType,
											onChange: set("employmentType"),
											disabled: saving,
											children: EMPLOYMENT.map((s) => /* @__PURE__ */ _jsxDEV("option", {
												value: s,
												children: s
											}, s, false, {
												fileName: _jsxFileName,
												lineNumber: 258,
												columnNumber: 44
											}, this))
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 257,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 255,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "col-6 col-md-4",
										children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "form-label",
											htmlFor: "f-chan",
											children: "Channel *"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 263,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("select", {
											id: "f-chan",
											className: `form-select ${invalid("applicationChannel")}`,
											value: form.applicationChannel,
											onChange: set("applicationChannel"),
											disabled: saving,
											children: CHANNELS.map((s) => /* @__PURE__ */ _jsxDEV("option", {
												value: s,
												children: s
											}, s, false, {
												fileName: _jsxFileName,
												lineNumber: 265,
												columnNumber: 42
											}, this))
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 264,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 262,
										columnNumber: 17
									}, this),
									isEdit && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "col-6 col-md-6",
										children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "form-label",
											htmlFor: "f-status",
											children: "Status *"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 272,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("select", {
											id: "f-status",
											className: `form-select ${invalid("applicationStatus")}`,
											value: form.applicationStatus,
											onChange: set("applicationStatus"),
											disabled: saving,
											children: STATUSES.map((s) => /* @__PURE__ */ _jsxDEV("option", {
												value: s,
												children: s
											}, s, false, {
												fileName: _jsxFileName,
												lineNumber: 274,
												columnNumber: 46
											}, this))
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 273,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 271,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "col-6 col-md-6",
										children: [
											/* @__PURE__ */ _jsxDEV("label", {
												className: "form-label",
												htmlFor: "f-date",
												children: "Application date *"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 278,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("input", {
												id: "f-date",
												type: "date",
												className: `form-control ${invalid("applicationDate")}`,
												value: form.applicationDate,
												onChange: set("applicationDate"),
												disabled: saving
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 279,
												columnNumber: 23
											}, this),
											errors.applicationDate && /* @__PURE__ */ _jsxDEV("div", {
												className: "invalid-feedback",
												children: errors.applicationDate
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 280,
												columnNumber: 50
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 277,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 270,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 190,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 187,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "modal-footer",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								className: "btn btn-outline-secondary",
								onClick: onClose,
								disabled: saving,
								children: "Cancel"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 288,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "submit",
								className: "btn btn-dhaniti",
								disabled: saving,
								children: saving ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "spinner-border spinner-border-sm me-2",
									role: "status",
									"aria-hidden": "true"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 292,
									columnNumber: 21
								}, this), "Saving…"] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 291,
									columnNumber: 17
								}, this) : isEdit ? "Save changes" : "Create record"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 289,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 287,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 178,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 177,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 176,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 175,
		columnNumber: 5
	}, this);
}
_s(ItemFormModal, "VhXeznd+XNV61WckohFk+m4yXO4=", false, function() {
	return [useToast];
});
_c = ItemFormModal;
var _c;
$RefreshReg$(_c, "ItemFormModal");
if (import.meta.hot && !inWebWorker) {
	window.$RefreshReg$ = prevRefreshReg;
	window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
	RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
		RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/components/ItemFormModal.jsx", currentExports);
		import.meta.hot.accept((nextExports) => {
			if (!nextExports) return;
			const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/components/ItemFormModal.jsx", currentExports, nextExports);
			if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
		});
	});
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLE9BQU9BLFNBQVNDLFdBQVdDLFNBQVNDLGdCQUFnQjtBQUNwRCxTQUFTQyxVQUFVQyxpQkFBaUI7QUFDcEMsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLGdCQUFnQjtBQUV6QixNQUFNQyxTQUFTO0NBQUM7Q0FBa0I7Q0FBUztDQUFhO0NBQVU7Q0FBZTtDQUFhO0NBQWM7Q0FBYTtDQUFXO0NBQWlCO0NBQWU7Q0FBUztDQUFrQjtDQUFVO0NBQVc7Q0FBVTtDQUFTO0NBQWE7Q0FBZ0I7Q0FBZTtDQUFvQjtDQUFPO0FBQW1CO0FBQ2pVLE1BQU1DLGFBQWE7Q0FBQztDQUFZO0NBQWlCO0NBQVk7QUFBVztBQUN4RSxNQUFNQyxXQUFXO0NBQUM7Q0FBVztDQUFVO0NBQVU7Q0FBUztDQUFnQjtDQUFjO0NBQXdCO0FBQWtCO0FBQ2xJLE1BQU1DLFdBQVc7Q0FBQztDQUFhO0NBQWdCO0NBQVk7QUFBVTtBQUVyRSxNQUFNQyxhQUFhO0NBQ2pCQyxhQUFhO0NBQ2JDLEtBQUs7Q0FDTEMsY0FBYztDQUNkQyxlQUFlO0NBQ2ZDLFVBQVU7Q0FDVkMsd0JBQXdCO0NBQ3hCQyx3QkFBd0I7Q0FDeEJDLCtCQUErQjtDQUMvQkMsYUFBYTtDQUNiQyxnQkFBZ0I7Q0FDaEJDLG9CQUFvQjtDQUNwQkMsbUJBQW1CO0NBQ25CQyxpQkFBaUI7QUFDbkI7Ozs7OztBQU9BLGVBQWUsU0FBU0MsY0FBYyxFQUFFQyxNQUFNQyxNQUFNQyxNQUFNQyxTQUFTQyxTQUFTQyxXQUFXO0NBQUFDLEdBQUE7Q0FDckYsTUFBTUMsUUFBUTNCLFNBQVM7Q0FDdkIsTUFBTSxDQUFDNEIsTUFBTUMsV0FBV2pDLFNBQVNTLFVBQVU7Q0FDM0MsTUFBTSxDQUFDeUIsUUFBUUMsYUFBYW5DLFNBQVMsQ0FBQyxDQUFDO0NBQ3ZDLE1BQU0sQ0FBQ29DLFVBQVVDLGVBQWVyQyxTQUFTLEVBQUU7Q0FDM0MsTUFBTSxDQUFDc0MsUUFBUUMsYUFBYXZDLFNBQVMsS0FBSztDQUUxQyxNQUFNd0MsU0FBU2YsU0FBUztDQUV4QjNCLGdCQUFnQjtFQUNkLElBQUksQ0FBQzBCLE1BQU07RUFDWGEsWUFBWSxFQUFFO0VBQ2RGLFVBQVUsQ0FBQyxDQUFDO0VBQ1osSUFBSUssVUFBVWQsTUFBTTtHQUNsQk8sUUFBUTtJQUNOdkIsYUFBYWdCLEtBQUtoQixlQUFlO0lBQ2pDQyxLQUFLZSxLQUFLZixPQUFPO0lBQ2pCQyxjQUFjYyxLQUFLZCxnQkFBZ0I7SUFDbkNDLGVBQWVhLEtBQUtiLGlCQUFpQjtJQUNyQ0MsVUFBVVksS0FBS1osWUFBWTtJQUMzQkMsd0JBQXdCVyxLQUFLWCwwQkFBMEI7SUFDdkRDLHdCQUF3QlUsS0FBS1YsMEJBQTBCO0lBQ3ZEQywrQkFBK0JTLEtBQUtULGlDQUFpQztJQUNyRUMsYUFBYVEsS0FBS1IsZUFBZTtJQUNqQ0MsZ0JBQWdCTyxLQUFLUCxrQkFBa0I7SUFDdkNDLG9CQUFvQk0sS0FBS04sc0JBQXNCO0lBQy9DQyxtQkFBbUJLLEtBQUtMLHFCQUFxQjtJQUM3Q0MsaUJBQWlCSSxLQUFLSixtQkFBbUI7R0FDM0MsQ0FBQztFQUNILE9BQU87R0FDTFcsUUFBUTtJQUFFLEdBQUd4QjtJQUFZSSxlQUFlYyxTQUFTYyxlQUFlLEVBQUUsRUFBRUMsTUFBTTtJQUFJNUIsVUFBVWEsU0FBU2dCLFVBQVUsRUFBRSxFQUFFRCxNQUFNO0dBQUcsQ0FBQztFQUMzSDtDQUNGLEdBQUc7RUFBQ2xCO0VBQU1nQjtFQUFRZDtFQUFNQztDQUFPLENBQUM7Q0FFaEMsTUFBTWlCLGlCQUFpQjdDLGVBQ2Q0QixTQUFTZ0IsV0FBVyxHQUFFLENBQUVFLE1BQU1DLE1BQU1BLEVBQUVKLE9BQU9WLEtBQUtsQixRQUFRLEdBQ2pFLENBQUNhLFNBQVNLLEtBQUtsQixRQUFRLENBQ3pCO0NBRUEsTUFBTWlDLE9BQU9DLFNBQVNDLE1BQU07RUFDMUIsTUFBTUMsUUFBUUQsRUFBRUUsT0FBT0Q7RUFDdkJqQixTQUFTbUIsT0FBTztHQUFFLEdBQUdBO0lBQUlKLE1BQU1FO0VBQU0sRUFBRTtFQUN2Q2YsV0FBV2tCLFVBQVU7R0FBRSxHQUFHQTtJQUFPTCxNQUFNTTtFQUFVLEVBQUU7Q0FDckQ7Q0FFQSxTQUFTQyxXQUFXO0VBQ2xCLE1BQU1DLE9BQU8sQ0FBQztFQUNkLElBQUksQ0FBQ3hCLEtBQUt0QixZQUFZK0MsS0FBSyxLQUFLekIsS0FBS3RCLFlBQVkrQyxLQUFLLENBQUMsQ0FBQ0MsU0FBUyxHQUFHRixLQUFLOUMsY0FBYztFQUN2RixNQUFNQyxNQUFNZ0QsT0FBTzNCLEtBQUtyQixHQUFHO0VBQzNCLElBQUksQ0FBQ3FCLEtBQUtyQixPQUFPZ0QsT0FBT0MsTUFBTWpELEdBQUcsS0FBS0EsTUFBTSxNQUFNQSxNQUFNLEtBQUs2QyxLQUFLN0MsTUFBTTtFQUN4RSxJQUFJLENBQUNxQixLQUFLcEIsY0FBYzRDLEtBQUs1QyxlQUFlO0VBQzVDLElBQUksQ0FBQ29CLEtBQUtuQixlQUFlMkMsS0FBSzNDLGdCQUFnQjtFQUM5QyxJQUFJLENBQUNtQixLQUFLbEIsVUFBVTBDLEtBQUsxQyxXQUFXO0VBQ3BDLE1BQU0rQyxPQUFPRixPQUFPM0IsS0FBS2pCLHNCQUFzQjtFQUMvQyxJQUFJLENBQUNpQixLQUFLakIsMEJBQTBCNEMsT0FBT0MsTUFBTUMsSUFBSSxLQUFLQSxPQUFPLEtBQU9MLEtBQUt6Qyx5QkFBeUI7RUFDdEcsTUFBTStDLFNBQVNILE9BQU8zQixLQUFLaEIsc0JBQXNCO0VBQ2pELElBQUlnQixLQUFLaEIsMkJBQTJCLE1BQU0yQyxPQUFPQyxNQUFNRSxNQUFNLEtBQUtBLFNBQVMsR0FBR04sS0FBS3hDLHlCQUF5QjtFQUM1RyxNQUFNK0MsY0FBY0osT0FBTzNCLEtBQUtmLDZCQUE2QjtFQUM3RCxJQUFJZSxLQUFLZixrQ0FBa0MsTUFBTTBDLE9BQU9DLE1BQU1HLFdBQVcsS0FBS0EsY0FBYyxHQUFHUCxLQUFLdkMsZ0NBQWdDO0VBQ3BJLElBQUllLEtBQUtkLGdCQUFnQixNQUFNYyxLQUFLZCxnQkFBZ0IsUUFBUWMsS0FBS2QsZ0JBQWdCb0MsV0FBVztHQUMxRixNQUFNVSxRQUFRTCxPQUFPM0IsS0FBS2QsV0FBVztHQUNyQyxJQUFJeUMsT0FBT0MsTUFBTUksS0FBSyxLQUFLQSxRQUFRLE9BQU9BLFFBQVEsS0FBS1IsS0FBS3RDLGNBQWM7RUFDNUU7RUFDQSxJQUFJLENBQUNjLEtBQUtiLGdCQUFnQnFDLEtBQUtyQyxpQkFBaUI7RUFDaEQsSUFBSSxDQUFDYSxLQUFLWixvQkFBb0JvQyxLQUFLcEMscUJBQXFCO0VBQ3hELElBQUlvQixRQUFRO0dBQ1YsSUFBSSxDQUFDUixLQUFLWCxxQkFBcUIsQ0FBQ2IsU0FBU3lELFNBQVNqQyxLQUFLWCxpQkFBaUIsR0FBR21DLEtBQUtuQyxvQkFBb0I7R0FDcEcsSUFBSSxDQUFDVyxLQUFLVixtQkFBbUIsQ0FBQyxzQkFBc0I0QyxLQUFLbEMsS0FBS1YsZUFBZSxHQUFHa0MsS0FBS2xDLGtCQUFrQjtFQUN6RztFQUNBYSxVQUFVcUIsSUFBSTtFQUNkLE9BQU9XLE9BQU9DLEtBQUtaLElBQUksQ0FBQyxDQUFDRSxXQUFXO0NBQ3RDO0NBRUEsU0FBU1csZUFBZTtFQUN0QixNQUFNQyxVQUFVO0dBQ2Q1RCxhQUFhc0IsS0FBS3RCLFlBQVkrQyxLQUFLO0dBQ25DOUMsS0FBS2dELE9BQU8zQixLQUFLckIsR0FBRztHQUNwQkMsY0FBY29CLEtBQUtwQjtHQUNuQkMsZUFBZW1CLEtBQUtuQjtHQUNwQkMsVUFBVWtCLEtBQUtsQjtHQUNmQyx3QkFBd0I0QyxPQUFPM0IsS0FBS2pCLHNCQUFzQjtHQUMxREMsd0JBQXdCMkMsT0FBTzNCLEtBQUtoQixzQkFBc0I7R0FDMURDLCtCQUErQjBDLE9BQU8zQixLQUFLZiw2QkFBNkI7R0FDeEVDLGFBQWFjLEtBQUtkLGdCQUFnQixNQUFNYyxLQUFLZCxnQkFBZ0IsT0FBTyxPQUFPeUMsT0FBTzNCLEtBQUtkLFdBQVc7R0FDbEdDLGdCQUFnQmEsS0FBS2I7R0FDckJDLG9CQUFvQlksS0FBS1o7RUFDM0I7RUFDQSxJQUFJb0IsUUFBUTtHQUNWOEIsUUFBUWpELG9CQUFvQlcsS0FBS1g7R0FDakNpRCxRQUFRaEQsa0JBQWtCVSxLQUFLVjtFQUNqQztFQUNBLE9BQU9nRDtDQUNUO0NBRUEsZUFBZUMsYUFBYXRCLEdBQUc7RUFDN0JBLEVBQUV1QixlQUFlO0VBQ2pCbkMsWUFBWSxFQUFFO0VBQ2QsSUFBSSxDQUFDa0IsU0FBUyxHQUFHO0VBQ2pCaEIsVUFBVSxJQUFJO0VBQ2QsSUFBSTtHQUNGLElBQUlDLFFBQVE7SUFDVixNQUFNdkMsU0FBU3dFLFdBQVcvQyxLQUFLZ0IsSUFBSTJCLGFBQWEsQ0FBQztJQUNqRHRDLE1BQU0yQyxRQUFRLFVBQVVoRCxLQUFLZ0IsR0FBRSx1QkFBd0I7R0FDekQsT0FBTztJQUNMLE1BQU1pQyxVQUFVLE1BQU0xRSxTQUFTMkUsV0FBV1AsYUFBYSxDQUFDO0lBQ3hEdEMsTUFBTTJDLFFBQVEsVUFBVUMsUUFBUWpDLEdBQUUsdUJBQXdCO0dBQzVEO0dBQ0FiLFFBQVE7RUFDVixTQUFTZ0QsS0FBSztHQUNaLElBQUlBLGVBQWUxRSxZQUFZMEUsSUFBSUMsU0FBU3BCLFFBQVE7SUFDbERyQixZQUFZLEdBQUd3QyxJQUFJRSxRQUFPLEdBQUlGLElBQUlDLFFBQVFFLEtBQUssR0FBRyxHQUFHO0dBQ3ZELE9BQU87SUFDTDNDLFlBQVl3QyxJQUFJRSxXQUFXLHdCQUF3QjtHQUNyRDtFQUNGLFVBQVU7R0FDUnhDLFVBQVUsS0FBSztFQUNqQjtDQUNGO0NBRUEsSUFBSSxDQUFDZixNQUFNLE9BQU87Q0FFbEIsTUFBTXlELFdBQVdDLFVBQVdoRCxPQUFPZ0QsU0FBUyxlQUFlO0NBRTNELE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7RUFBMEIsVUFBVSxDQUFDO0VBQUcsTUFBSztFQUFTLE9BQU8sRUFBRUMsWUFBWSxzQkFBc0I7RUFBRyxjQUFXO1lBQzVILHdCQUFDLE9BQUQ7R0FBSyxXQUFVO0dBQXNFLE1BQUs7YUFDeEYsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDYix3QkFBQyxRQUFEO0tBQU0sVUFBVVo7S0FBYztlQUE5QjtNQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQWQsQ0FDRSx3QkFBQyxLQUFEO1NBQUcsV0FBVyxNQUFNL0IsU0FBUyxxQkFBcUIsaUJBQWdCO1NBQXNCLGVBQVk7UUFBTTs7OztrQkFDekdBLFNBQVMsb0JBQW9CZCxNQUFNZ0IsT0FBTyxzQkFDekM7Ozs7O2lCQUNKLHdCQUFDLFVBQUQ7UUFBUSxNQUFLO1FBQVMsV0FBVTtRQUFZLGNBQVc7UUFBUSxTQUFTZDtRQUFTLFVBQVVVO09BQU87Ozs7ZUFDL0Y7Ozs7OztNQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0dGLFlBQVksd0JBQUMsT0FBRDtRQUFLLFdBQVU7UUFBMEIsTUFBSztrQkFBU0E7T0FBYzs7OztpQkFFbEYsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZjtXQUNFLHdCQUFDLFNBQUQ7WUFBTyxXQUFVO1lBQWEsU0FBUTtzQkFBUztXQUFxQjs7Ozs7V0FDcEUsd0JBQUMsU0FBRDtZQUFPLElBQUc7WUFBUyxXQUFXLGdCQUFnQjZDLFFBQVEsYUFBYTtZQUFLLE9BQU9qRCxLQUFLdEI7WUFBYSxVQUFVcUMsSUFBSSxhQUFhO1lBQUcsVUFBVVQ7V0FBTzs7Ozs7V0FDL0lKLE9BQU94QixlQUFlLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFvQndCLE9BQU94QjtXQUFpQjs7Ozs7VUFDL0U7Ozs7OztTQUVMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmO1dBQ0Usd0JBQUMsU0FBRDtZQUFPLFdBQVU7WUFBYSxTQUFRO3NCQUFRO1dBQVk7Ozs7O1dBQzFELHdCQUFDLFNBQUQ7WUFBTyxJQUFHO1lBQVEsTUFBSztZQUFTLEtBQUs7WUFBSSxLQUFLO1lBQUssV0FBVyxnQkFBZ0J1RSxRQUFRLEtBQUs7WUFBSyxPQUFPakQsS0FBS3JCO1lBQUssVUFBVW9DLElBQUksS0FBSztZQUFHLFVBQVVUO1dBQU87Ozs7O1dBQ3ZKSixPQUFPdkIsT0FBTyx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBb0J1QixPQUFPdkI7V0FBUzs7Ozs7VUFDL0Q7Ozs7OztTQUVMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsU0FBRDtXQUFPLFdBQVU7V0FBYSxTQUFRO3FCQUFVO1VBQWM7Ozs7b0JBQzlELHdCQUFDLFVBQUQ7V0FBUSxJQUFHO1dBQVUsV0FBVyxlQUFlc0UsUUFBUSxjQUFjO1dBQUssT0FBT2pELEtBQUtwQjtXQUFjLFVBQVVtQyxJQUFJLGNBQWM7V0FBRyxVQUFVVDtxQkFDMUlqQyxPQUFPK0UsS0FBS0MsTUFBTSx3QkFBQyxVQUFEO1lBQWdCLE9BQU9BO3NCQUFJQTtXQUFVLEdBQXhCQTs7OztrQkFBd0IsQ0FBQztVQUNuRDs7OztrQkFDTDs7Ozs7O1NBRUwsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWY7V0FDRSx3QkFBQyxTQUFEO1lBQU8sV0FBVTtZQUFhLFNBQVE7c0JBQVM7V0FBb0I7Ozs7O1dBQ25FLHdCQUFDLFVBQUQ7WUFBUSxJQUFHO1lBQVMsV0FBVyxlQUFlSixRQUFRLGVBQWU7WUFBSyxPQUFPakQsS0FBS25CO1lBQWUsVUFBVWtDLElBQUksZUFBZTtZQUFHLFVBQVVUO3NCQUEvSSxDQUNFLHdCQUFDLFVBQUQ7YUFBUSxPQUFNO3VCQUFHO1lBQTJCOzs7O3VCQUMxQ1gsU0FBU2MsZ0JBQWdCLEdBQUUsQ0FBRTJDLEtBQUtFLE1BQU0sd0JBQUMsVUFBRDthQUFtQixPQUFPQSxFQUFFNUM7dUJBQTVCO2NBQWlDNEMsRUFBRUM7Y0FBSztjQUFHRCxFQUFFNUM7Y0FBRzthQUFTO2VBQTVDNEMsRUFBRTVDOzs7O21CQUEwQyxDQUFDLENBQzlGOzs7Ozs7V0FDUFIsT0FBT3JCLGlCQUFpQix3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBb0JxQixPQUFPckI7V0FBbUI7Ozs7O1VBQ25GOzs7Ozs7U0FFTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZjtXQUNFLHdCQUFDLFNBQUQ7WUFBTyxXQUFVO1lBQWEsU0FBUTtzQkFBVztXQUFlOzs7OztXQUNoRSx3QkFBQyxVQUFEO1lBQVEsSUFBRztZQUFXLFdBQVcsZUFBZW9FLFFBQVEsVUFBVTtZQUFLLE9BQU9qRCxLQUFLbEI7WUFBVSxVQUFVaUMsSUFBSSxVQUFVO1lBQUcsVUFBVVQ7c0JBQWxJLENBQ0Usd0JBQUMsVUFBRDthQUFRLE9BQU07dUJBQUc7WUFBc0I7Ozs7dUJBQ3JDWCxTQUFTZ0IsV0FBVyxHQUFFLENBQUV5QyxLQUFLdEMsTUFBTSx3QkFBQyxVQUFEO2FBQW1CLE9BQU9BLEVBQUVKO3VCQUE1QjtjQUFpQ0ksRUFBRXlDO2NBQUs7Y0FBSXpDLEVBQUUwQztjQUFRMUMsRUFBRTJDLGdCQUFnQixTQUFTdkYsVUFBVTRDLEVBQUUyQyxhQUFhLEVBQUMsS0FBTTthQUFXO2VBQS9HM0MsRUFBRUo7Ozs7bUJBQTZHLENBQUMsQ0FDNUo7Ozs7OztXQUNQUixPQUFPcEIsWUFBWSx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBb0JvQixPQUFPcEI7V0FBYzs7Ozs7VUFDekU7Ozs7OztTQUVMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmO1dBQ0Usd0JBQUMsU0FBRDtZQUFPLFdBQVU7WUFBYSxTQUFRO3NCQUFTO1dBQTJCOzs7OztXQUMxRSx3QkFBQyxTQUFEO1lBQU8sSUFBRztZQUFTLE1BQUs7WUFBUyxLQUFLO1lBQU8sTUFBTTtZQUFPLFdBQVcsZ0JBQWdCbUUsUUFBUSx3QkFBd0I7WUFBSyxPQUFPakQsS0FBS2pCO1lBQXdCLFVBQVVnQyxJQUFJLHdCQUF3QjtZQUFHLFVBQVVUO1dBQU87Ozs7O1dBQ3ZOSixPQUFPbkIsMEJBQTBCLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFvQm1CLE9BQU9uQjtXQUE0Qjs7Ozs7V0FDdkc2QixnQkFBZ0I2QyxpQkFBaUI5QixPQUFPM0IsS0FBS2pCLHNCQUFzQixJQUFJNkIsZUFBZTZDLGlCQUNyRix3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZjthQUF3Qyx3QkFBQyxLQUFEO2NBQUcsV0FBVTtjQUFrQyxlQUFZO2FBQU07Ozs7O2FBQUc7YUFBc0J2RixVQUFVMEMsZUFBZTZDLGFBQWE7YUFBRTtZQUF5Qjs7Ozs7O1VBRWxNOzs7Ozs7U0FFTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZjtXQUNFLHdCQUFDLFNBQUQ7WUFBTyxXQUFVO1lBQWEsU0FBUTtzQkFBVztXQUE2Qjs7Ozs7V0FDOUUsd0JBQUMsU0FBRDtZQUFPLElBQUc7WUFBVyxNQUFLO1lBQVMsS0FBSztZQUFHLE1BQU07WUFBTSxXQUFXLGdCQUFnQlIsUUFBUSx3QkFBd0I7WUFBSyxPQUFPakQsS0FBS2hCO1lBQXdCLFVBQVUrQixJQUFJLHdCQUF3QjtZQUFHLFVBQVVUO1dBQU87Ozs7O1dBQ3BOSixPQUFPbEIsMEJBQTBCLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFvQmtCLE9BQU9sQjtXQUE0Qjs7Ozs7VUFDckc7Ozs7OztTQUVMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmO1dBQ0Usd0JBQUMsU0FBRDtZQUFPLFdBQVU7WUFBYSxTQUFRO3NCQUFRO1dBQW9DOzs7OztXQUNsRix3QkFBQyxTQUFEO1lBQU8sSUFBRztZQUFRLE1BQUs7WUFBUyxLQUFLO1lBQUcsTUFBTTtZQUFLLFdBQVcsZ0JBQWdCaUUsUUFBUSwrQkFBK0I7WUFBSyxPQUFPakQsS0FBS2Y7WUFBK0IsVUFBVThCLElBQUksK0JBQStCO1lBQUcsVUFBVVQ7V0FBTzs7Ozs7V0FDck9KLE9BQU9qQixpQ0FBaUMsd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQW9CaUIsT0FBT2pCO1dBQW1DOzs7OztVQUNuSDs7Ozs7O1NBRUwsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWY7V0FDRSx3QkFBQyxTQUFEO1lBQU8sV0FBVTtZQUFhLFNBQVE7c0JBQVU7V0FBbUI7Ozs7O1dBQ25FLHdCQUFDLFNBQUQ7WUFBTyxJQUFHO1lBQVUsTUFBSztZQUFTLEtBQUs7WUFBSyxLQUFLO1lBQUssYUFBWTtZQUFxQixXQUFXLGdCQUFnQmdFLFFBQVEsYUFBYTtZQUFLLE9BQU9qRCxLQUFLZCxlQUFlO1lBQUksVUFBVTZCLElBQUksYUFBYTtZQUFHLFVBQVVUO1dBQU87Ozs7O1dBQ3pOSixPQUFPaEIsZUFBZSx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBb0JnQixPQUFPaEI7V0FBaUI7Ozs7O1VBQy9FOzs7Ozs7U0FFTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFNBQUQ7V0FBTyxXQUFVO1dBQWEsU0FBUTtxQkFBUTtVQUF3Qjs7OztvQkFDdEUsd0JBQUMsVUFBRDtXQUFRLElBQUc7V0FBUSxXQUFXLGVBQWUrRCxRQUFRLGdCQUFnQjtXQUFLLE9BQU9qRCxLQUFLYjtXQUFnQixVQUFVNEIsSUFBSSxnQkFBZ0I7V0FBRyxVQUFVVDtxQkFDOUloQyxXQUFXOEUsS0FBS0MsTUFBTSx3QkFBQyxVQUFEO1lBQWdCLE9BQU9BO3NCQUFJQTtXQUFVLEdBQXhCQTs7OztrQkFBd0IsQ0FBQztVQUN2RDs7OztrQkFDTDs7Ozs7O1NBRUwsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxTQUFEO1dBQU8sV0FBVTtXQUFhLFNBQVE7cUJBQVM7VUFBZ0I7Ozs7b0JBQy9ELHdCQUFDLFVBQUQ7V0FBUSxJQUFHO1dBQVMsV0FBVyxlQUFlSixRQUFRLG9CQUFvQjtXQUFLLE9BQU9qRCxLQUFLWjtXQUFvQixVQUFVMkIsSUFBSSxvQkFBb0I7V0FBRyxVQUFVVDtxQkFDM0ovQixTQUFTNkUsS0FBS0MsTUFBTSx3QkFBQyxVQUFEO1lBQWdCLE9BQU9BO3NCQUFJQTtXQUFVLEdBQXhCQTs7OztrQkFBd0IsQ0FBQztVQUNyRDs7OztrQkFDTDs7Ozs7O1NBRUo3QyxVQUNDLGdEQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsU0FBRDtXQUFPLFdBQVU7V0FBYSxTQUFRO3FCQUFXO1VBQWU7Ozs7b0JBQ2hFLHdCQUFDLFVBQUQ7V0FBUSxJQUFHO1dBQVcsV0FBVyxlQUFleUMsUUFBUSxtQkFBbUI7V0FBSyxPQUFPakQsS0FBS1g7V0FBbUIsVUFBVTBCLElBQUksbUJBQW1CO1dBQUcsVUFBVVQ7cUJBQzFKOUIsU0FBUzRFLEtBQUtDLE1BQU0sd0JBQUMsVUFBRDtZQUFnQixPQUFPQTtzQkFBSUE7V0FBVSxHQUF4QkE7Ozs7a0JBQXdCLENBQUM7VUFDckQ7Ozs7a0JBQ0w7Ozs7O21CQUNMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmO1dBQ0Usd0JBQUMsU0FBRDtZQUFPLFdBQVU7WUFBYSxTQUFRO3NCQUFTO1dBQXlCOzs7OztXQUN4RSx3QkFBQyxTQUFEO1lBQU8sSUFBRztZQUFTLE1BQUs7WUFBTyxXQUFXLGdCQUFnQkosUUFBUSxpQkFBaUI7WUFBSyxPQUFPakQsS0FBS1Y7WUFBaUIsVUFBVXlCLElBQUksaUJBQWlCO1lBQUcsVUFBVVQ7V0FBTzs7Ozs7V0FDdktKLE9BQU9aLG1CQUFtQix3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBb0JZLE9BQU9aO1dBQXFCOzs7OztVQUN2Rjs7Ozs7aUJBQ1A7Ozs7O1FBRUM7Ozs7O2VBQ0Y7Ozs7OztNQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsVUFBRDtRQUFRLE1BQUs7UUFBUyxXQUFVO1FBQTRCLFNBQVNNO1FBQVMsVUFBVVU7a0JBQVE7T0FBYzs7OztpQkFDOUcsd0JBQUMsVUFBRDtRQUFRLE1BQUs7UUFBUyxXQUFVO1FBQWtCLFVBQVVBO2tCQUN6REEsU0FDQyxnREFDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTtTQUF3QyxNQUFLO1NBQVMsZUFBWTtRQUFNOzs7O2tCQUFBLFNBRTFGOzs7O21CQUNFRSxTQUFTLGlCQUFpQjtPQUN4Qjs7OztlQUNMOzs7Ozs7S0FDRDs7Ozs7O0dBQ0g7Ozs7O0VBQ0Y7Ozs7O0NBQ0Y7Ozs7O0FBRVQ7QUFBQ1YsR0E1UHVCUCxlQUFhO0NBQUEsUUFDckJuQixRQUFRO0FBQUE7QUFBQSxLQURBbUI7QUFBYSxJQUFBbUU7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJ1c2VFZmZlY3QiLCJ1c2VNZW1vIiwidXNlU3RhdGUiLCJpdGVtc0FwaSIsImZvcm1hdElOUiIsIkFwaUVycm9yIiwidXNlVG9hc3QiLCJTVEFURVMiLCJFTVBMT1lNRU5UIiwiQ0hBTk5FTFMiLCJTVEFUVVNFUyIsIkVNUFRZX0ZPUk0iLCJzdHVkZW50TmFtZSIsImFnZSIsInN0dWRlbnRTdGF0ZSIsImluc3RpdHV0aW9uSWQiLCJjb3Vyc2VJZCIsImxvYW5BbW91bnRSZXF1ZXN0ZWRJbnIiLCJwYXJlbnRNb250aGx5SW5jb21lSW5yIiwiZXhpc3RpbmdNb250aGx5T2JsaWdhdGlvbnNJbnIiLCJjcmVkaXRTY29yZSIsImVtcGxveW1lbnRUeXBlIiwiYXBwbGljYXRpb25DaGFubmVsIiwiYXBwbGljYXRpb25TdGF0dXMiLCJhcHBsaWNhdGlvbkRhdGUiLCJJdGVtRm9ybU1vZGFsIiwic2hvdyIsIm1vZGUiLCJpdGVtIiwiZmlsdGVycyIsIm9uQ2xvc2UiLCJvblNhdmVkIiwiX3MiLCJ0b2FzdCIsImZvcm0iLCJzZXRGb3JtIiwiZXJyb3JzIiwic2V0RXJyb3JzIiwiYXBpRXJyb3IiLCJzZXRBcGlFcnJvciIsInNhdmluZyIsInNldFNhdmluZyIsImlzRWRpdCIsImluc3RpdHV0aW9ucyIsImlkIiwiY291cnNlcyIsInNlbGVjdGVkQ291cnNlIiwiZmluZCIsImMiLCJzZXQiLCJrZXkiLCJlIiwidmFsdWUiLCJ0YXJnZXQiLCJmIiwicHJldiIsInVuZGVmaW5lZCIsInZhbGlkYXRlIiwibmV4dCIsInRyaW0iLCJsZW5ndGgiLCJOdW1iZXIiLCJpc05hTiIsImxvYW4iLCJpbmNvbWUiLCJvYmxpZ2F0aW9ucyIsInNjb3JlIiwiaW5jbHVkZXMiLCJ0ZXN0IiwiT2JqZWN0Iiwia2V5cyIsImJ1aWxkUGF5bG9hZCIsInBheWxvYWQiLCJoYW5kbGVTdWJtaXQiLCJwcmV2ZW50RGVmYXVsdCIsInVwZGF0ZUl0ZW0iLCJzdWNjZXNzIiwiY3JlYXRlZCIsImNyZWF0ZUl0ZW0iLCJlcnIiLCJkZXRhaWxzIiwibWVzc2FnZSIsImpvaW4iLCJpbnZhbGlkIiwiZmllbGQiLCJiYWNrZ3JvdW5kIiwibWFwIiwicyIsImkiLCJuYW1lIiwiZG9tYWluIiwidHlwaWNhbEZlZUluciIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkl0ZW1Gb3JtTW9kYWwuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIHVzZU1lbW8sIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBpdGVtc0FwaSwgZm9ybWF0SU5SIH0gZnJvbSBcIi4uL2FwaS9pdGVtcy5qc1wiO1xuaW1wb3J0IHsgQXBpRXJyb3IgfSBmcm9tIFwiLi4vYXBpL2NsaWVudC5qc1wiO1xuaW1wb3J0IHsgdXNlVG9hc3QgfSBmcm9tIFwiLi4vY29udGV4dC9Ub2FzdENvbnRleHQuanN4XCI7XG5cbmNvbnN0IFNUQVRFUyA9IFtcIkFuZGhyYSBQcmFkZXNoXCIsIFwiRGVsaGlcIiwgXCJLYXJuYXRha2FcIiwgXCJLZXJhbGFcIiwgXCJNYWhhcmFzaHRyYVwiLCBcIlJhamFzdGhhblwiLCBcIlRhbWlsIE5hZHVcIiwgXCJUZWxhbmdhbmFcIiwgXCJHdWphcmF0XCIsIFwiVXR0YXIgUHJhZGVzaFwiLCBcIldlc3QgQmVuZ2FsXCIsIFwiQmloYXJcIiwgXCJNYWRoeWEgUHJhZGVzaFwiLCBcIlB1bmphYlwiLCBcIkhhcnlhbmFcIiwgXCJPZGlzaGFcIiwgXCJBc3NhbVwiLCBcIkpoYXJraGFuZFwiLCBcIkNoaGF0dGlzZ2FyaFwiLCBcIlV0dGFyYWtoYW5kXCIsIFwiSGltYWNoYWwgUHJhZGVzaFwiLCBcIkdvYVwiLCBcIkphbW11IGFuZCBLYXNobWlyXCJdO1xuY29uc3QgRU1QTE9ZTUVOVCA9IFtcIlNhbGFyaWVkXCIsIFwiU2VsZi1FbXBsb3llZFwiLCBcIkJ1c2luZXNzXCIsIFwiUGVuc2lvbmVyXCJdO1xuY29uc3QgQ0hBTk5FTFMgPSBbXCJXZWJzaXRlXCIsIFwiT25saW5lXCIsIFwiQnJhbmNoXCIsIFwiQWdlbnRcIiwgXCJDYW1wdXMgRHJpdmVcIiwgXCJDb3Vuc2VsbG9yXCIsIFwiSW5zdGl0dXRpb24gUmVmZXJyYWxcIiwgXCJQYXJ0bmVyIFJlZmVycmFsXCJdO1xuY29uc3QgU1RBVFVTRVMgPSBbXCJTdWJtaXR0ZWRcIiwgXCJVbmRlciBSZXZpZXdcIiwgXCJBcHByb3ZlZFwiLCBcIlJlamVjdGVkXCJdO1xuXG5jb25zdCBFTVBUWV9GT1JNID0ge1xuICBzdHVkZW50TmFtZTogXCJcIixcbiAgYWdlOiBcIlwiLFxuICBzdHVkZW50U3RhdGU6IFwiS2FybmF0YWthXCIsXG4gIGluc3RpdHV0aW9uSWQ6IFwiXCIsXG4gIGNvdXJzZUlkOiBcIlwiLFxuICBsb2FuQW1vdW50UmVxdWVzdGVkSW5yOiBcIlwiLFxuICBwYXJlbnRNb250aGx5SW5jb21lSW5yOiBcIlwiLFxuICBleGlzdGluZ01vbnRobHlPYmxpZ2F0aW9uc0lucjogXCJcIixcbiAgY3JlZGl0U2NvcmU6IFwiXCIsXG4gIGVtcGxveW1lbnRUeXBlOiBcIlNhbGFyaWVkXCIsXG4gIGFwcGxpY2F0aW9uQ2hhbm5lbDogXCJXZWJzaXRlXCIsXG4gIGFwcGxpY2F0aW9uU3RhdHVzOiBcIlN1Ym1pdHRlZFwiLFxuICBhcHBsaWNhdGlvbkRhdGU6IFwiXCIsXG59O1xuXG4vKipcbiAqIENyZWF0ZSAvIEVkaXQgbW9kYWwgZm9yIGxvYW4gYXBwbGljYXRpb25zLlxuICogICBtb2RlID09PSBcImNyZWF0ZVwiICDihpIgUE9TVCAvYXBpL2FwcGxpY2F0aW9uc1xuICogICBtb2RlID09PSBcImVkaXRcIiAgICDihpIgUFVUICAvYXBpL2FwcGxpY2F0aW9ucy86aWQgKHByZS1maWxsZWQpXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEl0ZW1Gb3JtTW9kYWwoeyBzaG93LCBtb2RlLCBpdGVtLCBmaWx0ZXJzLCBvbkNsb3NlLCBvblNhdmVkIH0pIHtcbiAgY29uc3QgdG9hc3QgPSB1c2VUb2FzdCgpO1xuICBjb25zdCBbZm9ybSwgc2V0Rm9ybV0gPSB1c2VTdGF0ZShFTVBUWV9GT1JNKTtcbiAgY29uc3QgW2Vycm9ycywgc2V0RXJyb3JzXSA9IHVzZVN0YXRlKHt9KTtcbiAgY29uc3QgW2FwaUVycm9yLCBzZXRBcGlFcnJvcl0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW3NhdmluZywgc2V0U2F2aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICBjb25zdCBpc0VkaXQgPSBtb2RlID09PSBcImVkaXRcIjtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghc2hvdykgcmV0dXJuO1xuICAgIHNldEFwaUVycm9yKFwiXCIpO1xuICAgIHNldEVycm9ycyh7fSk7XG4gICAgaWYgKGlzRWRpdCAmJiBpdGVtKSB7XG4gICAgICBzZXRGb3JtKHtcbiAgICAgICAgc3R1ZGVudE5hbWU6IGl0ZW0uc3R1ZGVudE5hbWUgfHwgXCJcIixcbiAgICAgICAgYWdlOiBpdGVtLmFnZSA/PyBcIlwiLFxuICAgICAgICBzdHVkZW50U3RhdGU6IGl0ZW0uc3R1ZGVudFN0YXRlIHx8IFwiXCIsXG4gICAgICAgIGluc3RpdHV0aW9uSWQ6IGl0ZW0uaW5zdGl0dXRpb25JZCB8fCBcIlwiLFxuICAgICAgICBjb3Vyc2VJZDogaXRlbS5jb3Vyc2VJZCB8fCBcIlwiLFxuICAgICAgICBsb2FuQW1vdW50UmVxdWVzdGVkSW5yOiBpdGVtLmxvYW5BbW91bnRSZXF1ZXN0ZWRJbnIgPz8gXCJcIixcbiAgICAgICAgcGFyZW50TW9udGhseUluY29tZUlucjogaXRlbS5wYXJlbnRNb250aGx5SW5jb21lSW5yID8/IFwiXCIsXG4gICAgICAgIGV4aXN0aW5nTW9udGhseU9ibGlnYXRpb25zSW5yOiBpdGVtLmV4aXN0aW5nTW9udGhseU9ibGlnYXRpb25zSW5yID8/IFwiXCIsXG4gICAgICAgIGNyZWRpdFNjb3JlOiBpdGVtLmNyZWRpdFNjb3JlID8/IFwiXCIsXG4gICAgICAgIGVtcGxveW1lbnRUeXBlOiBpdGVtLmVtcGxveW1lbnRUeXBlIHx8IFwiU2FsYXJpZWRcIixcbiAgICAgICAgYXBwbGljYXRpb25DaGFubmVsOiBpdGVtLmFwcGxpY2F0aW9uQ2hhbm5lbCB8fCBcIldlYnNpdGVcIixcbiAgICAgICAgYXBwbGljYXRpb25TdGF0dXM6IGl0ZW0uYXBwbGljYXRpb25TdGF0dXMgfHwgXCJTdWJtaXR0ZWRcIixcbiAgICAgICAgYXBwbGljYXRpb25EYXRlOiBpdGVtLmFwcGxpY2F0aW9uRGF0ZSB8fCBcIlwiLFxuICAgICAgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHNldEZvcm0oeyAuLi5FTVBUWV9GT1JNLCBpbnN0aXR1dGlvbklkOiBmaWx0ZXJzPy5pbnN0aXR1dGlvbnM/LlswXT8uaWQgfHwgXCJcIiwgY291cnNlSWQ6IGZpbHRlcnM/LmNvdXJzZXM/LlswXT8uaWQgfHwgXCJcIiB9KTtcbiAgICB9XG4gIH0sIFtzaG93LCBpc0VkaXQsIGl0ZW0sIGZpbHRlcnNdKTtcblxuICBjb25zdCBzZWxlY3RlZENvdXJzZSA9IHVzZU1lbW8oXG4gICAgKCkgPT4gKGZpbHRlcnM/LmNvdXJzZXMgfHwgW10pLmZpbmQoKGMpID0+IGMuaWQgPT09IGZvcm0uY291cnNlSWQpLFxuICAgIFtmaWx0ZXJzLCBmb3JtLmNvdXJzZUlkXVxuICApO1xuXG4gIGNvbnN0IHNldCA9IChrZXkpID0+IChlKSA9PiB7XG4gICAgY29uc3QgdmFsdWUgPSBlLnRhcmdldC52YWx1ZTtcbiAgICBzZXRGb3JtKChmKSA9PiAoeyAuLi5mLCBba2V5XTogdmFsdWUgfSkpO1xuICAgIHNldEVycm9ycygocHJldikgPT4gKHsgLi4ucHJldiwgW2tleV06IHVuZGVmaW5lZCB9KSk7XG4gIH07XG5cbiAgZnVuY3Rpb24gdmFsaWRhdGUoKSB7XG4gICAgY29uc3QgbmV4dCA9IHt9O1xuICAgIGlmICghZm9ybS5zdHVkZW50TmFtZS50cmltKCkgfHwgZm9ybS5zdHVkZW50TmFtZS50cmltKCkubGVuZ3RoIDwgMikgbmV4dC5zdHVkZW50TmFtZSA9IFwiU3R1ZGVudCBuYW1lIGlzIHJlcXVpcmVkIChtaW4gMiBjaGFyYWN0ZXJzKS5cIjtcbiAgICBjb25zdCBhZ2UgPSBOdW1iZXIoZm9ybS5hZ2UpO1xuICAgIGlmICghZm9ybS5hZ2UgfHwgTnVtYmVyLmlzTmFOKGFnZSkgfHwgYWdlIDwgMTYgfHwgYWdlID4gMTAwKSBuZXh0LmFnZSA9IFwiQWdlIG11c3QgYmUgYmV0d2VlbiAxNiBhbmQgMTAwLlwiO1xuICAgIGlmICghZm9ybS5zdHVkZW50U3RhdGUpIG5leHQuc3R1ZGVudFN0YXRlID0gXCJTdGF0ZSBpcyByZXF1aXJlZC5cIjtcbiAgICBpZiAoIWZvcm0uaW5zdGl0dXRpb25JZCkgbmV4dC5pbnN0aXR1dGlvbklkID0gXCJTZWxlY3QgYW4gaW5zdGl0dXRpb24uXCI7XG4gICAgaWYgKCFmb3JtLmNvdXJzZUlkKSBuZXh0LmNvdXJzZUlkID0gXCJTZWxlY3QgYSBjb3Vyc2UuXCI7XG4gICAgY29uc3QgbG9hbiA9IE51bWJlcihmb3JtLmxvYW5BbW91bnRSZXF1ZXN0ZWRJbnIpO1xuICAgIGlmICghZm9ybS5sb2FuQW1vdW50UmVxdWVzdGVkSW5yIHx8IE51bWJlci5pc05hTihsb2FuKSB8fCBsb2FuIDwgMTAwMDApIG5leHQubG9hbkFtb3VudFJlcXVlc3RlZEluciA9IFwiTG9hbiBhbW91bnQgbXVzdCBiZSBhdCBsZWFzdCDigrkxMCwwMDAuXCI7XG4gICAgY29uc3QgaW5jb21lID0gTnVtYmVyKGZvcm0ucGFyZW50TW9udGhseUluY29tZUlucik7XG4gICAgaWYgKGZvcm0ucGFyZW50TW9udGhseUluY29tZUluciA9PT0gXCJcIiB8fCBOdW1iZXIuaXNOYU4oaW5jb21lKSB8fCBpbmNvbWUgPCAwKSBuZXh0LnBhcmVudE1vbnRobHlJbmNvbWVJbnIgPSBcIlBhcmVudCBtb250aGx5IGluY29tZSBpcyByZXF1aXJlZC5cIjtcbiAgICBjb25zdCBvYmxpZ2F0aW9ucyA9IE51bWJlcihmb3JtLmV4aXN0aW5nTW9udGhseU9ibGlnYXRpb25zSW5yKTtcbiAgICBpZiAoZm9ybS5leGlzdGluZ01vbnRobHlPYmxpZ2F0aW9uc0luciA9PT0gXCJcIiB8fCBOdW1iZXIuaXNOYU4ob2JsaWdhdGlvbnMpIHx8IG9ibGlnYXRpb25zIDwgMCkgbmV4dC5leGlzdGluZ01vbnRobHlPYmxpZ2F0aW9uc0luciA9IFwiRXhpc3Rpbmcgb2JsaWdhdGlvbnMgYXJlIHJlcXVpcmVkLlwiO1xuICAgIGlmIChmb3JtLmNyZWRpdFNjb3JlICE9PSBcIlwiICYmIGZvcm0uY3JlZGl0U2NvcmUgIT09IG51bGwgJiYgZm9ybS5jcmVkaXRTY29yZSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICBjb25zdCBzY29yZSA9IE51bWJlcihmb3JtLmNyZWRpdFNjb3JlKTtcbiAgICAgIGlmIChOdW1iZXIuaXNOYU4oc2NvcmUpIHx8IHNjb3JlIDwgMzAwIHx8IHNjb3JlID4gOTAwKSBuZXh0LmNyZWRpdFNjb3JlID0gXCJDcmVkaXQgc2NvcmUgbXVzdCBiZSBiZXR3ZWVuIDMwMCBhbmQgOTAwIChvciBsZWF2ZSBibGFuaykuXCI7XG4gICAgfVxuICAgIGlmICghZm9ybS5lbXBsb3ltZW50VHlwZSkgbmV4dC5lbXBsb3ltZW50VHlwZSA9IFwiRW1wbG95bWVudCB0eXBlIGlzIHJlcXVpcmVkLlwiO1xuICAgIGlmICghZm9ybS5hcHBsaWNhdGlvbkNoYW5uZWwpIG5leHQuYXBwbGljYXRpb25DaGFubmVsID0gXCJBcHBsaWNhdGlvbiBjaGFubmVsIGlzIHJlcXVpcmVkLlwiO1xuICAgIGlmIChpc0VkaXQpIHtcbiAgICAgIGlmICghZm9ybS5hcHBsaWNhdGlvblN0YXR1cyB8fCAhU1RBVFVTRVMuaW5jbHVkZXMoZm9ybS5hcHBsaWNhdGlvblN0YXR1cykpIG5leHQuYXBwbGljYXRpb25TdGF0dXMgPSBcIlNlbGVjdCBhIHZhbGlkIHN0YXR1cy5cIjtcbiAgICAgIGlmICghZm9ybS5hcHBsaWNhdGlvbkRhdGUgfHwgIS9eXFxkezR9LVxcZHsyfS1cXGR7Mn0kLy50ZXN0KGZvcm0uYXBwbGljYXRpb25EYXRlKSkgbmV4dC5hcHBsaWNhdGlvbkRhdGUgPSBcIkFwcGxpY2F0aW9uIGRhdGUgbXVzdCBiZSBZWVlZLU1NLURELlwiO1xuICAgIH1cbiAgICBzZXRFcnJvcnMobmV4dCk7XG4gICAgcmV0dXJuIE9iamVjdC5rZXlzKG5leHQpLmxlbmd0aCA9PT0gMDtcbiAgfVxuXG4gIGZ1bmN0aW9uIGJ1aWxkUGF5bG9hZCgpIHtcbiAgICBjb25zdCBwYXlsb2FkID0ge1xuICAgICAgc3R1ZGVudE5hbWU6IGZvcm0uc3R1ZGVudE5hbWUudHJpbSgpLFxuICAgICAgYWdlOiBOdW1iZXIoZm9ybS5hZ2UpLFxuICAgICAgc3R1ZGVudFN0YXRlOiBmb3JtLnN0dWRlbnRTdGF0ZSxcbiAgICAgIGluc3RpdHV0aW9uSWQ6IGZvcm0uaW5zdGl0dXRpb25JZCxcbiAgICAgIGNvdXJzZUlkOiBmb3JtLmNvdXJzZUlkLFxuICAgICAgbG9hbkFtb3VudFJlcXVlc3RlZElucjogTnVtYmVyKGZvcm0ubG9hbkFtb3VudFJlcXVlc3RlZEluciksXG4gICAgICBwYXJlbnRNb250aGx5SW5jb21lSW5yOiBOdW1iZXIoZm9ybS5wYXJlbnRNb250aGx5SW5jb21lSW5yKSxcbiAgICAgIGV4aXN0aW5nTW9udGhseU9ibGlnYXRpb25zSW5yOiBOdW1iZXIoZm9ybS5leGlzdGluZ01vbnRobHlPYmxpZ2F0aW9uc0luciksXG4gICAgICBjcmVkaXRTY29yZTogZm9ybS5jcmVkaXRTY29yZSA9PT0gXCJcIiB8fCBmb3JtLmNyZWRpdFNjb3JlID09PSBudWxsID8gbnVsbCA6IE51bWJlcihmb3JtLmNyZWRpdFNjb3JlKSxcbiAgICAgIGVtcGxveW1lbnRUeXBlOiBmb3JtLmVtcGxveW1lbnRUeXBlLFxuICAgICAgYXBwbGljYXRpb25DaGFubmVsOiBmb3JtLmFwcGxpY2F0aW9uQ2hhbm5lbCxcbiAgICB9O1xuICAgIGlmIChpc0VkaXQpIHtcbiAgICAgIHBheWxvYWQuYXBwbGljYXRpb25TdGF0dXMgPSBmb3JtLmFwcGxpY2F0aW9uU3RhdHVzO1xuICAgICAgcGF5bG9hZC5hcHBsaWNhdGlvbkRhdGUgPSBmb3JtLmFwcGxpY2F0aW9uRGF0ZTtcbiAgICB9XG4gICAgcmV0dXJuIHBheWxvYWQ7XG4gIH1cblxuICBhc3luYyBmdW5jdGlvbiBoYW5kbGVTdWJtaXQoZSkge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBzZXRBcGlFcnJvcihcIlwiKTtcbiAgICBpZiAoIXZhbGlkYXRlKCkpIHJldHVybjtcbiAgICBzZXRTYXZpbmcodHJ1ZSk7XG4gICAgdHJ5IHtcbiAgICAgIGlmIChpc0VkaXQpIHtcbiAgICAgICAgYXdhaXQgaXRlbXNBcGkudXBkYXRlSXRlbShpdGVtLmlkLCBidWlsZFBheWxvYWQoKSk7XG4gICAgICAgIHRvYXN0LnN1Y2Nlc3MoYFJlY29yZCAke2l0ZW0uaWR9IHVwZGF0ZWQgc3VjY2Vzc2Z1bGx5LmApO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uc3QgY3JlYXRlZCA9IGF3YWl0IGl0ZW1zQXBpLmNyZWF0ZUl0ZW0oYnVpbGRQYXlsb2FkKCkpO1xuICAgICAgICB0b2FzdC5zdWNjZXNzKGBSZWNvcmQgJHtjcmVhdGVkLmlkfSBjcmVhdGVkIHN1Y2Nlc3NmdWxseS5gKTtcbiAgICAgIH1cbiAgICAgIG9uU2F2ZWQoKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGlmIChlcnIgaW5zdGFuY2VvZiBBcGlFcnJvciAmJiBlcnIuZGV0YWlscz8ubGVuZ3RoKSB7XG4gICAgICAgIHNldEFwaUVycm9yKGAke2Vyci5tZXNzYWdlfSAke2Vyci5kZXRhaWxzLmpvaW4oXCIgXCIpfWApO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgc2V0QXBpRXJyb3IoZXJyLm1lc3NhZ2UgfHwgXCJVbmFibGUgdG8gc2F2ZSByZWNvcmQuXCIpO1xuICAgICAgfVxuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRTYXZpbmcoZmFsc2UpO1xuICAgIH1cbiAgfVxuXG4gIGlmICghc2hvdykgcmV0dXJuIG51bGw7XG5cbiAgY29uc3QgaW52YWxpZCA9IChmaWVsZCkgPT4gKGVycm9yc1tmaWVsZF0gPyBcImlzLWludmFsaWRcIiA6IFwiXCIpO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtb2RhbCBmYWRlIHNob3cgZC1ibG9ja1wiIHRhYkluZGV4PXstMX0gcm9sZT1cImRpYWxvZ1wiIHN0eWxlPXt7IGJhY2tncm91bmQ6IFwicmdiYSgxNSwyMyw0MiwwLjQ1KVwiIH19IGFyaWEtbW9kYWw9XCJ0cnVlXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1vZGFsLWRpYWxvZyBtb2RhbC1sZyBtb2RhbC1kaWFsb2ctY2VudGVyZWQgbW9kYWwtZGlhbG9nLXNjcm9sbGFibGVcIiByb2xlPVwiZG9jdW1lbnRcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtb2RhbC1jb250ZW50XCI+XG4gICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0gbm9WYWxpZGF0ZT5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibW9kYWwtaGVhZGVyXCI+XG4gICAgICAgICAgICAgIDxoNSBjbGFzc05hbWU9XCJtb2RhbC10aXRsZVwiPlxuICAgICAgICAgICAgICAgIDxpIGNsYXNzTmFtZT17YGJpICR7aXNFZGl0ID8gXCJiaS1wZW5jaWwtc3F1YXJlXCIgOiBcImJpLXBsdXMtY2lyY2xlXCJ9IHRleHQtZGhhbml0aSBtZS0yYH0gYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICAgICAgICB7aXNFZGl0ID8gYEVkaXQgQXBwbGljYXRpb24gJHtpdGVtPy5pZH1gIDogXCJOZXcgTG9hbiBBcHBsaWNhdGlvblwifVxuICAgICAgICAgICAgICA8L2g1PlxuICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJidG4tY2xvc2VcIiBhcmlhLWxhYmVsPVwiQ2xvc2VcIiBvbkNsaWNrPXtvbkNsb3NlfSBkaXNhYmxlZD17c2F2aW5nfSAvPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibW9kYWwtYm9keVwiPlxuICAgICAgICAgICAgICB7YXBpRXJyb3IgJiYgPGRpdiBjbGFzc05hbWU9XCJhbGVydCBhbGVydC1kYW5nZXIgcHktMlwiIHJvbGU9XCJhbGVydFwiPnthcGlFcnJvcn08L2Rpdj59XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgZy0zXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtMTIgY29sLW1kLTZcIj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmb3JtLWxhYmVsXCIgaHRtbEZvcj1cImYtbmFtZVwiPlN0dWRlbnQgbmFtZSAqPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dCBpZD1cImYtbmFtZVwiIGNsYXNzTmFtZT17YGZvcm0tY29udHJvbCAke2ludmFsaWQoXCJzdHVkZW50TmFtZVwiKX1gfSB2YWx1ZT17Zm9ybS5zdHVkZW50TmFtZX0gb25DaGFuZ2U9e3NldChcInN0dWRlbnROYW1lXCIpfSBkaXNhYmxlZD17c2F2aW5nfSAvPlxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5zdHVkZW50TmFtZSAmJiA8ZGl2IGNsYXNzTmFtZT1cImludmFsaWQtZmVlZGJhY2tcIj57ZXJyb3JzLnN0dWRlbnROYW1lfTwvZGl2Pn1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLTYgY29sLW1kLTNcIj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmb3JtLWxhYmVsXCIgaHRtbEZvcj1cImYtYWdlXCI+QWdlICo8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGlucHV0IGlkPVwiZi1hZ2VcIiB0eXBlPVwibnVtYmVyXCIgbWluPXsxNn0gbWF4PXsxMDB9IGNsYXNzTmFtZT17YGZvcm0tY29udHJvbCAke2ludmFsaWQoXCJhZ2VcIil9YH0gdmFsdWU9e2Zvcm0uYWdlfSBvbkNoYW5nZT17c2V0KFwiYWdlXCIpfSBkaXNhYmxlZD17c2F2aW5nfSAvPlxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5hZ2UgJiYgPGRpdiBjbGFzc05hbWU9XCJpbnZhbGlkLWZlZWRiYWNrXCI+e2Vycm9ycy5hZ2V9PC9kaXY+fVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtNiBjb2wtbWQtM1wiPlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZvcm0tbGFiZWxcIiBodG1sRm9yPVwiZi1zdGF0ZVwiPlN0YXRlICo8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPHNlbGVjdCBpZD1cImYtc3RhdGVcIiBjbGFzc05hbWU9e2Bmb3JtLXNlbGVjdCAke2ludmFsaWQoXCJzdHVkZW50U3RhdGVcIil9YH0gdmFsdWU9e2Zvcm0uc3R1ZGVudFN0YXRlfSBvbkNoYW5nZT17c2V0KFwic3R1ZGVudFN0YXRlXCIpfSBkaXNhYmxlZD17c2F2aW5nfT5cbiAgICAgICAgICAgICAgICAgICAge1NUQVRFUy5tYXAoKHMpID0+IDxvcHRpb24ga2V5PXtzfSB2YWx1ZT17c30+e3N9PC9vcHRpb24+KX1cbiAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtMTIgY29sLW1kLTZcIj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmb3JtLWxhYmVsXCIgaHRtbEZvcj1cImYtaW5zdFwiPkluc3RpdHV0aW9uICo8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPHNlbGVjdCBpZD1cImYtaW5zdFwiIGNsYXNzTmFtZT17YGZvcm0tc2VsZWN0ICR7aW52YWxpZChcImluc3RpdHV0aW9uSWRcIil9YH0gdmFsdWU9e2Zvcm0uaW5zdGl0dXRpb25JZH0gb25DaGFuZ2U9e3NldChcImluc3RpdHV0aW9uSWRcIil9IGRpc2FibGVkPXtzYXZpbmd9PlxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWN0IGluc3RpdHV0aW9u4oCmPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgIHsoZmlsdGVycz8uaW5zdGl0dXRpb25zIHx8IFtdKS5tYXAoKGkpID0+IDxvcHRpb24ga2V5PXtpLmlkfSB2YWx1ZT17aS5pZH0+e2kubmFtZX0gKHtpLmlkfSk8L29wdGlvbj4pfVxuICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLmluc3RpdHV0aW9uSWQgJiYgPGRpdiBjbGFzc05hbWU9XCJpbnZhbGlkLWZlZWRiYWNrXCI+e2Vycm9ycy5pbnN0aXR1dGlvbklkfTwvZGl2Pn1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLTEyIGNvbC1tZC02XCI+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZm9ybS1sYWJlbFwiIGh0bWxGb3I9XCJmLWNvdXJzZVwiPkNvdXJzZSAqPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxzZWxlY3QgaWQ9XCJmLWNvdXJzZVwiIGNsYXNzTmFtZT17YGZvcm0tc2VsZWN0ICR7aW52YWxpZChcImNvdXJzZUlkXCIpfWB9IHZhbHVlPXtmb3JtLmNvdXJzZUlkfSBvbkNoYW5nZT17c2V0KFwiY291cnNlSWRcIil9IGRpc2FibGVkPXtzYXZpbmd9PlxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWN0IGNvdXJzZeKApjwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICB7KGZpbHRlcnM/LmNvdXJzZXMgfHwgW10pLm1hcCgoYykgPT4gPG9wdGlvbiBrZXk9e2MuaWR9IHZhbHVlPXtjLmlkfT57Yy5uYW1lfSDigJQge2MuZG9tYWlufXtjLnR5cGljYWxGZWVJbnIgPyBgIChmZWUgJHtmb3JtYXRJTlIoYy50eXBpY2FsRmVlSW5yKX0pYCA6IFwiXCJ9PC9vcHRpb24+KX1cbiAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb3Vyc2VJZCAmJiA8ZGl2IGNsYXNzTmFtZT1cImludmFsaWQtZmVlZGJhY2tcIj57ZXJyb3JzLmNvdXJzZUlkfTwvZGl2Pn1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLTYgY29sLW1kLTRcIj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmb3JtLWxhYmVsXCIgaHRtbEZvcj1cImYtbG9hblwiPkxvYW4gcmVxdWVzdGVkICjigrkpICo8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGlucHV0IGlkPVwiZi1sb2FuXCIgdHlwZT1cIm51bWJlclwiIG1pbj17MTAwMDB9IHN0ZXA9ezEwMDAwfSBjbGFzc05hbWU9e2Bmb3JtLWNvbnRyb2wgJHtpbnZhbGlkKFwibG9hbkFtb3VudFJlcXVlc3RlZEluclwiKX1gfSB2YWx1ZT17Zm9ybS5sb2FuQW1vdW50UmVxdWVzdGVkSW5yfSBvbkNoYW5nZT17c2V0KFwibG9hbkFtb3VudFJlcXVlc3RlZEluclwiKX0gZGlzYWJsZWQ9e3NhdmluZ30gLz5cbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMubG9hbkFtb3VudFJlcXVlc3RlZEluciAmJiA8ZGl2IGNsYXNzTmFtZT1cImludmFsaWQtZmVlZGJhY2tcIj57ZXJyb3JzLmxvYW5BbW91bnRSZXF1ZXN0ZWRJbnJ9PC9kaXY+fVxuICAgICAgICAgICAgICAgICAge3NlbGVjdGVkQ291cnNlPy50eXBpY2FsRmVlSW5yICYmIE51bWJlcihmb3JtLmxvYW5BbW91bnRSZXF1ZXN0ZWRJbnIpID4gc2VsZWN0ZWRDb3Vyc2UudHlwaWNhbEZlZUluciAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS10ZXh0IHRleHQtd2FybmluZ1wiPjxpIGNsYXNzTmFtZT1cImJpIGJpLWV4Y2xhbWF0aW9uLXRyaWFuZ2xlIG1lLTFcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPkV4Y2VlZHMgdHlwaWNhbCBmZWUgKHtmb3JtYXRJTlIoc2VsZWN0ZWRDb3Vyc2UudHlwaWNhbEZlZUlucil9KSDigJQgd2lsbCBiZSBmbGFnZ2VkLjwvZGl2PlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLTYgY29sLW1kLTRcIj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmb3JtLWxhYmVsXCIgaHRtbEZvcj1cImYtaW5jb21lXCI+UGFyZW50IGluY29tZSAo4oK5L21vKSAqPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dCBpZD1cImYtaW5jb21lXCIgdHlwZT1cIm51bWJlclwiIG1pbj17MH0gc3RlcD17MTAwMH0gY2xhc3NOYW1lPXtgZm9ybS1jb250cm9sICR7aW52YWxpZChcInBhcmVudE1vbnRobHlJbmNvbWVJbnJcIil9YH0gdmFsdWU9e2Zvcm0ucGFyZW50TW9udGhseUluY29tZUlucn0gb25DaGFuZ2U9e3NldChcInBhcmVudE1vbnRobHlJbmNvbWVJbnJcIil9IGRpc2FibGVkPXtzYXZpbmd9IC8+XG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLnBhcmVudE1vbnRobHlJbmNvbWVJbnIgJiYgPGRpdiBjbGFzc05hbWU9XCJpbnZhbGlkLWZlZWRiYWNrXCI+e2Vycm9ycy5wYXJlbnRNb250aGx5SW5jb21lSW5yfTwvZGl2Pn1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLTYgY29sLW1kLTRcIj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmb3JtLWxhYmVsXCIgaHRtbEZvcj1cImYtb2JsXCI+RXhpc3Rpbmcgb2JsaWdhdGlvbnMgKOKCuS9tbykgKjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8aW5wdXQgaWQ9XCJmLW9ibFwiIHR5cGU9XCJudW1iZXJcIiBtaW49ezB9IHN0ZXA9ezUwMH0gY2xhc3NOYW1lPXtgZm9ybS1jb250cm9sICR7aW52YWxpZChcImV4aXN0aW5nTW9udGhseU9ibGlnYXRpb25zSW5yXCIpfWB9IHZhbHVlPXtmb3JtLmV4aXN0aW5nTW9udGhseU9ibGlnYXRpb25zSW5yfSBvbkNoYW5nZT17c2V0KFwiZXhpc3RpbmdNb250aGx5T2JsaWdhdGlvbnNJbnJcIil9IGRpc2FibGVkPXtzYXZpbmd9IC8+XG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLmV4aXN0aW5nTW9udGhseU9ibGlnYXRpb25zSW5yICYmIDxkaXYgY2xhc3NOYW1lPVwiaW52YWxpZC1mZWVkYmFja1wiPntlcnJvcnMuZXhpc3RpbmdNb250aGx5T2JsaWdhdGlvbnNJbnJ9PC9kaXY+fVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtNiBjb2wtbWQtNFwiPlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZvcm0tbGFiZWxcIiBodG1sRm9yPVwiZi1zY29yZVwiPkNyZWRpdCBzY29yZTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8aW5wdXQgaWQ9XCJmLXNjb3JlXCIgdHlwZT1cIm51bWJlclwiIG1pbj17MzAwfSBtYXg9ezkwMH0gcGxhY2Vob2xkZXI9XCIzMDDigJM5MDAgKG9wdGlvbmFsKVwiIGNsYXNzTmFtZT17YGZvcm0tY29udHJvbCAke2ludmFsaWQoXCJjcmVkaXRTY29yZVwiKX1gfSB2YWx1ZT17Zm9ybS5jcmVkaXRTY29yZSA/PyBcIlwifSBvbkNoYW5nZT17c2V0KFwiY3JlZGl0U2NvcmVcIil9IGRpc2FibGVkPXtzYXZpbmd9IC8+XG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNyZWRpdFNjb3JlICYmIDxkaXYgY2xhc3NOYW1lPVwiaW52YWxpZC1mZWVkYmFja1wiPntlcnJvcnMuY3JlZGl0U2NvcmV9PC9kaXY+fVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtNiBjb2wtbWQtNFwiPlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZvcm0tbGFiZWxcIiBodG1sRm9yPVwiZi1lbXBcIj5FbXBsb3ltZW50IHR5cGUgKjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8c2VsZWN0IGlkPVwiZi1lbXBcIiBjbGFzc05hbWU9e2Bmb3JtLXNlbGVjdCAke2ludmFsaWQoXCJlbXBsb3ltZW50VHlwZVwiKX1gfSB2YWx1ZT17Zm9ybS5lbXBsb3ltZW50VHlwZX0gb25DaGFuZ2U9e3NldChcImVtcGxveW1lbnRUeXBlXCIpfSBkaXNhYmxlZD17c2F2aW5nfT5cbiAgICAgICAgICAgICAgICAgICAge0VNUExPWU1FTlQubWFwKChzKSA9PiA8b3B0aW9uIGtleT17c30gdmFsdWU9e3N9PntzfTwvb3B0aW9uPil9XG4gICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLTYgY29sLW1kLTRcIj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmb3JtLWxhYmVsXCIgaHRtbEZvcj1cImYtY2hhblwiPkNoYW5uZWwgKjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8c2VsZWN0IGlkPVwiZi1jaGFuXCIgY2xhc3NOYW1lPXtgZm9ybS1zZWxlY3QgJHtpbnZhbGlkKFwiYXBwbGljYXRpb25DaGFubmVsXCIpfWB9IHZhbHVlPXtmb3JtLmFwcGxpY2F0aW9uQ2hhbm5lbH0gb25DaGFuZ2U9e3NldChcImFwcGxpY2F0aW9uQ2hhbm5lbFwiKX0gZGlzYWJsZWQ9e3NhdmluZ30+XG4gICAgICAgICAgICAgICAgICAgIHtDSEFOTkVMUy5tYXAoKHMpID0+IDxvcHRpb24ga2V5PXtzfSB2YWx1ZT17c30+e3N9PC9vcHRpb24+KX1cbiAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAge2lzRWRpdCAmJiAoXG4gICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC02IGNvbC1tZC02XCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZvcm0tbGFiZWxcIiBodG1sRm9yPVwiZi1zdGF0dXNcIj5TdGF0dXMgKjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdCBpZD1cImYtc3RhdHVzXCIgY2xhc3NOYW1lPXtgZm9ybS1zZWxlY3QgJHtpbnZhbGlkKFwiYXBwbGljYXRpb25TdGF0dXNcIil9YH0gdmFsdWU9e2Zvcm0uYXBwbGljYXRpb25TdGF0dXN9IG9uQ2hhbmdlPXtzZXQoXCJhcHBsaWNhdGlvblN0YXR1c1wiKX0gZGlzYWJsZWQ9e3NhdmluZ30+XG4gICAgICAgICAgICAgICAgICAgICAgICB7U1RBVFVTRVMubWFwKChzKSA9PiA8b3B0aW9uIGtleT17c30gdmFsdWU9e3N9PntzfTwvb3B0aW9uPil9XG4gICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC02IGNvbC1tZC02XCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZvcm0tbGFiZWxcIiBodG1sRm9yPVwiZi1kYXRlXCI+QXBwbGljYXRpb24gZGF0ZSAqPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgaWQ9XCJmLWRhdGVcIiB0eXBlPVwiZGF0ZVwiIGNsYXNzTmFtZT17YGZvcm0tY29udHJvbCAke2ludmFsaWQoXCJhcHBsaWNhdGlvbkRhdGVcIil9YH0gdmFsdWU9e2Zvcm0uYXBwbGljYXRpb25EYXRlfSBvbkNoYW5nZT17c2V0KFwiYXBwbGljYXRpb25EYXRlXCIpfSBkaXNhYmxlZD17c2F2aW5nfSAvPlxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuYXBwbGljYXRpb25EYXRlICYmIDxkaXYgY2xhc3NOYW1lPVwiaW52YWxpZC1mZWVkYmFja1wiPntlcnJvcnMuYXBwbGljYXRpb25EYXRlfTwvZGl2Pn1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1vZGFsLWZvb3RlclwiPlxuICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJidG4gYnRuLW91dGxpbmUtc2Vjb25kYXJ5XCIgb25DbGljaz17b25DbG9zZX0gZGlzYWJsZWQ9e3NhdmluZ30+Q2FuY2VsPC9idXR0b24+XG4gICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiIGNsYXNzTmFtZT1cImJ0biBidG4tZGhhbml0aVwiIGRpc2FibGVkPXtzYXZpbmd9PlxuICAgICAgICAgICAgICAgIHtzYXZpbmcgPyAoXG4gICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzcGlubmVyLWJvcmRlciBzcGlubmVyLWJvcmRlci1zbSBtZS0yXCIgcm9sZT1cInN0YXR1c1wiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgICAgICAgICAgIFNhdmluZ+KAplxuICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgKSA6IGlzRWRpdCA/IFwiU2F2ZSBjaGFuZ2VzXCIgOiBcIkNyZWF0ZSByZWNvcmRcIn1cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6IkM6L1VzZXJzL3VzZXIvRG93bmxvYWRzL2RoYW5pdGktYXBwLXVwZ3JhZGVkL2RoYW5pdGktYXBwL2Zyb250ZW5kL3NyYy9jb21wb25lbnRzL0l0ZW1Gb3JtTW9kYWwuanN4In0=