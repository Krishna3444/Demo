import { t as __commonJSMin } from "/node_modules/.vite/deps/rolldown-runtime-BPOCksWG.js?v=325d36c7";
//#region node_modules/bootstrap/dist/js/bootstrap.bundle.min.js
var require_bootstrap_bundle_min = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/*!
	* Bootstrap v5.3.8 (https://getbootstrap.com/)
	* Copyright 2011-2025 The Bootstrap Authors (https://github.com/twbs/bootstrap/graphs/contributors)
	* Licensed under MIT (https://github.com/twbs/bootstrap/blob/main/LICENSE)
	*/
	(function(t, e) {
		"object" == typeof exports && "undefined" != typeof module ? module.exports = e() : "function" == typeof define && define.amd ? define(e) : (t = "undefined" != typeof globalThis ? globalThis : t || self).bootstrap = e();
	})(exports, function() {
		"use strict";
		const t = /* @__PURE__ */ new Map(), e = {
			set(e, i, n) {
				t.has(e) || t.set(e, /* @__PURE__ */ new Map());
				const s = t.get(e);
				s.has(i) || 0 === s.size ? s.set(i, n) : console.error(`Bootstrap doesn't allow more than one instance per element. Bound instance: ${Array.from(s.keys())[0]}.`);
			},
			get: (e, i) => t.has(e) && t.get(e).get(i) || null,
			remove(e, i) {
				if (!t.has(e)) return;
				const n = t.get(e);
				n.delete(i), 0 === n.size && t.delete(e);
			}
		}, i = "transitionend", n = (t) => (t && window.CSS && window.CSS.escape && (t = t.replace(/#([^\s"#']+)/g, (t, e) => `#${CSS.escape(e)}`)), t), s = (t) => null == t ? `${t}` : Object.prototype.toString.call(t).match(/\s([a-z]+)/i)[1].toLowerCase(), o = (t) => {
			t.dispatchEvent(new Event(i));
		}, r = (t) => !(!t || "object" != typeof t) && (void 0 !== t.jquery && (t = t[0]), void 0 !== t.nodeType), a = (t) => r(t) ? t.jquery ? t[0] : t : "string" == typeof t && t.length > 0 ? document.querySelector(n(t)) : null, l = (t) => {
			if (!r(t) || 0 === t.getClientRects().length) return !1;
			const e = "visible" === getComputedStyle(t).getPropertyValue("visibility"), i = t.closest("details:not([open])");
			if (!i) return e;
			if (i !== t) {
				const e = t.closest("summary");
				if (e && e.parentNode !== i) return !1;
				if (null === e) return !1;
			}
			return e;
		}, c = (t) => !t || t.nodeType !== Node.ELEMENT_NODE || !!t.classList.contains("disabled") || (void 0 !== t.disabled ? t.disabled : t.hasAttribute("disabled") && "false" !== t.getAttribute("disabled")), h = (t) => {
			if (!document.documentElement.attachShadow) return null;
			if ("function" == typeof t.getRootNode) {
				const e = t.getRootNode();
				return e instanceof ShadowRoot ? e : null;
			}
			return t instanceof ShadowRoot ? t : t.parentNode ? h(t.parentNode) : null;
		}, d = () => {}, u = (t) => {
			t.offsetHeight;
		}, f = () => window.jQuery && !document.body.hasAttribute("data-bs-no-jquery") ? window.jQuery : null, p = [], m = () => "rtl" === document.documentElement.dir, g = (t) => {
			var e = () => {
				const e = f();
				if (e) {
					const i = t.NAME, n = e.fn[i];
					e.fn[i] = t.jQueryInterface, e.fn[i].Constructor = t, e.fn[i].noConflict = () => (e.fn[i] = n, t.jQueryInterface);
				}
			};
			"loading" === document.readyState ? (p.length || document.addEventListener("DOMContentLoaded", () => {
				for (const t of p) t();
			}), p.push(e)) : e();
		}, _ = (t, e = [], i = t) => "function" == typeof t ? t.call(...e) : i, b = (t, e, n = !0) => {
			if (!n) return void _(t);
			const s = ((t) => {
				if (!t) return 0;
				let { transitionDuration: e, transitionDelay: i } = window.getComputedStyle(t);
				return Number.parseFloat(e) || Number.parseFloat(i) ? (e = e.split(",")[0], i = i.split(",")[0], 1e3 * (Number.parseFloat(e) + Number.parseFloat(i))) : 0;
			})(e) + 5;
			let r = !1;
			const a = ({ target: n }) => {
				n === e && (r = !0, e.removeEventListener(i, a), _(t));
			};
			e.addEventListener(i, a), setTimeout(() => {
				r || o(e);
			}, s);
		}, v = (t, e, i, n) => {
			const s = t.length;
			let o = t.indexOf(e);
			return -1 === o ? !i && n ? t[s - 1] : t[0] : (o += i ? 1 : -1, n && (o = (o + s) % s), t[Math.max(0, Math.min(o, s - 1))]);
		}, y = /[^.]*(?=\..*)\.|.*/, w = /\..*/, A = /::\d+$/, E = {};
		let T = 1;
		const C = {
			mouseenter: "mouseover",
			mouseleave: "mouseout"
		}, O = /* @__PURE__ */ new Set([
			"click",
			"dblclick",
			"mouseup",
			"mousedown",
			"contextmenu",
			"mousewheel",
			"DOMMouseScroll",
			"mouseover",
			"mouseout",
			"mousemove",
			"selectstart",
			"selectend",
			"keydown",
			"keypress",
			"keyup",
			"orientationchange",
			"touchstart",
			"touchmove",
			"touchend",
			"touchcancel",
			"pointerdown",
			"pointermove",
			"pointerup",
			"pointerleave",
			"pointercancel",
			"gesturestart",
			"gesturechange",
			"gestureend",
			"focus",
			"blur",
			"change",
			"reset",
			"select",
			"submit",
			"focusin",
			"focusout",
			"load",
			"unload",
			"beforeunload",
			"resize",
			"move",
			"DOMContentLoaded",
			"readystatechange",
			"error",
			"abort",
			"scroll"
		]);
		function x(t, e) {
			return e && `${e}::${T++}` || t.uidEvent || T++;
		}
		function k(t) {
			const e = x(t);
			return t.uidEvent = e, E[e] = E[e] || {}, E[e];
		}
		function L(t, e, i = null) {
			return Object.values(t).find((t) => t.callable === e && t.delegationSelector === i);
		}
		function S(t, e, i) {
			const n = "string" == typeof e, s = n ? i : e || i;
			let o = N(t);
			return O.has(o) || (o = t), [
				n,
				s,
				o
			];
		}
		function D(t, e, i, n, s) {
			if ("string" != typeof e || !t) return;
			let [o, r, a] = S(e, i, n);
			if (e in C) {
				const t = (t) => function(e) {
					if (!e.relatedTarget || e.relatedTarget !== e.delegateTarget && !e.delegateTarget.contains(e.relatedTarget)) return t.call(this, e);
				};
				r = t(r);
			}
			const l = k(t), c = l[a] || (l[a] = {}), h = L(c, r, o ? i : null);
			if (h) return void (h.oneOff = h.oneOff && s);
			const d = x(r, e.replace(y, "")), u = o ? function(t, e, i) {
				return function n(s) {
					const o = t.querySelectorAll(e);
					for (let { target: r } = s; r && r !== this; r = r.parentNode) for (const a of o) if (a === r) return j(s, { delegateTarget: r }), n.oneOff && P.off(t, s.type, e, i), i.apply(r, [s]);
				};
			}(t, i, r) : function(t, e) {
				return function i(n) {
					return j(n, { delegateTarget: t }), i.oneOff && P.off(t, n.type, e), e.apply(t, [n]);
				};
			}(t, r);
			u.delegationSelector = o ? i : null, u.callable = r, u.oneOff = s, u.uidEvent = d, c[d] = u, t.addEventListener(a, u, o);
		}
		function $(t, e, i, n, s) {
			const o = L(e[i], n, s);
			o && (t.removeEventListener(i, o, Boolean(s)), delete e[i][o.uidEvent]);
		}
		function I(t, e, i, n) {
			const s = e[i] || {};
			for (const [o, r] of Object.entries(s)) o.includes(n) && $(t, e, i, r.callable, r.delegationSelector);
		}
		function N(t) {
			return t = t.replace(w, ""), C[t] || t;
		}
		const P = {
			on(t, e, i, n) {
				D(t, e, i, n, !1);
			},
			one(t, e, i, n) {
				D(t, e, i, n, !0);
			},
			off(t, e, i, n) {
				if ("string" != typeof e || !t) return;
				const [s, o, r] = S(e, i, n), a = r !== e, l = k(t), c = l[r] || {}, h = e.startsWith(".");
				if (void 0 === o) {
					if (h) for (const i of Object.keys(l)) I(t, l, i, e.slice(1));
					for (const [i, n] of Object.entries(c)) {
						const s = i.replace(A, "");
						a && !e.includes(s) || $(t, l, r, n.callable, n.delegationSelector);
					}
				} else {
					if (!Object.keys(c).length) return;
					$(t, l, r, o, s ? i : null);
				}
			},
			trigger(t, e, i) {
				if ("string" != typeof e || !t) return null;
				const n = f();
				let s = null, o = !0, r = !0, a = !1;
				e !== N(e) && n && (s = n.Event(e, i), n(t).trigger(s), o = !s.isPropagationStopped(), r = !s.isImmediatePropagationStopped(), a = s.isDefaultPrevented());
				const l = j(new Event(e, {
					bubbles: o,
					cancelable: !0
				}), i);
				return a && l.preventDefault(), r && t.dispatchEvent(l), l.defaultPrevented && s && s.preventDefault(), l;
			}
		};
		function j(t, e = {}) {
			for (const [i, n] of Object.entries(e)) try {
				t[i] = n;
			} catch (e) {
				Object.defineProperty(t, i, {
					configurable: !0,
					get: () => n
				});
			}
			return t;
		}
		function M(t) {
			if ("true" === t) return !0;
			if ("false" === t) return !1;
			if (t === Number(t).toString()) return Number(t);
			if ("" === t || "null" === t) return null;
			if ("string" != typeof t) return t;
			try {
				return JSON.parse(decodeURIComponent(t));
			} catch (e) {
				return t;
			}
		}
		function F(t) {
			return t.replace(/[A-Z]/g, (t) => `-${t.toLowerCase()}`);
		}
		const H = {
			setDataAttribute(t, e, i) {
				t.setAttribute(`data-bs-${F(e)}`, i);
			},
			removeDataAttribute(t, e) {
				t.removeAttribute(`data-bs-${F(e)}`);
			},
			getDataAttributes(t) {
				if (!t) return {};
				const e = {}, i = Object.keys(t.dataset).filter((t) => t.startsWith("bs") && !t.startsWith("bsConfig"));
				for (const n of i) {
					let i = n.replace(/^bs/, "");
					i = i.charAt(0).toLowerCase() + i.slice(1), e[i] = M(t.dataset[n]);
				}
				return e;
			},
			getDataAttribute: (t, e) => M(t.getAttribute(`data-bs-${F(e)}`))
		};
		class W {
			static get Default() {
				return {};
			}
			static get DefaultType() {
				return {};
			}
			static get NAME() {
				throw new Error("You have to implement the static method \"NAME\", for each component!");
			}
			_getConfig(t) {
				return t = this._mergeConfigObj(t), t = this._configAfterMerge(t), this._typeCheckConfig(t), t;
			}
			_configAfterMerge(t) {
				return t;
			}
			_mergeConfigObj(t, e) {
				const i = r(e) ? H.getDataAttribute(e, "config") : {};
				return {
					...this.constructor.Default,
					..."object" == typeof i ? i : {},
					...r(e) ? H.getDataAttributes(e) : {},
					..."object" == typeof t ? t : {}
				};
			}
			_typeCheckConfig(t, e = this.constructor.DefaultType) {
				for (const [i, n] of Object.entries(e)) {
					const e = t[i], o = r(e) ? "element" : s(e);
					if (!new RegExp(n).test(o)) throw new TypeError(`${this.constructor.NAME.toUpperCase()}: Option "${i}" provided type "${o}" but expected type "${n}".`);
				}
			}
		}
		class B extends W {
			constructor(t, i) {
				super(), (t = a(t)) && (this._element = t, this._config = this._getConfig(i), e.set(this._element, this.constructor.DATA_KEY, this));
			}
			dispose() {
				e.remove(this._element, this.constructor.DATA_KEY), P.off(this._element, this.constructor.EVENT_KEY);
				for (const t of Object.getOwnPropertyNames(this)) this[t] = null;
			}
			_queueCallback(t, e, i = !0) {
				b(t, e, i);
			}
			_getConfig(t) {
				return t = this._mergeConfigObj(t, this._element), t = this._configAfterMerge(t), this._typeCheckConfig(t), t;
			}
			static getInstance(t) {
				return e.get(a(t), this.DATA_KEY);
			}
			static getOrCreateInstance(t, e = {}) {
				return this.getInstance(t) || new this(t, "object" == typeof e ? e : null);
			}
			static get VERSION() {
				return "5.3.8";
			}
			static get DATA_KEY() {
				return `bs.${this.NAME}`;
			}
			static get EVENT_KEY() {
				return `.${this.DATA_KEY}`;
			}
			static eventName(t) {
				return `${t}${this.EVENT_KEY}`;
			}
		}
		const z = (t) => {
			let e = t.getAttribute("data-bs-target");
			if (!e || "#" === e) {
				let i = t.getAttribute("href");
				if (!i || !i.includes("#") && !i.startsWith(".")) return null;
				i.includes("#") && !i.startsWith("#") && (i = `#${i.split("#")[1]}`), e = i && "#" !== i ? i.trim() : null;
			}
			return e ? e.split(",").map((t) => n(t)).join(",") : null;
		}, R = {
			find: (t, e = document.documentElement) => [].concat(...Element.prototype.querySelectorAll.call(e, t)),
			findOne: (t, e = document.documentElement) => Element.prototype.querySelector.call(e, t),
			children: (t, e) => [].concat(...t.children).filter((t) => t.matches(e)),
			parents(t, e) {
				const i = [];
				let n = t.parentNode.closest(e);
				for (; n;) i.push(n), n = n.parentNode.closest(e);
				return i;
			},
			prev(t, e) {
				let i = t.previousElementSibling;
				for (; i;) {
					if (i.matches(e)) return [i];
					i = i.previousElementSibling;
				}
				return [];
			},
			next(t, e) {
				let i = t.nextElementSibling;
				for (; i;) {
					if (i.matches(e)) return [i];
					i = i.nextElementSibling;
				}
				return [];
			},
			focusableChildren(t) {
				const e = [
					"a",
					"button",
					"input",
					"textarea",
					"select",
					"details",
					"[tabindex]",
					"[contenteditable=\"true\"]"
				].map((t) => `${t}:not([tabindex^="-"])`).join(",");
				return this.find(e, t).filter((t) => !c(t) && l(t));
			},
			getSelectorFromElement(t) {
				const e = z(t);
				return e && R.findOne(e) ? e : null;
			},
			getElementFromSelector(t) {
				const e = z(t);
				return e ? R.findOne(e) : null;
			},
			getMultipleElementsFromSelector(t) {
				const e = z(t);
				return e ? R.find(e) : [];
			}
		}, q = (t, e = "hide") => {
			const i = `click.dismiss${t.EVENT_KEY}`, n = t.NAME;
			P.on(document, i, `[data-bs-dismiss="${n}"]`, function(i) {
				if (["A", "AREA"].includes(this.tagName) && i.preventDefault(), c(this)) return;
				const s = R.getElementFromSelector(this) || this.closest(`.${n}`);
				t.getOrCreateInstance(s)[e]();
			});
		}, V = ".bs.alert", K = `close${V}`, Q = `closed${V}`;
		class X extends B {
			static get NAME() {
				return "alert";
			}
			close() {
				if (P.trigger(this._element, K).defaultPrevented) return;
				this._element.classList.remove("show");
				const t = this._element.classList.contains("fade");
				this._queueCallback(() => this._destroyElement(), this._element, t);
			}
			_destroyElement() {
				this._element.remove(), P.trigger(this._element, Q), this.dispose();
			}
			static jQueryInterface(t) {
				return this.each(function() {
					const e = X.getOrCreateInstance(this);
					if ("string" == typeof t) {
						if (void 0 === e[t] || t.startsWith("_") || "constructor" === t) throw new TypeError(`No method named "${t}"`);
						e[t](this);
					}
				});
			}
		}
		q(X, "close"), g(X);
		const Y = "[data-bs-toggle=\"button\"]";
		class U extends B {
			static get NAME() {
				return "button";
			}
			toggle() {
				this._element.setAttribute("aria-pressed", this._element.classList.toggle("active"));
			}
			static jQueryInterface(t) {
				return this.each(function() {
					const e = U.getOrCreateInstance(this);
					"toggle" === t && e[t]();
				});
			}
		}
		P.on(document, "click.bs.button.data-api", Y, (t) => {
			t.preventDefault();
			const e = t.target.closest(Y);
			U.getOrCreateInstance(e).toggle();
		}), g(U);
		const G = ".bs.swipe", J = `touchstart${G}`, Z = `touchmove${G}`, tt = `touchend${G}`, et = `pointerdown${G}`, it = `pointerup${G}`, nt = {
			endCallback: null,
			leftCallback: null,
			rightCallback: null
		}, st = {
			endCallback: "(function|null)",
			leftCallback: "(function|null)",
			rightCallback: "(function|null)"
		};
		class ot extends W {
			constructor(t, e) {
				super(), this._element = t, t && ot.isSupported() && (this._config = this._getConfig(e), this._deltaX = 0, this._supportPointerEvents = Boolean(window.PointerEvent), this._initEvents());
			}
			static get Default() {
				return nt;
			}
			static get DefaultType() {
				return st;
			}
			static get NAME() {
				return "swipe";
			}
			dispose() {
				P.off(this._element, G);
			}
			_start(t) {
				this._supportPointerEvents ? this._eventIsPointerPenTouch(t) && (this._deltaX = t.clientX) : this._deltaX = t.touches[0].clientX;
			}
			_end(t) {
				this._eventIsPointerPenTouch(t) && (this._deltaX = t.clientX - this._deltaX), this._handleSwipe(), _(this._config.endCallback);
			}
			_move(t) {
				this._deltaX = t.touches && t.touches.length > 1 ? 0 : t.touches[0].clientX - this._deltaX;
			}
			_handleSwipe() {
				const t = Math.abs(this._deltaX);
				if (t <= 40) return;
				const e = t / this._deltaX;
				this._deltaX = 0, e && _(e > 0 ? this._config.rightCallback : this._config.leftCallback);
			}
			_initEvents() {
				this._supportPointerEvents ? (P.on(this._element, et, (t) => this._start(t)), P.on(this._element, it, (t) => this._end(t)), this._element.classList.add("pointer-event")) : (P.on(this._element, J, (t) => this._start(t)), P.on(this._element, Z, (t) => this._move(t)), P.on(this._element, tt, (t) => this._end(t)));
			}
			_eventIsPointerPenTouch(t) {
				return this._supportPointerEvents && ("pen" === t.pointerType || "touch" === t.pointerType);
			}
			static isSupported() {
				return "ontouchstart" in document.documentElement || navigator.maxTouchPoints > 0;
			}
		}
		const rt = ".bs.carousel", at = ".data-api", lt = "ArrowLeft", ct = "ArrowRight", ht = "next", dt = "prev", ut = "left", ft = "right", pt = `slide${rt}`, mt = `slid${rt}`, gt = `keydown${rt}`, _t = `mouseenter${rt}`, bt = `mouseleave${rt}`, vt = `dragstart${rt}`, yt = `load${rt}${at}`, wt = `click${rt}${at}`, At = "carousel", Et = "active", Tt = ".active", Ct = ".carousel-item", Ot = Tt + Ct, xt = {
			[lt]: ft,
			[ct]: ut
		}, kt = {
			interval: 5e3,
			keyboard: !0,
			pause: "hover",
			ride: !1,
			touch: !0,
			wrap: !0
		}, Lt = {
			interval: "(number|boolean)",
			keyboard: "boolean",
			pause: "(string|boolean)",
			ride: "(boolean|string)",
			touch: "boolean",
			wrap: "boolean"
		};
		class St extends B {
			constructor(t, e) {
				super(t, e), this._interval = null, this._activeElement = null, this._isSliding = !1, this.touchTimeout = null, this._swipeHelper = null, this._indicatorsElement = R.findOne(".carousel-indicators", this._element), this._addEventListeners(), this._config.ride === At && this.cycle();
			}
			static get Default() {
				return kt;
			}
			static get DefaultType() {
				return Lt;
			}
			static get NAME() {
				return "carousel";
			}
			next() {
				this._slide(ht);
			}
			nextWhenVisible() {
				!document.hidden && l(this._element) && this.next();
			}
			prev() {
				this._slide(dt);
			}
			pause() {
				this._isSliding && o(this._element), this._clearInterval();
			}
			cycle() {
				this._clearInterval(), this._updateInterval(), this._interval = setInterval(() => this.nextWhenVisible(), this._config.interval);
			}
			_maybeEnableCycle() {
				this._config.ride && (this._isSliding ? P.one(this._element, mt, () => this.cycle()) : this.cycle());
			}
			to(t) {
				const e = this._getItems();
				if (t > e.length - 1 || t < 0) return;
				if (this._isSliding) return void P.one(this._element, mt, () => this.to(t));
				const i = this._getItemIndex(this._getActive());
				if (i === t) return;
				const n = t > i ? ht : dt;
				this._slide(n, e[t]);
			}
			dispose() {
				this._swipeHelper && this._swipeHelper.dispose(), super.dispose();
			}
			_configAfterMerge(t) {
				return t.defaultInterval = t.interval, t;
			}
			_addEventListeners() {
				this._config.keyboard && P.on(this._element, gt, (t) => this._keydown(t)), "hover" === this._config.pause && (P.on(this._element, _t, () => this.pause()), P.on(this._element, bt, () => this._maybeEnableCycle())), this._config.touch && ot.isSupported() && this._addTouchEventListeners();
			}
			_addTouchEventListeners() {
				for (const t of R.find(".carousel-item img", this._element)) P.on(t, vt, (t) => t.preventDefault());
				const t = {
					leftCallback: () => this._slide(this._directionToOrder(ut)),
					rightCallback: () => this._slide(this._directionToOrder(ft)),
					endCallback: () => {
						"hover" === this._config.pause && (this.pause(), this.touchTimeout && clearTimeout(this.touchTimeout), this.touchTimeout = setTimeout(() => this._maybeEnableCycle(), 500 + this._config.interval));
					}
				};
				this._swipeHelper = new ot(this._element, t);
			}
			_keydown(t) {
				if (/input|textarea/i.test(t.target.tagName)) return;
				const e = xt[t.key];
				e && (t.preventDefault(), this._slide(this._directionToOrder(e)));
			}
			_getItemIndex(t) {
				return this._getItems().indexOf(t);
			}
			_setActiveIndicatorElement(t) {
				if (!this._indicatorsElement) return;
				const e = R.findOne(Tt, this._indicatorsElement);
				e.classList.remove(Et), e.removeAttribute("aria-current");
				const i = R.findOne(`[data-bs-slide-to="${t}"]`, this._indicatorsElement);
				i && (i.classList.add(Et), i.setAttribute("aria-current", "true"));
			}
			_updateInterval() {
				const t = this._activeElement || this._getActive();
				if (!t) return;
				const e = Number.parseInt(t.getAttribute("data-bs-interval"), 10);
				this._config.interval = e || this._config.defaultInterval;
			}
			_slide(t, e = null) {
				if (this._isSliding) return;
				const i = this._getActive(), n = t === ht, s = e || v(this._getItems(), i, n, this._config.wrap);
				if (s === i) return;
				const o = this._getItemIndex(s), r = (e) => P.trigger(this._element, e, {
					relatedTarget: s,
					direction: this._orderToDirection(t),
					from: this._getItemIndex(i),
					to: o
				});
				if (r(pt).defaultPrevented) return;
				if (!i || !s) return;
				const a = Boolean(this._interval);
				this.pause(), this._isSliding = !0, this._setActiveIndicatorElement(o), this._activeElement = s;
				const l = n ? "carousel-item-start" : "carousel-item-end", c = n ? "carousel-item-next" : "carousel-item-prev";
				s.classList.add(c), u(s), i.classList.add(l), s.classList.add(l), this._queueCallback(() => {
					s.classList.remove(l, c), s.classList.add(Et), i.classList.remove(Et, c, l), this._isSliding = !1, r(mt);
				}, i, this._isAnimated()), a && this.cycle();
			}
			_isAnimated() {
				return this._element.classList.contains("slide");
			}
			_getActive() {
				return R.findOne(Ot, this._element);
			}
			_getItems() {
				return R.find(Ct, this._element);
			}
			_clearInterval() {
				this._interval && (clearInterval(this._interval), this._interval = null);
			}
			_directionToOrder(t) {
				return m() ? t === ut ? dt : ht : t === ut ? ht : dt;
			}
			_orderToDirection(t) {
				return m() ? t === dt ? ut : ft : t === dt ? ft : ut;
			}
			static jQueryInterface(t) {
				return this.each(function() {
					const e = St.getOrCreateInstance(this, t);
					if ("number" != typeof t) {
						if ("string" == typeof t) {
							if (void 0 === e[t] || t.startsWith("_") || "constructor" === t) throw new TypeError(`No method named "${t}"`);
							e[t]();
						}
					} else e.to(t);
				});
			}
		}
		P.on(document, wt, "[data-bs-slide], [data-bs-slide-to]", function(t) {
			const e = R.getElementFromSelector(this);
			if (!e || !e.classList.contains(At)) return;
			t.preventDefault();
			const i = St.getOrCreateInstance(e), n = this.getAttribute("data-bs-slide-to");
			n ? (i.to(n), i._maybeEnableCycle()) : "next" === H.getDataAttribute(this, "slide") ? (i.next(), i._maybeEnableCycle()) : (i.prev(), i._maybeEnableCycle());
		}), P.on(window, yt, () => {
			const t = R.find("[data-bs-ride=\"carousel\"]");
			for (const e of t) St.getOrCreateInstance(e);
		}), g(St);
		const Dt = ".bs.collapse", $t = `show${Dt}`, It = `shown${Dt}`, Nt = `hide${Dt}`, Pt = `hidden${Dt}`, jt = `click${Dt}.data-api`, Mt = "show", Ft = "collapse", Ht = "collapsing", Wt = `:scope .${Ft} .${Ft}`, Bt = "[data-bs-toggle=\"collapse\"]", zt = {
			parent: null,
			toggle: !0
		}, Rt = {
			parent: "(null|element)",
			toggle: "boolean"
		};
		class qt extends B {
			constructor(t, e) {
				super(t, e), this._isTransitioning = !1, this._triggerArray = [];
				const i = R.find(Bt);
				for (const t of i) {
					const e = R.getSelectorFromElement(t), i = R.find(e).filter((t) => t === this._element);
					null !== e && i.length && this._triggerArray.push(t);
				}
				this._initializeChildren(), this._config.parent || this._addAriaAndCollapsedClass(this._triggerArray, this._isShown()), this._config.toggle && this.toggle();
			}
			static get Default() {
				return zt;
			}
			static get DefaultType() {
				return Rt;
			}
			static get NAME() {
				return "collapse";
			}
			toggle() {
				this._isShown() ? this.hide() : this.show();
			}
			show() {
				if (this._isTransitioning || this._isShown()) return;
				let t = [];
				if (this._config.parent && (t = this._getFirstLevelChildren(".collapse.show, .collapse.collapsing").filter((t) => t !== this._element).map((t) => qt.getOrCreateInstance(t, { toggle: !1 }))), t.length && t[0]._isTransitioning) return;
				if (P.trigger(this._element, $t).defaultPrevented) return;
				for (const e of t) e.hide();
				const e = this._getDimension();
				this._element.classList.remove(Ft), this._element.classList.add(Ht), this._element.style[e] = 0, this._addAriaAndCollapsedClass(this._triggerArray, !0), this._isTransitioning = !0;
				const i = `scroll${e[0].toUpperCase() + e.slice(1)}`;
				this._queueCallback(() => {
					this._isTransitioning = !1, this._element.classList.remove(Ht), this._element.classList.add(Ft, Mt), this._element.style[e] = "", P.trigger(this._element, It);
				}, this._element, !0), this._element.style[e] = `${this._element[i]}px`;
			}
			hide() {
				if (this._isTransitioning || !this._isShown()) return;
				if (P.trigger(this._element, Nt).defaultPrevented) return;
				const t = this._getDimension();
				this._element.style[t] = `${this._element.getBoundingClientRect()[t]}px`, u(this._element), this._element.classList.add(Ht), this._element.classList.remove(Ft, Mt);
				for (const t of this._triggerArray) {
					const e = R.getElementFromSelector(t);
					e && !this._isShown(e) && this._addAriaAndCollapsedClass([t], !1);
				}
				this._isTransitioning = !0, this._element.style[t] = "", this._queueCallback(() => {
					this._isTransitioning = !1, this._element.classList.remove(Ht), this._element.classList.add(Ft), P.trigger(this._element, Pt);
				}, this._element, !0);
			}
			_isShown(t = this._element) {
				return t.classList.contains(Mt);
			}
			_configAfterMerge(t) {
				return t.toggle = Boolean(t.toggle), t.parent = a(t.parent), t;
			}
			_getDimension() {
				return this._element.classList.contains("collapse-horizontal") ? "width" : "height";
			}
			_initializeChildren() {
				if (!this._config.parent) return;
				const t = this._getFirstLevelChildren(Bt);
				for (const e of t) {
					const t = R.getElementFromSelector(e);
					t && this._addAriaAndCollapsedClass([e], this._isShown(t));
				}
			}
			_getFirstLevelChildren(t) {
				const e = R.find(Wt, this._config.parent);
				return R.find(t, this._config.parent).filter((t) => !e.includes(t));
			}
			_addAriaAndCollapsedClass(t, e) {
				if (t.length) for (const i of t) i.classList.toggle("collapsed", !e), i.setAttribute("aria-expanded", e);
			}
			static jQueryInterface(t) {
				const e = {};
				return "string" == typeof t && /show|hide/.test(t) && (e.toggle = !1), this.each(function() {
					const i = qt.getOrCreateInstance(this, e);
					if ("string" == typeof t) {
						if (void 0 === i[t]) throw new TypeError(`No method named "${t}"`);
						i[t]();
					}
				});
			}
		}
		P.on(document, jt, Bt, function(t) {
			("A" === t.target.tagName || t.delegateTarget && "A" === t.delegateTarget.tagName) && t.preventDefault();
			for (const t of R.getMultipleElementsFromSelector(this)) qt.getOrCreateInstance(t, { toggle: !1 }).toggle();
		}), g(qt);
		var Vt = "top", Kt = "bottom", Qt = "right", Xt = "left", Yt = "auto", Ut = [
			Vt,
			Kt,
			Qt,
			Xt
		], Gt = "start", Jt = "end", Zt = "clippingParents", te = "viewport", ee = "popper", ie = "reference", ne = Ut.reduce(function(t, e) {
			return t.concat([e + "-" + Gt, e + "-" + Jt]);
		}, []), se = [].concat(Ut, [Yt]).reduce(function(t, e) {
			return t.concat([
				e,
				e + "-" + Gt,
				e + "-" + Jt
			]);
		}, []), oe = "beforeRead", re = "read", ae = "afterRead", le = "beforeMain", ce = "main", he = "afterMain", de = "beforeWrite", ue = "write", fe = "afterWrite", pe = [
			oe,
			re,
			ae,
			le,
			ce,
			he,
			de,
			ue,
			fe
		];
		function me(t) {
			return t ? (t.nodeName || "").toLowerCase() : null;
		}
		function ge(t) {
			if (null == t) return window;
			if ("[object Window]" !== t.toString()) {
				var e = t.ownerDocument;
				return e && e.defaultView || window;
			}
			return t;
		}
		function _e(t) {
			return t instanceof ge(t).Element || t instanceof Element;
		}
		function be(t) {
			return t instanceof ge(t).HTMLElement || t instanceof HTMLElement;
		}
		function ve(t) {
			return "undefined" != typeof ShadowRoot && (t instanceof ge(t).ShadowRoot || t instanceof ShadowRoot);
		}
		const ye = {
			name: "applyStyles",
			enabled: !0,
			phase: "write",
			fn: function(t) {
				var e = t.state;
				Object.keys(e.elements).forEach(function(t) {
					var i = e.styles[t] || {}, n = e.attributes[t] || {}, s = e.elements[t];
					be(s) && me(s) && (Object.assign(s.style, i), Object.keys(n).forEach(function(t) {
						var e = n[t];
						!1 === e ? s.removeAttribute(t) : s.setAttribute(t, !0 === e ? "" : e);
					}));
				});
			},
			effect: function(t) {
				var e = t.state, i = {
					popper: {
						position: e.options.strategy,
						left: "0",
						top: "0",
						margin: "0"
					},
					arrow: { position: "absolute" },
					reference: {}
				};
				return Object.assign(e.elements.popper.style, i.popper), e.styles = i, e.elements.arrow && Object.assign(e.elements.arrow.style, i.arrow), function() {
					Object.keys(e.elements).forEach(function(t) {
						var n = e.elements[t], s = e.attributes[t] || {}, o = Object.keys(e.styles.hasOwnProperty(t) ? e.styles[t] : i[t]).reduce(function(t, e) {
							return t[e] = "", t;
						}, {});
						be(n) && me(n) && (Object.assign(n.style, o), Object.keys(s).forEach(function(t) {
							n.removeAttribute(t);
						}));
					});
				};
			},
			requires: ["computeStyles"]
		};
		function we(t) {
			return t.split("-")[0];
		}
		var Ae = Math.max, Ee = Math.min, Te = Math.round;
		function Ce() {
			var t = navigator.userAgentData;
			return null != t && t.brands && Array.isArray(t.brands) ? t.brands.map(function(t) {
				return t.brand + "/" + t.version;
			}).join(" ") : navigator.userAgent;
		}
		function Oe() {
			return !/^((?!chrome|android).)*safari/i.test(Ce());
		}
		function xe(t, e, i) {
			void 0 === e && (e = !1), void 0 === i && (i = !1);
			var n = t.getBoundingClientRect(), s = 1, o = 1;
			e && be(t) && (s = t.offsetWidth > 0 && Te(n.width) / t.offsetWidth || 1, o = t.offsetHeight > 0 && Te(n.height) / t.offsetHeight || 1);
			var r = (_e(t) ? ge(t) : window).visualViewport, a = !Oe() && i, l = (n.left + (a && r ? r.offsetLeft : 0)) / s, c = (n.top + (a && r ? r.offsetTop : 0)) / o, h = n.width / s, d = n.height / o;
			return {
				width: h,
				height: d,
				top: c,
				right: l + h,
				bottom: c + d,
				left: l,
				x: l,
				y: c
			};
		}
		function ke(t) {
			var e = xe(t), i = t.offsetWidth, n = t.offsetHeight;
			return Math.abs(e.width - i) <= 1 && (i = e.width), Math.abs(e.height - n) <= 1 && (n = e.height), {
				x: t.offsetLeft,
				y: t.offsetTop,
				width: i,
				height: n
			};
		}
		function Le(t, e) {
			var i = e.getRootNode && e.getRootNode();
			if (t.contains(e)) return !0;
			if (i && ve(i)) {
				var n = e;
				do {
					if (n && t.isSameNode(n)) return !0;
					n = n.parentNode || n.host;
				} while (n);
			}
			return !1;
		}
		function Se(t) {
			return ge(t).getComputedStyle(t);
		}
		function De(t) {
			return [
				"table",
				"td",
				"th"
			].indexOf(me(t)) >= 0;
		}
		function $e(t) {
			return ((_e(t) ? t.ownerDocument : t.document) || window.document).documentElement;
		}
		function Ie(t) {
			return "html" === me(t) ? t : t.assignedSlot || t.parentNode || (ve(t) ? t.host : null) || $e(t);
		}
		function Ne(t) {
			return be(t) && "fixed" !== Se(t).position ? t.offsetParent : null;
		}
		function Pe(t) {
			for (var e = ge(t), i = Ne(t); i && De(i) && "static" === Se(i).position;) i = Ne(i);
			return i && ("html" === me(i) || "body" === me(i) && "static" === Se(i).position) ? e : i || function(t) {
				var e = /firefox/i.test(Ce());
				if (/Trident/i.test(Ce()) && be(t) && "fixed" === Se(t).position) return null;
				var i = Ie(t);
				for (ve(i) && (i = i.host); be(i) && ["html", "body"].indexOf(me(i)) < 0;) {
					var n = Se(i);
					if ("none" !== n.transform || "none" !== n.perspective || "paint" === n.contain || -1 !== ["transform", "perspective"].indexOf(n.willChange) || e && "filter" === n.willChange || e && n.filter && "none" !== n.filter) return i;
					i = i.parentNode;
				}
				return null;
			}(t) || e;
		}
		function je(t) {
			return ["top", "bottom"].indexOf(t) >= 0 ? "x" : "y";
		}
		function Me(t, e, i) {
			return Ae(t, Ee(e, i));
		}
		function Fe(t) {
			return Object.assign({}, {
				top: 0,
				right: 0,
				bottom: 0,
				left: 0
			}, t);
		}
		function He(t, e) {
			return e.reduce(function(e, i) {
				return e[i] = t, e;
			}, {});
		}
		const We = {
			name: "arrow",
			enabled: !0,
			phase: "main",
			fn: function(t) {
				var e, i = t.state, n = t.name, s = t.options, o = i.elements.arrow, r = i.modifiersData.popperOffsets, a = we(i.placement), l = je(a), c = [Xt, Qt].indexOf(a) >= 0 ? "height" : "width";
				if (o && r) {
					var h = function(t, e) {
						return Fe("number" != typeof (t = "function" == typeof t ? t(Object.assign({}, e.rects, { placement: e.placement })) : t) ? t : He(t, Ut));
					}(s.padding, i), d = ke(o), u = "y" === l ? Vt : Xt, f = "y" === l ? Kt : Qt, p = i.rects.reference[c] + i.rects.reference[l] - r[l] - i.rects.popper[c], m = r[l] - i.rects.reference[l], g = Pe(o), _ = g ? "y" === l ? g.clientHeight || 0 : g.clientWidth || 0 : 0, b = p / 2 - m / 2, v = h[u], y = _ - d[c] - h[f], w = _ / 2 - d[c] / 2 + b, A = Me(v, w, y), E = l;
					i.modifiersData[n] = ((e = {})[E] = A, e.centerOffset = A - w, e);
				}
			},
			effect: function(t) {
				var e = t.state, i = t.options.element, n = void 0 === i ? "[data-popper-arrow]" : i;
				null != n && ("string" != typeof n || (n = e.elements.popper.querySelector(n))) && Le(e.elements.popper, n) && (e.elements.arrow = n);
			},
			requires: ["popperOffsets"],
			requiresIfExists: ["preventOverflow"]
		};
		function Be(t) {
			return t.split("-")[1];
		}
		var ze = {
			top: "auto",
			right: "auto",
			bottom: "auto",
			left: "auto"
		};
		function Re(t) {
			var e, i = t.popper, n = t.popperRect, s = t.placement, o = t.variation, r = t.offsets, a = t.position, l = t.gpuAcceleration, c = t.adaptive, h = t.roundOffsets, d = t.isFixed, u = r.x, f = void 0 === u ? 0 : u, p = r.y, m = void 0 === p ? 0 : p, g = "function" == typeof h ? h({
				x: f,
				y: m
			}) : {
				x: f,
				y: m
			};
			f = g.x, m = g.y;
			var _ = r.hasOwnProperty("x"), b = r.hasOwnProperty("y"), v = Xt, y = Vt, w = window;
			if (c) {
				var A = Pe(i), E = "clientHeight", T = "clientWidth";
				A === ge(i) && "static" !== Se(A = $e(i)).position && "absolute" === a && (E = "scrollHeight", T = "scrollWidth"), (s === Vt || (s === Xt || s === Qt) && o === Jt) && (y = Kt, m -= (d && A === w && w.visualViewport ? w.visualViewport.height : A[E]) - n.height, m *= l ? 1 : -1), s !== Xt && (s !== Vt && s !== Kt || o !== Jt) || (v = Qt, f -= (d && A === w && w.visualViewport ? w.visualViewport.width : A[T]) - n.width, f *= l ? 1 : -1);
			}
			var C, O = Object.assign({ position: a }, c && ze), x = !0 === h ? function(t, e) {
				var i = t.x, n = t.y, s = e.devicePixelRatio || 1;
				return {
					x: Te(i * s) / s || 0,
					y: Te(n * s) / s || 0
				};
			}({
				x: f,
				y: m
			}, ge(i)) : {
				x: f,
				y: m
			};
			return f = x.x, m = x.y, l ? Object.assign({}, O, ((C = {})[y] = b ? "0" : "", C[v] = _ ? "0" : "", C.transform = (w.devicePixelRatio || 1) <= 1 ? "translate(" + f + "px, " + m + "px)" : "translate3d(" + f + "px, " + m + "px, 0)", C)) : Object.assign({}, O, ((e = {})[y] = b ? m + "px" : "", e[v] = _ ? f + "px" : "", e.transform = "", e));
		}
		const qe = {
			name: "computeStyles",
			enabled: !0,
			phase: "beforeWrite",
			fn: function(t) {
				var e = t.state, i = t.options, n = i.gpuAcceleration, s = void 0 === n || n, o = i.adaptive, r = void 0 === o || o, a = i.roundOffsets, l = void 0 === a || a, c = {
					placement: we(e.placement),
					variation: Be(e.placement),
					popper: e.elements.popper,
					popperRect: e.rects.popper,
					gpuAcceleration: s,
					isFixed: "fixed" === e.options.strategy
				};
				null != e.modifiersData.popperOffsets && (e.styles.popper = Object.assign({}, e.styles.popper, Re(Object.assign({}, c, {
					offsets: e.modifiersData.popperOffsets,
					position: e.options.strategy,
					adaptive: r,
					roundOffsets: l
				})))), null != e.modifiersData.arrow && (e.styles.arrow = Object.assign({}, e.styles.arrow, Re(Object.assign({}, c, {
					offsets: e.modifiersData.arrow,
					position: "absolute",
					adaptive: !1,
					roundOffsets: l
				})))), e.attributes.popper = Object.assign({}, e.attributes.popper, { "data-popper-placement": e.placement });
			},
			data: {}
		};
		var Ve = { passive: !0 };
		const Ke = {
			name: "eventListeners",
			enabled: !0,
			phase: "write",
			fn: function() {},
			effect: function(t) {
				var e = t.state, i = t.instance, n = t.options, s = n.scroll, o = void 0 === s || s, r = n.resize, a = void 0 === r || r, l = ge(e.elements.popper), c = [].concat(e.scrollParents.reference, e.scrollParents.popper);
				return o && c.forEach(function(t) {
					t.addEventListener("scroll", i.update, Ve);
				}), a && l.addEventListener("resize", i.update, Ve), function() {
					o && c.forEach(function(t) {
						t.removeEventListener("scroll", i.update, Ve);
					}), a && l.removeEventListener("resize", i.update, Ve);
				};
			},
			data: {}
		};
		var Qe = {
			left: "right",
			right: "left",
			bottom: "top",
			top: "bottom"
		};
		function Xe(t) {
			return t.replace(/left|right|bottom|top/g, function(t) {
				return Qe[t];
			});
		}
		var Ye = {
			start: "end",
			end: "start"
		};
		function Ue(t) {
			return t.replace(/start|end/g, function(t) {
				return Ye[t];
			});
		}
		function Ge(t) {
			var e = ge(t);
			return {
				scrollLeft: e.pageXOffset,
				scrollTop: e.pageYOffset
			};
		}
		function Je(t) {
			return xe($e(t)).left + Ge(t).scrollLeft;
		}
		function Ze(t) {
			var e = Se(t), i = e.overflow, n = e.overflowX, s = e.overflowY;
			return /auto|scroll|overlay|hidden/.test(i + s + n);
		}
		function ti(t) {
			return [
				"html",
				"body",
				"#document"
			].indexOf(me(t)) >= 0 ? t.ownerDocument.body : be(t) && Ze(t) ? t : ti(Ie(t));
		}
		function ei(t, e) {
			var i;
			void 0 === e && (e = []);
			var n = ti(t), s = n === (null == (i = t.ownerDocument) ? void 0 : i.body), o = ge(n), r = s ? [o].concat(o.visualViewport || [], Ze(n) ? n : []) : n, a = e.concat(r);
			return s ? a : a.concat(ei(Ie(r)));
		}
		function ii(t) {
			return Object.assign({}, t, {
				left: t.x,
				top: t.y,
				right: t.x + t.width,
				bottom: t.y + t.height
			});
		}
		function ni(t, e, i) {
			return e === te ? ii(function(t, e) {
				var i = ge(t), n = $e(t), s = i.visualViewport, o = n.clientWidth, r = n.clientHeight, a = 0, l = 0;
				if (s) {
					o = s.width, r = s.height;
					var c = Oe();
					(c || !c && "fixed" === e) && (a = s.offsetLeft, l = s.offsetTop);
				}
				return {
					width: o,
					height: r,
					x: a + Je(t),
					y: l
				};
			}(t, i)) : _e(e) ? function(t, e) {
				var i = xe(t, !1, "fixed" === e);
				return i.top = i.top + t.clientTop, i.left = i.left + t.clientLeft, i.bottom = i.top + t.clientHeight, i.right = i.left + t.clientWidth, i.width = t.clientWidth, i.height = t.clientHeight, i.x = i.left, i.y = i.top, i;
			}(e, i) : ii(function(t) {
				var e, i = $e(t), n = Ge(t), s = null == (e = t.ownerDocument) ? void 0 : e.body, o = Ae(i.scrollWidth, i.clientWidth, s ? s.scrollWidth : 0, s ? s.clientWidth : 0), r = Ae(i.scrollHeight, i.clientHeight, s ? s.scrollHeight : 0, s ? s.clientHeight : 0), a = -n.scrollLeft + Je(t), l = -n.scrollTop;
				return "rtl" === Se(s || i).direction && (a += Ae(i.clientWidth, s ? s.clientWidth : 0) - o), {
					width: o,
					height: r,
					x: a,
					y: l
				};
			}($e(t)));
		}
		function si(t) {
			var e, i = t.reference, n = t.element, s = t.placement, o = s ? we(s) : null, r = s ? Be(s) : null, a = i.x + i.width / 2 - n.width / 2, l = i.y + i.height / 2 - n.height / 2;
			switch (o) {
				case Vt:
					e = {
						x: a,
						y: i.y - n.height
					};
					break;
				case Kt:
					e = {
						x: a,
						y: i.y + i.height
					};
					break;
				case Qt:
					e = {
						x: i.x + i.width,
						y: l
					};
					break;
				case Xt:
					e = {
						x: i.x - n.width,
						y: l
					};
					break;
				default: e = {
					x: i.x,
					y: i.y
				};
			}
			var c = o ? je(o) : null;
			if (null != c) {
				var h = "y" === c ? "height" : "width";
				switch (r) {
					case Gt:
						e[c] = e[c] - (i[h] / 2 - n[h] / 2);
						break;
					case Jt: e[c] = e[c] + (i[h] / 2 - n[h] / 2);
				}
			}
			return e;
		}
		function oi(t, e) {
			void 0 === e && (e = {});
			var i = e, n = i.placement, s = void 0 === n ? t.placement : n, o = i.strategy, r = void 0 === o ? t.strategy : o, a = i.boundary, l = void 0 === a ? Zt : a, c = i.rootBoundary, h = void 0 === c ? te : c, d = i.elementContext, u = void 0 === d ? ee : d, f = i.altBoundary, p = void 0 !== f && f, m = i.padding, g = void 0 === m ? 0 : m, _ = Fe("number" != typeof g ? g : He(g, Ut)), b = u === ee ? ie : ee, v = t.rects.popper, y = t.elements[p ? b : u], w = function(t, e, i, n) {
				var s = "clippingParents" === e ? function(t) {
					var e = ei(Ie(t)), i = ["absolute", "fixed"].indexOf(Se(t).position) >= 0 && be(t) ? Pe(t) : t;
					return _e(i) ? e.filter(function(t) {
						return _e(t) && Le(t, i) && "body" !== me(t);
					}) : [];
				}(t) : [].concat(e), o = [].concat(s, [i]), r = o[0], a = o.reduce(function(e, i) {
					var s = ni(t, i, n);
					return e.top = Ae(s.top, e.top), e.right = Ee(s.right, e.right), e.bottom = Ee(s.bottom, e.bottom), e.left = Ae(s.left, e.left), e;
				}, ni(t, r, n));
				return a.width = a.right - a.left, a.height = a.bottom - a.top, a.x = a.left, a.y = a.top, a;
			}(_e(y) ? y : y.contextElement || $e(t.elements.popper), l, h, r), A = xe(t.elements.reference), E = si({
				reference: A,
				element: v,
				placement: s
			}), T = ii(Object.assign({}, v, E)), C = u === ee ? T : A, O = {
				top: w.top - C.top + _.top,
				bottom: C.bottom - w.bottom + _.bottom,
				left: w.left - C.left + _.left,
				right: C.right - w.right + _.right
			}, x = t.modifiersData.offset;
			if (u === ee && x) {
				var k = x[s];
				Object.keys(O).forEach(function(t) {
					var e = [Qt, Kt].indexOf(t) >= 0 ? 1 : -1, i = [Vt, Kt].indexOf(t) >= 0 ? "y" : "x";
					O[t] += k[i] * e;
				});
			}
			return O;
		}
		function ri(t, e) {
			void 0 === e && (e = {});
			var i = e, n = i.placement, s = i.boundary, o = i.rootBoundary, r = i.padding, a = i.flipVariations, l = i.allowedAutoPlacements, c = void 0 === l ? se : l, h = Be(n), d = h ? a ? ne : ne.filter(function(t) {
				return Be(t) === h;
			}) : Ut, u = d.filter(function(t) {
				return c.indexOf(t) >= 0;
			});
			0 === u.length && (u = d);
			var f = u.reduce(function(e, i) {
				return e[i] = oi(t, {
					placement: i,
					boundary: s,
					rootBoundary: o,
					padding: r
				})[we(i)], e;
			}, {});
			return Object.keys(f).sort(function(t, e) {
				return f[t] - f[e];
			});
		}
		const ai = {
			name: "flip",
			enabled: !0,
			phase: "main",
			fn: function(t) {
				var e = t.state, i = t.options, n = t.name;
				if (!e.modifiersData[n]._skip) {
					for (var s = i.mainAxis, o = void 0 === s || s, r = i.altAxis, a = void 0 === r || r, l = i.fallbackPlacements, c = i.padding, h = i.boundary, d = i.rootBoundary, u = i.altBoundary, f = i.flipVariations, p = void 0 === f || f, m = i.allowedAutoPlacements, g = e.options.placement, _ = we(g), b = l || (_ !== g && p ? function(t) {
						if (we(t) === Yt) return [];
						var e = Xe(t);
						return [
							Ue(t),
							e,
							Ue(e)
						];
					}(g) : [Xe(g)]), v = [g].concat(b).reduce(function(t, i) {
						return t.concat(we(i) === Yt ? ri(e, {
							placement: i,
							boundary: h,
							rootBoundary: d,
							padding: c,
							flipVariations: p,
							allowedAutoPlacements: m
						}) : i);
					}, []), y = e.rects.reference, w = e.rects.popper, A = /* @__PURE__ */ new Map(), E = !0, T = v[0], C = 0; C < v.length; C++) {
						var O = v[C], x = we(O), k = Be(O) === Gt, L = [Vt, Kt].indexOf(x) >= 0, S = L ? "width" : "height", D = oi(e, {
							placement: O,
							boundary: h,
							rootBoundary: d,
							altBoundary: u,
							padding: c
						}), $ = L ? k ? Qt : Xt : k ? Kt : Vt;
						y[S] > w[S] && ($ = Xe($));
						var I = Xe($), N = [];
						if (o && N.push(D[x] <= 0), a && N.push(D[$] <= 0, D[I] <= 0), N.every(function(t) {
							return t;
						})) {
							T = O, E = !1;
							break;
						}
						A.set(O, N);
					}
					if (E) for (var P = function(t) {
						var e = v.find(function(e) {
							var i = A.get(e);
							if (i) return i.slice(0, t).every(function(t) {
								return t;
							});
						});
						if (e) return T = e, "break";
					}, j = p ? 3 : 1; j > 0 && "break" !== P(j); j--);
					e.placement !== T && (e.modifiersData[n]._skip = !0, e.placement = T, e.reset = !0);
				}
			},
			requiresIfExists: ["offset"],
			data: { _skip: !1 }
		};
		function li(t, e, i) {
			return void 0 === i && (i = {
				x: 0,
				y: 0
			}), {
				top: t.top - e.height - i.y,
				right: t.right - e.width + i.x,
				bottom: t.bottom - e.height + i.y,
				left: t.left - e.width - i.x
			};
		}
		function ci(t) {
			return [
				Vt,
				Qt,
				Kt,
				Xt
			].some(function(e) {
				return t[e] >= 0;
			});
		}
		const hi = {
			name: "hide",
			enabled: !0,
			phase: "main",
			requiresIfExists: ["preventOverflow"],
			fn: function(t) {
				var e = t.state, i = t.name, n = e.rects.reference, s = e.rects.popper, o = e.modifiersData.preventOverflow, r = oi(e, { elementContext: "reference" }), a = oi(e, { altBoundary: !0 }), l = li(r, n), c = li(a, s, o), h = ci(l), d = ci(c);
				e.modifiersData[i] = {
					referenceClippingOffsets: l,
					popperEscapeOffsets: c,
					isReferenceHidden: h,
					hasPopperEscaped: d
				}, e.attributes.popper = Object.assign({}, e.attributes.popper, {
					"data-popper-reference-hidden": h,
					"data-popper-escaped": d
				});
			}
		}, di = {
			name: "offset",
			enabled: !0,
			phase: "main",
			requires: ["popperOffsets"],
			fn: function(t) {
				var e = t.state, i = t.options, n = t.name, s = i.offset, o = void 0 === s ? [0, 0] : s, r = se.reduce(function(t, i) {
					return t[i] = function(t, e, i) {
						var n = we(t), s = [Xt, Vt].indexOf(n) >= 0 ? -1 : 1, o = "function" == typeof i ? i(Object.assign({}, e, { placement: t })) : i, r = o[0], a = o[1];
						return r = r || 0, a = (a || 0) * s, [Xt, Qt].indexOf(n) >= 0 ? {
							x: a,
							y: r
						} : {
							x: r,
							y: a
						};
					}(i, e.rects, o), t;
				}, {}), a = r[e.placement], l = a.x, c = a.y;
				null != e.modifiersData.popperOffsets && (e.modifiersData.popperOffsets.x += l, e.modifiersData.popperOffsets.y += c), e.modifiersData[n] = r;
			}
		}, ui = {
			name: "popperOffsets",
			enabled: !0,
			phase: "read",
			fn: function(t) {
				var e = t.state, i = t.name;
				e.modifiersData[i] = si({
					reference: e.rects.reference,
					element: e.rects.popper,
					placement: e.placement
				});
			},
			data: {}
		}, fi = {
			name: "preventOverflow",
			enabled: !0,
			phase: "main",
			fn: function(t) {
				var e = t.state, i = t.options, n = t.name, s = i.mainAxis, o = void 0 === s || s, r = i.altAxis, a = void 0 !== r && r, l = i.boundary, c = i.rootBoundary, h = i.altBoundary, d = i.padding, u = i.tether, f = void 0 === u || u, p = i.tetherOffset, m = void 0 === p ? 0 : p, g = oi(e, {
					boundary: l,
					rootBoundary: c,
					padding: d,
					altBoundary: h
				}), _ = we(e.placement), b = Be(e.placement), v = !b, y = je(_), w = "x" === y ? "y" : "x", A = e.modifiersData.popperOffsets, E = e.rects.reference, T = e.rects.popper, C = "function" == typeof m ? m(Object.assign({}, e.rects, { placement: e.placement })) : m, O = "number" == typeof C ? {
					mainAxis: C,
					altAxis: C
				} : Object.assign({
					mainAxis: 0,
					altAxis: 0
				}, C), x = e.modifiersData.offset ? e.modifiersData.offset[e.placement] : null, k = {
					x: 0,
					y: 0
				};
				if (A) {
					if (o) {
						var L, S = "y" === y ? Vt : Xt, D = "y" === y ? Kt : Qt, $ = "y" === y ? "height" : "width", I = A[y], N = I + g[S], P = I - g[D], j = f ? -T[$] / 2 : 0, M = b === Gt ? E[$] : T[$], F = b === Gt ? -T[$] : -E[$], H = e.elements.arrow, W = f && H ? ke(H) : {
							width: 0,
							height: 0
						}, B = e.modifiersData["arrow#persistent"] ? e.modifiersData["arrow#persistent"].padding : {
							top: 0,
							right: 0,
							bottom: 0,
							left: 0
						}, z = B[S], R = B[D], q = Me(0, E[$], W[$]), V = v ? E[$] / 2 - j - q - z - O.mainAxis : M - q - z - O.mainAxis, K = v ? -E[$] / 2 + j + q + R + O.mainAxis : F + q + R + O.mainAxis, Q = e.elements.arrow && Pe(e.elements.arrow), X = Q ? "y" === y ? Q.clientTop || 0 : Q.clientLeft || 0 : 0, Y = null != (L = null == x ? void 0 : x[y]) ? L : 0, U = I + K - Y, G = Me(f ? Ee(N, I + V - Y - X) : N, I, f ? Ae(P, U) : P);
						A[y] = G, k[y] = G - I;
					}
					if (a) {
						var J, Z = "x" === y ? Vt : Xt, tt = "x" === y ? Kt : Qt, et = A[w], it = "y" === w ? "height" : "width", nt = et + g[Z], st = et - g[tt], ot = -1 !== [Vt, Xt].indexOf(_), rt = null != (J = null == x ? void 0 : x[w]) ? J : 0, at = ot ? nt : et - E[it] - T[it] - rt + O.altAxis, lt = ot ? et + E[it] + T[it] - rt - O.altAxis : st, ct = f && ot ? function(t, e, i) {
							var n = Me(t, e, i);
							return n > i ? i : n;
						}(at, et, lt) : Me(f ? at : nt, et, f ? lt : st);
						A[w] = ct, k[w] = ct - et;
					}
					e.modifiersData[n] = k;
				}
			},
			requiresIfExists: ["offset"]
		};
		function pi(t, e, i) {
			void 0 === i && (i = !1);
			var n, s, o = be(e), r = be(e) && function(t) {
				var e = t.getBoundingClientRect(), i = Te(e.width) / t.offsetWidth || 1, n = Te(e.height) / t.offsetHeight || 1;
				return 1 !== i || 1 !== n;
			}(e), a = $e(e), l = xe(t, r, i), c = {
				scrollLeft: 0,
				scrollTop: 0
			}, h = {
				x: 0,
				y: 0
			};
			return (o || !o && !i) && (("body" !== me(e) || Ze(a)) && (c = (n = e) !== ge(n) && be(n) ? {
				scrollLeft: (s = n).scrollLeft,
				scrollTop: s.scrollTop
			} : Ge(n)), be(e) ? ((h = xe(e, !0)).x += e.clientLeft, h.y += e.clientTop) : a && (h.x = Je(a))), {
				x: l.left + c.scrollLeft - h.x,
				y: l.top + c.scrollTop - h.y,
				width: l.width,
				height: l.height
			};
		}
		function mi(t) {
			var e = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new Set(), n = [];
			function s(t) {
				i.add(t.name), [].concat(t.requires || [], t.requiresIfExists || []).forEach(function(t) {
					if (!i.has(t)) {
						var n = e.get(t);
						n && s(n);
					}
				}), n.push(t);
			}
			return t.forEach(function(t) {
				e.set(t.name, t);
			}), t.forEach(function(t) {
				i.has(t.name) || s(t);
			}), n;
		}
		var gi = {
			placement: "bottom",
			modifiers: [],
			strategy: "absolute"
		};
		function _i() {
			for (var t = arguments.length, e = new Array(t), i = 0; i < t; i++) e[i] = arguments[i];
			return !e.some(function(t) {
				return !(t && "function" == typeof t.getBoundingClientRect);
			});
		}
		function bi(t) {
			void 0 === t && (t = {});
			var e = t, i = e.defaultModifiers, n = void 0 === i ? [] : i, s = e.defaultOptions, o = void 0 === s ? gi : s;
			return function(t, e, i) {
				void 0 === i && (i = o);
				var s, r, a = {
					placement: "bottom",
					orderedModifiers: [],
					options: Object.assign({}, gi, o),
					modifiersData: {},
					elements: {
						reference: t,
						popper: e
					},
					attributes: {},
					styles: {}
				}, l = [], c = !1, h = {
					state: a,
					setOptions: function(i) {
						var s = "function" == typeof i ? i(a.options) : i;
						d(), a.options = Object.assign({}, o, a.options, s), a.scrollParents = {
							reference: _e(t) ? ei(t) : t.contextElement ? ei(t.contextElement) : [],
							popper: ei(e)
						};
						var r, c, u = function(t) {
							var e = mi(t);
							return pe.reduce(function(t, i) {
								return t.concat(e.filter(function(t) {
									return t.phase === i;
								}));
							}, []);
						}((r = [].concat(n, a.options.modifiers), c = r.reduce(function(t, e) {
							var i = t[e.name];
							return t[e.name] = i ? Object.assign({}, i, e, {
								options: Object.assign({}, i.options, e.options),
								data: Object.assign({}, i.data, e.data)
							}) : e, t;
						}, {}), Object.keys(c).map(function(t) {
							return c[t];
						})));
						return a.orderedModifiers = u.filter(function(t) {
							return t.enabled;
						}), a.orderedModifiers.forEach(function(t) {
							var e = t.name, i = t.options, n = void 0 === i ? {} : i, s = t.effect;
							if ("function" == typeof s) {
								var o = s({
									state: a,
									name: e,
									instance: h,
									options: n
								});
								l.push(o || function() {});
							}
						}), h.update();
					},
					forceUpdate: function() {
						if (!c) {
							var t = a.elements, e = t.reference, i = t.popper;
							if (_i(e, i)) {
								a.rects = {
									reference: pi(e, Pe(i), "fixed" === a.options.strategy),
									popper: ke(i)
								}, a.reset = !1, a.placement = a.options.placement, a.orderedModifiers.forEach(function(t) {
									return a.modifiersData[t.name] = Object.assign({}, t.data);
								});
								for (var n = 0; n < a.orderedModifiers.length; n++) if (!0 !== a.reset) {
									var s = a.orderedModifiers[n], o = s.fn, r = s.options, l = void 0 === r ? {} : r, d = s.name;
									"function" == typeof o && (a = o({
										state: a,
										options: l,
										name: d,
										instance: h
									}) || a);
								} else a.reset = !1, n = -1;
							}
						}
					},
					update: (s = function() {
						return new Promise(function(t) {
							h.forceUpdate(), t(a);
						});
					}, function() {
						return r || (r = new Promise(function(t) {
							Promise.resolve().then(function() {
								r = void 0, t(s());
							});
						})), r;
					}),
					destroy: function() {
						d(), c = !0;
					}
				};
				if (!_i(t, e)) return h;
				function d() {
					l.forEach(function(t) {
						return t();
					}), l = [];
				}
				return h.setOptions(i).then(function(t) {
					!c && i.onFirstUpdate && i.onFirstUpdate(t);
				}), h;
			};
		}
		var vi = bi(), yi = bi({ defaultModifiers: [
			Ke,
			ui,
			qe,
			ye
		] }), wi = bi({ defaultModifiers: [
			Ke,
			ui,
			qe,
			ye,
			di,
			ai,
			fi,
			We,
			hi
		] });
		const Ai = Object.freeze(Object.defineProperty({
			__proto__: null,
			afterMain: he,
			afterRead: ae,
			afterWrite: fe,
			applyStyles: ye,
			arrow: We,
			auto: Yt,
			basePlacements: Ut,
			beforeMain: le,
			beforeRead: oe,
			beforeWrite: de,
			bottom: Kt,
			clippingParents: Zt,
			computeStyles: qe,
			createPopper: wi,
			createPopperBase: vi,
			createPopperLite: yi,
			detectOverflow: oi,
			end: Jt,
			eventListeners: Ke,
			flip: ai,
			hide: hi,
			left: Xt,
			main: ce,
			modifierPhases: pe,
			offset: di,
			placements: se,
			popper: ee,
			popperGenerator: bi,
			popperOffsets: ui,
			preventOverflow: fi,
			read: re,
			reference: ie,
			right: Qt,
			start: Gt,
			top: Vt,
			variationPlacements: ne,
			viewport: te,
			write: ue
		}, Symbol.toStringTag, { value: "Module" })), Ei = "dropdown", Ti = ".bs.dropdown", Ci = ".data-api", Oi = "ArrowUp", xi = "ArrowDown", ki = `hide${Ti}`, Li = `hidden${Ti}`, Si = `show${Ti}`, Di = `shown${Ti}`, $i = `click${Ti}${Ci}`, Ii = `keydown${Ti}${Ci}`, Ni = `keyup${Ti}${Ci}`, Pi = "show", ji = "[data-bs-toggle=\"dropdown\"]:not(.disabled):not(:disabled)", Mi = `${ji}.${Pi}`, Fi = ".dropdown-menu", Hi = m() ? "top-end" : "top-start", Wi = m() ? "top-start" : "top-end", Bi = m() ? "bottom-end" : "bottom-start", zi = m() ? "bottom-start" : "bottom-end", Ri = m() ? "left-start" : "right-start", qi = m() ? "right-start" : "left-start", Vi = {
			autoClose: !0,
			boundary: "clippingParents",
			display: "dynamic",
			offset: [0, 2],
			popperConfig: null,
			reference: "toggle"
		}, Ki = {
			autoClose: "(boolean|string)",
			boundary: "(string|element)",
			display: "string",
			offset: "(array|string|function)",
			popperConfig: "(null|object|function)",
			reference: "(string|element|object)"
		};
		class Qi extends B {
			constructor(t, e) {
				super(t, e), this._popper = null, this._parent = this._element.parentNode, this._menu = R.next(this._element, Fi)[0] || R.prev(this._element, Fi)[0] || R.findOne(Fi, this._parent), this._inNavbar = this._detectNavbar();
			}
			static get Default() {
				return Vi;
			}
			static get DefaultType() {
				return Ki;
			}
			static get NAME() {
				return Ei;
			}
			toggle() {
				return this._isShown() ? this.hide() : this.show();
			}
			show() {
				if (c(this._element) || this._isShown()) return;
				const t = { relatedTarget: this._element };
				if (!P.trigger(this._element, Si, t).defaultPrevented) {
					if (this._createPopper(), "ontouchstart" in document.documentElement && !this._parent.closest(".navbar-nav")) for (const t of [].concat(...document.body.children)) P.on(t, "mouseover", d);
					this._element.focus(), this._element.setAttribute("aria-expanded", !0), this._menu.classList.add(Pi), this._element.classList.add(Pi), P.trigger(this._element, Di, t);
				}
			}
			hide() {
				if (c(this._element) || !this._isShown()) return;
				const t = { relatedTarget: this._element };
				this._completeHide(t);
			}
			dispose() {
				this._popper && this._popper.destroy(), super.dispose();
			}
			update() {
				this._inNavbar = this._detectNavbar(), this._popper && this._popper.update();
			}
			_completeHide(t) {
				if (!P.trigger(this._element, ki, t).defaultPrevented) {
					if ("ontouchstart" in document.documentElement) for (const t of [].concat(...document.body.children)) P.off(t, "mouseover", d);
					this._popper && this._popper.destroy(), this._menu.classList.remove(Pi), this._element.classList.remove(Pi), this._element.setAttribute("aria-expanded", "false"), H.removeDataAttribute(this._menu, "popper"), P.trigger(this._element, Li, t);
				}
			}
			_getConfig(t) {
				if ("object" == typeof (t = super._getConfig(t)).reference && !r(t.reference) && "function" != typeof t.reference.getBoundingClientRect) throw new TypeError(`${Ei.toUpperCase()}: Option "reference" provided type "object" without a required "getBoundingClientRect" method.`);
				return t;
			}
			_createPopper() {
				if (void 0 === Ai) throw new TypeError("Bootstrap's dropdowns require Popper (https://popper.js.org/docs/v2/)");
				let t = this._element;
				"parent" === this._config.reference ? t = this._parent : r(this._config.reference) ? t = a(this._config.reference) : "object" == typeof this._config.reference && (t = this._config.reference);
				const e = this._getPopperConfig();
				this._popper = wi(t, this._menu, e);
			}
			_isShown() {
				return this._menu.classList.contains(Pi);
			}
			_getPlacement() {
				const t = this._parent;
				if (t.classList.contains("dropend")) return Ri;
				if (t.classList.contains("dropstart")) return qi;
				if (t.classList.contains("dropup-center")) return "top";
				if (t.classList.contains("dropdown-center")) return "bottom";
				const e = "end" === getComputedStyle(this._menu).getPropertyValue("--bs-position").trim();
				return t.classList.contains("dropup") ? e ? Wi : Hi : e ? zi : Bi;
			}
			_detectNavbar() {
				return null !== this._element.closest(".navbar");
			}
			_getOffset() {
				const { offset: t } = this._config;
				return "string" == typeof t ? t.split(",").map((t) => Number.parseInt(t, 10)) : "function" == typeof t ? (e) => t(e, this._element) : t;
			}
			_getPopperConfig() {
				const t = {
					placement: this._getPlacement(),
					modifiers: [{
						name: "preventOverflow",
						options: { boundary: this._config.boundary }
					}, {
						name: "offset",
						options: { offset: this._getOffset() }
					}]
				};
				return (this._inNavbar || "static" === this._config.display) && (H.setDataAttribute(this._menu, "popper", "static"), t.modifiers = [{
					name: "applyStyles",
					enabled: !1
				}]), {
					...t,
					..._(this._config.popperConfig, [void 0, t])
				};
			}
			_selectMenuItem({ key: t, target: e }) {
				const i = R.find(".dropdown-menu .dropdown-item:not(.disabled):not(:disabled)", this._menu).filter((t) => l(t));
				i.length && v(i, e, t === xi, !i.includes(e)).focus();
			}
			static jQueryInterface(t) {
				return this.each(function() {
					const e = Qi.getOrCreateInstance(this, t);
					if ("string" == typeof t) {
						if (void 0 === e[t]) throw new TypeError(`No method named "${t}"`);
						e[t]();
					}
				});
			}
			static clearMenus(t) {
				if (2 === t.button || "keyup" === t.type && "Tab" !== t.key) return;
				const e = R.find(Mi);
				for (const i of e) {
					const e = Qi.getInstance(i);
					if (!e || !1 === e._config.autoClose) continue;
					const n = t.composedPath(), s = n.includes(e._menu);
					if (n.includes(e._element) || "inside" === e._config.autoClose && !s || "outside" === e._config.autoClose && s) continue;
					if (e._menu.contains(t.target) && ("keyup" === t.type && "Tab" === t.key || /input|select|option|textarea|form/i.test(t.target.tagName))) continue;
					const o = { relatedTarget: e._element };
					"click" === t.type && (o.clickEvent = t), e._completeHide(o);
				}
			}
			static dataApiKeydownHandler(t) {
				const e = /input|textarea/i.test(t.target.tagName), i = "Escape" === t.key, n = [Oi, xi].includes(t.key);
				if (!n && !i) return;
				if (e && !i) return;
				t.preventDefault();
				const s = this.matches(ji) ? this : R.prev(this, ji)[0] || R.next(this, ji)[0] || R.findOne(ji, t.delegateTarget.parentNode), o = Qi.getOrCreateInstance(s);
				if (n) return t.stopPropagation(), o.show(), void o._selectMenuItem(t);
				o._isShown() && (t.stopPropagation(), o.hide(), s.focus());
			}
		}
		P.on(document, Ii, ji, Qi.dataApiKeydownHandler), P.on(document, Ii, Fi, Qi.dataApiKeydownHandler), P.on(document, $i, Qi.clearMenus), P.on(document, Ni, Qi.clearMenus), P.on(document, $i, ji, function(t) {
			t.preventDefault(), Qi.getOrCreateInstance(this).toggle();
		}), g(Qi);
		const Xi = "backdrop", Yi = "show", Ui = `mousedown.bs.${Xi}`, Gi = {
			className: "modal-backdrop",
			clickCallback: null,
			isAnimated: !1,
			isVisible: !0,
			rootElement: "body"
		}, Ji = {
			className: "string",
			clickCallback: "(function|null)",
			isAnimated: "boolean",
			isVisible: "boolean",
			rootElement: "(element|string)"
		};
		class Zi extends W {
			constructor(t) {
				super(), this._config = this._getConfig(t), this._isAppended = !1, this._element = null;
			}
			static get Default() {
				return Gi;
			}
			static get DefaultType() {
				return Ji;
			}
			static get NAME() {
				return Xi;
			}
			show(t) {
				if (!this._config.isVisible) return void _(t);
				this._append();
				const e = this._getElement();
				this._config.isAnimated && u(e), e.classList.add(Yi), this._emulateAnimation(() => {
					_(t);
				});
			}
			hide(t) {
				this._config.isVisible ? (this._getElement().classList.remove(Yi), this._emulateAnimation(() => {
					this.dispose(), _(t);
				})) : _(t);
			}
			dispose() {
				this._isAppended && (P.off(this._element, Ui), this._element.remove(), this._isAppended = !1);
			}
			_getElement() {
				if (!this._element) {
					const t = document.createElement("div");
					t.className = this._config.className, this._config.isAnimated && t.classList.add("fade"), this._element = t;
				}
				return this._element;
			}
			_configAfterMerge(t) {
				return t.rootElement = a(t.rootElement), t;
			}
			_append() {
				if (this._isAppended) return;
				const t = this._getElement();
				this._config.rootElement.append(t), P.on(t, Ui, () => {
					_(this._config.clickCallback);
				}), this._isAppended = !0;
			}
			_emulateAnimation(t) {
				b(t, this._getElement(), this._config.isAnimated);
			}
		}
		const tn = ".bs.focustrap", en = `focusin${tn}`, nn = `keydown.tab${tn}`, sn = "backward", on = {
			autofocus: !0,
			trapElement: null
		}, rn = {
			autofocus: "boolean",
			trapElement: "element"
		};
		class an extends W {
			constructor(t) {
				super(), this._config = this._getConfig(t), this._isActive = !1, this._lastTabNavDirection = null;
			}
			static get Default() {
				return on;
			}
			static get DefaultType() {
				return rn;
			}
			static get NAME() {
				return "focustrap";
			}
			activate() {
				this._isActive || (this._config.autofocus && this._config.trapElement.focus(), P.off(document, tn), P.on(document, en, (t) => this._handleFocusin(t)), P.on(document, nn, (t) => this._handleKeydown(t)), this._isActive = !0);
			}
			deactivate() {
				this._isActive && (this._isActive = !1, P.off(document, tn));
			}
			_handleFocusin(t) {
				const { trapElement: e } = this._config;
				if (t.target === document || t.target === e || e.contains(t.target)) return;
				const i = R.focusableChildren(e);
				0 === i.length ? e.focus() : this._lastTabNavDirection === sn ? i[i.length - 1].focus() : i[0].focus();
			}
			_handleKeydown(t) {
				"Tab" === t.key && (this._lastTabNavDirection = t.shiftKey ? sn : "forward");
			}
		}
		const ln = ".fixed-top, .fixed-bottom, .is-fixed, .sticky-top", cn = ".sticky-top", hn = "padding-right", dn = "margin-right";
		class un {
			constructor() {
				this._element = document.body;
			}
			getWidth() {
				const t = document.documentElement.clientWidth;
				return Math.abs(window.innerWidth - t);
			}
			hide() {
				const t = this.getWidth();
				this._disableOverFlow(), this._setElementAttributes(this._element, hn, (e) => e + t), this._setElementAttributes(ln, hn, (e) => e + t), this._setElementAttributes(cn, dn, (e) => e - t);
			}
			reset() {
				this._resetElementAttributes(this._element, "overflow"), this._resetElementAttributes(this._element, hn), this._resetElementAttributes(ln, hn), this._resetElementAttributes(cn, dn);
			}
			isOverflowing() {
				return this.getWidth() > 0;
			}
			_disableOverFlow() {
				this._saveInitialAttribute(this._element, "overflow"), this._element.style.overflow = "hidden";
			}
			_setElementAttributes(t, e, i) {
				const n = this.getWidth();
				this._applyManipulationCallback(t, (t) => {
					if (t !== this._element && window.innerWidth > t.clientWidth + n) return;
					this._saveInitialAttribute(t, e);
					const s = window.getComputedStyle(t).getPropertyValue(e);
					t.style.setProperty(e, `${i(Number.parseFloat(s))}px`);
				});
			}
			_saveInitialAttribute(t, e) {
				const i = t.style.getPropertyValue(e);
				i && H.setDataAttribute(t, e, i);
			}
			_resetElementAttributes(t, e) {
				this._applyManipulationCallback(t, (t) => {
					const i = H.getDataAttribute(t, e);
					null !== i ? (H.removeDataAttribute(t, e), t.style.setProperty(e, i)) : t.style.removeProperty(e);
				});
			}
			_applyManipulationCallback(t, e) {
				if (r(t)) e(t);
				else for (const i of R.find(t, this._element)) e(i);
			}
		}
		const fn = ".bs.modal", pn = `hide${fn}`, mn = `hidePrevented${fn}`, gn = `hidden${fn}`, _n = `show${fn}`, bn = `shown${fn}`, vn = `resize${fn}`, yn = `click.dismiss${fn}`, wn = `mousedown.dismiss${fn}`, An = `keydown.dismiss${fn}`, En = `click${fn}.data-api`, Tn = "modal-open", Cn = "show", On = "modal-static", xn = {
			backdrop: !0,
			focus: !0,
			keyboard: !0
		}, kn = {
			backdrop: "(boolean|string)",
			focus: "boolean",
			keyboard: "boolean"
		};
		class Ln extends B {
			constructor(t, e) {
				super(t, e), this._dialog = R.findOne(".modal-dialog", this._element), this._backdrop = this._initializeBackDrop(), this._focustrap = this._initializeFocusTrap(), this._isShown = !1, this._isTransitioning = !1, this._scrollBar = new un(), this._addEventListeners();
			}
			static get Default() {
				return xn;
			}
			static get DefaultType() {
				return kn;
			}
			static get NAME() {
				return "modal";
			}
			toggle(t) {
				return this._isShown ? this.hide() : this.show(t);
			}
			show(t) {
				this._isShown || this._isTransitioning || P.trigger(this._element, _n, { relatedTarget: t }).defaultPrevented || (this._isShown = !0, this._isTransitioning = !0, this._scrollBar.hide(), document.body.classList.add(Tn), this._adjustDialog(), this._backdrop.show(() => this._showElement(t)));
			}
			hide() {
				this._isShown && !this._isTransitioning && (P.trigger(this._element, pn).defaultPrevented || (this._isShown = !1, this._isTransitioning = !0, this._focustrap.deactivate(), this._element.classList.remove(Cn), this._queueCallback(() => this._hideModal(), this._element, this._isAnimated())));
			}
			dispose() {
				P.off(window, fn), P.off(this._dialog, fn), this._backdrop.dispose(), this._focustrap.deactivate(), super.dispose();
			}
			handleUpdate() {
				this._adjustDialog();
			}
			_initializeBackDrop() {
				return new Zi({
					isVisible: Boolean(this._config.backdrop),
					isAnimated: this._isAnimated()
				});
			}
			_initializeFocusTrap() {
				return new an({ trapElement: this._element });
			}
			_showElement(t) {
				document.body.contains(this._element) || document.body.append(this._element), this._element.style.display = "block", this._element.removeAttribute("aria-hidden"), this._element.setAttribute("aria-modal", !0), this._element.setAttribute("role", "dialog"), this._element.scrollTop = 0;
				const e = R.findOne(".modal-body", this._dialog);
				e && (e.scrollTop = 0), u(this._element), this._element.classList.add(Cn), this._queueCallback(() => {
					this._config.focus && this._focustrap.activate(), this._isTransitioning = !1, P.trigger(this._element, bn, { relatedTarget: t });
				}, this._dialog, this._isAnimated());
			}
			_addEventListeners() {
				P.on(this._element, An, (t) => {
					"Escape" === t.key && (this._config.keyboard ? this.hide() : this._triggerBackdropTransition());
				}), P.on(window, vn, () => {
					this._isShown && !this._isTransitioning && this._adjustDialog();
				}), P.on(this._element, wn, (t) => {
					P.one(this._element, yn, (e) => {
						this._element === t.target && this._element === e.target && ("static" !== this._config.backdrop ? this._config.backdrop && this.hide() : this._triggerBackdropTransition());
					});
				});
			}
			_hideModal() {
				this._element.style.display = "none", this._element.setAttribute("aria-hidden", !0), this._element.removeAttribute("aria-modal"), this._element.removeAttribute("role"), this._isTransitioning = !1, this._backdrop.hide(() => {
					document.body.classList.remove(Tn), this._resetAdjustments(), this._scrollBar.reset(), P.trigger(this._element, gn);
				});
			}
			_isAnimated() {
				return this._element.classList.contains("fade");
			}
			_triggerBackdropTransition() {
				if (P.trigger(this._element, mn).defaultPrevented) return;
				const t = this._element.scrollHeight > document.documentElement.clientHeight, e = this._element.style.overflowY;
				"hidden" === e || this._element.classList.contains(On) || (t || (this._element.style.overflowY = "hidden"), this._element.classList.add(On), this._queueCallback(() => {
					this._element.classList.remove(On), this._queueCallback(() => {
						this._element.style.overflowY = e;
					}, this._dialog);
				}, this._dialog), this._element.focus());
			}
			_adjustDialog() {
				const t = this._element.scrollHeight > document.documentElement.clientHeight, e = this._scrollBar.getWidth(), i = e > 0;
				if (i && !t) {
					const t = m() ? "paddingLeft" : "paddingRight";
					this._element.style[t] = `${e}px`;
				}
				if (!i && t) {
					const t = m() ? "paddingRight" : "paddingLeft";
					this._element.style[t] = `${e}px`;
				}
			}
			_resetAdjustments() {
				this._element.style.paddingLeft = "", this._element.style.paddingRight = "";
			}
			static jQueryInterface(t, e) {
				return this.each(function() {
					const i = Ln.getOrCreateInstance(this, t);
					if ("string" == typeof t) {
						if (void 0 === i[t]) throw new TypeError(`No method named "${t}"`);
						i[t](e);
					}
				});
			}
		}
		P.on(document, En, "[data-bs-toggle=\"modal\"]", function(t) {
			const e = R.getElementFromSelector(this);
			["A", "AREA"].includes(this.tagName) && t.preventDefault(), P.one(e, _n, (t) => {
				t.defaultPrevented || P.one(e, gn, () => {
					l(this) && this.focus();
				});
			});
			const i = R.findOne(".modal.show");
			i && Ln.getInstance(i).hide(), Ln.getOrCreateInstance(e).toggle(this);
		}), q(Ln), g(Ln);
		const Sn = ".bs.offcanvas", Dn = ".data-api", $n = `load${Sn}${Dn}`, In = "show", Nn = "showing", Pn = "hiding", jn = ".offcanvas.show", Mn = `show${Sn}`, Fn = `shown${Sn}`, Hn = `hide${Sn}`, Wn = `hidePrevented${Sn}`, Bn = `hidden${Sn}`, zn = `resize${Sn}`, Rn = `click${Sn}${Dn}`, qn = `keydown.dismiss${Sn}`, Vn = {
			backdrop: !0,
			keyboard: !0,
			scroll: !1
		}, Kn = {
			backdrop: "(boolean|string)",
			keyboard: "boolean",
			scroll: "boolean"
		};
		class Qn extends B {
			constructor(t, e) {
				super(t, e), this._isShown = !1, this._backdrop = this._initializeBackDrop(), this._focustrap = this._initializeFocusTrap(), this._addEventListeners();
			}
			static get Default() {
				return Vn;
			}
			static get DefaultType() {
				return Kn;
			}
			static get NAME() {
				return "offcanvas";
			}
			toggle(t) {
				return this._isShown ? this.hide() : this.show(t);
			}
			show(t) {
				this._isShown || P.trigger(this._element, Mn, { relatedTarget: t }).defaultPrevented || (this._isShown = !0, this._backdrop.show(), this._config.scroll || new un().hide(), this._element.setAttribute("aria-modal", !0), this._element.setAttribute("role", "dialog"), this._element.classList.add(Nn), this._queueCallback(() => {
					this._config.scroll && !this._config.backdrop || this._focustrap.activate(), this._element.classList.add(In), this._element.classList.remove(Nn), P.trigger(this._element, Fn, { relatedTarget: t });
				}, this._element, !0));
			}
			hide() {
				this._isShown && (P.trigger(this._element, Hn).defaultPrevented || (this._focustrap.deactivate(), this._element.blur(), this._isShown = !1, this._element.classList.add(Pn), this._backdrop.hide(), this._queueCallback(() => {
					this._element.classList.remove(In, Pn), this._element.removeAttribute("aria-modal"), this._element.removeAttribute("role"), this._config.scroll || new un().reset(), P.trigger(this._element, Bn);
				}, this._element, !0)));
			}
			dispose() {
				this._backdrop.dispose(), this._focustrap.deactivate(), super.dispose();
			}
			_initializeBackDrop() {
				const t = Boolean(this._config.backdrop);
				return new Zi({
					className: "offcanvas-backdrop",
					isVisible: t,
					isAnimated: !0,
					rootElement: this._element.parentNode,
					clickCallback: t ? () => {
						"static" !== this._config.backdrop ? this.hide() : P.trigger(this._element, Wn);
					} : null
				});
			}
			_initializeFocusTrap() {
				return new an({ trapElement: this._element });
			}
			_addEventListeners() {
				P.on(this._element, qn, (t) => {
					"Escape" === t.key && (this._config.keyboard ? this.hide() : P.trigger(this._element, Wn));
				});
			}
			static jQueryInterface(t) {
				return this.each(function() {
					const e = Qn.getOrCreateInstance(this, t);
					if ("string" == typeof t) {
						if (void 0 === e[t] || t.startsWith("_") || "constructor" === t) throw new TypeError(`No method named "${t}"`);
						e[t](this);
					}
				});
			}
		}
		P.on(document, Rn, "[data-bs-toggle=\"offcanvas\"]", function(t) {
			const e = R.getElementFromSelector(this);
			if (["A", "AREA"].includes(this.tagName) && t.preventDefault(), c(this)) return;
			P.one(e, Bn, () => {
				l(this) && this.focus();
			});
			const i = R.findOne(jn);
			i && i !== e && Qn.getInstance(i).hide(), Qn.getOrCreateInstance(e).toggle(this);
		}), P.on(window, $n, () => {
			for (const t of R.find(jn)) Qn.getOrCreateInstance(t).show();
		}), P.on(window, zn, () => {
			for (const t of R.find("[aria-modal][class*=show][class*=offcanvas-]")) "fixed" !== getComputedStyle(t).position && Qn.getOrCreateInstance(t).hide();
		}), q(Qn), g(Qn);
		const Xn = {
			"*": [
				"class",
				"dir",
				"id",
				"lang",
				"role",
				/^aria-[\w-]*$/i
			],
			a: [
				"target",
				"href",
				"title",
				"rel"
			],
			area: [],
			b: [],
			br: [],
			col: [],
			code: [],
			dd: [],
			div: [],
			dl: [],
			dt: [],
			em: [],
			hr: [],
			h1: [],
			h2: [],
			h3: [],
			h4: [],
			h5: [],
			h6: [],
			i: [],
			img: [
				"src",
				"srcset",
				"alt",
				"title",
				"width",
				"height"
			],
			li: [],
			ol: [],
			p: [],
			pre: [],
			s: [],
			small: [],
			span: [],
			sub: [],
			sup: [],
			strong: [],
			u: [],
			ul: []
		}, Yn = /* @__PURE__ */ new Set([
			"background",
			"cite",
			"href",
			"itemtype",
			"longdesc",
			"poster",
			"src",
			"xlink:href"
		]), Un = /^(?!javascript:)(?:[a-z0-9+.-]+:|[^&:/?#]*(?:[/?#]|$))/i, Gn = (t, e) => {
			const i = t.nodeName.toLowerCase();
			return e.includes(i) ? !Yn.has(i) || Boolean(Un.test(t.nodeValue)) : e.filter((t) => t instanceof RegExp).some((t) => t.test(i));
		}, Jn = {
			allowList: Xn,
			content: {},
			extraClass: "",
			html: !1,
			sanitize: !0,
			sanitizeFn: null,
			template: "<div></div>"
		}, Zn = {
			allowList: "object",
			content: "object",
			extraClass: "(string|function)",
			html: "boolean",
			sanitize: "boolean",
			sanitizeFn: "(null|function)",
			template: "string"
		}, ts = {
			entry: "(string|element|function|null)",
			selector: "(string|element)"
		};
		class es extends W {
			constructor(t) {
				super(), this._config = this._getConfig(t);
			}
			static get Default() {
				return Jn;
			}
			static get DefaultType() {
				return Zn;
			}
			static get NAME() {
				return "TemplateFactory";
			}
			getContent() {
				return Object.values(this._config.content).map((t) => this._resolvePossibleFunction(t)).filter(Boolean);
			}
			hasContent() {
				return this.getContent().length > 0;
			}
			changeContent(t) {
				return this._checkContent(t), this._config.content = {
					...this._config.content,
					...t
				}, this;
			}
			toHtml() {
				const t = document.createElement("div");
				t.innerHTML = this._maybeSanitize(this._config.template);
				for (const [e, i] of Object.entries(this._config.content)) this._setContent(t, i, e);
				const e = t.children[0], i = this._resolvePossibleFunction(this._config.extraClass);
				return i && e.classList.add(...i.split(" ")), e;
			}
			_typeCheckConfig(t) {
				super._typeCheckConfig(t), this._checkContent(t.content);
			}
			_checkContent(t) {
				for (const [e, i] of Object.entries(t)) super._typeCheckConfig({
					selector: e,
					entry: i
				}, ts);
			}
			_setContent(t, e, i) {
				const n = R.findOne(i, t);
				n && ((e = this._resolvePossibleFunction(e)) ? r(e) ? this._putElementInTemplate(a(e), n) : this._config.html ? n.innerHTML = this._maybeSanitize(e) : n.textContent = e : n.remove());
			}
			_maybeSanitize(t) {
				return this._config.sanitize ? function(t, e, i) {
					if (!t.length) return t;
					if (i && "function" == typeof i) return i(t);
					const n = new window.DOMParser().parseFromString(t, "text/html"), s = [].concat(...n.body.querySelectorAll("*"));
					for (const t of s) {
						const i = t.nodeName.toLowerCase();
						if (!Object.keys(e).includes(i)) {
							t.remove();
							continue;
						}
						const n = [].concat(...t.attributes), s = [].concat(e["*"] || [], e[i] || []);
						for (const e of n) Gn(e, s) || t.removeAttribute(e.nodeName);
					}
					return n.body.innerHTML;
				}(t, this._config.allowList, this._config.sanitizeFn) : t;
			}
			_resolvePossibleFunction(t) {
				return _(t, [void 0, this]);
			}
			_putElementInTemplate(t, e) {
				if (this._config.html) return e.innerHTML = "", void e.append(t);
				e.textContent = t.textContent;
			}
		}
		const is = /* @__PURE__ */ new Set([
			"sanitize",
			"allowList",
			"sanitizeFn"
		]), ns = "fade", ss = "show", os = ".tooltip-inner", rs = ".modal", as = "hide.bs.modal", ls = "hover", cs = "focus", hs = "click", ds = {
			AUTO: "auto",
			TOP: "top",
			RIGHT: m() ? "left" : "right",
			BOTTOM: "bottom",
			LEFT: m() ? "right" : "left"
		}, us = {
			allowList: Xn,
			animation: !0,
			boundary: "clippingParents",
			container: !1,
			customClass: "",
			delay: 0,
			fallbackPlacements: [
				"top",
				"right",
				"bottom",
				"left"
			],
			html: !1,
			offset: [0, 6],
			placement: "top",
			popperConfig: null,
			sanitize: !0,
			sanitizeFn: null,
			selector: !1,
			template: "<div class=\"tooltip\" role=\"tooltip\"><div class=\"tooltip-arrow\"></div><div class=\"tooltip-inner\"></div></div>",
			title: "",
			trigger: "hover focus"
		}, fs = {
			allowList: "object",
			animation: "boolean",
			boundary: "(string|element)",
			container: "(string|element|boolean)",
			customClass: "(string|function)",
			delay: "(number|object)",
			fallbackPlacements: "array",
			html: "boolean",
			offset: "(array|string|function)",
			placement: "(string|function)",
			popperConfig: "(null|object|function)",
			sanitize: "boolean",
			sanitizeFn: "(null|function)",
			selector: "(string|boolean)",
			template: "string",
			title: "(string|element|function)",
			trigger: "string"
		};
		class ps extends B {
			constructor(t, e) {
				if (void 0 === Ai) throw new TypeError("Bootstrap's tooltips require Popper (https://popper.js.org/docs/v2/)");
				super(t, e), this._isEnabled = !0, this._timeout = 0, this._isHovered = null, this._activeTrigger = {}, this._popper = null, this._templateFactory = null, this._newContent = null, this.tip = null, this._setListeners(), this._config.selector || this._fixTitle();
			}
			static get Default() {
				return us;
			}
			static get DefaultType() {
				return fs;
			}
			static get NAME() {
				return "tooltip";
			}
			enable() {
				this._isEnabled = !0;
			}
			disable() {
				this._isEnabled = !1;
			}
			toggleEnabled() {
				this._isEnabled = !this._isEnabled;
			}
			toggle() {
				this._isEnabled && (this._isShown() ? this._leave() : this._enter());
			}
			dispose() {
				clearTimeout(this._timeout), P.off(this._element.closest(rs), as, this._hideModalHandler), this._element.getAttribute("data-bs-original-title") && this._element.setAttribute("title", this._element.getAttribute("data-bs-original-title")), this._disposePopper(), super.dispose();
			}
			show() {
				if ("none" === this._element.style.display) throw new Error("Please use show on visible elements");
				if (!this._isWithContent() || !this._isEnabled) return;
				const t = P.trigger(this._element, this.constructor.eventName("show")), e = (h(this._element) || this._element.ownerDocument.documentElement).contains(this._element);
				if (t.defaultPrevented || !e) return;
				this._disposePopper();
				const i = this._getTipElement();
				this._element.setAttribute("aria-describedby", i.getAttribute("id"));
				const { container: n } = this._config;
				if (this._element.ownerDocument.documentElement.contains(this.tip) || (n.append(i), P.trigger(this._element, this.constructor.eventName("inserted"))), this._popper = this._createPopper(i), i.classList.add(ss), "ontouchstart" in document.documentElement) for (const t of [].concat(...document.body.children)) P.on(t, "mouseover", d);
				this._queueCallback(() => {
					P.trigger(this._element, this.constructor.eventName("shown")), !1 === this._isHovered && this._leave(), this._isHovered = !1;
				}, this.tip, this._isAnimated());
			}
			hide() {
				if (this._isShown() && !P.trigger(this._element, this.constructor.eventName("hide")).defaultPrevented) {
					if (this._getTipElement().classList.remove(ss), "ontouchstart" in document.documentElement) for (const t of [].concat(...document.body.children)) P.off(t, "mouseover", d);
					this._activeTrigger[hs] = !1, this._activeTrigger[cs] = !1, this._activeTrigger[ls] = !1, this._isHovered = null, this._queueCallback(() => {
						this._isWithActiveTrigger() || (this._isHovered || this._disposePopper(), this._element.removeAttribute("aria-describedby"), P.trigger(this._element, this.constructor.eventName("hidden")));
					}, this.tip, this._isAnimated());
				}
			}
			update() {
				this._popper && this._popper.update();
			}
			_isWithContent() {
				return Boolean(this._getTitle());
			}
			_getTipElement() {
				return this.tip || (this.tip = this._createTipElement(this._newContent || this._getContentForTemplate())), this.tip;
			}
			_createTipElement(t) {
				const e = this._getTemplateFactory(t).toHtml();
				if (!e) return null;
				e.classList.remove(ns, ss), e.classList.add(`bs-${this.constructor.NAME}-auto`);
				const i = ((t) => {
					do
						t += Math.floor(1e6 * Math.random());
					while (document.getElementById(t));
					return t;
				})(this.constructor.NAME).toString();
				return e.setAttribute("id", i), this._isAnimated() && e.classList.add(ns), e;
			}
			setContent(t) {
				this._newContent = t, this._isShown() && (this._disposePopper(), this.show());
			}
			_getTemplateFactory(t) {
				return this._templateFactory ? this._templateFactory.changeContent(t) : this._templateFactory = new es({
					...this._config,
					content: t,
					extraClass: this._resolvePossibleFunction(this._config.customClass)
				}), this._templateFactory;
			}
			_getContentForTemplate() {
				return { [os]: this._getTitle() };
			}
			_getTitle() {
				return this._resolvePossibleFunction(this._config.title) || this._element.getAttribute("data-bs-original-title");
			}
			_initializeOnDelegatedTarget(t) {
				return this.constructor.getOrCreateInstance(t.delegateTarget, this._getDelegateConfig());
			}
			_isAnimated() {
				return this._config.animation || this.tip && this.tip.classList.contains(ns);
			}
			_isShown() {
				return this.tip && this.tip.classList.contains(ss);
			}
			_createPopper(t) {
				const e = _(this._config.placement, [
					this,
					t,
					this._element
				]), i = ds[e.toUpperCase()];
				return wi(this._element, t, this._getPopperConfig(i));
			}
			_getOffset() {
				const { offset: t } = this._config;
				return "string" == typeof t ? t.split(",").map((t) => Number.parseInt(t, 10)) : "function" == typeof t ? (e) => t(e, this._element) : t;
			}
			_resolvePossibleFunction(t) {
				return _(t, [this._element, this._element]);
			}
			_getPopperConfig(t) {
				const e = {
					placement: t,
					modifiers: [
						{
							name: "flip",
							options: { fallbackPlacements: this._config.fallbackPlacements }
						},
						{
							name: "offset",
							options: { offset: this._getOffset() }
						},
						{
							name: "preventOverflow",
							options: { boundary: this._config.boundary }
						},
						{
							name: "arrow",
							options: { element: `.${this.constructor.NAME}-arrow` }
						},
						{
							name: "preSetPlacement",
							enabled: !0,
							phase: "beforeMain",
							fn: (t) => {
								this._getTipElement().setAttribute("data-popper-placement", t.state.placement);
							}
						}
					]
				};
				return {
					...e,
					..._(this._config.popperConfig, [void 0, e])
				};
			}
			_setListeners() {
				const t = this._config.trigger.split(" ");
				for (const e of t) if ("click" === e) P.on(this._element, this.constructor.eventName("click"), this._config.selector, (t) => {
					const e = this._initializeOnDelegatedTarget(t);
					e._activeTrigger[hs] = !(e._isShown() && e._activeTrigger[hs]), e.toggle();
				});
				else if ("manual" !== e) {
					const t = e === ls ? this.constructor.eventName("mouseenter") : this.constructor.eventName("focusin"), i = e === ls ? this.constructor.eventName("mouseleave") : this.constructor.eventName("focusout");
					P.on(this._element, t, this._config.selector, (t) => {
						const e = this._initializeOnDelegatedTarget(t);
						e._activeTrigger["focusin" === t.type ? cs : ls] = !0, e._enter();
					}), P.on(this._element, i, this._config.selector, (t) => {
						const e = this._initializeOnDelegatedTarget(t);
						e._activeTrigger["focusout" === t.type ? cs : ls] = e._element.contains(t.relatedTarget), e._leave();
					});
				}
				this._hideModalHandler = () => {
					this._element && this.hide();
				}, P.on(this._element.closest(rs), as, this._hideModalHandler);
			}
			_fixTitle() {
				const t = this._element.getAttribute("title");
				t && (this._element.getAttribute("aria-label") || this._element.textContent.trim() || this._element.setAttribute("aria-label", t), this._element.setAttribute("data-bs-original-title", t), this._element.removeAttribute("title"));
			}
			_enter() {
				this._isShown() || this._isHovered ? this._isHovered = !0 : (this._isHovered = !0, this._setTimeout(() => {
					this._isHovered && this.show();
				}, this._config.delay.show));
			}
			_leave() {
				this._isWithActiveTrigger() || (this._isHovered = !1, this._setTimeout(() => {
					this._isHovered || this.hide();
				}, this._config.delay.hide));
			}
			_setTimeout(t, e) {
				clearTimeout(this._timeout), this._timeout = setTimeout(t, e);
			}
			_isWithActiveTrigger() {
				return Object.values(this._activeTrigger).includes(!0);
			}
			_getConfig(t) {
				const e = H.getDataAttributes(this._element);
				for (const t of Object.keys(e)) is.has(t) && delete e[t];
				return t = {
					...e,
					..."object" == typeof t && t ? t : {}
				}, t = this._mergeConfigObj(t), t = this._configAfterMerge(t), this._typeCheckConfig(t), t;
			}
			_configAfterMerge(t) {
				return t.container = !1 === t.container ? document.body : a(t.container), "number" == typeof t.delay && (t.delay = {
					show: t.delay,
					hide: t.delay
				}), "number" == typeof t.title && (t.title = t.title.toString()), "number" == typeof t.content && (t.content = t.content.toString()), t;
			}
			_getDelegateConfig() {
				const t = {};
				for (const [e, i] of Object.entries(this._config)) this.constructor.Default[e] !== i && (t[e] = i);
				return t.selector = !1, t.trigger = "manual", t;
			}
			_disposePopper() {
				this._popper && (this._popper.destroy(), this._popper = null), this.tip && (this.tip.remove(), this.tip = null);
			}
			static jQueryInterface(t) {
				return this.each(function() {
					const e = ps.getOrCreateInstance(this, t);
					if ("string" == typeof t) {
						if (void 0 === e[t]) throw new TypeError(`No method named "${t}"`);
						e[t]();
					}
				});
			}
		}
		g(ps);
		const ms = ".popover-header", gs = ".popover-body", _s = {
			...ps.Default,
			content: "",
			offset: [0, 8],
			placement: "right",
			template: "<div class=\"popover\" role=\"tooltip\"><div class=\"popover-arrow\"></div><h3 class=\"popover-header\"></h3><div class=\"popover-body\"></div></div>",
			trigger: "click"
		}, bs = {
			...ps.DefaultType,
			content: "(null|string|element|function)"
		};
		class vs extends ps {
			static get Default() {
				return _s;
			}
			static get DefaultType() {
				return bs;
			}
			static get NAME() {
				return "popover";
			}
			_isWithContent() {
				return this._getTitle() || this._getContent();
			}
			_getContentForTemplate() {
				return {
					[ms]: this._getTitle(),
					[gs]: this._getContent()
				};
			}
			_getContent() {
				return this._resolvePossibleFunction(this._config.content);
			}
			static jQueryInterface(t) {
				return this.each(function() {
					const e = vs.getOrCreateInstance(this, t);
					if ("string" == typeof t) {
						if (void 0 === e[t]) throw new TypeError(`No method named "${t}"`);
						e[t]();
					}
				});
			}
		}
		g(vs);
		const ys = ".bs.scrollspy", ws = `activate${ys}`, As = `click${ys}`, Es = `load${ys}.data-api`, Ts = "active", Cs = "[href]", Os = ".nav-link", xs = `${Os}, .nav-item > ${Os}, .list-group-item`, ks = {
			offset: null,
			rootMargin: "0px 0px -25%",
			smoothScroll: !1,
			target: null,
			threshold: [
				.1,
				.5,
				1
			]
		}, Ls = {
			offset: "(number|null)",
			rootMargin: "string",
			smoothScroll: "boolean",
			target: "element",
			threshold: "array"
		};
		class Ss extends B {
			constructor(t, e) {
				super(t, e), this._targetLinks = /* @__PURE__ */ new Map(), this._observableSections = /* @__PURE__ */ new Map(), this._rootElement = "visible" === getComputedStyle(this._element).overflowY ? null : this._element, this._activeTarget = null, this._observer = null, this._previousScrollData = {
					visibleEntryTop: 0,
					parentScrollTop: 0
				}, this.refresh();
			}
			static get Default() {
				return ks;
			}
			static get DefaultType() {
				return Ls;
			}
			static get NAME() {
				return "scrollspy";
			}
			refresh() {
				this._initializeTargetsAndObservables(), this._maybeEnableSmoothScroll(), this._observer ? this._observer.disconnect() : this._observer = this._getNewObserver();
				for (const t of this._observableSections.values()) this._observer.observe(t);
			}
			dispose() {
				this._observer.disconnect(), super.dispose();
			}
			_configAfterMerge(t) {
				return t.target = a(t.target) || document.body, t.rootMargin = t.offset ? `${t.offset}px 0px -30%` : t.rootMargin, "string" == typeof t.threshold && (t.threshold = t.threshold.split(",").map((t) => Number.parseFloat(t))), t;
			}
			_maybeEnableSmoothScroll() {
				this._config.smoothScroll && (P.off(this._config.target, As), P.on(this._config.target, As, Cs, (t) => {
					const e = this._observableSections.get(t.target.hash);
					if (e) {
						t.preventDefault();
						const i = this._rootElement || window, n = e.offsetTop - this._element.offsetTop;
						if (i.scrollTo) return void i.scrollTo({
							top: n,
							behavior: "smooth"
						});
						i.scrollTop = n;
					}
				}));
			}
			_getNewObserver() {
				const t = {
					root: this._rootElement,
					threshold: this._config.threshold,
					rootMargin: this._config.rootMargin
				};
				return new IntersectionObserver((t) => this._observerCallback(t), t);
			}
			_observerCallback(t) {
				const e = (t) => this._targetLinks.get(`#${t.target.id}`), i = (t) => {
					this._previousScrollData.visibleEntryTop = t.target.offsetTop, this._process(e(t));
				}, n = (this._rootElement || document.documentElement).scrollTop, s = n >= this._previousScrollData.parentScrollTop;
				this._previousScrollData.parentScrollTop = n;
				for (const o of t) {
					if (!o.isIntersecting) {
						this._activeTarget = null, this._clearActiveClass(e(o));
						continue;
					}
					const t = o.target.offsetTop >= this._previousScrollData.visibleEntryTop;
					if (s && t) {
						if (i(o), !n) return;
					} else s || t || i(o);
				}
			}
			_initializeTargetsAndObservables() {
				this._targetLinks = /* @__PURE__ */ new Map(), this._observableSections = /* @__PURE__ */ new Map();
				const t = R.find(Cs, this._config.target);
				for (const e of t) {
					if (!e.hash || c(e)) continue;
					const t = R.findOne(decodeURI(e.hash), this._element);
					l(t) && (this._targetLinks.set(decodeURI(e.hash), e), this._observableSections.set(e.hash, t));
				}
			}
			_process(t) {
				this._activeTarget !== t && (this._clearActiveClass(this._config.target), this._activeTarget = t, t.classList.add(Ts), this._activateParents(t), P.trigger(this._element, ws, { relatedTarget: t }));
			}
			_activateParents(t) {
				if (t.classList.contains("dropdown-item")) R.findOne(".dropdown-toggle", t.closest(".dropdown")).classList.add(Ts);
				else for (const e of R.parents(t, ".nav, .list-group")) for (const t of R.prev(e, xs)) t.classList.add(Ts);
			}
			_clearActiveClass(t) {
				t.classList.remove(Ts);
				const e = R.find(`${Cs}.${Ts}`, t);
				for (const t of e) t.classList.remove(Ts);
			}
			static jQueryInterface(t) {
				return this.each(function() {
					const e = Ss.getOrCreateInstance(this, t);
					if ("string" == typeof t) {
						if (void 0 === e[t] || t.startsWith("_") || "constructor" === t) throw new TypeError(`No method named "${t}"`);
						e[t]();
					}
				});
			}
		}
		P.on(window, Es, () => {
			for (const t of R.find("[data-bs-spy=\"scroll\"]")) Ss.getOrCreateInstance(t);
		}), g(Ss);
		const Ds = ".bs.tab", $s = `hide${Ds}`, Is = `hidden${Ds}`, Ns = `show${Ds}`, Ps = `shown${Ds}`, js = `click${Ds}`, Ms = `keydown${Ds}`, Fs = `load${Ds}`, Hs = "ArrowLeft", Ws = "ArrowRight", Bs = "ArrowUp", zs = "ArrowDown", Rs = "Home", qs = "End", Vs = "active", Ks = "fade", Qs = "show", Xs = ".dropdown-toggle", Ys = `:not(${Xs})`, Us = "[data-bs-toggle=\"tab\"], [data-bs-toggle=\"pill\"], [data-bs-toggle=\"list\"]", Gs = `.nav-link${Ys}, .list-group-item${Ys}, [role="tab"]${Ys}, ${Us}`, Js = `.${Vs}[data-bs-toggle="tab"], .${Vs}[data-bs-toggle="pill"], .${Vs}[data-bs-toggle="list"]`;
		class Zs extends B {
			constructor(t) {
				super(t), this._parent = this._element.closest(".list-group, .nav, [role=\"tablist\"]"), this._parent && (this._setInitialAttributes(this._parent, this._getChildren()), P.on(this._element, Ms, (t) => this._keydown(t)));
			}
			static get NAME() {
				return "tab";
			}
			show() {
				const t = this._element;
				if (this._elemIsActive(t)) return;
				const e = this._getActiveElem(), i = e ? P.trigger(e, $s, { relatedTarget: t }) : null;
				P.trigger(t, Ns, { relatedTarget: e }).defaultPrevented || i && i.defaultPrevented || (this._deactivate(e, t), this._activate(t, e));
			}
			_activate(t, e) {
				t && (t.classList.add(Vs), this._activate(R.getElementFromSelector(t)), this._queueCallback(() => {
					"tab" === t.getAttribute("role") ? (t.removeAttribute("tabindex"), t.setAttribute("aria-selected", !0), this._toggleDropDown(t, !0), P.trigger(t, Ps, { relatedTarget: e })) : t.classList.add(Qs);
				}, t, t.classList.contains(Ks)));
			}
			_deactivate(t, e) {
				t && (t.classList.remove(Vs), t.blur(), this._deactivate(R.getElementFromSelector(t)), this._queueCallback(() => {
					"tab" === t.getAttribute("role") ? (t.setAttribute("aria-selected", !1), t.setAttribute("tabindex", "-1"), this._toggleDropDown(t, !1), P.trigger(t, Is, { relatedTarget: e })) : t.classList.remove(Qs);
				}, t, t.classList.contains(Ks)));
			}
			_keydown(t) {
				if (![
					Hs,
					Ws,
					Bs,
					zs,
					Rs,
					qs
				].includes(t.key)) return;
				t.stopPropagation(), t.preventDefault();
				const e = this._getChildren().filter((t) => !c(t));
				let i;
				if ([Rs, qs].includes(t.key)) i = e[t.key === Rs ? 0 : e.length - 1];
				else {
					const n = [Ws, zs].includes(t.key);
					i = v(e, t.target, n, !0);
				}
				i && (i.focus({ preventScroll: !0 }), Zs.getOrCreateInstance(i).show());
			}
			_getChildren() {
				return R.find(Gs, this._parent);
			}
			_getActiveElem() {
				return this._getChildren().find((t) => this._elemIsActive(t)) || null;
			}
			_setInitialAttributes(t, e) {
				this._setAttributeIfNotExists(t, "role", "tablist");
				for (const t of e) this._setInitialAttributesOnChild(t);
			}
			_setInitialAttributesOnChild(t) {
				t = this._getInnerElement(t);
				const e = this._elemIsActive(t), i = this._getOuterElement(t);
				t.setAttribute("aria-selected", e), i !== t && this._setAttributeIfNotExists(i, "role", "presentation"), e || t.setAttribute("tabindex", "-1"), this._setAttributeIfNotExists(t, "role", "tab"), this._setInitialAttributesOnTargetPanel(t);
			}
			_setInitialAttributesOnTargetPanel(t) {
				const e = R.getElementFromSelector(t);
				e && (this._setAttributeIfNotExists(e, "role", "tabpanel"), t.id && this._setAttributeIfNotExists(e, "aria-labelledby", `${t.id}`));
			}
			_toggleDropDown(t, e) {
				const i = this._getOuterElement(t);
				if (!i.classList.contains("dropdown")) return;
				const n = (t, n) => {
					const s = R.findOne(t, i);
					s && s.classList.toggle(n, e);
				};
				n(Xs, Vs), n(".dropdown-menu", Qs), i.setAttribute("aria-expanded", e);
			}
			_setAttributeIfNotExists(t, e, i) {
				t.hasAttribute(e) || t.setAttribute(e, i);
			}
			_elemIsActive(t) {
				return t.classList.contains(Vs);
			}
			_getInnerElement(t) {
				return t.matches(Gs) ? t : R.findOne(Gs, t);
			}
			_getOuterElement(t) {
				return t.closest(".nav-item, .list-group-item") || t;
			}
			static jQueryInterface(t) {
				return this.each(function() {
					const e = Zs.getOrCreateInstance(this);
					if ("string" == typeof t) {
						if (void 0 === e[t] || t.startsWith("_") || "constructor" === t) throw new TypeError(`No method named "${t}"`);
						e[t]();
					}
				});
			}
		}
		P.on(document, js, Us, function(t) {
			["A", "AREA"].includes(this.tagName) && t.preventDefault(), c(this) || Zs.getOrCreateInstance(this).show();
		}), P.on(window, Fs, () => {
			for (const t of R.find(Js)) Zs.getOrCreateInstance(t);
		}), g(Zs);
		const to = ".bs.toast", eo = `mouseover${to}`, io = `mouseout${to}`, no = `focusin${to}`, so = `focusout${to}`, oo = `hide${to}`, ro = `hidden${to}`, ao = `show${to}`, lo = `shown${to}`, co = "hide", ho = "show", uo = "showing", fo = {
			animation: "boolean",
			autohide: "boolean",
			delay: "number"
		}, po = {
			animation: !0,
			autohide: !0,
			delay: 5e3
		};
		class mo extends B {
			constructor(t, e) {
				super(t, e), this._timeout = null, this._hasMouseInteraction = !1, this._hasKeyboardInteraction = !1, this._setListeners();
			}
			static get Default() {
				return po;
			}
			static get DefaultType() {
				return fo;
			}
			static get NAME() {
				return "toast";
			}
			show() {
				P.trigger(this._element, ao).defaultPrevented || (this._clearTimeout(), this._config.animation && this._element.classList.add("fade"), this._element.classList.remove(co), u(this._element), this._element.classList.add(ho, uo), this._queueCallback(() => {
					this._element.classList.remove(uo), P.trigger(this._element, lo), this._maybeScheduleHide();
				}, this._element, this._config.animation));
			}
			hide() {
				this.isShown() && (P.trigger(this._element, oo).defaultPrevented || (this._element.classList.add(uo), this._queueCallback(() => {
					this._element.classList.add(co), this._element.classList.remove(uo, ho), P.trigger(this._element, ro);
				}, this._element, this._config.animation)));
			}
			dispose() {
				this._clearTimeout(), this.isShown() && this._element.classList.remove(ho), super.dispose();
			}
			isShown() {
				return this._element.classList.contains(ho);
			}
			_maybeScheduleHide() {
				this._config.autohide && (this._hasMouseInteraction || this._hasKeyboardInteraction || (this._timeout = setTimeout(() => {
					this.hide();
				}, this._config.delay)));
			}
			_onInteraction(t, e) {
				switch (t.type) {
					case "mouseover":
					case "mouseout":
						this._hasMouseInteraction = e;
						break;
					case "focusin":
					case "focusout": this._hasKeyboardInteraction = e;
				}
				if (e) return void this._clearTimeout();
				const i = t.relatedTarget;
				this._element === i || this._element.contains(i) || this._maybeScheduleHide();
			}
			_setListeners() {
				P.on(this._element, eo, (t) => this._onInteraction(t, !0)), P.on(this._element, io, (t) => this._onInteraction(t, !1)), P.on(this._element, no, (t) => this._onInteraction(t, !0)), P.on(this._element, so, (t) => this._onInteraction(t, !1));
			}
			_clearTimeout() {
				clearTimeout(this._timeout), this._timeout = null;
			}
			static jQueryInterface(t) {
				return this.each(function() {
					const e = mo.getOrCreateInstance(this, t);
					if ("string" == typeof t) {
						if (void 0 === e[t]) throw new TypeError(`No method named "${t}"`);
						e[t](this);
					}
				});
			}
		}
		return q(mo), g(mo), {
			Alert: X,
			Button: U,
			Carousel: St,
			Collapse: qt,
			Dropdown: Qi,
			Modal: Ln,
			Offcanvas: Qn,
			Popover: vs,
			ScrollSpy: Ss,
			Tab: Zs,
			Toast: mo,
			Tooltip: ps
		};
	});
}));
//#endregion
export default require_bootstrap_bundle_min();

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYm9vdHN0cmFwX2Rpc3RfanNfYm9vdHN0cmFwX19idW5kbGVfX21pbl9fanMuanMiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiLi4vLi4vYm9vdHN0cmFwL2Rpc3QvanMvYm9vdHN0cmFwLmJ1bmRsZS5taW4uanMiXSwic291cmNlc0NvbnRlbnQiOlsiLyohXG4gICogQm9vdHN0cmFwIHY1LjMuOCAoaHR0cHM6Ly9nZXRib290c3RyYXAuY29tLylcbiAgKiBDb3B5cmlnaHQgMjAxMS0yMDI1IFRoZSBCb290c3RyYXAgQXV0aG9ycyAoaHR0cHM6Ly9naXRodWIuY29tL3R3YnMvYm9vdHN0cmFwL2dyYXBocy9jb250cmlidXRvcnMpXG4gICogTGljZW5zZWQgdW5kZXIgTUlUIChodHRwczovL2dpdGh1Yi5jb20vdHdicy9ib290c3RyYXAvYmxvYi9tYWluL0xJQ0VOU0UpXG4gICovXG4hZnVuY3Rpb24odCxlKXtcIm9iamVjdFwiPT10eXBlb2YgZXhwb3J0cyYmXCJ1bmRlZmluZWRcIiE9dHlwZW9mIG1vZHVsZT9tb2R1bGUuZXhwb3J0cz1lKCk6XCJmdW5jdGlvblwiPT10eXBlb2YgZGVmaW5lJiZkZWZpbmUuYW1kP2RlZmluZShlKToodD1cInVuZGVmaW5lZFwiIT10eXBlb2YgZ2xvYmFsVGhpcz9nbG9iYWxUaGlzOnR8fHNlbGYpLmJvb3RzdHJhcD1lKCl9KHRoaXMsZnVuY3Rpb24oKXtcInVzZSBzdHJpY3RcIjtjb25zdCB0PW5ldyBNYXAsZT17c2V0KGUsaSxuKXt0LmhhcyhlKXx8dC5zZXQoZSxuZXcgTWFwKTtjb25zdCBzPXQuZ2V0KGUpO3MuaGFzKGkpfHwwPT09cy5zaXplP3Muc2V0KGksbik6Y29uc29sZS5lcnJvcihgQm9vdHN0cmFwIGRvZXNuJ3QgYWxsb3cgbW9yZSB0aGFuIG9uZSBpbnN0YW5jZSBwZXIgZWxlbWVudC4gQm91bmQgaW5zdGFuY2U6ICR7QXJyYXkuZnJvbShzLmtleXMoKSlbMF19LmApfSxnZXQ6KGUsaSk9PnQuaGFzKGUpJiZ0LmdldChlKS5nZXQoaSl8fG51bGwscmVtb3ZlKGUsaSl7aWYoIXQuaGFzKGUpKXJldHVybjtjb25zdCBuPXQuZ2V0KGUpO24uZGVsZXRlKGkpLDA9PT1uLnNpemUmJnQuZGVsZXRlKGUpfX0saT1cInRyYW5zaXRpb25lbmRcIixuPXQ9Pih0JiZ3aW5kb3cuQ1NTJiZ3aW5kb3cuQ1NTLmVzY2FwZSYmKHQ9dC5yZXBsYWNlKC8jKFteXFxzXCIjJ10rKS9nLCh0LGUpPT5gIyR7Q1NTLmVzY2FwZShlKX1gKSksdCkscz10PT5udWxsPT10P2Ake3R9YDpPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwodCkubWF0Y2goL1xccyhbYS16XSspL2kpWzFdLnRvTG93ZXJDYXNlKCksbz10PT57dC5kaXNwYXRjaEV2ZW50KG5ldyBFdmVudChpKSl9LHI9dD0+ISghdHx8XCJvYmplY3RcIiE9dHlwZW9mIHQpJiYodm9pZCAwIT09dC5qcXVlcnkmJih0PXRbMF0pLHZvaWQgMCE9PXQubm9kZVR5cGUpLGE9dD0+cih0KT90LmpxdWVyeT90WzBdOnQ6XCJzdHJpbmdcIj09dHlwZW9mIHQmJnQubGVuZ3RoPjA/ZG9jdW1lbnQucXVlcnlTZWxlY3RvcihuKHQpKTpudWxsLGw9dD0+e2lmKCFyKHQpfHwwPT09dC5nZXRDbGllbnRSZWN0cygpLmxlbmd0aClyZXR1cm4hMTtjb25zdCBlPVwidmlzaWJsZVwiPT09Z2V0Q29tcHV0ZWRTdHlsZSh0KS5nZXRQcm9wZXJ0eVZhbHVlKFwidmlzaWJpbGl0eVwiKSxpPXQuY2xvc2VzdChcImRldGFpbHM6bm90KFtvcGVuXSlcIik7aWYoIWkpcmV0dXJuIGU7aWYoaSE9PXQpe2NvbnN0IGU9dC5jbG9zZXN0KFwic3VtbWFyeVwiKTtpZihlJiZlLnBhcmVudE5vZGUhPT1pKXJldHVybiExO2lmKG51bGw9PT1lKXJldHVybiExfXJldHVybiBlfSxjPXQ9PiF0fHx0Lm5vZGVUeXBlIT09Tm9kZS5FTEVNRU5UX05PREV8fCEhdC5jbGFzc0xpc3QuY29udGFpbnMoXCJkaXNhYmxlZFwiKXx8KHZvaWQgMCE9PXQuZGlzYWJsZWQ/dC5kaXNhYmxlZDp0Lmhhc0F0dHJpYnV0ZShcImRpc2FibGVkXCIpJiZcImZhbHNlXCIhPT10LmdldEF0dHJpYnV0ZShcImRpc2FibGVkXCIpKSxoPXQ9PntpZighZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LmF0dGFjaFNoYWRvdylyZXR1cm4gbnVsbDtpZihcImZ1bmN0aW9uXCI9PXR5cGVvZiB0LmdldFJvb3ROb2RlKXtjb25zdCBlPXQuZ2V0Um9vdE5vZGUoKTtyZXR1cm4gZSBpbnN0YW5jZW9mIFNoYWRvd1Jvb3Q/ZTpudWxsfXJldHVybiB0IGluc3RhbmNlb2YgU2hhZG93Um9vdD90OnQucGFyZW50Tm9kZT9oKHQucGFyZW50Tm9kZSk6bnVsbH0sZD0oKT0+e30sdT10PT57dC5vZmZzZXRIZWlnaHR9LGY9KCk9PndpbmRvdy5qUXVlcnkmJiFkb2N1bWVudC5ib2R5Lmhhc0F0dHJpYnV0ZShcImRhdGEtYnMtbm8tanF1ZXJ5XCIpP3dpbmRvdy5qUXVlcnk6bnVsbCxwPVtdLG09KCk9PlwicnRsXCI9PT1kb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuZGlyLGc9dD0+e3ZhciBlO2U9KCk9Pntjb25zdCBlPWYoKTtpZihlKXtjb25zdCBpPXQuTkFNRSxuPWUuZm5baV07ZS5mbltpXT10LmpRdWVyeUludGVyZmFjZSxlLmZuW2ldLkNvbnN0cnVjdG9yPXQsZS5mbltpXS5ub0NvbmZsaWN0PSgpPT4oZS5mbltpXT1uLHQualF1ZXJ5SW50ZXJmYWNlKX19LFwibG9hZGluZ1wiPT09ZG9jdW1lbnQucmVhZHlTdGF0ZT8ocC5sZW5ndGh8fGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJET01Db250ZW50TG9hZGVkXCIsKCk9Pntmb3IoY29uc3QgdCBvZiBwKXQoKX0pLHAucHVzaChlKSk6ZSgpfSxfPSh0LGU9W10saT10KT0+XCJmdW5jdGlvblwiPT10eXBlb2YgdD90LmNhbGwoLi4uZSk6aSxiPSh0LGUsbj0hMCk9PntpZighbilyZXR1cm4gdm9pZCBfKHQpO2NvbnN0IHM9KHQ9PntpZighdClyZXR1cm4gMDtsZXR7dHJhbnNpdGlvbkR1cmF0aW9uOmUsdHJhbnNpdGlvbkRlbGF5Oml9PXdpbmRvdy5nZXRDb21wdXRlZFN0eWxlKHQpO2NvbnN0IG49TnVtYmVyLnBhcnNlRmxvYXQoZSkscz1OdW1iZXIucGFyc2VGbG9hdChpKTtyZXR1cm4gbnx8cz8oZT1lLnNwbGl0KFwiLFwiKVswXSxpPWkuc3BsaXQoXCIsXCIpWzBdLDFlMyooTnVtYmVyLnBhcnNlRmxvYXQoZSkrTnVtYmVyLnBhcnNlRmxvYXQoaSkpKTowfSkoZSkrNTtsZXQgcj0hMTtjb25zdCBhPSh7dGFyZ2V0Om59KT0+e249PT1lJiYocj0hMCxlLnJlbW92ZUV2ZW50TGlzdGVuZXIoaSxhKSxfKHQpKX07ZS5hZGRFdmVudExpc3RlbmVyKGksYSksc2V0VGltZW91dCgoKT0+e3J8fG8oZSl9LHMpfSx2PSh0LGUsaSxuKT0+e2NvbnN0IHM9dC5sZW5ndGg7bGV0IG89dC5pbmRleE9mKGUpO3JldHVybi0xPT09bz8haSYmbj90W3MtMV06dFswXToobys9aT8xOi0xLG4mJihvPShvK3MpJXMpLHRbTWF0aC5tYXgoMCxNYXRoLm1pbihvLHMtMSkpXSl9LHk9L1teLl0qKD89XFwuLiopXFwufC4qLyx3PS9cXC4uKi8sQT0vOjpcXGQrJC8sRT17fTtsZXQgVD0xO2NvbnN0IEM9e21vdXNlZW50ZXI6XCJtb3VzZW92ZXJcIixtb3VzZWxlYXZlOlwibW91c2VvdXRcIn0sTz1uZXcgU2V0KFtcImNsaWNrXCIsXCJkYmxjbGlja1wiLFwibW91c2V1cFwiLFwibW91c2Vkb3duXCIsXCJjb250ZXh0bWVudVwiLFwibW91c2V3aGVlbFwiLFwiRE9NTW91c2VTY3JvbGxcIixcIm1vdXNlb3ZlclwiLFwibW91c2VvdXRcIixcIm1vdXNlbW92ZVwiLFwic2VsZWN0c3RhcnRcIixcInNlbGVjdGVuZFwiLFwia2V5ZG93blwiLFwia2V5cHJlc3NcIixcImtleXVwXCIsXCJvcmllbnRhdGlvbmNoYW5nZVwiLFwidG91Y2hzdGFydFwiLFwidG91Y2htb3ZlXCIsXCJ0b3VjaGVuZFwiLFwidG91Y2hjYW5jZWxcIixcInBvaW50ZXJkb3duXCIsXCJwb2ludGVybW92ZVwiLFwicG9pbnRlcnVwXCIsXCJwb2ludGVybGVhdmVcIixcInBvaW50ZXJjYW5jZWxcIixcImdlc3R1cmVzdGFydFwiLFwiZ2VzdHVyZWNoYW5nZVwiLFwiZ2VzdHVyZWVuZFwiLFwiZm9jdXNcIixcImJsdXJcIixcImNoYW5nZVwiLFwicmVzZXRcIixcInNlbGVjdFwiLFwic3VibWl0XCIsXCJmb2N1c2luXCIsXCJmb2N1c291dFwiLFwibG9hZFwiLFwidW5sb2FkXCIsXCJiZWZvcmV1bmxvYWRcIixcInJlc2l6ZVwiLFwibW92ZVwiLFwiRE9NQ29udGVudExvYWRlZFwiLFwicmVhZHlzdGF0ZWNoYW5nZVwiLFwiZXJyb3JcIixcImFib3J0XCIsXCJzY3JvbGxcIl0pO2Z1bmN0aW9uIHgodCxlKXtyZXR1cm4gZSYmYCR7ZX06OiR7VCsrfWB8fHQudWlkRXZlbnR8fFQrK31mdW5jdGlvbiBrKHQpe2NvbnN0IGU9eCh0KTtyZXR1cm4gdC51aWRFdmVudD1lLEVbZV09RVtlXXx8e30sRVtlXX1mdW5jdGlvbiBMKHQsZSxpPW51bGwpe3JldHVybiBPYmplY3QudmFsdWVzKHQpLmZpbmQodD0+dC5jYWxsYWJsZT09PWUmJnQuZGVsZWdhdGlvblNlbGVjdG9yPT09aSl9ZnVuY3Rpb24gUyh0LGUsaSl7Y29uc3Qgbj1cInN0cmluZ1wiPT10eXBlb2YgZSxzPW4/aTplfHxpO2xldCBvPU4odCk7cmV0dXJuIE8uaGFzKG8pfHwobz10KSxbbixzLG9dfWZ1bmN0aW9uIEQodCxlLGksbixzKXtpZihcInN0cmluZ1wiIT10eXBlb2YgZXx8IXQpcmV0dXJuO2xldFtvLHIsYV09UyhlLGksbik7aWYoZSBpbiBDKXtjb25zdCB0PXQ9PmZ1bmN0aW9uKGUpe2lmKCFlLnJlbGF0ZWRUYXJnZXR8fGUucmVsYXRlZFRhcmdldCE9PWUuZGVsZWdhdGVUYXJnZXQmJiFlLmRlbGVnYXRlVGFyZ2V0LmNvbnRhaW5zKGUucmVsYXRlZFRhcmdldCkpcmV0dXJuIHQuY2FsbCh0aGlzLGUpfTtyPXQocil9Y29uc3QgbD1rKHQpLGM9bFthXXx8KGxbYV09e30pLGg9TChjLHIsbz9pOm51bGwpO2lmKGgpcmV0dXJuIHZvaWQoaC5vbmVPZmY9aC5vbmVPZmYmJnMpO2NvbnN0IGQ9eChyLGUucmVwbGFjZSh5LFwiXCIpKSx1PW8/ZnVuY3Rpb24odCxlLGkpe3JldHVybiBmdW5jdGlvbiBuKHMpe2NvbnN0IG89dC5xdWVyeVNlbGVjdG9yQWxsKGUpO2ZvcihsZXR7dGFyZ2V0OnJ9PXM7ciYmciE9PXRoaXM7cj1yLnBhcmVudE5vZGUpZm9yKGNvbnN0IGEgb2YgbylpZihhPT09cilyZXR1cm4gaihzLHtkZWxlZ2F0ZVRhcmdldDpyfSksbi5vbmVPZmYmJlAub2ZmKHQscy50eXBlLGUsaSksaS5hcHBseShyLFtzXSl9fSh0LGkscik6ZnVuY3Rpb24odCxlKXtyZXR1cm4gZnVuY3Rpb24gaShuKXtyZXR1cm4gaihuLHtkZWxlZ2F0ZVRhcmdldDp0fSksaS5vbmVPZmYmJlAub2ZmKHQsbi50eXBlLGUpLGUuYXBwbHkodCxbbl0pfX0odCxyKTt1LmRlbGVnYXRpb25TZWxlY3Rvcj1vP2k6bnVsbCx1LmNhbGxhYmxlPXIsdS5vbmVPZmY9cyx1LnVpZEV2ZW50PWQsY1tkXT11LHQuYWRkRXZlbnRMaXN0ZW5lcihhLHUsbyl9ZnVuY3Rpb24gJCh0LGUsaSxuLHMpe2NvbnN0IG89TChlW2ldLG4scyk7byYmKHQucmVtb3ZlRXZlbnRMaXN0ZW5lcihpLG8sQm9vbGVhbihzKSksZGVsZXRlIGVbaV1bby51aWRFdmVudF0pfWZ1bmN0aW9uIEkodCxlLGksbil7Y29uc3Qgcz1lW2ldfHx7fTtmb3IoY29uc3RbbyxyXW9mIE9iamVjdC5lbnRyaWVzKHMpKW8uaW5jbHVkZXMobikmJiQodCxlLGksci5jYWxsYWJsZSxyLmRlbGVnYXRpb25TZWxlY3Rvcil9ZnVuY3Rpb24gTih0KXtyZXR1cm4gdD10LnJlcGxhY2UodyxcIlwiKSxDW3RdfHx0fWNvbnN0IFA9e29uKHQsZSxpLG4pe0QodCxlLGksbiwhMSl9LG9uZSh0LGUsaSxuKXtEKHQsZSxpLG4sITApfSxvZmYodCxlLGksbil7aWYoXCJzdHJpbmdcIiE9dHlwZW9mIGV8fCF0KXJldHVybjtjb25zdFtzLG8scl09UyhlLGksbiksYT1yIT09ZSxsPWsodCksYz1sW3JdfHx7fSxoPWUuc3RhcnRzV2l0aChcIi5cIik7aWYodm9pZCAwPT09byl7aWYoaClmb3IoY29uc3QgaSBvZiBPYmplY3Qua2V5cyhsKSlJKHQsbCxpLGUuc2xpY2UoMSkpO2Zvcihjb25zdFtpLG5db2YgT2JqZWN0LmVudHJpZXMoYykpe2NvbnN0IHM9aS5yZXBsYWNlKEEsXCJcIik7YSYmIWUuaW5jbHVkZXMocyl8fCQodCxsLHIsbi5jYWxsYWJsZSxuLmRlbGVnYXRpb25TZWxlY3Rvcil9fWVsc2V7aWYoIU9iamVjdC5rZXlzKGMpLmxlbmd0aClyZXR1cm47JCh0LGwscixvLHM/aTpudWxsKX19LHRyaWdnZXIodCxlLGkpe2lmKFwic3RyaW5nXCIhPXR5cGVvZiBlfHwhdClyZXR1cm4gbnVsbDtjb25zdCBuPWYoKTtsZXQgcz1udWxsLG89ITAscj0hMCxhPSExO2UhPT1OKGUpJiZuJiYocz1uLkV2ZW50KGUsaSksbih0KS50cmlnZ2VyKHMpLG89IXMuaXNQcm9wYWdhdGlvblN0b3BwZWQoKSxyPSFzLmlzSW1tZWRpYXRlUHJvcGFnYXRpb25TdG9wcGVkKCksYT1zLmlzRGVmYXVsdFByZXZlbnRlZCgpKTtjb25zdCBsPWoobmV3IEV2ZW50KGUse2J1YmJsZXM6byxjYW5jZWxhYmxlOiEwfSksaSk7cmV0dXJuIGEmJmwucHJldmVudERlZmF1bHQoKSxyJiZ0LmRpc3BhdGNoRXZlbnQobCksbC5kZWZhdWx0UHJldmVudGVkJiZzJiZzLnByZXZlbnREZWZhdWx0KCksbH19O2Z1bmN0aW9uIGoodCxlPXt9KXtmb3IoY29uc3RbaSxuXW9mIE9iamVjdC5lbnRyaWVzKGUpKXRyeXt0W2ldPW59Y2F0Y2goZSl7T2JqZWN0LmRlZmluZVByb3BlcnR5KHQsaSx7Y29uZmlndXJhYmxlOiEwLGdldDooKT0+bn0pfXJldHVybiB0fWZ1bmN0aW9uIE0odCl7aWYoXCJ0cnVlXCI9PT10KXJldHVybiEwO2lmKFwiZmFsc2VcIj09PXQpcmV0dXJuITE7aWYodD09PU51bWJlcih0KS50b1N0cmluZygpKXJldHVybiBOdW1iZXIodCk7aWYoXCJcIj09PXR8fFwibnVsbFwiPT09dClyZXR1cm4gbnVsbDtpZihcInN0cmluZ1wiIT10eXBlb2YgdClyZXR1cm4gdDt0cnl7cmV0dXJuIEpTT04ucGFyc2UoZGVjb2RlVVJJQ29tcG9uZW50KHQpKX1jYXRjaChlKXtyZXR1cm4gdH19ZnVuY3Rpb24gRih0KXtyZXR1cm4gdC5yZXBsYWNlKC9bQS1aXS9nLHQ9PmAtJHt0LnRvTG93ZXJDYXNlKCl9YCl9Y29uc3QgSD17c2V0RGF0YUF0dHJpYnV0ZSh0LGUsaSl7dC5zZXRBdHRyaWJ1dGUoYGRhdGEtYnMtJHtGKGUpfWAsaSl9LHJlbW92ZURhdGFBdHRyaWJ1dGUodCxlKXt0LnJlbW92ZUF0dHJpYnV0ZShgZGF0YS1icy0ke0YoZSl9YCl9LGdldERhdGFBdHRyaWJ1dGVzKHQpe2lmKCF0KXJldHVybnt9O2NvbnN0IGU9e30saT1PYmplY3Qua2V5cyh0LmRhdGFzZXQpLmZpbHRlcih0PT50LnN0YXJ0c1dpdGgoXCJic1wiKSYmIXQuc3RhcnRzV2l0aChcImJzQ29uZmlnXCIpKTtmb3IoY29uc3QgbiBvZiBpKXtsZXQgaT1uLnJlcGxhY2UoL15icy8sXCJcIik7aT1pLmNoYXJBdCgwKS50b0xvd2VyQ2FzZSgpK2kuc2xpY2UoMSksZVtpXT1NKHQuZGF0YXNldFtuXSl9cmV0dXJuIGV9LGdldERhdGFBdHRyaWJ1dGU6KHQsZSk9Pk0odC5nZXRBdHRyaWJ1dGUoYGRhdGEtYnMtJHtGKGUpfWApKX07Y2xhc3MgV3tzdGF0aWMgZ2V0IERlZmF1bHQoKXtyZXR1cm57fX1zdGF0aWMgZ2V0IERlZmF1bHRUeXBlKCl7cmV0dXJue319c3RhdGljIGdldCBOQU1FKCl7dGhyb3cgbmV3IEVycm9yKCdZb3UgaGF2ZSB0byBpbXBsZW1lbnQgdGhlIHN0YXRpYyBtZXRob2QgXCJOQU1FXCIsIGZvciBlYWNoIGNvbXBvbmVudCEnKX1fZ2V0Q29uZmlnKHQpe3JldHVybiB0PXRoaXMuX21lcmdlQ29uZmlnT2JqKHQpLHQ9dGhpcy5fY29uZmlnQWZ0ZXJNZXJnZSh0KSx0aGlzLl90eXBlQ2hlY2tDb25maWcodCksdH1fY29uZmlnQWZ0ZXJNZXJnZSh0KXtyZXR1cm4gdH1fbWVyZ2VDb25maWdPYmoodCxlKXtjb25zdCBpPXIoZSk/SC5nZXREYXRhQXR0cmlidXRlKGUsXCJjb25maWdcIik6e307cmV0dXJuey4uLnRoaXMuY29uc3RydWN0b3IuRGVmYXVsdCwuLi5cIm9iamVjdFwiPT10eXBlb2YgaT9pOnt9LC4uLnIoZSk/SC5nZXREYXRhQXR0cmlidXRlcyhlKTp7fSwuLi5cIm9iamVjdFwiPT10eXBlb2YgdD90Ont9fX1fdHlwZUNoZWNrQ29uZmlnKHQsZT10aGlzLmNvbnN0cnVjdG9yLkRlZmF1bHRUeXBlKXtmb3IoY29uc3RbaSxuXW9mIE9iamVjdC5lbnRyaWVzKGUpKXtjb25zdCBlPXRbaV0sbz1yKGUpP1wiZWxlbWVudFwiOnMoZSk7aWYoIW5ldyBSZWdFeHAobikudGVzdChvKSl0aHJvdyBuZXcgVHlwZUVycm9yKGAke3RoaXMuY29uc3RydWN0b3IuTkFNRS50b1VwcGVyQ2FzZSgpfTogT3B0aW9uIFwiJHtpfVwiIHByb3ZpZGVkIHR5cGUgXCIke299XCIgYnV0IGV4cGVjdGVkIHR5cGUgXCIke259XCIuYCl9fX1jbGFzcyBCIGV4dGVuZHMgV3tjb25zdHJ1Y3Rvcih0LGkpe3N1cGVyKCksKHQ9YSh0KSkmJih0aGlzLl9lbGVtZW50PXQsdGhpcy5fY29uZmlnPXRoaXMuX2dldENvbmZpZyhpKSxlLnNldCh0aGlzLl9lbGVtZW50LHRoaXMuY29uc3RydWN0b3IuREFUQV9LRVksdGhpcykpfWRpc3Bvc2UoKXtlLnJlbW92ZSh0aGlzLl9lbGVtZW50LHRoaXMuY29uc3RydWN0b3IuREFUQV9LRVkpLFAub2ZmKHRoaXMuX2VsZW1lbnQsdGhpcy5jb25zdHJ1Y3Rvci5FVkVOVF9LRVkpO2Zvcihjb25zdCB0IG9mIE9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzKHRoaXMpKXRoaXNbdF09bnVsbH1fcXVldWVDYWxsYmFjayh0LGUsaT0hMCl7Yih0LGUsaSl9X2dldENvbmZpZyh0KXtyZXR1cm4gdD10aGlzLl9tZXJnZUNvbmZpZ09iaih0LHRoaXMuX2VsZW1lbnQpLHQ9dGhpcy5fY29uZmlnQWZ0ZXJNZXJnZSh0KSx0aGlzLl90eXBlQ2hlY2tDb25maWcodCksdH1zdGF0aWMgZ2V0SW5zdGFuY2UodCl7cmV0dXJuIGUuZ2V0KGEodCksdGhpcy5EQVRBX0tFWSl9c3RhdGljIGdldE9yQ3JlYXRlSW5zdGFuY2UodCxlPXt9KXtyZXR1cm4gdGhpcy5nZXRJbnN0YW5jZSh0KXx8bmV3IHRoaXModCxcIm9iamVjdFwiPT10eXBlb2YgZT9lOm51bGwpfXN0YXRpYyBnZXQgVkVSU0lPTigpe3JldHVyblwiNS4zLjhcIn1zdGF0aWMgZ2V0IERBVEFfS0VZKCl7cmV0dXJuYGJzLiR7dGhpcy5OQU1FfWB9c3RhdGljIGdldCBFVkVOVF9LRVkoKXtyZXR1cm5gLiR7dGhpcy5EQVRBX0tFWX1gfXN0YXRpYyBldmVudE5hbWUodCl7cmV0dXJuYCR7dH0ke3RoaXMuRVZFTlRfS0VZfWB9fWNvbnN0IHo9dD0+e2xldCBlPXQuZ2V0QXR0cmlidXRlKFwiZGF0YS1icy10YXJnZXRcIik7aWYoIWV8fFwiI1wiPT09ZSl7bGV0IGk9dC5nZXRBdHRyaWJ1dGUoXCJocmVmXCIpO2lmKCFpfHwhaS5pbmNsdWRlcyhcIiNcIikmJiFpLnN0YXJ0c1dpdGgoXCIuXCIpKXJldHVybiBudWxsO2kuaW5jbHVkZXMoXCIjXCIpJiYhaS5zdGFydHNXaXRoKFwiI1wiKSYmKGk9YCMke2kuc3BsaXQoXCIjXCIpWzFdfWApLGU9aSYmXCIjXCIhPT1pP2kudHJpbSgpOm51bGx9cmV0dXJuIGU/ZS5zcGxpdChcIixcIikubWFwKHQ9Pm4odCkpLmpvaW4oXCIsXCIpOm51bGx9LFI9e2ZpbmQ6KHQsZT1kb2N1bWVudC5kb2N1bWVudEVsZW1lbnQpPT5bXS5jb25jYXQoLi4uRWxlbWVudC5wcm90b3R5cGUucXVlcnlTZWxlY3RvckFsbC5jYWxsKGUsdCkpLGZpbmRPbmU6KHQsZT1kb2N1bWVudC5kb2N1bWVudEVsZW1lbnQpPT5FbGVtZW50LnByb3RvdHlwZS5xdWVyeVNlbGVjdG9yLmNhbGwoZSx0KSxjaGlsZHJlbjoodCxlKT0+W10uY29uY2F0KC4uLnQuY2hpbGRyZW4pLmZpbHRlcih0PT50Lm1hdGNoZXMoZSkpLHBhcmVudHModCxlKXtjb25zdCBpPVtdO2xldCBuPXQucGFyZW50Tm9kZS5jbG9zZXN0KGUpO2Zvcig7bjspaS5wdXNoKG4pLG49bi5wYXJlbnROb2RlLmNsb3Nlc3QoZSk7cmV0dXJuIGl9LHByZXYodCxlKXtsZXQgaT10LnByZXZpb3VzRWxlbWVudFNpYmxpbmc7Zm9yKDtpOyl7aWYoaS5tYXRjaGVzKGUpKXJldHVybltpXTtpPWkucHJldmlvdXNFbGVtZW50U2libGluZ31yZXR1cm5bXX0sbmV4dCh0LGUpe2xldCBpPXQubmV4dEVsZW1lbnRTaWJsaW5nO2Zvcig7aTspe2lmKGkubWF0Y2hlcyhlKSlyZXR1cm5baV07aT1pLm5leHRFbGVtZW50U2libGluZ31yZXR1cm5bXX0sZm9jdXNhYmxlQ2hpbGRyZW4odCl7Y29uc3QgZT1bXCJhXCIsXCJidXR0b25cIixcImlucHV0XCIsXCJ0ZXh0YXJlYVwiLFwic2VsZWN0XCIsXCJkZXRhaWxzXCIsXCJbdGFiaW5kZXhdXCIsJ1tjb250ZW50ZWRpdGFibGU9XCJ0cnVlXCJdJ10ubWFwKHQ9PmAke3R9Om5vdChbdGFiaW5kZXhePVwiLVwiXSlgKS5qb2luKFwiLFwiKTtyZXR1cm4gdGhpcy5maW5kKGUsdCkuZmlsdGVyKHQ9PiFjKHQpJiZsKHQpKX0sZ2V0U2VsZWN0b3JGcm9tRWxlbWVudCh0KXtjb25zdCBlPXoodCk7cmV0dXJuIGUmJlIuZmluZE9uZShlKT9lOm51bGx9LGdldEVsZW1lbnRGcm9tU2VsZWN0b3IodCl7Y29uc3QgZT16KHQpO3JldHVybiBlP1IuZmluZE9uZShlKTpudWxsfSxnZXRNdWx0aXBsZUVsZW1lbnRzRnJvbVNlbGVjdG9yKHQpe2NvbnN0IGU9eih0KTtyZXR1cm4gZT9SLmZpbmQoZSk6W119fSxxPSh0LGU9XCJoaWRlXCIpPT57Y29uc3QgaT1gY2xpY2suZGlzbWlzcyR7dC5FVkVOVF9LRVl9YCxuPXQuTkFNRTtQLm9uKGRvY3VtZW50LGksYFtkYXRhLWJzLWRpc21pc3M9XCIke259XCJdYCxmdW5jdGlvbihpKXtpZihbXCJBXCIsXCJBUkVBXCJdLmluY2x1ZGVzKHRoaXMudGFnTmFtZSkmJmkucHJldmVudERlZmF1bHQoKSxjKHRoaXMpKXJldHVybjtjb25zdCBzPVIuZ2V0RWxlbWVudEZyb21TZWxlY3Rvcih0aGlzKXx8dGhpcy5jbG9zZXN0KGAuJHtufWApO3QuZ2V0T3JDcmVhdGVJbnN0YW5jZShzKVtlXSgpfSl9LFY9XCIuYnMuYWxlcnRcIixLPWBjbG9zZSR7Vn1gLFE9YGNsb3NlZCR7Vn1gO2NsYXNzIFggZXh0ZW5kcyBCe3N0YXRpYyBnZXQgTkFNRSgpe3JldHVyblwiYWxlcnRcIn1jbG9zZSgpe2lmKFAudHJpZ2dlcih0aGlzLl9lbGVtZW50LEspLmRlZmF1bHRQcmV2ZW50ZWQpcmV0dXJuO3RoaXMuX2VsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZShcInNob3dcIik7Y29uc3QgdD10aGlzLl9lbGVtZW50LmNsYXNzTGlzdC5jb250YWlucyhcImZhZGVcIik7dGhpcy5fcXVldWVDYWxsYmFjaygoKT0+dGhpcy5fZGVzdHJveUVsZW1lbnQoKSx0aGlzLl9lbGVtZW50LHQpfV9kZXN0cm95RWxlbWVudCgpe3RoaXMuX2VsZW1lbnQucmVtb3ZlKCksUC50cmlnZ2VyKHRoaXMuX2VsZW1lbnQsUSksdGhpcy5kaXNwb3NlKCl9c3RhdGljIGpRdWVyeUludGVyZmFjZSh0KXtyZXR1cm4gdGhpcy5lYWNoKGZ1bmN0aW9uKCl7Y29uc3QgZT1YLmdldE9yQ3JlYXRlSW5zdGFuY2UodGhpcyk7aWYoXCJzdHJpbmdcIj09dHlwZW9mIHQpe2lmKHZvaWQgMD09PWVbdF18fHQuc3RhcnRzV2l0aChcIl9cIil8fFwiY29uc3RydWN0b3JcIj09PXQpdGhyb3cgbmV3IFR5cGVFcnJvcihgTm8gbWV0aG9kIG5hbWVkIFwiJHt0fVwiYCk7ZVt0XSh0aGlzKX19KX19cShYLFwiY2xvc2VcIiksZyhYKTtjb25zdCBZPSdbZGF0YS1icy10b2dnbGU9XCJidXR0b25cIl0nO2NsYXNzIFUgZXh0ZW5kcyBCe3N0YXRpYyBnZXQgTkFNRSgpe3JldHVyblwiYnV0dG9uXCJ9dG9nZ2xlKCl7dGhpcy5fZWxlbWVudC5zZXRBdHRyaWJ1dGUoXCJhcmlhLXByZXNzZWRcIix0aGlzLl9lbGVtZW50LmNsYXNzTGlzdC50b2dnbGUoXCJhY3RpdmVcIikpfXN0YXRpYyBqUXVlcnlJbnRlcmZhY2UodCl7cmV0dXJuIHRoaXMuZWFjaChmdW5jdGlvbigpe2NvbnN0IGU9VS5nZXRPckNyZWF0ZUluc3RhbmNlKHRoaXMpO1widG9nZ2xlXCI9PT10JiZlW3RdKCl9KX19UC5vbihkb2N1bWVudCxcImNsaWNrLmJzLmJ1dHRvbi5kYXRhLWFwaVwiLFksdD0+e3QucHJldmVudERlZmF1bHQoKTtjb25zdCBlPXQudGFyZ2V0LmNsb3Nlc3QoWSk7VS5nZXRPckNyZWF0ZUluc3RhbmNlKGUpLnRvZ2dsZSgpfSksZyhVKTtjb25zdCBHPVwiLmJzLnN3aXBlXCIsSj1gdG91Y2hzdGFydCR7R31gLFo9YHRvdWNobW92ZSR7R31gLHR0PWB0b3VjaGVuZCR7R31gLGV0PWBwb2ludGVyZG93biR7R31gLGl0PWBwb2ludGVydXAke0d9YCxudD17ZW5kQ2FsbGJhY2s6bnVsbCxsZWZ0Q2FsbGJhY2s6bnVsbCxyaWdodENhbGxiYWNrOm51bGx9LHN0PXtlbmRDYWxsYmFjazpcIihmdW5jdGlvbnxudWxsKVwiLGxlZnRDYWxsYmFjazpcIihmdW5jdGlvbnxudWxsKVwiLHJpZ2h0Q2FsbGJhY2s6XCIoZnVuY3Rpb258bnVsbClcIn07Y2xhc3Mgb3QgZXh0ZW5kcyBXe2NvbnN0cnVjdG9yKHQsZSl7c3VwZXIoKSx0aGlzLl9lbGVtZW50PXQsdCYmb3QuaXNTdXBwb3J0ZWQoKSYmKHRoaXMuX2NvbmZpZz10aGlzLl9nZXRDb25maWcoZSksdGhpcy5fZGVsdGFYPTAsdGhpcy5fc3VwcG9ydFBvaW50ZXJFdmVudHM9Qm9vbGVhbih3aW5kb3cuUG9pbnRlckV2ZW50KSx0aGlzLl9pbml0RXZlbnRzKCkpfXN0YXRpYyBnZXQgRGVmYXVsdCgpe3JldHVybiBudH1zdGF0aWMgZ2V0IERlZmF1bHRUeXBlKCl7cmV0dXJuIHN0fXN0YXRpYyBnZXQgTkFNRSgpe3JldHVyblwic3dpcGVcIn1kaXNwb3NlKCl7UC5vZmYodGhpcy5fZWxlbWVudCxHKX1fc3RhcnQodCl7dGhpcy5fc3VwcG9ydFBvaW50ZXJFdmVudHM/dGhpcy5fZXZlbnRJc1BvaW50ZXJQZW5Ub3VjaCh0KSYmKHRoaXMuX2RlbHRhWD10LmNsaWVudFgpOnRoaXMuX2RlbHRhWD10LnRvdWNoZXNbMF0uY2xpZW50WH1fZW5kKHQpe3RoaXMuX2V2ZW50SXNQb2ludGVyUGVuVG91Y2godCkmJih0aGlzLl9kZWx0YVg9dC5jbGllbnRYLXRoaXMuX2RlbHRhWCksdGhpcy5faGFuZGxlU3dpcGUoKSxfKHRoaXMuX2NvbmZpZy5lbmRDYWxsYmFjayl9X21vdmUodCl7dGhpcy5fZGVsdGFYPXQudG91Y2hlcyYmdC50b3VjaGVzLmxlbmd0aD4xPzA6dC50b3VjaGVzWzBdLmNsaWVudFgtdGhpcy5fZGVsdGFYfV9oYW5kbGVTd2lwZSgpe2NvbnN0IHQ9TWF0aC5hYnModGhpcy5fZGVsdGFYKTtpZih0PD00MClyZXR1cm47Y29uc3QgZT10L3RoaXMuX2RlbHRhWDt0aGlzLl9kZWx0YVg9MCxlJiZfKGU+MD90aGlzLl9jb25maWcucmlnaHRDYWxsYmFjazp0aGlzLl9jb25maWcubGVmdENhbGxiYWNrKX1faW5pdEV2ZW50cygpe3RoaXMuX3N1cHBvcnRQb2ludGVyRXZlbnRzPyhQLm9uKHRoaXMuX2VsZW1lbnQsZXQsdD0+dGhpcy5fc3RhcnQodCkpLFAub24odGhpcy5fZWxlbWVudCxpdCx0PT50aGlzLl9lbmQodCkpLHRoaXMuX2VsZW1lbnQuY2xhc3NMaXN0LmFkZChcInBvaW50ZXItZXZlbnRcIikpOihQLm9uKHRoaXMuX2VsZW1lbnQsSix0PT50aGlzLl9zdGFydCh0KSksUC5vbih0aGlzLl9lbGVtZW50LFosdD0+dGhpcy5fbW92ZSh0KSksUC5vbih0aGlzLl9lbGVtZW50LHR0LHQ9PnRoaXMuX2VuZCh0KSkpfV9ldmVudElzUG9pbnRlclBlblRvdWNoKHQpe3JldHVybiB0aGlzLl9zdXBwb3J0UG9pbnRlckV2ZW50cyYmKFwicGVuXCI9PT10LnBvaW50ZXJUeXBlfHxcInRvdWNoXCI9PT10LnBvaW50ZXJUeXBlKX1zdGF0aWMgaXNTdXBwb3J0ZWQoKXtyZXR1cm5cIm9udG91Y2hzdGFydFwiaW4gZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50fHxuYXZpZ2F0b3IubWF4VG91Y2hQb2ludHM+MH19Y29uc3QgcnQ9XCIuYnMuY2Fyb3VzZWxcIixhdD1cIi5kYXRhLWFwaVwiLGx0PVwiQXJyb3dMZWZ0XCIsY3Q9XCJBcnJvd1JpZ2h0XCIsaHQ9XCJuZXh0XCIsZHQ9XCJwcmV2XCIsdXQ9XCJsZWZ0XCIsZnQ9XCJyaWdodFwiLHB0PWBzbGlkZSR7cnR9YCxtdD1gc2xpZCR7cnR9YCxndD1ga2V5ZG93biR7cnR9YCxfdD1gbW91c2VlbnRlciR7cnR9YCxidD1gbW91c2VsZWF2ZSR7cnR9YCx2dD1gZHJhZ3N0YXJ0JHtydH1gLHl0PWBsb2FkJHtydH0ke2F0fWAsd3Q9YGNsaWNrJHtydH0ke2F0fWAsQXQ9XCJjYXJvdXNlbFwiLEV0PVwiYWN0aXZlXCIsVHQ9XCIuYWN0aXZlXCIsQ3Q9XCIuY2Fyb3VzZWwtaXRlbVwiLE90PVR0K0N0LHh0PXtbbHRdOmZ0LFtjdF06dXR9LGt0PXtpbnRlcnZhbDo1ZTMsa2V5Ym9hcmQ6ITAscGF1c2U6XCJob3ZlclwiLHJpZGU6ITEsdG91Y2g6ITAsd3JhcDohMH0sTHQ9e2ludGVydmFsOlwiKG51bWJlcnxib29sZWFuKVwiLGtleWJvYXJkOlwiYm9vbGVhblwiLHBhdXNlOlwiKHN0cmluZ3xib29sZWFuKVwiLHJpZGU6XCIoYm9vbGVhbnxzdHJpbmcpXCIsdG91Y2g6XCJib29sZWFuXCIsd3JhcDpcImJvb2xlYW5cIn07Y2xhc3MgU3QgZXh0ZW5kcyBCe2NvbnN0cnVjdG9yKHQsZSl7c3VwZXIodCxlKSx0aGlzLl9pbnRlcnZhbD1udWxsLHRoaXMuX2FjdGl2ZUVsZW1lbnQ9bnVsbCx0aGlzLl9pc1NsaWRpbmc9ITEsdGhpcy50b3VjaFRpbWVvdXQ9bnVsbCx0aGlzLl9zd2lwZUhlbHBlcj1udWxsLHRoaXMuX2luZGljYXRvcnNFbGVtZW50PVIuZmluZE9uZShcIi5jYXJvdXNlbC1pbmRpY2F0b3JzXCIsdGhpcy5fZWxlbWVudCksdGhpcy5fYWRkRXZlbnRMaXN0ZW5lcnMoKSx0aGlzLl9jb25maWcucmlkZT09PUF0JiZ0aGlzLmN5Y2xlKCl9c3RhdGljIGdldCBEZWZhdWx0KCl7cmV0dXJuIGt0fXN0YXRpYyBnZXQgRGVmYXVsdFR5cGUoKXtyZXR1cm4gTHR9c3RhdGljIGdldCBOQU1FKCl7cmV0dXJuXCJjYXJvdXNlbFwifW5leHQoKXt0aGlzLl9zbGlkZShodCl9bmV4dFdoZW5WaXNpYmxlKCl7IWRvY3VtZW50LmhpZGRlbiYmbCh0aGlzLl9lbGVtZW50KSYmdGhpcy5uZXh0KCl9cHJldigpe3RoaXMuX3NsaWRlKGR0KX1wYXVzZSgpe3RoaXMuX2lzU2xpZGluZyYmbyh0aGlzLl9lbGVtZW50KSx0aGlzLl9jbGVhckludGVydmFsKCl9Y3ljbGUoKXt0aGlzLl9jbGVhckludGVydmFsKCksdGhpcy5fdXBkYXRlSW50ZXJ2YWwoKSx0aGlzLl9pbnRlcnZhbD1zZXRJbnRlcnZhbCgoKT0+dGhpcy5uZXh0V2hlblZpc2libGUoKSx0aGlzLl9jb25maWcuaW50ZXJ2YWwpfV9tYXliZUVuYWJsZUN5Y2xlKCl7dGhpcy5fY29uZmlnLnJpZGUmJih0aGlzLl9pc1NsaWRpbmc/UC5vbmUodGhpcy5fZWxlbWVudCxtdCwoKT0+dGhpcy5jeWNsZSgpKTp0aGlzLmN5Y2xlKCkpfXRvKHQpe2NvbnN0IGU9dGhpcy5fZ2V0SXRlbXMoKTtpZih0PmUubGVuZ3RoLTF8fHQ8MClyZXR1cm47aWYodGhpcy5faXNTbGlkaW5nKXJldHVybiB2b2lkIFAub25lKHRoaXMuX2VsZW1lbnQsbXQsKCk9PnRoaXMudG8odCkpO2NvbnN0IGk9dGhpcy5fZ2V0SXRlbUluZGV4KHRoaXMuX2dldEFjdGl2ZSgpKTtpZihpPT09dClyZXR1cm47Y29uc3Qgbj10Pmk/aHQ6ZHQ7dGhpcy5fc2xpZGUobixlW3RdKX1kaXNwb3NlKCl7dGhpcy5fc3dpcGVIZWxwZXImJnRoaXMuX3N3aXBlSGVscGVyLmRpc3Bvc2UoKSxzdXBlci5kaXNwb3NlKCl9X2NvbmZpZ0FmdGVyTWVyZ2UodCl7cmV0dXJuIHQuZGVmYXVsdEludGVydmFsPXQuaW50ZXJ2YWwsdH1fYWRkRXZlbnRMaXN0ZW5lcnMoKXt0aGlzLl9jb25maWcua2V5Ym9hcmQmJlAub24odGhpcy5fZWxlbWVudCxndCx0PT50aGlzLl9rZXlkb3duKHQpKSxcImhvdmVyXCI9PT10aGlzLl9jb25maWcucGF1c2UmJihQLm9uKHRoaXMuX2VsZW1lbnQsX3QsKCk9PnRoaXMucGF1c2UoKSksUC5vbih0aGlzLl9lbGVtZW50LGJ0LCgpPT50aGlzLl9tYXliZUVuYWJsZUN5Y2xlKCkpKSx0aGlzLl9jb25maWcudG91Y2gmJm90LmlzU3VwcG9ydGVkKCkmJnRoaXMuX2FkZFRvdWNoRXZlbnRMaXN0ZW5lcnMoKX1fYWRkVG91Y2hFdmVudExpc3RlbmVycygpe2Zvcihjb25zdCB0IG9mIFIuZmluZChcIi5jYXJvdXNlbC1pdGVtIGltZ1wiLHRoaXMuX2VsZW1lbnQpKVAub24odCx2dCx0PT50LnByZXZlbnREZWZhdWx0KCkpO2NvbnN0IHQ9e2xlZnRDYWxsYmFjazooKT0+dGhpcy5fc2xpZGUodGhpcy5fZGlyZWN0aW9uVG9PcmRlcih1dCkpLHJpZ2h0Q2FsbGJhY2s6KCk9PnRoaXMuX3NsaWRlKHRoaXMuX2RpcmVjdGlvblRvT3JkZXIoZnQpKSxlbmRDYWxsYmFjazooKT0+e1wiaG92ZXJcIj09PXRoaXMuX2NvbmZpZy5wYXVzZSYmKHRoaXMucGF1c2UoKSx0aGlzLnRvdWNoVGltZW91dCYmY2xlYXJUaW1lb3V0KHRoaXMudG91Y2hUaW1lb3V0KSx0aGlzLnRvdWNoVGltZW91dD1zZXRUaW1lb3V0KCgpPT50aGlzLl9tYXliZUVuYWJsZUN5Y2xlKCksNTAwK3RoaXMuX2NvbmZpZy5pbnRlcnZhbCkpfX07dGhpcy5fc3dpcGVIZWxwZXI9bmV3IG90KHRoaXMuX2VsZW1lbnQsdCl9X2tleWRvd24odCl7aWYoL2lucHV0fHRleHRhcmVhL2kudGVzdCh0LnRhcmdldC50YWdOYW1lKSlyZXR1cm47Y29uc3QgZT14dFt0LmtleV07ZSYmKHQucHJldmVudERlZmF1bHQoKSx0aGlzLl9zbGlkZSh0aGlzLl9kaXJlY3Rpb25Ub09yZGVyKGUpKSl9X2dldEl0ZW1JbmRleCh0KXtyZXR1cm4gdGhpcy5fZ2V0SXRlbXMoKS5pbmRleE9mKHQpfV9zZXRBY3RpdmVJbmRpY2F0b3JFbGVtZW50KHQpe2lmKCF0aGlzLl9pbmRpY2F0b3JzRWxlbWVudClyZXR1cm47Y29uc3QgZT1SLmZpbmRPbmUoVHQsdGhpcy5faW5kaWNhdG9yc0VsZW1lbnQpO2UuY2xhc3NMaXN0LnJlbW92ZShFdCksZS5yZW1vdmVBdHRyaWJ1dGUoXCJhcmlhLWN1cnJlbnRcIik7Y29uc3QgaT1SLmZpbmRPbmUoYFtkYXRhLWJzLXNsaWRlLXRvPVwiJHt0fVwiXWAsdGhpcy5faW5kaWNhdG9yc0VsZW1lbnQpO2kmJihpLmNsYXNzTGlzdC5hZGQoRXQpLGkuc2V0QXR0cmlidXRlKFwiYXJpYS1jdXJyZW50XCIsXCJ0cnVlXCIpKX1fdXBkYXRlSW50ZXJ2YWwoKXtjb25zdCB0PXRoaXMuX2FjdGl2ZUVsZW1lbnR8fHRoaXMuX2dldEFjdGl2ZSgpO2lmKCF0KXJldHVybjtjb25zdCBlPU51bWJlci5wYXJzZUludCh0LmdldEF0dHJpYnV0ZShcImRhdGEtYnMtaW50ZXJ2YWxcIiksMTApO3RoaXMuX2NvbmZpZy5pbnRlcnZhbD1lfHx0aGlzLl9jb25maWcuZGVmYXVsdEludGVydmFsfV9zbGlkZSh0LGU9bnVsbCl7aWYodGhpcy5faXNTbGlkaW5nKXJldHVybjtjb25zdCBpPXRoaXMuX2dldEFjdGl2ZSgpLG49dD09PWh0LHM9ZXx8dih0aGlzLl9nZXRJdGVtcygpLGksbix0aGlzLl9jb25maWcud3JhcCk7aWYocz09PWkpcmV0dXJuO2NvbnN0IG89dGhpcy5fZ2V0SXRlbUluZGV4KHMpLHI9ZT0+UC50cmlnZ2VyKHRoaXMuX2VsZW1lbnQsZSx7cmVsYXRlZFRhcmdldDpzLGRpcmVjdGlvbjp0aGlzLl9vcmRlclRvRGlyZWN0aW9uKHQpLGZyb206dGhpcy5fZ2V0SXRlbUluZGV4KGkpLHRvOm99KTtpZihyKHB0KS5kZWZhdWx0UHJldmVudGVkKXJldHVybjtpZighaXx8IXMpcmV0dXJuO2NvbnN0IGE9Qm9vbGVhbih0aGlzLl9pbnRlcnZhbCk7dGhpcy5wYXVzZSgpLHRoaXMuX2lzU2xpZGluZz0hMCx0aGlzLl9zZXRBY3RpdmVJbmRpY2F0b3JFbGVtZW50KG8pLHRoaXMuX2FjdGl2ZUVsZW1lbnQ9cztjb25zdCBsPW4/XCJjYXJvdXNlbC1pdGVtLXN0YXJ0XCI6XCJjYXJvdXNlbC1pdGVtLWVuZFwiLGM9bj9cImNhcm91c2VsLWl0ZW0tbmV4dFwiOlwiY2Fyb3VzZWwtaXRlbS1wcmV2XCI7cy5jbGFzc0xpc3QuYWRkKGMpLHUocyksaS5jbGFzc0xpc3QuYWRkKGwpLHMuY2xhc3NMaXN0LmFkZChsKSx0aGlzLl9xdWV1ZUNhbGxiYWNrKCgpPT57cy5jbGFzc0xpc3QucmVtb3ZlKGwsYykscy5jbGFzc0xpc3QuYWRkKEV0KSxpLmNsYXNzTGlzdC5yZW1vdmUoRXQsYyxsKSx0aGlzLl9pc1NsaWRpbmc9ITEscihtdCl9LGksdGhpcy5faXNBbmltYXRlZCgpKSxhJiZ0aGlzLmN5Y2xlKCl9X2lzQW5pbWF0ZWQoKXtyZXR1cm4gdGhpcy5fZWxlbWVudC5jbGFzc0xpc3QuY29udGFpbnMoXCJzbGlkZVwiKX1fZ2V0QWN0aXZlKCl7cmV0dXJuIFIuZmluZE9uZShPdCx0aGlzLl9lbGVtZW50KX1fZ2V0SXRlbXMoKXtyZXR1cm4gUi5maW5kKEN0LHRoaXMuX2VsZW1lbnQpfV9jbGVhckludGVydmFsKCl7dGhpcy5faW50ZXJ2YWwmJihjbGVhckludGVydmFsKHRoaXMuX2ludGVydmFsKSx0aGlzLl9pbnRlcnZhbD1udWxsKX1fZGlyZWN0aW9uVG9PcmRlcih0KXtyZXR1cm4gbSgpP3Q9PT11dD9kdDpodDp0PT09dXQ/aHQ6ZHR9X29yZGVyVG9EaXJlY3Rpb24odCl7cmV0dXJuIG0oKT90PT09ZHQ/dXQ6ZnQ6dD09PWR0P2Z0OnV0fXN0YXRpYyBqUXVlcnlJbnRlcmZhY2UodCl7cmV0dXJuIHRoaXMuZWFjaChmdW5jdGlvbigpe2NvbnN0IGU9U3QuZ2V0T3JDcmVhdGVJbnN0YW5jZSh0aGlzLHQpO2lmKFwibnVtYmVyXCIhPXR5cGVvZiB0KXtpZihcInN0cmluZ1wiPT10eXBlb2YgdCl7aWYodm9pZCAwPT09ZVt0XXx8dC5zdGFydHNXaXRoKFwiX1wiKXx8XCJjb25zdHJ1Y3RvclwiPT09dCl0aHJvdyBuZXcgVHlwZUVycm9yKGBObyBtZXRob2QgbmFtZWQgXCIke3R9XCJgKTtlW3RdKCl9fWVsc2UgZS50byh0KX0pfX1QLm9uKGRvY3VtZW50LHd0LFwiW2RhdGEtYnMtc2xpZGVdLCBbZGF0YS1icy1zbGlkZS10b11cIixmdW5jdGlvbih0KXtjb25zdCBlPVIuZ2V0RWxlbWVudEZyb21TZWxlY3Rvcih0aGlzKTtpZighZXx8IWUuY2xhc3NMaXN0LmNvbnRhaW5zKEF0KSlyZXR1cm47dC5wcmV2ZW50RGVmYXVsdCgpO2NvbnN0IGk9U3QuZ2V0T3JDcmVhdGVJbnN0YW5jZShlKSxuPXRoaXMuZ2V0QXR0cmlidXRlKFwiZGF0YS1icy1zbGlkZS10b1wiKTtyZXR1cm4gbj8oaS50byhuKSx2b2lkIGkuX21heWJlRW5hYmxlQ3ljbGUoKSk6XCJuZXh0XCI9PT1ILmdldERhdGFBdHRyaWJ1dGUodGhpcyxcInNsaWRlXCIpPyhpLm5leHQoKSx2b2lkIGkuX21heWJlRW5hYmxlQ3ljbGUoKSk6KGkucHJldigpLHZvaWQgaS5fbWF5YmVFbmFibGVDeWNsZSgpKX0pLFAub24od2luZG93LHl0LCgpPT57Y29uc3QgdD1SLmZpbmQoJ1tkYXRhLWJzLXJpZGU9XCJjYXJvdXNlbFwiXScpO2Zvcihjb25zdCBlIG9mIHQpU3QuZ2V0T3JDcmVhdGVJbnN0YW5jZShlKX0pLGcoU3QpO2NvbnN0IER0PVwiLmJzLmNvbGxhcHNlXCIsJHQ9YHNob3cke0R0fWAsSXQ9YHNob3duJHtEdH1gLE50PWBoaWRlJHtEdH1gLFB0PWBoaWRkZW4ke0R0fWAsanQ9YGNsaWNrJHtEdH0uZGF0YS1hcGlgLE10PVwic2hvd1wiLEZ0PVwiY29sbGFwc2VcIixIdD1cImNvbGxhcHNpbmdcIixXdD1gOnNjb3BlIC4ke0Z0fSAuJHtGdH1gLEJ0PSdbZGF0YS1icy10b2dnbGU9XCJjb2xsYXBzZVwiXScsenQ9e3BhcmVudDpudWxsLHRvZ2dsZTohMH0sUnQ9e3BhcmVudDpcIihudWxsfGVsZW1lbnQpXCIsdG9nZ2xlOlwiYm9vbGVhblwifTtjbGFzcyBxdCBleHRlbmRzIEJ7Y29uc3RydWN0b3IodCxlKXtzdXBlcih0LGUpLHRoaXMuX2lzVHJhbnNpdGlvbmluZz0hMSx0aGlzLl90cmlnZ2VyQXJyYXk9W107Y29uc3QgaT1SLmZpbmQoQnQpO2Zvcihjb25zdCB0IG9mIGkpe2NvbnN0IGU9Ui5nZXRTZWxlY3RvckZyb21FbGVtZW50KHQpLGk9Ui5maW5kKGUpLmZpbHRlcih0PT50PT09dGhpcy5fZWxlbWVudCk7bnVsbCE9PWUmJmkubGVuZ3RoJiZ0aGlzLl90cmlnZ2VyQXJyYXkucHVzaCh0KX10aGlzLl9pbml0aWFsaXplQ2hpbGRyZW4oKSx0aGlzLl9jb25maWcucGFyZW50fHx0aGlzLl9hZGRBcmlhQW5kQ29sbGFwc2VkQ2xhc3ModGhpcy5fdHJpZ2dlckFycmF5LHRoaXMuX2lzU2hvd24oKSksdGhpcy5fY29uZmlnLnRvZ2dsZSYmdGhpcy50b2dnbGUoKX1zdGF0aWMgZ2V0IERlZmF1bHQoKXtyZXR1cm4genR9c3RhdGljIGdldCBEZWZhdWx0VHlwZSgpe3JldHVybiBSdH1zdGF0aWMgZ2V0IE5BTUUoKXtyZXR1cm5cImNvbGxhcHNlXCJ9dG9nZ2xlKCl7dGhpcy5faXNTaG93bigpP3RoaXMuaGlkZSgpOnRoaXMuc2hvdygpfXNob3coKXtpZih0aGlzLl9pc1RyYW5zaXRpb25pbmd8fHRoaXMuX2lzU2hvd24oKSlyZXR1cm47bGV0IHQ9W107aWYodGhpcy5fY29uZmlnLnBhcmVudCYmKHQ9dGhpcy5fZ2V0Rmlyc3RMZXZlbENoaWxkcmVuKFwiLmNvbGxhcHNlLnNob3csIC5jb2xsYXBzZS5jb2xsYXBzaW5nXCIpLmZpbHRlcih0PT50IT09dGhpcy5fZWxlbWVudCkubWFwKHQ9PnF0LmdldE9yQ3JlYXRlSW5zdGFuY2UodCx7dG9nZ2xlOiExfSkpKSx0Lmxlbmd0aCYmdFswXS5faXNUcmFuc2l0aW9uaW5nKXJldHVybjtpZihQLnRyaWdnZXIodGhpcy5fZWxlbWVudCwkdCkuZGVmYXVsdFByZXZlbnRlZClyZXR1cm47Zm9yKGNvbnN0IGUgb2YgdCllLmhpZGUoKTtjb25zdCBlPXRoaXMuX2dldERpbWVuc2lvbigpO3RoaXMuX2VsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZShGdCksdGhpcy5fZWxlbWVudC5jbGFzc0xpc3QuYWRkKEh0KSx0aGlzLl9lbGVtZW50LnN0eWxlW2VdPTAsdGhpcy5fYWRkQXJpYUFuZENvbGxhcHNlZENsYXNzKHRoaXMuX3RyaWdnZXJBcnJheSwhMCksdGhpcy5faXNUcmFuc2l0aW9uaW5nPSEwO2NvbnN0IGk9YHNjcm9sbCR7ZVswXS50b1VwcGVyQ2FzZSgpK2Uuc2xpY2UoMSl9YDt0aGlzLl9xdWV1ZUNhbGxiYWNrKCgpPT57dGhpcy5faXNUcmFuc2l0aW9uaW5nPSExLHRoaXMuX2VsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZShIdCksdGhpcy5fZWxlbWVudC5jbGFzc0xpc3QuYWRkKEZ0LE10KSx0aGlzLl9lbGVtZW50LnN0eWxlW2VdPVwiXCIsUC50cmlnZ2VyKHRoaXMuX2VsZW1lbnQsSXQpfSx0aGlzLl9lbGVtZW50LCEwKSx0aGlzLl9lbGVtZW50LnN0eWxlW2VdPWAke3RoaXMuX2VsZW1lbnRbaV19cHhgfWhpZGUoKXtpZih0aGlzLl9pc1RyYW5zaXRpb25pbmd8fCF0aGlzLl9pc1Nob3duKCkpcmV0dXJuO2lmKFAudHJpZ2dlcih0aGlzLl9lbGVtZW50LE50KS5kZWZhdWx0UHJldmVudGVkKXJldHVybjtjb25zdCB0PXRoaXMuX2dldERpbWVuc2lvbigpO3RoaXMuX2VsZW1lbnQuc3R5bGVbdF09YCR7dGhpcy5fZWxlbWVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKVt0XX1weGAsdSh0aGlzLl9lbGVtZW50KSx0aGlzLl9lbGVtZW50LmNsYXNzTGlzdC5hZGQoSHQpLHRoaXMuX2VsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZShGdCxNdCk7Zm9yKGNvbnN0IHQgb2YgdGhpcy5fdHJpZ2dlckFycmF5KXtjb25zdCBlPVIuZ2V0RWxlbWVudEZyb21TZWxlY3Rvcih0KTtlJiYhdGhpcy5faXNTaG93bihlKSYmdGhpcy5fYWRkQXJpYUFuZENvbGxhcHNlZENsYXNzKFt0XSwhMSl9dGhpcy5faXNUcmFuc2l0aW9uaW5nPSEwLHRoaXMuX2VsZW1lbnQuc3R5bGVbdF09XCJcIix0aGlzLl9xdWV1ZUNhbGxiYWNrKCgpPT57dGhpcy5faXNUcmFuc2l0aW9uaW5nPSExLHRoaXMuX2VsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZShIdCksdGhpcy5fZWxlbWVudC5jbGFzc0xpc3QuYWRkKEZ0KSxQLnRyaWdnZXIodGhpcy5fZWxlbWVudCxQdCl9LHRoaXMuX2VsZW1lbnQsITApfV9pc1Nob3duKHQ9dGhpcy5fZWxlbWVudCl7cmV0dXJuIHQuY2xhc3NMaXN0LmNvbnRhaW5zKE10KX1fY29uZmlnQWZ0ZXJNZXJnZSh0KXtyZXR1cm4gdC50b2dnbGU9Qm9vbGVhbih0LnRvZ2dsZSksdC5wYXJlbnQ9YSh0LnBhcmVudCksdH1fZ2V0RGltZW5zaW9uKCl7cmV0dXJuIHRoaXMuX2VsZW1lbnQuY2xhc3NMaXN0LmNvbnRhaW5zKFwiY29sbGFwc2UtaG9yaXpvbnRhbFwiKT9cIndpZHRoXCI6XCJoZWlnaHRcIn1faW5pdGlhbGl6ZUNoaWxkcmVuKCl7aWYoIXRoaXMuX2NvbmZpZy5wYXJlbnQpcmV0dXJuO2NvbnN0IHQ9dGhpcy5fZ2V0Rmlyc3RMZXZlbENoaWxkcmVuKEJ0KTtmb3IoY29uc3QgZSBvZiB0KXtjb25zdCB0PVIuZ2V0RWxlbWVudEZyb21TZWxlY3RvcihlKTt0JiZ0aGlzLl9hZGRBcmlhQW5kQ29sbGFwc2VkQ2xhc3MoW2VdLHRoaXMuX2lzU2hvd24odCkpfX1fZ2V0Rmlyc3RMZXZlbENoaWxkcmVuKHQpe2NvbnN0IGU9Ui5maW5kKFd0LHRoaXMuX2NvbmZpZy5wYXJlbnQpO3JldHVybiBSLmZpbmQodCx0aGlzLl9jb25maWcucGFyZW50KS5maWx0ZXIodD0+IWUuaW5jbHVkZXModCkpfV9hZGRBcmlhQW5kQ29sbGFwc2VkQ2xhc3ModCxlKXtpZih0Lmxlbmd0aClmb3IoY29uc3QgaSBvZiB0KWkuY2xhc3NMaXN0LnRvZ2dsZShcImNvbGxhcHNlZFwiLCFlKSxpLnNldEF0dHJpYnV0ZShcImFyaWEtZXhwYW5kZWRcIixlKX1zdGF0aWMgalF1ZXJ5SW50ZXJmYWNlKHQpe2NvbnN0IGU9e307cmV0dXJuXCJzdHJpbmdcIj09dHlwZW9mIHQmJi9zaG93fGhpZGUvLnRlc3QodCkmJihlLnRvZ2dsZT0hMSksdGhpcy5lYWNoKGZ1bmN0aW9uKCl7Y29uc3QgaT1xdC5nZXRPckNyZWF0ZUluc3RhbmNlKHRoaXMsZSk7aWYoXCJzdHJpbmdcIj09dHlwZW9mIHQpe2lmKHZvaWQgMD09PWlbdF0pdGhyb3cgbmV3IFR5cGVFcnJvcihgTm8gbWV0aG9kIG5hbWVkIFwiJHt0fVwiYCk7aVt0XSgpfX0pfX1QLm9uKGRvY3VtZW50LGp0LEJ0LGZ1bmN0aW9uKHQpeyhcIkFcIj09PXQudGFyZ2V0LnRhZ05hbWV8fHQuZGVsZWdhdGVUYXJnZXQmJlwiQVwiPT09dC5kZWxlZ2F0ZVRhcmdldC50YWdOYW1lKSYmdC5wcmV2ZW50RGVmYXVsdCgpO2Zvcihjb25zdCB0IG9mIFIuZ2V0TXVsdGlwbGVFbGVtZW50c0Zyb21TZWxlY3Rvcih0aGlzKSlxdC5nZXRPckNyZWF0ZUluc3RhbmNlKHQse3RvZ2dsZTohMX0pLnRvZ2dsZSgpfSksZyhxdCk7dmFyIFZ0PVwidG9wXCIsS3Q9XCJib3R0b21cIixRdD1cInJpZ2h0XCIsWHQ9XCJsZWZ0XCIsWXQ9XCJhdXRvXCIsVXQ9W1Z0LEt0LFF0LFh0XSxHdD1cInN0YXJ0XCIsSnQ9XCJlbmRcIixadD1cImNsaXBwaW5nUGFyZW50c1wiLHRlPVwidmlld3BvcnRcIixlZT1cInBvcHBlclwiLGllPVwicmVmZXJlbmNlXCIsbmU9VXQucmVkdWNlKGZ1bmN0aW9uKHQsZSl7cmV0dXJuIHQuY29uY2F0KFtlK1wiLVwiK0d0LGUrXCItXCIrSnRdKX0sW10pLHNlPVtdLmNvbmNhdChVdCxbWXRdKS5yZWR1Y2UoZnVuY3Rpb24odCxlKXtyZXR1cm4gdC5jb25jYXQoW2UsZStcIi1cIitHdCxlK1wiLVwiK0p0XSl9LFtdKSxvZT1cImJlZm9yZVJlYWRcIixyZT1cInJlYWRcIixhZT1cImFmdGVyUmVhZFwiLGxlPVwiYmVmb3JlTWFpblwiLGNlPVwibWFpblwiLGhlPVwiYWZ0ZXJNYWluXCIsZGU9XCJiZWZvcmVXcml0ZVwiLHVlPVwid3JpdGVcIixmZT1cImFmdGVyV3JpdGVcIixwZT1bb2UscmUsYWUsbGUsY2UsaGUsZGUsdWUsZmVdO2Z1bmN0aW9uIG1lKHQpe3JldHVybiB0Pyh0Lm5vZGVOYW1lfHxcIlwiKS50b0xvd2VyQ2FzZSgpOm51bGx9ZnVuY3Rpb24gZ2UodCl7aWYobnVsbD09dClyZXR1cm4gd2luZG93O2lmKFwiW29iamVjdCBXaW5kb3ddXCIhPT10LnRvU3RyaW5nKCkpe3ZhciBlPXQub3duZXJEb2N1bWVudDtyZXR1cm4gZSYmZS5kZWZhdWx0Vmlld3x8d2luZG93fXJldHVybiB0fWZ1bmN0aW9uIF9lKHQpe3JldHVybiB0IGluc3RhbmNlb2YgZ2UodCkuRWxlbWVudHx8dCBpbnN0YW5jZW9mIEVsZW1lbnR9ZnVuY3Rpb24gYmUodCl7cmV0dXJuIHQgaW5zdGFuY2VvZiBnZSh0KS5IVE1MRWxlbWVudHx8dCBpbnN0YW5jZW9mIEhUTUxFbGVtZW50fWZ1bmN0aW9uIHZlKHQpe3JldHVyblwidW5kZWZpbmVkXCIhPXR5cGVvZiBTaGFkb3dSb290JiYodCBpbnN0YW5jZW9mIGdlKHQpLlNoYWRvd1Jvb3R8fHQgaW5zdGFuY2VvZiBTaGFkb3dSb290KX1jb25zdCB5ZT17bmFtZTpcImFwcGx5U3R5bGVzXCIsZW5hYmxlZDohMCxwaGFzZTpcIndyaXRlXCIsZm46ZnVuY3Rpb24odCl7dmFyIGU9dC5zdGF0ZTtPYmplY3Qua2V5cyhlLmVsZW1lbnRzKS5mb3JFYWNoKGZ1bmN0aW9uKHQpe3ZhciBpPWUuc3R5bGVzW3RdfHx7fSxuPWUuYXR0cmlidXRlc1t0XXx8e30scz1lLmVsZW1lbnRzW3RdO2JlKHMpJiZtZShzKSYmKE9iamVjdC5hc3NpZ24ocy5zdHlsZSxpKSxPYmplY3Qua2V5cyhuKS5mb3JFYWNoKGZ1bmN0aW9uKHQpe3ZhciBlPW5bdF07ITE9PT1lP3MucmVtb3ZlQXR0cmlidXRlKHQpOnMuc2V0QXR0cmlidXRlKHQsITA9PT1lP1wiXCI6ZSl9KSl9KX0sZWZmZWN0OmZ1bmN0aW9uKHQpe3ZhciBlPXQuc3RhdGUsaT17cG9wcGVyOntwb3NpdGlvbjplLm9wdGlvbnMuc3RyYXRlZ3ksbGVmdDpcIjBcIix0b3A6XCIwXCIsbWFyZ2luOlwiMFwifSxhcnJvdzp7cG9zaXRpb246XCJhYnNvbHV0ZVwifSxyZWZlcmVuY2U6e319O3JldHVybiBPYmplY3QuYXNzaWduKGUuZWxlbWVudHMucG9wcGVyLnN0eWxlLGkucG9wcGVyKSxlLnN0eWxlcz1pLGUuZWxlbWVudHMuYXJyb3cmJk9iamVjdC5hc3NpZ24oZS5lbGVtZW50cy5hcnJvdy5zdHlsZSxpLmFycm93KSxmdW5jdGlvbigpe09iamVjdC5rZXlzKGUuZWxlbWVudHMpLmZvckVhY2goZnVuY3Rpb24odCl7dmFyIG49ZS5lbGVtZW50c1t0XSxzPWUuYXR0cmlidXRlc1t0XXx8e30sbz1PYmplY3Qua2V5cyhlLnN0eWxlcy5oYXNPd25Qcm9wZXJ0eSh0KT9lLnN0eWxlc1t0XTppW3RdKS5yZWR1Y2UoZnVuY3Rpb24odCxlKXtyZXR1cm4gdFtlXT1cIlwiLHR9LHt9KTtiZShuKSYmbWUobikmJihPYmplY3QuYXNzaWduKG4uc3R5bGUsbyksT2JqZWN0LmtleXMocykuZm9yRWFjaChmdW5jdGlvbih0KXtuLnJlbW92ZUF0dHJpYnV0ZSh0KX0pKX0pfX0scmVxdWlyZXM6W1wiY29tcHV0ZVN0eWxlc1wiXX07ZnVuY3Rpb24gd2UodCl7cmV0dXJuIHQuc3BsaXQoXCItXCIpWzBdfXZhciBBZT1NYXRoLm1heCxFZT1NYXRoLm1pbixUZT1NYXRoLnJvdW5kO2Z1bmN0aW9uIENlKCl7dmFyIHQ9bmF2aWdhdG9yLnVzZXJBZ2VudERhdGE7cmV0dXJuIG51bGwhPXQmJnQuYnJhbmRzJiZBcnJheS5pc0FycmF5KHQuYnJhbmRzKT90LmJyYW5kcy5tYXAoZnVuY3Rpb24odCl7cmV0dXJuIHQuYnJhbmQrXCIvXCIrdC52ZXJzaW9ufSkuam9pbihcIiBcIik6bmF2aWdhdG9yLnVzZXJBZ2VudH1mdW5jdGlvbiBPZSgpe3JldHVybiEvXigoPyFjaHJvbWV8YW5kcm9pZCkuKSpzYWZhcmkvaS50ZXN0KENlKCkpfWZ1bmN0aW9uIHhlKHQsZSxpKXt2b2lkIDA9PT1lJiYoZT0hMSksdm9pZCAwPT09aSYmKGk9ITEpO3ZhciBuPXQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkscz0xLG89MTtlJiZiZSh0KSYmKHM9dC5vZmZzZXRXaWR0aD4wJiZUZShuLndpZHRoKS90Lm9mZnNldFdpZHRofHwxLG89dC5vZmZzZXRIZWlnaHQ+MCYmVGUobi5oZWlnaHQpL3Qub2Zmc2V0SGVpZ2h0fHwxKTt2YXIgcj0oX2UodCk/Z2UodCk6d2luZG93KS52aXN1YWxWaWV3cG9ydCxhPSFPZSgpJiZpLGw9KG4ubGVmdCsoYSYmcj9yLm9mZnNldExlZnQ6MCkpL3MsYz0obi50b3ArKGEmJnI/ci5vZmZzZXRUb3A6MCkpL28saD1uLndpZHRoL3MsZD1uLmhlaWdodC9vO3JldHVybnt3aWR0aDpoLGhlaWdodDpkLHRvcDpjLHJpZ2h0OmwraCxib3R0b206YytkLGxlZnQ6bCx4OmwseTpjfX1mdW5jdGlvbiBrZSh0KXt2YXIgZT14ZSh0KSxpPXQub2Zmc2V0V2lkdGgsbj10Lm9mZnNldEhlaWdodDtyZXR1cm4gTWF0aC5hYnMoZS53aWR0aC1pKTw9MSYmKGk9ZS53aWR0aCksTWF0aC5hYnMoZS5oZWlnaHQtbik8PTEmJihuPWUuaGVpZ2h0KSx7eDp0Lm9mZnNldExlZnQseTp0Lm9mZnNldFRvcCx3aWR0aDppLGhlaWdodDpufX1mdW5jdGlvbiBMZSh0LGUpe3ZhciBpPWUuZ2V0Um9vdE5vZGUmJmUuZ2V0Um9vdE5vZGUoKTtpZih0LmNvbnRhaW5zKGUpKXJldHVybiEwO2lmKGkmJnZlKGkpKXt2YXIgbj1lO2Rve2lmKG4mJnQuaXNTYW1lTm9kZShuKSlyZXR1cm4hMDtuPW4ucGFyZW50Tm9kZXx8bi5ob3N0fXdoaWxlKG4pfXJldHVybiExfWZ1bmN0aW9uIFNlKHQpe3JldHVybiBnZSh0KS5nZXRDb21wdXRlZFN0eWxlKHQpfWZ1bmN0aW9uIERlKHQpe3JldHVybltcInRhYmxlXCIsXCJ0ZFwiLFwidGhcIl0uaW5kZXhPZihtZSh0KSk+PTB9ZnVuY3Rpb24gJGUodCl7cmV0dXJuKChfZSh0KT90Lm93bmVyRG9jdW1lbnQ6dC5kb2N1bWVudCl8fHdpbmRvdy5kb2N1bWVudCkuZG9jdW1lbnRFbGVtZW50fWZ1bmN0aW9uIEllKHQpe3JldHVyblwiaHRtbFwiPT09bWUodCk/dDp0LmFzc2lnbmVkU2xvdHx8dC5wYXJlbnROb2RlfHwodmUodCk/dC5ob3N0Om51bGwpfHwkZSh0KX1mdW5jdGlvbiBOZSh0KXtyZXR1cm4gYmUodCkmJlwiZml4ZWRcIiE9PVNlKHQpLnBvc2l0aW9uP3Qub2Zmc2V0UGFyZW50Om51bGx9ZnVuY3Rpb24gUGUodCl7Zm9yKHZhciBlPWdlKHQpLGk9TmUodCk7aSYmRGUoaSkmJlwic3RhdGljXCI9PT1TZShpKS5wb3NpdGlvbjspaT1OZShpKTtyZXR1cm4gaSYmKFwiaHRtbFwiPT09bWUoaSl8fFwiYm9keVwiPT09bWUoaSkmJlwic3RhdGljXCI9PT1TZShpKS5wb3NpdGlvbik/ZTppfHxmdW5jdGlvbih0KXt2YXIgZT0vZmlyZWZveC9pLnRlc3QoQ2UoKSk7aWYoL1RyaWRlbnQvaS50ZXN0KENlKCkpJiZiZSh0KSYmXCJmaXhlZFwiPT09U2UodCkucG9zaXRpb24pcmV0dXJuIG51bGw7dmFyIGk9SWUodCk7Zm9yKHZlKGkpJiYoaT1pLmhvc3QpO2JlKGkpJiZbXCJodG1sXCIsXCJib2R5XCJdLmluZGV4T2YobWUoaSkpPDA7KXt2YXIgbj1TZShpKTtpZihcIm5vbmVcIiE9PW4udHJhbnNmb3JtfHxcIm5vbmVcIiE9PW4ucGVyc3BlY3RpdmV8fFwicGFpbnRcIj09PW4uY29udGFpbnx8LTEhPT1bXCJ0cmFuc2Zvcm1cIixcInBlcnNwZWN0aXZlXCJdLmluZGV4T2Yobi53aWxsQ2hhbmdlKXx8ZSYmXCJmaWx0ZXJcIj09PW4ud2lsbENoYW5nZXx8ZSYmbi5maWx0ZXImJlwibm9uZVwiIT09bi5maWx0ZXIpcmV0dXJuIGk7aT1pLnBhcmVudE5vZGV9cmV0dXJuIG51bGx9KHQpfHxlfWZ1bmN0aW9uIGplKHQpe3JldHVybltcInRvcFwiLFwiYm90dG9tXCJdLmluZGV4T2YodCk+PTA/XCJ4XCI6XCJ5XCJ9ZnVuY3Rpb24gTWUodCxlLGkpe3JldHVybiBBZSh0LEVlKGUsaSkpfWZ1bmN0aW9uIEZlKHQpe3JldHVybiBPYmplY3QuYXNzaWduKHt9LHt0b3A6MCxyaWdodDowLGJvdHRvbTowLGxlZnQ6MH0sdCl9ZnVuY3Rpb24gSGUodCxlKXtyZXR1cm4gZS5yZWR1Y2UoZnVuY3Rpb24oZSxpKXtyZXR1cm4gZVtpXT10LGV9LHt9KX1jb25zdCBXZT17bmFtZTpcImFycm93XCIsZW5hYmxlZDohMCxwaGFzZTpcIm1haW5cIixmbjpmdW5jdGlvbih0KXt2YXIgZSxpPXQuc3RhdGUsbj10Lm5hbWUscz10Lm9wdGlvbnMsbz1pLmVsZW1lbnRzLmFycm93LHI9aS5tb2RpZmllcnNEYXRhLnBvcHBlck9mZnNldHMsYT13ZShpLnBsYWNlbWVudCksbD1qZShhKSxjPVtYdCxRdF0uaW5kZXhPZihhKT49MD9cImhlaWdodFwiOlwid2lkdGhcIjtpZihvJiZyKXt2YXIgaD1mdW5jdGlvbih0LGUpe3JldHVybiBGZShcIm51bWJlclwiIT10eXBlb2YodD1cImZ1bmN0aW9uXCI9PXR5cGVvZiB0P3QoT2JqZWN0LmFzc2lnbih7fSxlLnJlY3RzLHtwbGFjZW1lbnQ6ZS5wbGFjZW1lbnR9KSk6dCk/dDpIZSh0LFV0KSl9KHMucGFkZGluZyxpKSxkPWtlKG8pLHU9XCJ5XCI9PT1sP1Z0Olh0LGY9XCJ5XCI9PT1sP0t0OlF0LHA9aS5yZWN0cy5yZWZlcmVuY2VbY10raS5yZWN0cy5yZWZlcmVuY2VbbF0tcltsXS1pLnJlY3RzLnBvcHBlcltjXSxtPXJbbF0taS5yZWN0cy5yZWZlcmVuY2VbbF0sZz1QZShvKSxfPWc/XCJ5XCI9PT1sP2cuY2xpZW50SGVpZ2h0fHwwOmcuY2xpZW50V2lkdGh8fDA6MCxiPXAvMi1tLzIsdj1oW3VdLHk9Xy1kW2NdLWhbZl0sdz1fLzItZFtjXS8yK2IsQT1NZSh2LHcseSksRT1sO2kubW9kaWZpZXJzRGF0YVtuXT0oKGU9e30pW0VdPUEsZS5jZW50ZXJPZmZzZXQ9QS13LGUpfX0sZWZmZWN0OmZ1bmN0aW9uKHQpe3ZhciBlPXQuc3RhdGUsaT10Lm9wdGlvbnMuZWxlbWVudCxuPXZvaWQgMD09PWk/XCJbZGF0YS1wb3BwZXItYXJyb3ddXCI6aTtudWxsIT1uJiYoXCJzdHJpbmdcIiE9dHlwZW9mIG58fChuPWUuZWxlbWVudHMucG9wcGVyLnF1ZXJ5U2VsZWN0b3IobikpKSYmTGUoZS5lbGVtZW50cy5wb3BwZXIsbikmJihlLmVsZW1lbnRzLmFycm93PW4pfSxyZXF1aXJlczpbXCJwb3BwZXJPZmZzZXRzXCJdLHJlcXVpcmVzSWZFeGlzdHM6W1wicHJldmVudE92ZXJmbG93XCJdfTtmdW5jdGlvbiBCZSh0KXtyZXR1cm4gdC5zcGxpdChcIi1cIilbMV19dmFyIHplPXt0b3A6XCJhdXRvXCIscmlnaHQ6XCJhdXRvXCIsYm90dG9tOlwiYXV0b1wiLGxlZnQ6XCJhdXRvXCJ9O2Z1bmN0aW9uIFJlKHQpe3ZhciBlLGk9dC5wb3BwZXIsbj10LnBvcHBlclJlY3Qscz10LnBsYWNlbWVudCxvPXQudmFyaWF0aW9uLHI9dC5vZmZzZXRzLGE9dC5wb3NpdGlvbixsPXQuZ3B1QWNjZWxlcmF0aW9uLGM9dC5hZGFwdGl2ZSxoPXQucm91bmRPZmZzZXRzLGQ9dC5pc0ZpeGVkLHU9ci54LGY9dm9pZCAwPT09dT8wOnUscD1yLnksbT12b2lkIDA9PT1wPzA6cCxnPVwiZnVuY3Rpb25cIj09dHlwZW9mIGg/aCh7eDpmLHk6bX0pOnt4OmYseTptfTtmPWcueCxtPWcueTt2YXIgXz1yLmhhc093blByb3BlcnR5KFwieFwiKSxiPXIuaGFzT3duUHJvcGVydHkoXCJ5XCIpLHY9WHQseT1WdCx3PXdpbmRvdztpZihjKXt2YXIgQT1QZShpKSxFPVwiY2xpZW50SGVpZ2h0XCIsVD1cImNsaWVudFdpZHRoXCI7QT09PWdlKGkpJiZcInN0YXRpY1wiIT09U2UoQT0kZShpKSkucG9zaXRpb24mJlwiYWJzb2x1dGVcIj09PWEmJihFPVwic2Nyb2xsSGVpZ2h0XCIsVD1cInNjcm9sbFdpZHRoXCIpLChzPT09VnR8fChzPT09WHR8fHM9PT1RdCkmJm89PT1KdCkmJih5PUt0LG0tPShkJiZBPT09dyYmdy52aXN1YWxWaWV3cG9ydD93LnZpc3VhbFZpZXdwb3J0LmhlaWdodDpBW0VdKS1uLmhlaWdodCxtKj1sPzE6LTEpLHMhPT1YdCYmKHMhPT1WdCYmcyE9PUt0fHxvIT09SnQpfHwodj1RdCxmLT0oZCYmQT09PXcmJncudmlzdWFsVmlld3BvcnQ/dy52aXN1YWxWaWV3cG9ydC53aWR0aDpBW1RdKS1uLndpZHRoLGYqPWw/MTotMSl9dmFyIEMsTz1PYmplY3QuYXNzaWduKHtwb3NpdGlvbjphfSxjJiZ6ZSkseD0hMD09PWg/ZnVuY3Rpb24odCxlKXt2YXIgaT10Lngsbj10Lnkscz1lLmRldmljZVBpeGVsUmF0aW98fDE7cmV0dXJue3g6VGUoaSpzKS9zfHwwLHk6VGUobipzKS9zfHwwfX0oe3g6Zix5Om19LGdlKGkpKTp7eDpmLHk6bX07cmV0dXJuIGY9eC54LG09eC55LGw/T2JqZWN0LmFzc2lnbih7fSxPLCgoQz17fSlbeV09Yj9cIjBcIjpcIlwiLENbdl09Xz9cIjBcIjpcIlwiLEMudHJhbnNmb3JtPSh3LmRldmljZVBpeGVsUmF0aW98fDEpPD0xP1widHJhbnNsYXRlKFwiK2YrXCJweCwgXCIrbStcInB4KVwiOlwidHJhbnNsYXRlM2QoXCIrZitcInB4LCBcIittK1wicHgsIDApXCIsQykpOk9iamVjdC5hc3NpZ24oe30sTywoKGU9e30pW3ldPWI/bStcInB4XCI6XCJcIixlW3ZdPV8/ZitcInB4XCI6XCJcIixlLnRyYW5zZm9ybT1cIlwiLGUpKX1jb25zdCBxZT17bmFtZTpcImNvbXB1dGVTdHlsZXNcIixlbmFibGVkOiEwLHBoYXNlOlwiYmVmb3JlV3JpdGVcIixmbjpmdW5jdGlvbih0KXt2YXIgZT10LnN0YXRlLGk9dC5vcHRpb25zLG49aS5ncHVBY2NlbGVyYXRpb24scz12b2lkIDA9PT1ufHxuLG89aS5hZGFwdGl2ZSxyPXZvaWQgMD09PW98fG8sYT1pLnJvdW5kT2Zmc2V0cyxsPXZvaWQgMD09PWF8fGEsYz17cGxhY2VtZW50OndlKGUucGxhY2VtZW50KSx2YXJpYXRpb246QmUoZS5wbGFjZW1lbnQpLHBvcHBlcjplLmVsZW1lbnRzLnBvcHBlcixwb3BwZXJSZWN0OmUucmVjdHMucG9wcGVyLGdwdUFjY2VsZXJhdGlvbjpzLGlzRml4ZWQ6XCJmaXhlZFwiPT09ZS5vcHRpb25zLnN0cmF0ZWd5fTtudWxsIT1lLm1vZGlmaWVyc0RhdGEucG9wcGVyT2Zmc2V0cyYmKGUuc3R5bGVzLnBvcHBlcj1PYmplY3QuYXNzaWduKHt9LGUuc3R5bGVzLnBvcHBlcixSZShPYmplY3QuYXNzaWduKHt9LGMse29mZnNldHM6ZS5tb2RpZmllcnNEYXRhLnBvcHBlck9mZnNldHMscG9zaXRpb246ZS5vcHRpb25zLnN0cmF0ZWd5LGFkYXB0aXZlOnIscm91bmRPZmZzZXRzOmx9KSkpKSxudWxsIT1lLm1vZGlmaWVyc0RhdGEuYXJyb3cmJihlLnN0eWxlcy5hcnJvdz1PYmplY3QuYXNzaWduKHt9LGUuc3R5bGVzLmFycm93LFJlKE9iamVjdC5hc3NpZ24oe30sYyx7b2Zmc2V0czplLm1vZGlmaWVyc0RhdGEuYXJyb3cscG9zaXRpb246XCJhYnNvbHV0ZVwiLGFkYXB0aXZlOiExLHJvdW5kT2Zmc2V0czpsfSkpKSksZS5hdHRyaWJ1dGVzLnBvcHBlcj1PYmplY3QuYXNzaWduKHt9LGUuYXR0cmlidXRlcy5wb3BwZXIse1wiZGF0YS1wb3BwZXItcGxhY2VtZW50XCI6ZS5wbGFjZW1lbnR9KX0sZGF0YTp7fX07dmFyIFZlPXtwYXNzaXZlOiEwfTtjb25zdCBLZT17bmFtZTpcImV2ZW50TGlzdGVuZXJzXCIsZW5hYmxlZDohMCxwaGFzZTpcIndyaXRlXCIsZm46ZnVuY3Rpb24oKXt9LGVmZmVjdDpmdW5jdGlvbih0KXt2YXIgZT10LnN0YXRlLGk9dC5pbnN0YW5jZSxuPXQub3B0aW9ucyxzPW4uc2Nyb2xsLG89dm9pZCAwPT09c3x8cyxyPW4ucmVzaXplLGE9dm9pZCAwPT09cnx8cixsPWdlKGUuZWxlbWVudHMucG9wcGVyKSxjPVtdLmNvbmNhdChlLnNjcm9sbFBhcmVudHMucmVmZXJlbmNlLGUuc2Nyb2xsUGFyZW50cy5wb3BwZXIpO3JldHVybiBvJiZjLmZvckVhY2goZnVuY3Rpb24odCl7dC5hZGRFdmVudExpc3RlbmVyKFwic2Nyb2xsXCIsaS51cGRhdGUsVmUpfSksYSYmbC5hZGRFdmVudExpc3RlbmVyKFwicmVzaXplXCIsaS51cGRhdGUsVmUpLGZ1bmN0aW9uKCl7byYmYy5mb3JFYWNoKGZ1bmN0aW9uKHQpe3QucmVtb3ZlRXZlbnRMaXN0ZW5lcihcInNjcm9sbFwiLGkudXBkYXRlLFZlKX0pLGEmJmwucmVtb3ZlRXZlbnRMaXN0ZW5lcihcInJlc2l6ZVwiLGkudXBkYXRlLFZlKX19LGRhdGE6e319O3ZhciBRZT17bGVmdDpcInJpZ2h0XCIscmlnaHQ6XCJsZWZ0XCIsYm90dG9tOlwidG9wXCIsdG9wOlwiYm90dG9tXCJ9O2Z1bmN0aW9uIFhlKHQpe3JldHVybiB0LnJlcGxhY2UoL2xlZnR8cmlnaHR8Ym90dG9tfHRvcC9nLGZ1bmN0aW9uKHQpe3JldHVybiBRZVt0XX0pfXZhciBZZT17c3RhcnQ6XCJlbmRcIixlbmQ6XCJzdGFydFwifTtmdW5jdGlvbiBVZSh0KXtyZXR1cm4gdC5yZXBsYWNlKC9zdGFydHxlbmQvZyxmdW5jdGlvbih0KXtyZXR1cm4gWWVbdF19KX1mdW5jdGlvbiBHZSh0KXt2YXIgZT1nZSh0KTtyZXR1cm57c2Nyb2xsTGVmdDplLnBhZ2VYT2Zmc2V0LHNjcm9sbFRvcDplLnBhZ2VZT2Zmc2V0fX1mdW5jdGlvbiBKZSh0KXtyZXR1cm4geGUoJGUodCkpLmxlZnQrR2UodCkuc2Nyb2xsTGVmdH1mdW5jdGlvbiBaZSh0KXt2YXIgZT1TZSh0KSxpPWUub3ZlcmZsb3csbj1lLm92ZXJmbG93WCxzPWUub3ZlcmZsb3dZO3JldHVybi9hdXRvfHNjcm9sbHxvdmVybGF5fGhpZGRlbi8udGVzdChpK3Mrbil9ZnVuY3Rpb24gdGkodCl7cmV0dXJuW1wiaHRtbFwiLFwiYm9keVwiLFwiI2RvY3VtZW50XCJdLmluZGV4T2YobWUodCkpPj0wP3Qub3duZXJEb2N1bWVudC5ib2R5OmJlKHQpJiZaZSh0KT90OnRpKEllKHQpKX1mdW5jdGlvbiBlaSh0LGUpe3ZhciBpO3ZvaWQgMD09PWUmJihlPVtdKTt2YXIgbj10aSh0KSxzPW49PT0obnVsbD09KGk9dC5vd25lckRvY3VtZW50KT92b2lkIDA6aS5ib2R5KSxvPWdlKG4pLHI9cz9bb10uY29uY2F0KG8udmlzdWFsVmlld3BvcnR8fFtdLFplKG4pP246W10pOm4sYT1lLmNvbmNhdChyKTtyZXR1cm4gcz9hOmEuY29uY2F0KGVpKEllKHIpKSl9ZnVuY3Rpb24gaWkodCl7cmV0dXJuIE9iamVjdC5hc3NpZ24oe30sdCx7bGVmdDp0LngsdG9wOnQueSxyaWdodDp0LngrdC53aWR0aCxib3R0b206dC55K3QuaGVpZ2h0fSl9ZnVuY3Rpb24gbmkodCxlLGkpe3JldHVybiBlPT09dGU/aWkoZnVuY3Rpb24odCxlKXt2YXIgaT1nZSh0KSxuPSRlKHQpLHM9aS52aXN1YWxWaWV3cG9ydCxvPW4uY2xpZW50V2lkdGgscj1uLmNsaWVudEhlaWdodCxhPTAsbD0wO2lmKHMpe289cy53aWR0aCxyPXMuaGVpZ2h0O3ZhciBjPU9lKCk7KGN8fCFjJiZcImZpeGVkXCI9PT1lKSYmKGE9cy5vZmZzZXRMZWZ0LGw9cy5vZmZzZXRUb3ApfXJldHVybnt3aWR0aDpvLGhlaWdodDpyLHg6YStKZSh0KSx5Omx9fSh0LGkpKTpfZShlKT9mdW5jdGlvbih0LGUpe3ZhciBpPXhlKHQsITEsXCJmaXhlZFwiPT09ZSk7cmV0dXJuIGkudG9wPWkudG9wK3QuY2xpZW50VG9wLGkubGVmdD1pLmxlZnQrdC5jbGllbnRMZWZ0LGkuYm90dG9tPWkudG9wK3QuY2xpZW50SGVpZ2h0LGkucmlnaHQ9aS5sZWZ0K3QuY2xpZW50V2lkdGgsaS53aWR0aD10LmNsaWVudFdpZHRoLGkuaGVpZ2h0PXQuY2xpZW50SGVpZ2h0LGkueD1pLmxlZnQsaS55PWkudG9wLGl9KGUsaSk6aWkoZnVuY3Rpb24odCl7dmFyIGUsaT0kZSh0KSxuPUdlKHQpLHM9bnVsbD09KGU9dC5vd25lckRvY3VtZW50KT92b2lkIDA6ZS5ib2R5LG89QWUoaS5zY3JvbGxXaWR0aCxpLmNsaWVudFdpZHRoLHM/cy5zY3JvbGxXaWR0aDowLHM/cy5jbGllbnRXaWR0aDowKSxyPUFlKGkuc2Nyb2xsSGVpZ2h0LGkuY2xpZW50SGVpZ2h0LHM/cy5zY3JvbGxIZWlnaHQ6MCxzP3MuY2xpZW50SGVpZ2h0OjApLGE9LW4uc2Nyb2xsTGVmdCtKZSh0KSxsPS1uLnNjcm9sbFRvcDtyZXR1cm5cInJ0bFwiPT09U2Uoc3x8aSkuZGlyZWN0aW9uJiYoYSs9QWUoaS5jbGllbnRXaWR0aCxzP3MuY2xpZW50V2lkdGg6MCktbykse3dpZHRoOm8saGVpZ2h0OnIseDphLHk6bH19KCRlKHQpKSl9ZnVuY3Rpb24gc2kodCl7dmFyIGUsaT10LnJlZmVyZW5jZSxuPXQuZWxlbWVudCxzPXQucGxhY2VtZW50LG89cz93ZShzKTpudWxsLHI9cz9CZShzKTpudWxsLGE9aS54K2kud2lkdGgvMi1uLndpZHRoLzIsbD1pLnkraS5oZWlnaHQvMi1uLmhlaWdodC8yO3N3aXRjaChvKXtjYXNlIFZ0OmU9e3g6YSx5OmkueS1uLmhlaWdodH07YnJlYWs7Y2FzZSBLdDplPXt4OmEseTppLnkraS5oZWlnaHR9O2JyZWFrO2Nhc2UgUXQ6ZT17eDppLngraS53aWR0aCx5Omx9O2JyZWFrO2Nhc2UgWHQ6ZT17eDppLngtbi53aWR0aCx5Omx9O2JyZWFrO2RlZmF1bHQ6ZT17eDppLngseTppLnl9fXZhciBjPW8/amUobyk6bnVsbDtpZihudWxsIT1jKXt2YXIgaD1cInlcIj09PWM/XCJoZWlnaHRcIjpcIndpZHRoXCI7c3dpdGNoKHIpe2Nhc2UgR3Q6ZVtjXT1lW2NdLShpW2hdLzItbltoXS8yKTticmVhaztjYXNlIEp0OmVbY109ZVtjXSsoaVtoXS8yLW5baF0vMil9fXJldHVybiBlfWZ1bmN0aW9uIG9pKHQsZSl7dm9pZCAwPT09ZSYmKGU9e30pO3ZhciBpPWUsbj1pLnBsYWNlbWVudCxzPXZvaWQgMD09PW4/dC5wbGFjZW1lbnQ6bixvPWkuc3RyYXRlZ3kscj12b2lkIDA9PT1vP3Quc3RyYXRlZ3k6byxhPWkuYm91bmRhcnksbD12b2lkIDA9PT1hP1p0OmEsYz1pLnJvb3RCb3VuZGFyeSxoPXZvaWQgMD09PWM/dGU6YyxkPWkuZWxlbWVudENvbnRleHQsdT12b2lkIDA9PT1kP2VlOmQsZj1pLmFsdEJvdW5kYXJ5LHA9dm9pZCAwIT09ZiYmZixtPWkucGFkZGluZyxnPXZvaWQgMD09PW0/MDptLF89RmUoXCJudW1iZXJcIiE9dHlwZW9mIGc/ZzpIZShnLFV0KSksYj11PT09ZWU/aWU6ZWUsdj10LnJlY3RzLnBvcHBlcix5PXQuZWxlbWVudHNbcD9iOnVdLHc9ZnVuY3Rpb24odCxlLGksbil7dmFyIHM9XCJjbGlwcGluZ1BhcmVudHNcIj09PWU/ZnVuY3Rpb24odCl7dmFyIGU9ZWkoSWUodCkpLGk9W1wiYWJzb2x1dGVcIixcImZpeGVkXCJdLmluZGV4T2YoU2UodCkucG9zaXRpb24pPj0wJiZiZSh0KT9QZSh0KTp0O3JldHVybiBfZShpKT9lLmZpbHRlcihmdW5jdGlvbih0KXtyZXR1cm4gX2UodCkmJkxlKHQsaSkmJlwiYm9keVwiIT09bWUodCl9KTpbXX0odCk6W10uY29uY2F0KGUpLG89W10uY29uY2F0KHMsW2ldKSxyPW9bMF0sYT1vLnJlZHVjZShmdW5jdGlvbihlLGkpe3ZhciBzPW5pKHQsaSxuKTtyZXR1cm4gZS50b3A9QWUocy50b3AsZS50b3ApLGUucmlnaHQ9RWUocy5yaWdodCxlLnJpZ2h0KSxlLmJvdHRvbT1FZShzLmJvdHRvbSxlLmJvdHRvbSksZS5sZWZ0PUFlKHMubGVmdCxlLmxlZnQpLGV9LG5pKHQscixuKSk7cmV0dXJuIGEud2lkdGg9YS5yaWdodC1hLmxlZnQsYS5oZWlnaHQ9YS5ib3R0b20tYS50b3AsYS54PWEubGVmdCxhLnk9YS50b3AsYX0oX2UoeSk/eTp5LmNvbnRleHRFbGVtZW50fHwkZSh0LmVsZW1lbnRzLnBvcHBlciksbCxoLHIpLEE9eGUodC5lbGVtZW50cy5yZWZlcmVuY2UpLEU9c2koe3JlZmVyZW5jZTpBLGVsZW1lbnQ6dixwbGFjZW1lbnQ6c30pLFQ9aWkoT2JqZWN0LmFzc2lnbih7fSx2LEUpKSxDPXU9PT1lZT9UOkEsTz17dG9wOncudG9wLUMudG9wK18udG9wLGJvdHRvbTpDLmJvdHRvbS13LmJvdHRvbStfLmJvdHRvbSxsZWZ0OncubGVmdC1DLmxlZnQrXy5sZWZ0LHJpZ2h0OkMucmlnaHQtdy5yaWdodCtfLnJpZ2h0fSx4PXQubW9kaWZpZXJzRGF0YS5vZmZzZXQ7aWYodT09PWVlJiZ4KXt2YXIgaz14W3NdO09iamVjdC5rZXlzKE8pLmZvckVhY2goZnVuY3Rpb24odCl7dmFyIGU9W1F0LEt0XS5pbmRleE9mKHQpPj0wPzE6LTEsaT1bVnQsS3RdLmluZGV4T2YodCk+PTA/XCJ5XCI6XCJ4XCI7T1t0XSs9a1tpXSplfSl9cmV0dXJuIE99ZnVuY3Rpb24gcmkodCxlKXt2b2lkIDA9PT1lJiYoZT17fSk7dmFyIGk9ZSxuPWkucGxhY2VtZW50LHM9aS5ib3VuZGFyeSxvPWkucm9vdEJvdW5kYXJ5LHI9aS5wYWRkaW5nLGE9aS5mbGlwVmFyaWF0aW9ucyxsPWkuYWxsb3dlZEF1dG9QbGFjZW1lbnRzLGM9dm9pZCAwPT09bD9zZTpsLGg9QmUobiksZD1oP2E/bmU6bmUuZmlsdGVyKGZ1bmN0aW9uKHQpe3JldHVybiBCZSh0KT09PWh9KTpVdCx1PWQuZmlsdGVyKGZ1bmN0aW9uKHQpe3JldHVybiBjLmluZGV4T2YodCk+PTB9KTswPT09dS5sZW5ndGgmJih1PWQpO3ZhciBmPXUucmVkdWNlKGZ1bmN0aW9uKGUsaSl7cmV0dXJuIGVbaV09b2kodCx7cGxhY2VtZW50OmksYm91bmRhcnk6cyxyb290Qm91bmRhcnk6byxwYWRkaW5nOnJ9KVt3ZShpKV0sZX0se30pO3JldHVybiBPYmplY3Qua2V5cyhmKS5zb3J0KGZ1bmN0aW9uKHQsZSl7cmV0dXJuIGZbdF0tZltlXX0pfWNvbnN0IGFpPXtuYW1lOlwiZmxpcFwiLGVuYWJsZWQ6ITAscGhhc2U6XCJtYWluXCIsZm46ZnVuY3Rpb24odCl7dmFyIGU9dC5zdGF0ZSxpPXQub3B0aW9ucyxuPXQubmFtZTtpZighZS5tb2RpZmllcnNEYXRhW25dLl9za2lwKXtmb3IodmFyIHM9aS5tYWluQXhpcyxvPXZvaWQgMD09PXN8fHMscj1pLmFsdEF4aXMsYT12b2lkIDA9PT1yfHxyLGw9aS5mYWxsYmFja1BsYWNlbWVudHMsYz1pLnBhZGRpbmcsaD1pLmJvdW5kYXJ5LGQ9aS5yb290Qm91bmRhcnksdT1pLmFsdEJvdW5kYXJ5LGY9aS5mbGlwVmFyaWF0aW9ucyxwPXZvaWQgMD09PWZ8fGYsbT1pLmFsbG93ZWRBdXRvUGxhY2VtZW50cyxnPWUub3B0aW9ucy5wbGFjZW1lbnQsXz13ZShnKSxiPWx8fChfIT09ZyYmcD9mdW5jdGlvbih0KXtpZih3ZSh0KT09PVl0KXJldHVybltdO3ZhciBlPVhlKHQpO3JldHVybltVZSh0KSxlLFVlKGUpXX0oZyk6W1hlKGcpXSksdj1bZ10uY29uY2F0KGIpLnJlZHVjZShmdW5jdGlvbih0LGkpe3JldHVybiB0LmNvbmNhdCh3ZShpKT09PVl0P3JpKGUse3BsYWNlbWVudDppLGJvdW5kYXJ5Omgscm9vdEJvdW5kYXJ5OmQscGFkZGluZzpjLGZsaXBWYXJpYXRpb25zOnAsYWxsb3dlZEF1dG9QbGFjZW1lbnRzOm19KTppKX0sW10pLHk9ZS5yZWN0cy5yZWZlcmVuY2Usdz1lLnJlY3RzLnBvcHBlcixBPW5ldyBNYXAsRT0hMCxUPXZbMF0sQz0wO0M8di5sZW5ndGg7QysrKXt2YXIgTz12W0NdLHg9d2UoTyksaz1CZShPKT09PUd0LEw9W1Z0LEt0XS5pbmRleE9mKHgpPj0wLFM9TD9cIndpZHRoXCI6XCJoZWlnaHRcIixEPW9pKGUse3BsYWNlbWVudDpPLGJvdW5kYXJ5Omgscm9vdEJvdW5kYXJ5OmQsYWx0Qm91bmRhcnk6dSxwYWRkaW5nOmN9KSwkPUw/az9RdDpYdDprP0t0OlZ0O3lbU10+d1tTXSYmKCQ9WGUoJCkpO3ZhciBJPVhlKCQpLE49W107aWYobyYmTi5wdXNoKERbeF08PTApLGEmJk4ucHVzaChEWyRdPD0wLERbSV08PTApLE4uZXZlcnkoZnVuY3Rpb24odCl7cmV0dXJuIHR9KSl7VD1PLEU9ITE7YnJlYWt9QS5zZXQoTyxOKX1pZihFKWZvcih2YXIgUD1mdW5jdGlvbih0KXt2YXIgZT12LmZpbmQoZnVuY3Rpb24oZSl7dmFyIGk9QS5nZXQoZSk7aWYoaSlyZXR1cm4gaS5zbGljZSgwLHQpLmV2ZXJ5KGZ1bmN0aW9uKHQpe3JldHVybiB0fSl9KTtpZihlKXJldHVybiBUPWUsXCJicmVha1wifSxqPXA/MzoxO2o+MCYmXCJicmVha1wiIT09UChqKTtqLS0pO2UucGxhY2VtZW50IT09VCYmKGUubW9kaWZpZXJzRGF0YVtuXS5fc2tpcD0hMCxlLnBsYWNlbWVudD1ULGUucmVzZXQ9ITApfX0scmVxdWlyZXNJZkV4aXN0czpbXCJvZmZzZXRcIl0sZGF0YTp7X3NraXA6ITF9fTtmdW5jdGlvbiBsaSh0LGUsaSl7cmV0dXJuIHZvaWQgMD09PWkmJihpPXt4OjAseTowfSkse3RvcDp0LnRvcC1lLmhlaWdodC1pLnkscmlnaHQ6dC5yaWdodC1lLndpZHRoK2kueCxib3R0b206dC5ib3R0b20tZS5oZWlnaHQraS55LGxlZnQ6dC5sZWZ0LWUud2lkdGgtaS54fX1mdW5jdGlvbiBjaSh0KXtyZXR1cm5bVnQsUXQsS3QsWHRdLnNvbWUoZnVuY3Rpb24oZSl7cmV0dXJuIHRbZV0+PTB9KX1jb25zdCBoaT17bmFtZTpcImhpZGVcIixlbmFibGVkOiEwLHBoYXNlOlwibWFpblwiLHJlcXVpcmVzSWZFeGlzdHM6W1wicHJldmVudE92ZXJmbG93XCJdLGZuOmZ1bmN0aW9uKHQpe3ZhciBlPXQuc3RhdGUsaT10Lm5hbWUsbj1lLnJlY3RzLnJlZmVyZW5jZSxzPWUucmVjdHMucG9wcGVyLG89ZS5tb2RpZmllcnNEYXRhLnByZXZlbnRPdmVyZmxvdyxyPW9pKGUse2VsZW1lbnRDb250ZXh0OlwicmVmZXJlbmNlXCJ9KSxhPW9pKGUse2FsdEJvdW5kYXJ5OiEwfSksbD1saShyLG4pLGM9bGkoYSxzLG8pLGg9Y2kobCksZD1jaShjKTtlLm1vZGlmaWVyc0RhdGFbaV09e3JlZmVyZW5jZUNsaXBwaW5nT2Zmc2V0czpsLHBvcHBlckVzY2FwZU9mZnNldHM6Yyxpc1JlZmVyZW5jZUhpZGRlbjpoLGhhc1BvcHBlckVzY2FwZWQ6ZH0sZS5hdHRyaWJ1dGVzLnBvcHBlcj1PYmplY3QuYXNzaWduKHt9LGUuYXR0cmlidXRlcy5wb3BwZXIse1wiZGF0YS1wb3BwZXItcmVmZXJlbmNlLWhpZGRlblwiOmgsXCJkYXRhLXBvcHBlci1lc2NhcGVkXCI6ZH0pfX0sZGk9e25hbWU6XCJvZmZzZXRcIixlbmFibGVkOiEwLHBoYXNlOlwibWFpblwiLHJlcXVpcmVzOltcInBvcHBlck9mZnNldHNcIl0sZm46ZnVuY3Rpb24odCl7dmFyIGU9dC5zdGF0ZSxpPXQub3B0aW9ucyxuPXQubmFtZSxzPWkub2Zmc2V0LG89dm9pZCAwPT09cz9bMCwwXTpzLHI9c2UucmVkdWNlKGZ1bmN0aW9uKHQsaSl7cmV0dXJuIHRbaV09ZnVuY3Rpb24odCxlLGkpe3ZhciBuPXdlKHQpLHM9W1h0LFZ0XS5pbmRleE9mKG4pPj0wPy0xOjEsbz1cImZ1bmN0aW9uXCI9PXR5cGVvZiBpP2koT2JqZWN0LmFzc2lnbih7fSxlLHtwbGFjZW1lbnQ6dH0pKTppLHI9b1swXSxhPW9bMV07cmV0dXJuIHI9cnx8MCxhPShhfHwwKSpzLFtYdCxRdF0uaW5kZXhPZihuKT49MD97eDphLHk6cn06e3g6cix5OmF9fShpLGUucmVjdHMsbyksdH0se30pLGE9cltlLnBsYWNlbWVudF0sbD1hLngsYz1hLnk7bnVsbCE9ZS5tb2RpZmllcnNEYXRhLnBvcHBlck9mZnNldHMmJihlLm1vZGlmaWVyc0RhdGEucG9wcGVyT2Zmc2V0cy54Kz1sLGUubW9kaWZpZXJzRGF0YS5wb3BwZXJPZmZzZXRzLnkrPWMpLGUubW9kaWZpZXJzRGF0YVtuXT1yfX0sdWk9e25hbWU6XCJwb3BwZXJPZmZzZXRzXCIsZW5hYmxlZDohMCxwaGFzZTpcInJlYWRcIixmbjpmdW5jdGlvbih0KXt2YXIgZT10LnN0YXRlLGk9dC5uYW1lO2UubW9kaWZpZXJzRGF0YVtpXT1zaSh7cmVmZXJlbmNlOmUucmVjdHMucmVmZXJlbmNlLGVsZW1lbnQ6ZS5yZWN0cy5wb3BwZXIscGxhY2VtZW50OmUucGxhY2VtZW50fSl9LGRhdGE6e319LGZpPXtuYW1lOlwicHJldmVudE92ZXJmbG93XCIsZW5hYmxlZDohMCxwaGFzZTpcIm1haW5cIixmbjpmdW5jdGlvbih0KXt2YXIgZT10LnN0YXRlLGk9dC5vcHRpb25zLG49dC5uYW1lLHM9aS5tYWluQXhpcyxvPXZvaWQgMD09PXN8fHMscj1pLmFsdEF4aXMsYT12b2lkIDAhPT1yJiZyLGw9aS5ib3VuZGFyeSxjPWkucm9vdEJvdW5kYXJ5LGg9aS5hbHRCb3VuZGFyeSxkPWkucGFkZGluZyx1PWkudGV0aGVyLGY9dm9pZCAwPT09dXx8dSxwPWkudGV0aGVyT2Zmc2V0LG09dm9pZCAwPT09cD8wOnAsZz1vaShlLHtib3VuZGFyeTpsLHJvb3RCb3VuZGFyeTpjLHBhZGRpbmc6ZCxhbHRCb3VuZGFyeTpofSksXz13ZShlLnBsYWNlbWVudCksYj1CZShlLnBsYWNlbWVudCksdj0hYix5PWplKF8pLHc9XCJ4XCI9PT15P1wieVwiOlwieFwiLEE9ZS5tb2RpZmllcnNEYXRhLnBvcHBlck9mZnNldHMsRT1lLnJlY3RzLnJlZmVyZW5jZSxUPWUucmVjdHMucG9wcGVyLEM9XCJmdW5jdGlvblwiPT10eXBlb2YgbT9tKE9iamVjdC5hc3NpZ24oe30sZS5yZWN0cyx7cGxhY2VtZW50OmUucGxhY2VtZW50fSkpOm0sTz1cIm51bWJlclwiPT10eXBlb2YgQz97bWFpbkF4aXM6QyxhbHRBeGlzOkN9Ok9iamVjdC5hc3NpZ24oe21haW5BeGlzOjAsYWx0QXhpczowfSxDKSx4PWUubW9kaWZpZXJzRGF0YS5vZmZzZXQ/ZS5tb2RpZmllcnNEYXRhLm9mZnNldFtlLnBsYWNlbWVudF06bnVsbCxrPXt4OjAseTowfTtpZihBKXtpZihvKXt2YXIgTCxTPVwieVwiPT09eT9WdDpYdCxEPVwieVwiPT09eT9LdDpRdCwkPVwieVwiPT09eT9cImhlaWdodFwiOlwid2lkdGhcIixJPUFbeV0sTj1JK2dbU10sUD1JLWdbRF0saj1mPy1UWyRdLzI6MCxNPWI9PT1HdD9FWyRdOlRbJF0sRj1iPT09R3Q/LVRbJF06LUVbJF0sSD1lLmVsZW1lbnRzLmFycm93LFc9ZiYmSD9rZShIKTp7d2lkdGg6MCxoZWlnaHQ6MH0sQj1lLm1vZGlmaWVyc0RhdGFbXCJhcnJvdyNwZXJzaXN0ZW50XCJdP2UubW9kaWZpZXJzRGF0YVtcImFycm93I3BlcnNpc3RlbnRcIl0ucGFkZGluZzp7dG9wOjAscmlnaHQ6MCxib3R0b206MCxsZWZ0OjB9LHo9QltTXSxSPUJbRF0scT1NZSgwLEVbJF0sV1skXSksVj12P0VbJF0vMi1qLXEtei1PLm1haW5BeGlzOk0tcS16LU8ubWFpbkF4aXMsSz12Py1FWyRdLzIraitxK1IrTy5tYWluQXhpczpGK3ErUitPLm1haW5BeGlzLFE9ZS5lbGVtZW50cy5hcnJvdyYmUGUoZS5lbGVtZW50cy5hcnJvdyksWD1RP1wieVwiPT09eT9RLmNsaWVudFRvcHx8MDpRLmNsaWVudExlZnR8fDA6MCxZPW51bGwhPShMPW51bGw9PXg/dm9pZCAwOnhbeV0pP0w6MCxVPUkrSy1ZLEc9TWUoZj9FZShOLEkrVi1ZLVgpOk4sSSxmP0FlKFAsVSk6UCk7QVt5XT1HLGtbeV09Ry1JfWlmKGEpe3ZhciBKLFo9XCJ4XCI9PT15P1Z0Olh0LHR0PVwieFwiPT09eT9LdDpRdCxldD1BW3ddLGl0PVwieVwiPT09dz9cImhlaWdodFwiOlwid2lkdGhcIixudD1ldCtnW1pdLHN0PWV0LWdbdHRdLG90PS0xIT09W1Z0LFh0XS5pbmRleE9mKF8pLHJ0PW51bGwhPShKPW51bGw9PXg/dm9pZCAwOnhbd10pP0o6MCxhdD1vdD9udDpldC1FW2l0XS1UW2l0XS1ydCtPLmFsdEF4aXMsbHQ9b3Q/ZXQrRVtpdF0rVFtpdF0tcnQtTy5hbHRBeGlzOnN0LGN0PWYmJm90P2Z1bmN0aW9uKHQsZSxpKXt2YXIgbj1NZSh0LGUsaSk7cmV0dXJuIG4+aT9pOm59KGF0LGV0LGx0KTpNZShmP2F0Om50LGV0LGY/bHQ6c3QpO0Fbd109Y3Qsa1t3XT1jdC1ldH1lLm1vZGlmaWVyc0RhdGFbbl09a319LHJlcXVpcmVzSWZFeGlzdHM6W1wib2Zmc2V0XCJdfTtmdW5jdGlvbiBwaSh0LGUsaSl7dm9pZCAwPT09aSYmKGk9ITEpO3ZhciBuLHMsbz1iZShlKSxyPWJlKGUpJiZmdW5jdGlvbih0KXt2YXIgZT10LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLGk9VGUoZS53aWR0aCkvdC5vZmZzZXRXaWR0aHx8MSxuPVRlKGUuaGVpZ2h0KS90Lm9mZnNldEhlaWdodHx8MTtyZXR1cm4gMSE9PWl8fDEhPT1ufShlKSxhPSRlKGUpLGw9eGUodCxyLGkpLGM9e3Njcm9sbExlZnQ6MCxzY3JvbGxUb3A6MH0saD17eDowLHk6MH07cmV0dXJuKG98fCFvJiYhaSkmJigoXCJib2R5XCIhPT1tZShlKXx8WmUoYSkpJiYoYz0obj1lKSE9PWdlKG4pJiZiZShuKT97c2Nyb2xsTGVmdDoocz1uKS5zY3JvbGxMZWZ0LHNjcm9sbFRvcDpzLnNjcm9sbFRvcH06R2UobikpLGJlKGUpPygoaD14ZShlLCEwKSkueCs9ZS5jbGllbnRMZWZ0LGgueSs9ZS5jbGllbnRUb3ApOmEmJihoLng9SmUoYSkpKSx7eDpsLmxlZnQrYy5zY3JvbGxMZWZ0LWgueCx5OmwudG9wK2Muc2Nyb2xsVG9wLWgueSx3aWR0aDpsLndpZHRoLGhlaWdodDpsLmhlaWdodH19ZnVuY3Rpb24gbWkodCl7dmFyIGU9bmV3IE1hcCxpPW5ldyBTZXQsbj1bXTtmdW5jdGlvbiBzKHQpe2kuYWRkKHQubmFtZSksW10uY29uY2F0KHQucmVxdWlyZXN8fFtdLHQucmVxdWlyZXNJZkV4aXN0c3x8W10pLmZvckVhY2goZnVuY3Rpb24odCl7aWYoIWkuaGFzKHQpKXt2YXIgbj1lLmdldCh0KTtuJiZzKG4pfX0pLG4ucHVzaCh0KX1yZXR1cm4gdC5mb3JFYWNoKGZ1bmN0aW9uKHQpe2Uuc2V0KHQubmFtZSx0KX0pLHQuZm9yRWFjaChmdW5jdGlvbih0KXtpLmhhcyh0Lm5hbWUpfHxzKHQpfSksbn12YXIgZ2k9e3BsYWNlbWVudDpcImJvdHRvbVwiLG1vZGlmaWVyczpbXSxzdHJhdGVneTpcImFic29sdXRlXCJ9O2Z1bmN0aW9uIF9pKCl7Zm9yKHZhciB0PWFyZ3VtZW50cy5sZW5ndGgsZT1uZXcgQXJyYXkodCksaT0wO2k8dDtpKyspZVtpXT1hcmd1bWVudHNbaV07cmV0dXJuIWUuc29tZShmdW5jdGlvbih0KXtyZXR1cm4hKHQmJlwiZnVuY3Rpb25cIj09dHlwZW9mIHQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KX0pfWZ1bmN0aW9uIGJpKHQpe3ZvaWQgMD09PXQmJih0PXt9KTt2YXIgZT10LGk9ZS5kZWZhdWx0TW9kaWZpZXJzLG49dm9pZCAwPT09aT9bXTppLHM9ZS5kZWZhdWx0T3B0aW9ucyxvPXZvaWQgMD09PXM/Z2k6cztyZXR1cm4gZnVuY3Rpb24odCxlLGkpe3ZvaWQgMD09PWkmJihpPW8pO3ZhciBzLHIsYT17cGxhY2VtZW50OlwiYm90dG9tXCIsb3JkZXJlZE1vZGlmaWVyczpbXSxvcHRpb25zOk9iamVjdC5hc3NpZ24oe30sZ2ksbyksbW9kaWZpZXJzRGF0YTp7fSxlbGVtZW50czp7cmVmZXJlbmNlOnQscG9wcGVyOmV9LGF0dHJpYnV0ZXM6e30sc3R5bGVzOnt9fSxsPVtdLGM9ITEsaD17c3RhdGU6YSxzZXRPcHRpb25zOmZ1bmN0aW9uKGkpe3ZhciBzPVwiZnVuY3Rpb25cIj09dHlwZW9mIGk/aShhLm9wdGlvbnMpOmk7ZCgpLGEub3B0aW9ucz1PYmplY3QuYXNzaWduKHt9LG8sYS5vcHRpb25zLHMpLGEuc2Nyb2xsUGFyZW50cz17cmVmZXJlbmNlOl9lKHQpP2VpKHQpOnQuY29udGV4dEVsZW1lbnQ/ZWkodC5jb250ZXh0RWxlbWVudCk6W10scG9wcGVyOmVpKGUpfTt2YXIgcixjLHU9ZnVuY3Rpb24odCl7dmFyIGU9bWkodCk7cmV0dXJuIHBlLnJlZHVjZShmdW5jdGlvbih0LGkpe3JldHVybiB0LmNvbmNhdChlLmZpbHRlcihmdW5jdGlvbih0KXtyZXR1cm4gdC5waGFzZT09PWl9KSl9LFtdKX0oKHI9W10uY29uY2F0KG4sYS5vcHRpb25zLm1vZGlmaWVycyksYz1yLnJlZHVjZShmdW5jdGlvbih0LGUpe3ZhciBpPXRbZS5uYW1lXTtyZXR1cm4gdFtlLm5hbWVdPWk/T2JqZWN0LmFzc2lnbih7fSxpLGUse29wdGlvbnM6T2JqZWN0LmFzc2lnbih7fSxpLm9wdGlvbnMsZS5vcHRpb25zKSxkYXRhOk9iamVjdC5hc3NpZ24oe30saS5kYXRhLGUuZGF0YSl9KTplLHR9LHt9KSxPYmplY3Qua2V5cyhjKS5tYXAoZnVuY3Rpb24odCl7cmV0dXJuIGNbdF19KSkpO3JldHVybiBhLm9yZGVyZWRNb2RpZmllcnM9dS5maWx0ZXIoZnVuY3Rpb24odCl7cmV0dXJuIHQuZW5hYmxlZH0pLGEub3JkZXJlZE1vZGlmaWVycy5mb3JFYWNoKGZ1bmN0aW9uKHQpe3ZhciBlPXQubmFtZSxpPXQub3B0aW9ucyxuPXZvaWQgMD09PWk/e306aSxzPXQuZWZmZWN0O2lmKFwiZnVuY3Rpb25cIj09dHlwZW9mIHMpe3ZhciBvPXMoe3N0YXRlOmEsbmFtZTplLGluc3RhbmNlOmgsb3B0aW9uczpufSk7bC5wdXNoKG98fGZ1bmN0aW9uKCl7fSl9fSksaC51cGRhdGUoKX0sZm9yY2VVcGRhdGU6ZnVuY3Rpb24oKXtpZighYyl7dmFyIHQ9YS5lbGVtZW50cyxlPXQucmVmZXJlbmNlLGk9dC5wb3BwZXI7aWYoX2koZSxpKSl7YS5yZWN0cz17cmVmZXJlbmNlOnBpKGUsUGUoaSksXCJmaXhlZFwiPT09YS5vcHRpb25zLnN0cmF0ZWd5KSxwb3BwZXI6a2UoaSl9LGEucmVzZXQ9ITEsYS5wbGFjZW1lbnQ9YS5vcHRpb25zLnBsYWNlbWVudCxhLm9yZGVyZWRNb2RpZmllcnMuZm9yRWFjaChmdW5jdGlvbih0KXtyZXR1cm4gYS5tb2RpZmllcnNEYXRhW3QubmFtZV09T2JqZWN0LmFzc2lnbih7fSx0LmRhdGEpfSk7Zm9yKHZhciBuPTA7bjxhLm9yZGVyZWRNb2RpZmllcnMubGVuZ3RoO24rKylpZighMCE9PWEucmVzZXQpe3ZhciBzPWEub3JkZXJlZE1vZGlmaWVyc1tuXSxvPXMuZm4scj1zLm9wdGlvbnMsbD12b2lkIDA9PT1yP3t9OnIsZD1zLm5hbWU7XCJmdW5jdGlvblwiPT10eXBlb2YgbyYmKGE9byh7c3RhdGU6YSxvcHRpb25zOmwsbmFtZTpkLGluc3RhbmNlOmh9KXx8YSl9ZWxzZSBhLnJlc2V0PSExLG49LTF9fX0sdXBkYXRlOihzPWZ1bmN0aW9uKCl7cmV0dXJuIG5ldyBQcm9taXNlKGZ1bmN0aW9uKHQpe2guZm9yY2VVcGRhdGUoKSx0KGEpfSl9LGZ1bmN0aW9uKCl7cmV0dXJuIHJ8fChyPW5ldyBQcm9taXNlKGZ1bmN0aW9uKHQpe1Byb21pc2UucmVzb2x2ZSgpLnRoZW4oZnVuY3Rpb24oKXtyPXZvaWQgMCx0KHMoKSl9KX0pKSxyfSksZGVzdHJveTpmdW5jdGlvbigpe2QoKSxjPSEwfX07aWYoIV9pKHQsZSkpcmV0dXJuIGg7ZnVuY3Rpb24gZCgpe2wuZm9yRWFjaChmdW5jdGlvbih0KXtyZXR1cm4gdCgpfSksbD1bXX1yZXR1cm4gaC5zZXRPcHRpb25zKGkpLnRoZW4oZnVuY3Rpb24odCl7IWMmJmkub25GaXJzdFVwZGF0ZSYmaS5vbkZpcnN0VXBkYXRlKHQpfSksaH19dmFyIHZpPWJpKCkseWk9Ymkoe2RlZmF1bHRNb2RpZmllcnM6W0tlLHVpLHFlLHllXX0pLHdpPWJpKHtkZWZhdWx0TW9kaWZpZXJzOltLZSx1aSxxZSx5ZSxkaSxhaSxmaSxXZSxoaV19KTtjb25zdCBBaT1PYmplY3QuZnJlZXplKE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh7X19wcm90b19fOm51bGwsYWZ0ZXJNYWluOmhlLGFmdGVyUmVhZDphZSxhZnRlcldyaXRlOmZlLGFwcGx5U3R5bGVzOnllLGFycm93OldlLGF1dG86WXQsYmFzZVBsYWNlbWVudHM6VXQsYmVmb3JlTWFpbjpsZSxiZWZvcmVSZWFkOm9lLGJlZm9yZVdyaXRlOmRlLGJvdHRvbTpLdCxjbGlwcGluZ1BhcmVudHM6WnQsY29tcHV0ZVN0eWxlczpxZSxjcmVhdGVQb3BwZXI6d2ksY3JlYXRlUG9wcGVyQmFzZTp2aSxjcmVhdGVQb3BwZXJMaXRlOnlpLGRldGVjdE92ZXJmbG93Om9pLGVuZDpKdCxldmVudExpc3RlbmVyczpLZSxmbGlwOmFpLGhpZGU6aGksbGVmdDpYdCxtYWluOmNlLG1vZGlmaWVyUGhhc2VzOnBlLG9mZnNldDpkaSxwbGFjZW1lbnRzOnNlLHBvcHBlcjplZSxwb3BwZXJHZW5lcmF0b3I6YmkscG9wcGVyT2Zmc2V0czp1aSxwcmV2ZW50T3ZlcmZsb3c6ZmkscmVhZDpyZSxyZWZlcmVuY2U6aWUscmlnaHQ6UXQsc3RhcnQ6R3QsdG9wOlZ0LHZhcmlhdGlvblBsYWNlbWVudHM6bmUsdmlld3BvcnQ6dGUsd3JpdGU6dWV9LFN5bWJvbC50b1N0cmluZ1RhZyx7dmFsdWU6XCJNb2R1bGVcIn0pKSxFaT1cImRyb3Bkb3duXCIsVGk9XCIuYnMuZHJvcGRvd25cIixDaT1cIi5kYXRhLWFwaVwiLE9pPVwiQXJyb3dVcFwiLHhpPVwiQXJyb3dEb3duXCIsa2k9YGhpZGUke1RpfWAsTGk9YGhpZGRlbiR7VGl9YCxTaT1gc2hvdyR7VGl9YCxEaT1gc2hvd24ke1RpfWAsJGk9YGNsaWNrJHtUaX0ke0NpfWAsSWk9YGtleWRvd24ke1RpfSR7Q2l9YCxOaT1ga2V5dXAke1RpfSR7Q2l9YCxQaT1cInNob3dcIixqaT0nW2RhdGEtYnMtdG9nZ2xlPVwiZHJvcGRvd25cIl06bm90KC5kaXNhYmxlZCk6bm90KDpkaXNhYmxlZCknLE1pPWAke2ppfS4ke1BpfWAsRmk9XCIuZHJvcGRvd24tbWVudVwiLEhpPW0oKT9cInRvcC1lbmRcIjpcInRvcC1zdGFydFwiLFdpPW0oKT9cInRvcC1zdGFydFwiOlwidG9wLWVuZFwiLEJpPW0oKT9cImJvdHRvbS1lbmRcIjpcImJvdHRvbS1zdGFydFwiLHppPW0oKT9cImJvdHRvbS1zdGFydFwiOlwiYm90dG9tLWVuZFwiLFJpPW0oKT9cImxlZnQtc3RhcnRcIjpcInJpZ2h0LXN0YXJ0XCIscWk9bSgpP1wicmlnaHQtc3RhcnRcIjpcImxlZnQtc3RhcnRcIixWaT17YXV0b0Nsb3NlOiEwLGJvdW5kYXJ5OlwiY2xpcHBpbmdQYXJlbnRzXCIsZGlzcGxheTpcImR5bmFtaWNcIixvZmZzZXQ6WzAsMl0scG9wcGVyQ29uZmlnOm51bGwscmVmZXJlbmNlOlwidG9nZ2xlXCJ9LEtpPXthdXRvQ2xvc2U6XCIoYm9vbGVhbnxzdHJpbmcpXCIsYm91bmRhcnk6XCIoc3RyaW5nfGVsZW1lbnQpXCIsZGlzcGxheTpcInN0cmluZ1wiLG9mZnNldDpcIihhcnJheXxzdHJpbmd8ZnVuY3Rpb24pXCIscG9wcGVyQ29uZmlnOlwiKG51bGx8b2JqZWN0fGZ1bmN0aW9uKVwiLHJlZmVyZW5jZTpcIihzdHJpbmd8ZWxlbWVudHxvYmplY3QpXCJ9O2NsYXNzIFFpIGV4dGVuZHMgQntjb25zdHJ1Y3Rvcih0LGUpe3N1cGVyKHQsZSksdGhpcy5fcG9wcGVyPW51bGwsdGhpcy5fcGFyZW50PXRoaXMuX2VsZW1lbnQucGFyZW50Tm9kZSx0aGlzLl9tZW51PVIubmV4dCh0aGlzLl9lbGVtZW50LEZpKVswXXx8Ui5wcmV2KHRoaXMuX2VsZW1lbnQsRmkpWzBdfHxSLmZpbmRPbmUoRmksdGhpcy5fcGFyZW50KSx0aGlzLl9pbk5hdmJhcj10aGlzLl9kZXRlY3ROYXZiYXIoKX1zdGF0aWMgZ2V0IERlZmF1bHQoKXtyZXR1cm4gVml9c3RhdGljIGdldCBEZWZhdWx0VHlwZSgpe3JldHVybiBLaX1zdGF0aWMgZ2V0IE5BTUUoKXtyZXR1cm4gRWl9dG9nZ2xlKCl7cmV0dXJuIHRoaXMuX2lzU2hvd24oKT90aGlzLmhpZGUoKTp0aGlzLnNob3coKX1zaG93KCl7aWYoYyh0aGlzLl9lbGVtZW50KXx8dGhpcy5faXNTaG93bigpKXJldHVybjtjb25zdCB0PXtyZWxhdGVkVGFyZ2V0OnRoaXMuX2VsZW1lbnR9O2lmKCFQLnRyaWdnZXIodGhpcy5fZWxlbWVudCxTaSx0KS5kZWZhdWx0UHJldmVudGVkKXtpZih0aGlzLl9jcmVhdGVQb3BwZXIoKSxcIm9udG91Y2hzdGFydFwiaW4gZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50JiYhdGhpcy5fcGFyZW50LmNsb3Nlc3QoXCIubmF2YmFyLW5hdlwiKSlmb3IoY29uc3QgdCBvZltdLmNvbmNhdCguLi5kb2N1bWVudC5ib2R5LmNoaWxkcmVuKSlQLm9uKHQsXCJtb3VzZW92ZXJcIixkKTt0aGlzLl9lbGVtZW50LmZvY3VzKCksdGhpcy5fZWxlbWVudC5zZXRBdHRyaWJ1dGUoXCJhcmlhLWV4cGFuZGVkXCIsITApLHRoaXMuX21lbnUuY2xhc3NMaXN0LmFkZChQaSksdGhpcy5fZWxlbWVudC5jbGFzc0xpc3QuYWRkKFBpKSxQLnRyaWdnZXIodGhpcy5fZWxlbWVudCxEaSx0KX19aGlkZSgpe2lmKGModGhpcy5fZWxlbWVudCl8fCF0aGlzLl9pc1Nob3duKCkpcmV0dXJuO2NvbnN0IHQ9e3JlbGF0ZWRUYXJnZXQ6dGhpcy5fZWxlbWVudH07dGhpcy5fY29tcGxldGVIaWRlKHQpfWRpc3Bvc2UoKXt0aGlzLl9wb3BwZXImJnRoaXMuX3BvcHBlci5kZXN0cm95KCksc3VwZXIuZGlzcG9zZSgpfXVwZGF0ZSgpe3RoaXMuX2luTmF2YmFyPXRoaXMuX2RldGVjdE5hdmJhcigpLHRoaXMuX3BvcHBlciYmdGhpcy5fcG9wcGVyLnVwZGF0ZSgpfV9jb21wbGV0ZUhpZGUodCl7aWYoIVAudHJpZ2dlcih0aGlzLl9lbGVtZW50LGtpLHQpLmRlZmF1bHRQcmV2ZW50ZWQpe2lmKFwib250b3VjaHN0YXJ0XCJpbiBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQpZm9yKGNvbnN0IHQgb2ZbXS5jb25jYXQoLi4uZG9jdW1lbnQuYm9keS5jaGlsZHJlbikpUC5vZmYodCxcIm1vdXNlb3ZlclwiLGQpO3RoaXMuX3BvcHBlciYmdGhpcy5fcG9wcGVyLmRlc3Ryb3koKSx0aGlzLl9tZW51LmNsYXNzTGlzdC5yZW1vdmUoUGkpLHRoaXMuX2VsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZShQaSksdGhpcy5fZWxlbWVudC5zZXRBdHRyaWJ1dGUoXCJhcmlhLWV4cGFuZGVkXCIsXCJmYWxzZVwiKSxILnJlbW92ZURhdGFBdHRyaWJ1dGUodGhpcy5fbWVudSxcInBvcHBlclwiKSxQLnRyaWdnZXIodGhpcy5fZWxlbWVudCxMaSx0KX19X2dldENvbmZpZyh0KXtpZihcIm9iamVjdFwiPT10eXBlb2YodD1zdXBlci5fZ2V0Q29uZmlnKHQpKS5yZWZlcmVuY2UmJiFyKHQucmVmZXJlbmNlKSYmXCJmdW5jdGlvblwiIT10eXBlb2YgdC5yZWZlcmVuY2UuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KXRocm93IG5ldyBUeXBlRXJyb3IoYCR7RWkudG9VcHBlckNhc2UoKX06IE9wdGlvbiBcInJlZmVyZW5jZVwiIHByb3ZpZGVkIHR5cGUgXCJvYmplY3RcIiB3aXRob3V0IGEgcmVxdWlyZWQgXCJnZXRCb3VuZGluZ0NsaWVudFJlY3RcIiBtZXRob2QuYCk7cmV0dXJuIHR9X2NyZWF0ZVBvcHBlcigpe2lmKHZvaWQgMD09PUFpKXRocm93IG5ldyBUeXBlRXJyb3IoXCJCb290c3RyYXAncyBkcm9wZG93bnMgcmVxdWlyZSBQb3BwZXIgKGh0dHBzOi8vcG9wcGVyLmpzLm9yZy9kb2NzL3YyLylcIik7bGV0IHQ9dGhpcy5fZWxlbWVudDtcInBhcmVudFwiPT09dGhpcy5fY29uZmlnLnJlZmVyZW5jZT90PXRoaXMuX3BhcmVudDpyKHRoaXMuX2NvbmZpZy5yZWZlcmVuY2UpP3Q9YSh0aGlzLl9jb25maWcucmVmZXJlbmNlKTpcIm9iamVjdFwiPT10eXBlb2YgdGhpcy5fY29uZmlnLnJlZmVyZW5jZSYmKHQ9dGhpcy5fY29uZmlnLnJlZmVyZW5jZSk7Y29uc3QgZT10aGlzLl9nZXRQb3BwZXJDb25maWcoKTt0aGlzLl9wb3BwZXI9d2kodCx0aGlzLl9tZW51LGUpfV9pc1Nob3duKCl7cmV0dXJuIHRoaXMuX21lbnUuY2xhc3NMaXN0LmNvbnRhaW5zKFBpKX1fZ2V0UGxhY2VtZW50KCl7Y29uc3QgdD10aGlzLl9wYXJlbnQ7aWYodC5jbGFzc0xpc3QuY29udGFpbnMoXCJkcm9wZW5kXCIpKXJldHVybiBSaTtpZih0LmNsYXNzTGlzdC5jb250YWlucyhcImRyb3BzdGFydFwiKSlyZXR1cm4gcWk7aWYodC5jbGFzc0xpc3QuY29udGFpbnMoXCJkcm9wdXAtY2VudGVyXCIpKXJldHVyblwidG9wXCI7aWYodC5jbGFzc0xpc3QuY29udGFpbnMoXCJkcm9wZG93bi1jZW50ZXJcIikpcmV0dXJuXCJib3R0b21cIjtjb25zdCBlPVwiZW5kXCI9PT1nZXRDb21wdXRlZFN0eWxlKHRoaXMuX21lbnUpLmdldFByb3BlcnR5VmFsdWUoXCItLWJzLXBvc2l0aW9uXCIpLnRyaW0oKTtyZXR1cm4gdC5jbGFzc0xpc3QuY29udGFpbnMoXCJkcm9wdXBcIik/ZT9XaTpIaTplP3ppOkJpfV9kZXRlY3ROYXZiYXIoKXtyZXR1cm4gbnVsbCE9PXRoaXMuX2VsZW1lbnQuY2xvc2VzdChcIi5uYXZiYXJcIil9X2dldE9mZnNldCgpe2NvbnN0e29mZnNldDp0fT10aGlzLl9jb25maWc7cmV0dXJuXCJzdHJpbmdcIj09dHlwZW9mIHQ/dC5zcGxpdChcIixcIikubWFwKHQ9Pk51bWJlci5wYXJzZUludCh0LDEwKSk6XCJmdW5jdGlvblwiPT10eXBlb2YgdD9lPT50KGUsdGhpcy5fZWxlbWVudCk6dH1fZ2V0UG9wcGVyQ29uZmlnKCl7Y29uc3QgdD17cGxhY2VtZW50OnRoaXMuX2dldFBsYWNlbWVudCgpLG1vZGlmaWVyczpbe25hbWU6XCJwcmV2ZW50T3ZlcmZsb3dcIixvcHRpb25zOntib3VuZGFyeTp0aGlzLl9jb25maWcuYm91bmRhcnl9fSx7bmFtZTpcIm9mZnNldFwiLG9wdGlvbnM6e29mZnNldDp0aGlzLl9nZXRPZmZzZXQoKX19XX07cmV0dXJuKHRoaXMuX2luTmF2YmFyfHxcInN0YXRpY1wiPT09dGhpcy5fY29uZmlnLmRpc3BsYXkpJiYoSC5zZXREYXRhQXR0cmlidXRlKHRoaXMuX21lbnUsXCJwb3BwZXJcIixcInN0YXRpY1wiKSx0Lm1vZGlmaWVycz1be25hbWU6XCJhcHBseVN0eWxlc1wiLGVuYWJsZWQ6ITF9XSksey4uLnQsLi4uXyh0aGlzLl9jb25maWcucG9wcGVyQ29uZmlnLFt2b2lkIDAsdF0pfX1fc2VsZWN0TWVudUl0ZW0oe2tleTp0LHRhcmdldDplfSl7Y29uc3QgaT1SLmZpbmQoXCIuZHJvcGRvd24tbWVudSAuZHJvcGRvd24taXRlbTpub3QoLmRpc2FibGVkKTpub3QoOmRpc2FibGVkKVwiLHRoaXMuX21lbnUpLmZpbHRlcih0PT5sKHQpKTtpLmxlbmd0aCYmdihpLGUsdD09PXhpLCFpLmluY2x1ZGVzKGUpKS5mb2N1cygpfXN0YXRpYyBqUXVlcnlJbnRlcmZhY2UodCl7cmV0dXJuIHRoaXMuZWFjaChmdW5jdGlvbigpe2NvbnN0IGU9UWkuZ2V0T3JDcmVhdGVJbnN0YW5jZSh0aGlzLHQpO2lmKFwic3RyaW5nXCI9PXR5cGVvZiB0KXtpZih2b2lkIDA9PT1lW3RdKXRocm93IG5ldyBUeXBlRXJyb3IoYE5vIG1ldGhvZCBuYW1lZCBcIiR7dH1cImApO2VbdF0oKX19KX1zdGF0aWMgY2xlYXJNZW51cyh0KXtpZigyPT09dC5idXR0b258fFwia2V5dXBcIj09PXQudHlwZSYmXCJUYWJcIiE9PXQua2V5KXJldHVybjtjb25zdCBlPVIuZmluZChNaSk7Zm9yKGNvbnN0IGkgb2YgZSl7Y29uc3QgZT1RaS5nZXRJbnN0YW5jZShpKTtpZighZXx8ITE9PT1lLl9jb25maWcuYXV0b0Nsb3NlKWNvbnRpbnVlO2NvbnN0IG49dC5jb21wb3NlZFBhdGgoKSxzPW4uaW5jbHVkZXMoZS5fbWVudSk7aWYobi5pbmNsdWRlcyhlLl9lbGVtZW50KXx8XCJpbnNpZGVcIj09PWUuX2NvbmZpZy5hdXRvQ2xvc2UmJiFzfHxcIm91dHNpZGVcIj09PWUuX2NvbmZpZy5hdXRvQ2xvc2UmJnMpY29udGludWU7aWYoZS5fbWVudS5jb250YWlucyh0LnRhcmdldCkmJihcImtleXVwXCI9PT10LnR5cGUmJlwiVGFiXCI9PT10LmtleXx8L2lucHV0fHNlbGVjdHxvcHRpb258dGV4dGFyZWF8Zm9ybS9pLnRlc3QodC50YXJnZXQudGFnTmFtZSkpKWNvbnRpbnVlO2NvbnN0IG89e3JlbGF0ZWRUYXJnZXQ6ZS5fZWxlbWVudH07XCJjbGlja1wiPT09dC50eXBlJiYoby5jbGlja0V2ZW50PXQpLGUuX2NvbXBsZXRlSGlkZShvKX19c3RhdGljIGRhdGFBcGlLZXlkb3duSGFuZGxlcih0KXtjb25zdCBlPS9pbnB1dHx0ZXh0YXJlYS9pLnRlc3QodC50YXJnZXQudGFnTmFtZSksaT1cIkVzY2FwZVwiPT09dC5rZXksbj1bT2kseGldLmluY2x1ZGVzKHQua2V5KTtpZighbiYmIWkpcmV0dXJuO2lmKGUmJiFpKXJldHVybjt0LnByZXZlbnREZWZhdWx0KCk7Y29uc3Qgcz10aGlzLm1hdGNoZXMoamkpP3RoaXM6Ui5wcmV2KHRoaXMsamkpWzBdfHxSLm5leHQodGhpcyxqaSlbMF18fFIuZmluZE9uZShqaSx0LmRlbGVnYXRlVGFyZ2V0LnBhcmVudE5vZGUpLG89UWkuZ2V0T3JDcmVhdGVJbnN0YW5jZShzKTtpZihuKXJldHVybiB0LnN0b3BQcm9wYWdhdGlvbigpLG8uc2hvdygpLHZvaWQgby5fc2VsZWN0TWVudUl0ZW0odCk7by5faXNTaG93bigpJiYodC5zdG9wUHJvcGFnYXRpb24oKSxvLmhpZGUoKSxzLmZvY3VzKCkpfX1QLm9uKGRvY3VtZW50LElpLGppLFFpLmRhdGFBcGlLZXlkb3duSGFuZGxlciksUC5vbihkb2N1bWVudCxJaSxGaSxRaS5kYXRhQXBpS2V5ZG93bkhhbmRsZXIpLFAub24oZG9jdW1lbnQsJGksUWkuY2xlYXJNZW51cyksUC5vbihkb2N1bWVudCxOaSxRaS5jbGVhck1lbnVzKSxQLm9uKGRvY3VtZW50LCRpLGppLGZ1bmN0aW9uKHQpe3QucHJldmVudERlZmF1bHQoKSxRaS5nZXRPckNyZWF0ZUluc3RhbmNlKHRoaXMpLnRvZ2dsZSgpfSksZyhRaSk7Y29uc3QgWGk9XCJiYWNrZHJvcFwiLFlpPVwic2hvd1wiLFVpPWBtb3VzZWRvd24uYnMuJHtYaX1gLEdpPXtjbGFzc05hbWU6XCJtb2RhbC1iYWNrZHJvcFwiLGNsaWNrQ2FsbGJhY2s6bnVsbCxpc0FuaW1hdGVkOiExLGlzVmlzaWJsZTohMCxyb290RWxlbWVudDpcImJvZHlcIn0sSmk9e2NsYXNzTmFtZTpcInN0cmluZ1wiLGNsaWNrQ2FsbGJhY2s6XCIoZnVuY3Rpb258bnVsbClcIixpc0FuaW1hdGVkOlwiYm9vbGVhblwiLGlzVmlzaWJsZTpcImJvb2xlYW5cIixyb290RWxlbWVudDpcIihlbGVtZW50fHN0cmluZylcIn07Y2xhc3MgWmkgZXh0ZW5kcyBXe2NvbnN0cnVjdG9yKHQpe3N1cGVyKCksdGhpcy5fY29uZmlnPXRoaXMuX2dldENvbmZpZyh0KSx0aGlzLl9pc0FwcGVuZGVkPSExLHRoaXMuX2VsZW1lbnQ9bnVsbH1zdGF0aWMgZ2V0IERlZmF1bHQoKXtyZXR1cm4gR2l9c3RhdGljIGdldCBEZWZhdWx0VHlwZSgpe3JldHVybiBKaX1zdGF0aWMgZ2V0IE5BTUUoKXtyZXR1cm4gWGl9c2hvdyh0KXtpZighdGhpcy5fY29uZmlnLmlzVmlzaWJsZSlyZXR1cm4gdm9pZCBfKHQpO3RoaXMuX2FwcGVuZCgpO2NvbnN0IGU9dGhpcy5fZ2V0RWxlbWVudCgpO3RoaXMuX2NvbmZpZy5pc0FuaW1hdGVkJiZ1KGUpLGUuY2xhc3NMaXN0LmFkZChZaSksdGhpcy5fZW11bGF0ZUFuaW1hdGlvbigoKT0+e18odCl9KX1oaWRlKHQpe3RoaXMuX2NvbmZpZy5pc1Zpc2libGU/KHRoaXMuX2dldEVsZW1lbnQoKS5jbGFzc0xpc3QucmVtb3ZlKFlpKSx0aGlzLl9lbXVsYXRlQW5pbWF0aW9uKCgpPT57dGhpcy5kaXNwb3NlKCksXyh0KX0pKTpfKHQpfWRpc3Bvc2UoKXt0aGlzLl9pc0FwcGVuZGVkJiYoUC5vZmYodGhpcy5fZWxlbWVudCxVaSksdGhpcy5fZWxlbWVudC5yZW1vdmUoKSx0aGlzLl9pc0FwcGVuZGVkPSExKX1fZ2V0RWxlbWVudCgpe2lmKCF0aGlzLl9lbGVtZW50KXtjb25zdCB0PWRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7dC5jbGFzc05hbWU9dGhpcy5fY29uZmlnLmNsYXNzTmFtZSx0aGlzLl9jb25maWcuaXNBbmltYXRlZCYmdC5jbGFzc0xpc3QuYWRkKFwiZmFkZVwiKSx0aGlzLl9lbGVtZW50PXR9cmV0dXJuIHRoaXMuX2VsZW1lbnR9X2NvbmZpZ0FmdGVyTWVyZ2UodCl7cmV0dXJuIHQucm9vdEVsZW1lbnQ9YSh0LnJvb3RFbGVtZW50KSx0fV9hcHBlbmQoKXtpZih0aGlzLl9pc0FwcGVuZGVkKXJldHVybjtjb25zdCB0PXRoaXMuX2dldEVsZW1lbnQoKTt0aGlzLl9jb25maWcucm9vdEVsZW1lbnQuYXBwZW5kKHQpLFAub24odCxVaSwoKT0+e18odGhpcy5fY29uZmlnLmNsaWNrQ2FsbGJhY2spfSksdGhpcy5faXNBcHBlbmRlZD0hMH1fZW11bGF0ZUFuaW1hdGlvbih0KXtiKHQsdGhpcy5fZ2V0RWxlbWVudCgpLHRoaXMuX2NvbmZpZy5pc0FuaW1hdGVkKX19Y29uc3QgdG49XCIuYnMuZm9jdXN0cmFwXCIsZW49YGZvY3VzaW4ke3RufWAsbm49YGtleWRvd24udGFiJHt0bn1gLHNuPVwiYmFja3dhcmRcIixvbj17YXV0b2ZvY3VzOiEwLHRyYXBFbGVtZW50Om51bGx9LHJuPXthdXRvZm9jdXM6XCJib29sZWFuXCIsdHJhcEVsZW1lbnQ6XCJlbGVtZW50XCJ9O2NsYXNzIGFuIGV4dGVuZHMgV3tjb25zdHJ1Y3Rvcih0KXtzdXBlcigpLHRoaXMuX2NvbmZpZz10aGlzLl9nZXRDb25maWcodCksdGhpcy5faXNBY3RpdmU9ITEsdGhpcy5fbGFzdFRhYk5hdkRpcmVjdGlvbj1udWxsfXN0YXRpYyBnZXQgRGVmYXVsdCgpe3JldHVybiBvbn1zdGF0aWMgZ2V0IERlZmF1bHRUeXBlKCl7cmV0dXJuIHJufXN0YXRpYyBnZXQgTkFNRSgpe3JldHVyblwiZm9jdXN0cmFwXCJ9YWN0aXZhdGUoKXt0aGlzLl9pc0FjdGl2ZXx8KHRoaXMuX2NvbmZpZy5hdXRvZm9jdXMmJnRoaXMuX2NvbmZpZy50cmFwRWxlbWVudC5mb2N1cygpLFAub2ZmKGRvY3VtZW50LHRuKSxQLm9uKGRvY3VtZW50LGVuLHQ9PnRoaXMuX2hhbmRsZUZvY3VzaW4odCkpLFAub24oZG9jdW1lbnQsbm4sdD0+dGhpcy5faGFuZGxlS2V5ZG93bih0KSksdGhpcy5faXNBY3RpdmU9ITApfWRlYWN0aXZhdGUoKXt0aGlzLl9pc0FjdGl2ZSYmKHRoaXMuX2lzQWN0aXZlPSExLFAub2ZmKGRvY3VtZW50LHRuKSl9X2hhbmRsZUZvY3VzaW4odCl7Y29uc3R7dHJhcEVsZW1lbnQ6ZX09dGhpcy5fY29uZmlnO2lmKHQudGFyZ2V0PT09ZG9jdW1lbnR8fHQudGFyZ2V0PT09ZXx8ZS5jb250YWlucyh0LnRhcmdldCkpcmV0dXJuO2NvbnN0IGk9Ui5mb2N1c2FibGVDaGlsZHJlbihlKTswPT09aS5sZW5ndGg/ZS5mb2N1cygpOnRoaXMuX2xhc3RUYWJOYXZEaXJlY3Rpb249PT1zbj9pW2kubGVuZ3RoLTFdLmZvY3VzKCk6aVswXS5mb2N1cygpfV9oYW5kbGVLZXlkb3duKHQpe1wiVGFiXCI9PT10LmtleSYmKHRoaXMuX2xhc3RUYWJOYXZEaXJlY3Rpb249dC5zaGlmdEtleT9zbjpcImZvcndhcmRcIil9fWNvbnN0IGxuPVwiLmZpeGVkLXRvcCwgLmZpeGVkLWJvdHRvbSwgLmlzLWZpeGVkLCAuc3RpY2t5LXRvcFwiLGNuPVwiLnN0aWNreS10b3BcIixobj1cInBhZGRpbmctcmlnaHRcIixkbj1cIm1hcmdpbi1yaWdodFwiO2NsYXNzIHVue2NvbnN0cnVjdG9yKCl7dGhpcy5fZWxlbWVudD1kb2N1bWVudC5ib2R5fWdldFdpZHRoKCl7Y29uc3QgdD1kb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuY2xpZW50V2lkdGg7cmV0dXJuIE1hdGguYWJzKHdpbmRvdy5pbm5lcldpZHRoLXQpfWhpZGUoKXtjb25zdCB0PXRoaXMuZ2V0V2lkdGgoKTt0aGlzLl9kaXNhYmxlT3ZlckZsb3coKSx0aGlzLl9zZXRFbGVtZW50QXR0cmlidXRlcyh0aGlzLl9lbGVtZW50LGhuLGU9PmUrdCksdGhpcy5fc2V0RWxlbWVudEF0dHJpYnV0ZXMobG4saG4sZT0+ZSt0KSx0aGlzLl9zZXRFbGVtZW50QXR0cmlidXRlcyhjbixkbixlPT5lLXQpfXJlc2V0KCl7dGhpcy5fcmVzZXRFbGVtZW50QXR0cmlidXRlcyh0aGlzLl9lbGVtZW50LFwib3ZlcmZsb3dcIiksdGhpcy5fcmVzZXRFbGVtZW50QXR0cmlidXRlcyh0aGlzLl9lbGVtZW50LGhuKSx0aGlzLl9yZXNldEVsZW1lbnRBdHRyaWJ1dGVzKGxuLGhuKSx0aGlzLl9yZXNldEVsZW1lbnRBdHRyaWJ1dGVzKGNuLGRuKX1pc092ZXJmbG93aW5nKCl7cmV0dXJuIHRoaXMuZ2V0V2lkdGgoKT4wfV9kaXNhYmxlT3ZlckZsb3coKXt0aGlzLl9zYXZlSW5pdGlhbEF0dHJpYnV0ZSh0aGlzLl9lbGVtZW50LFwib3ZlcmZsb3dcIiksdGhpcy5fZWxlbWVudC5zdHlsZS5vdmVyZmxvdz1cImhpZGRlblwifV9zZXRFbGVtZW50QXR0cmlidXRlcyh0LGUsaSl7Y29uc3Qgbj10aGlzLmdldFdpZHRoKCk7dGhpcy5fYXBwbHlNYW5pcHVsYXRpb25DYWxsYmFjayh0LHQ9PntpZih0IT09dGhpcy5fZWxlbWVudCYmd2luZG93LmlubmVyV2lkdGg+dC5jbGllbnRXaWR0aCtuKXJldHVybjt0aGlzLl9zYXZlSW5pdGlhbEF0dHJpYnV0ZSh0LGUpO2NvbnN0IHM9d2luZG93LmdldENvbXB1dGVkU3R5bGUodCkuZ2V0UHJvcGVydHlWYWx1ZShlKTt0LnN0eWxlLnNldFByb3BlcnR5KGUsYCR7aShOdW1iZXIucGFyc2VGbG9hdChzKSl9cHhgKX0pfV9zYXZlSW5pdGlhbEF0dHJpYnV0ZSh0LGUpe2NvbnN0IGk9dC5zdHlsZS5nZXRQcm9wZXJ0eVZhbHVlKGUpO2kmJkguc2V0RGF0YUF0dHJpYnV0ZSh0LGUsaSl9X3Jlc2V0RWxlbWVudEF0dHJpYnV0ZXModCxlKXt0aGlzLl9hcHBseU1hbmlwdWxhdGlvbkNhbGxiYWNrKHQsdD0+e2NvbnN0IGk9SC5nZXREYXRhQXR0cmlidXRlKHQsZSk7bnVsbCE9PWk/KEgucmVtb3ZlRGF0YUF0dHJpYnV0ZSh0LGUpLHQuc3R5bGUuc2V0UHJvcGVydHkoZSxpKSk6dC5zdHlsZS5yZW1vdmVQcm9wZXJ0eShlKX0pfV9hcHBseU1hbmlwdWxhdGlvbkNhbGxiYWNrKHQsZSl7aWYocih0KSllKHQpO2Vsc2UgZm9yKGNvbnN0IGkgb2YgUi5maW5kKHQsdGhpcy5fZWxlbWVudCkpZShpKX19Y29uc3QgZm49XCIuYnMubW9kYWxcIixwbj1gaGlkZSR7Zm59YCxtbj1gaGlkZVByZXZlbnRlZCR7Zm59YCxnbj1gaGlkZGVuJHtmbn1gLF9uPWBzaG93JHtmbn1gLGJuPWBzaG93biR7Zm59YCx2bj1gcmVzaXplJHtmbn1gLHluPWBjbGljay5kaXNtaXNzJHtmbn1gLHduPWBtb3VzZWRvd24uZGlzbWlzcyR7Zm59YCxBbj1ga2V5ZG93bi5kaXNtaXNzJHtmbn1gLEVuPWBjbGljayR7Zm59LmRhdGEtYXBpYCxUbj1cIm1vZGFsLW9wZW5cIixDbj1cInNob3dcIixPbj1cIm1vZGFsLXN0YXRpY1wiLHhuPXtiYWNrZHJvcDohMCxmb2N1czohMCxrZXlib2FyZDohMH0sa249e2JhY2tkcm9wOlwiKGJvb2xlYW58c3RyaW5nKVwiLGZvY3VzOlwiYm9vbGVhblwiLGtleWJvYXJkOlwiYm9vbGVhblwifTtjbGFzcyBMbiBleHRlbmRzIEJ7Y29uc3RydWN0b3IodCxlKXtzdXBlcih0LGUpLHRoaXMuX2RpYWxvZz1SLmZpbmRPbmUoXCIubW9kYWwtZGlhbG9nXCIsdGhpcy5fZWxlbWVudCksdGhpcy5fYmFja2Ryb3A9dGhpcy5faW5pdGlhbGl6ZUJhY2tEcm9wKCksdGhpcy5fZm9jdXN0cmFwPXRoaXMuX2luaXRpYWxpemVGb2N1c1RyYXAoKSx0aGlzLl9pc1Nob3duPSExLHRoaXMuX2lzVHJhbnNpdGlvbmluZz0hMSx0aGlzLl9zY3JvbGxCYXI9bmV3IHVuLHRoaXMuX2FkZEV2ZW50TGlzdGVuZXJzKCl9c3RhdGljIGdldCBEZWZhdWx0KCl7cmV0dXJuIHhufXN0YXRpYyBnZXQgRGVmYXVsdFR5cGUoKXtyZXR1cm4ga259c3RhdGljIGdldCBOQU1FKCl7cmV0dXJuXCJtb2RhbFwifXRvZ2dsZSh0KXtyZXR1cm4gdGhpcy5faXNTaG93bj90aGlzLmhpZGUoKTp0aGlzLnNob3codCl9c2hvdyh0KXt0aGlzLl9pc1Nob3dufHx0aGlzLl9pc1RyYW5zaXRpb25pbmd8fFAudHJpZ2dlcih0aGlzLl9lbGVtZW50LF9uLHtyZWxhdGVkVGFyZ2V0OnR9KS5kZWZhdWx0UHJldmVudGVkfHwodGhpcy5faXNTaG93bj0hMCx0aGlzLl9pc1RyYW5zaXRpb25pbmc9ITAsdGhpcy5fc2Nyb2xsQmFyLmhpZGUoKSxkb2N1bWVudC5ib2R5LmNsYXNzTGlzdC5hZGQoVG4pLHRoaXMuX2FkanVzdERpYWxvZygpLHRoaXMuX2JhY2tkcm9wLnNob3coKCk9PnRoaXMuX3Nob3dFbGVtZW50KHQpKSl9aGlkZSgpe3RoaXMuX2lzU2hvd24mJiF0aGlzLl9pc1RyYW5zaXRpb25pbmcmJihQLnRyaWdnZXIodGhpcy5fZWxlbWVudCxwbikuZGVmYXVsdFByZXZlbnRlZHx8KHRoaXMuX2lzU2hvd249ITEsdGhpcy5faXNUcmFuc2l0aW9uaW5nPSEwLHRoaXMuX2ZvY3VzdHJhcC5kZWFjdGl2YXRlKCksdGhpcy5fZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKENuKSx0aGlzLl9xdWV1ZUNhbGxiYWNrKCgpPT50aGlzLl9oaWRlTW9kYWwoKSx0aGlzLl9lbGVtZW50LHRoaXMuX2lzQW5pbWF0ZWQoKSkpKX1kaXNwb3NlKCl7UC5vZmYod2luZG93LGZuKSxQLm9mZih0aGlzLl9kaWFsb2csZm4pLHRoaXMuX2JhY2tkcm9wLmRpc3Bvc2UoKSx0aGlzLl9mb2N1c3RyYXAuZGVhY3RpdmF0ZSgpLHN1cGVyLmRpc3Bvc2UoKX1oYW5kbGVVcGRhdGUoKXt0aGlzLl9hZGp1c3REaWFsb2coKX1faW5pdGlhbGl6ZUJhY2tEcm9wKCl7cmV0dXJuIG5ldyBaaSh7aXNWaXNpYmxlOkJvb2xlYW4odGhpcy5fY29uZmlnLmJhY2tkcm9wKSxpc0FuaW1hdGVkOnRoaXMuX2lzQW5pbWF0ZWQoKX0pfV9pbml0aWFsaXplRm9jdXNUcmFwKCl7cmV0dXJuIG5ldyBhbih7dHJhcEVsZW1lbnQ6dGhpcy5fZWxlbWVudH0pfV9zaG93RWxlbWVudCh0KXtkb2N1bWVudC5ib2R5LmNvbnRhaW5zKHRoaXMuX2VsZW1lbnQpfHxkb2N1bWVudC5ib2R5LmFwcGVuZCh0aGlzLl9lbGVtZW50KSx0aGlzLl9lbGVtZW50LnN0eWxlLmRpc3BsYXk9XCJibG9ja1wiLHRoaXMuX2VsZW1lbnQucmVtb3ZlQXR0cmlidXRlKFwiYXJpYS1oaWRkZW5cIiksdGhpcy5fZWxlbWVudC5zZXRBdHRyaWJ1dGUoXCJhcmlhLW1vZGFsXCIsITApLHRoaXMuX2VsZW1lbnQuc2V0QXR0cmlidXRlKFwicm9sZVwiLFwiZGlhbG9nXCIpLHRoaXMuX2VsZW1lbnQuc2Nyb2xsVG9wPTA7Y29uc3QgZT1SLmZpbmRPbmUoXCIubW9kYWwtYm9keVwiLHRoaXMuX2RpYWxvZyk7ZSYmKGUuc2Nyb2xsVG9wPTApLHUodGhpcy5fZWxlbWVudCksdGhpcy5fZWxlbWVudC5jbGFzc0xpc3QuYWRkKENuKSx0aGlzLl9xdWV1ZUNhbGxiYWNrKCgpPT57dGhpcy5fY29uZmlnLmZvY3VzJiZ0aGlzLl9mb2N1c3RyYXAuYWN0aXZhdGUoKSx0aGlzLl9pc1RyYW5zaXRpb25pbmc9ITEsUC50cmlnZ2VyKHRoaXMuX2VsZW1lbnQsYm4se3JlbGF0ZWRUYXJnZXQ6dH0pfSx0aGlzLl9kaWFsb2csdGhpcy5faXNBbmltYXRlZCgpKX1fYWRkRXZlbnRMaXN0ZW5lcnMoKXtQLm9uKHRoaXMuX2VsZW1lbnQsQW4sdD0+e1wiRXNjYXBlXCI9PT10LmtleSYmKHRoaXMuX2NvbmZpZy5rZXlib2FyZD90aGlzLmhpZGUoKTp0aGlzLl90cmlnZ2VyQmFja2Ryb3BUcmFuc2l0aW9uKCkpfSksUC5vbih3aW5kb3csdm4sKCk9Pnt0aGlzLl9pc1Nob3duJiYhdGhpcy5faXNUcmFuc2l0aW9uaW5nJiZ0aGlzLl9hZGp1c3REaWFsb2coKX0pLFAub24odGhpcy5fZWxlbWVudCx3bix0PT57UC5vbmUodGhpcy5fZWxlbWVudCx5bixlPT57dGhpcy5fZWxlbWVudD09PXQudGFyZ2V0JiZ0aGlzLl9lbGVtZW50PT09ZS50YXJnZXQmJihcInN0YXRpY1wiIT09dGhpcy5fY29uZmlnLmJhY2tkcm9wP3RoaXMuX2NvbmZpZy5iYWNrZHJvcCYmdGhpcy5oaWRlKCk6dGhpcy5fdHJpZ2dlckJhY2tkcm9wVHJhbnNpdGlvbigpKX0pfSl9X2hpZGVNb2RhbCgpe3RoaXMuX2VsZW1lbnQuc3R5bGUuZGlzcGxheT1cIm5vbmVcIix0aGlzLl9lbGVtZW50LnNldEF0dHJpYnV0ZShcImFyaWEtaGlkZGVuXCIsITApLHRoaXMuX2VsZW1lbnQucmVtb3ZlQXR0cmlidXRlKFwiYXJpYS1tb2RhbFwiKSx0aGlzLl9lbGVtZW50LnJlbW92ZUF0dHJpYnV0ZShcInJvbGVcIiksdGhpcy5faXNUcmFuc2l0aW9uaW5nPSExLHRoaXMuX2JhY2tkcm9wLmhpZGUoKCk9Pntkb2N1bWVudC5ib2R5LmNsYXNzTGlzdC5yZW1vdmUoVG4pLHRoaXMuX3Jlc2V0QWRqdXN0bWVudHMoKSx0aGlzLl9zY3JvbGxCYXIucmVzZXQoKSxQLnRyaWdnZXIodGhpcy5fZWxlbWVudCxnbil9KX1faXNBbmltYXRlZCgpe3JldHVybiB0aGlzLl9lbGVtZW50LmNsYXNzTGlzdC5jb250YWlucyhcImZhZGVcIil9X3RyaWdnZXJCYWNrZHJvcFRyYW5zaXRpb24oKXtpZihQLnRyaWdnZXIodGhpcy5fZWxlbWVudCxtbikuZGVmYXVsdFByZXZlbnRlZClyZXR1cm47Y29uc3QgdD10aGlzLl9lbGVtZW50LnNjcm9sbEhlaWdodD5kb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuY2xpZW50SGVpZ2h0LGU9dGhpcy5fZWxlbWVudC5zdHlsZS5vdmVyZmxvd1k7XCJoaWRkZW5cIj09PWV8fHRoaXMuX2VsZW1lbnQuY2xhc3NMaXN0LmNvbnRhaW5zKE9uKXx8KHR8fCh0aGlzLl9lbGVtZW50LnN0eWxlLm92ZXJmbG93WT1cImhpZGRlblwiKSx0aGlzLl9lbGVtZW50LmNsYXNzTGlzdC5hZGQoT24pLHRoaXMuX3F1ZXVlQ2FsbGJhY2soKCk9Pnt0aGlzLl9lbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoT24pLHRoaXMuX3F1ZXVlQ2FsbGJhY2soKCk9Pnt0aGlzLl9lbGVtZW50LnN0eWxlLm92ZXJmbG93WT1lfSx0aGlzLl9kaWFsb2cpfSx0aGlzLl9kaWFsb2cpLHRoaXMuX2VsZW1lbnQuZm9jdXMoKSl9X2FkanVzdERpYWxvZygpe2NvbnN0IHQ9dGhpcy5fZWxlbWVudC5zY3JvbGxIZWlnaHQ+ZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LmNsaWVudEhlaWdodCxlPXRoaXMuX3Njcm9sbEJhci5nZXRXaWR0aCgpLGk9ZT4wO2lmKGkmJiF0KXtjb25zdCB0PW0oKT9cInBhZGRpbmdMZWZ0XCI6XCJwYWRkaW5nUmlnaHRcIjt0aGlzLl9lbGVtZW50LnN0eWxlW3RdPWAke2V9cHhgfWlmKCFpJiZ0KXtjb25zdCB0PW0oKT9cInBhZGRpbmdSaWdodFwiOlwicGFkZGluZ0xlZnRcIjt0aGlzLl9lbGVtZW50LnN0eWxlW3RdPWAke2V9cHhgfX1fcmVzZXRBZGp1c3RtZW50cygpe3RoaXMuX2VsZW1lbnQuc3R5bGUucGFkZGluZ0xlZnQ9XCJcIix0aGlzLl9lbGVtZW50LnN0eWxlLnBhZGRpbmdSaWdodD1cIlwifXN0YXRpYyBqUXVlcnlJbnRlcmZhY2UodCxlKXtyZXR1cm4gdGhpcy5lYWNoKGZ1bmN0aW9uKCl7Y29uc3QgaT1Mbi5nZXRPckNyZWF0ZUluc3RhbmNlKHRoaXMsdCk7aWYoXCJzdHJpbmdcIj09dHlwZW9mIHQpe2lmKHZvaWQgMD09PWlbdF0pdGhyb3cgbmV3IFR5cGVFcnJvcihgTm8gbWV0aG9kIG5hbWVkIFwiJHt0fVwiYCk7aVt0XShlKX19KX19UC5vbihkb2N1bWVudCxFbiwnW2RhdGEtYnMtdG9nZ2xlPVwibW9kYWxcIl0nLGZ1bmN0aW9uKHQpe2NvbnN0IGU9Ui5nZXRFbGVtZW50RnJvbVNlbGVjdG9yKHRoaXMpO1tcIkFcIixcIkFSRUFcIl0uaW5jbHVkZXModGhpcy50YWdOYW1lKSYmdC5wcmV2ZW50RGVmYXVsdCgpLFAub25lKGUsX24sdD0+e3QuZGVmYXVsdFByZXZlbnRlZHx8UC5vbmUoZSxnbiwoKT0+e2wodGhpcykmJnRoaXMuZm9jdXMoKX0pfSk7Y29uc3QgaT1SLmZpbmRPbmUoXCIubW9kYWwuc2hvd1wiKTtpJiZMbi5nZXRJbnN0YW5jZShpKS5oaWRlKCksTG4uZ2V0T3JDcmVhdGVJbnN0YW5jZShlKS50b2dnbGUodGhpcyl9KSxxKExuKSxnKExuKTtjb25zdCBTbj1cIi5icy5vZmZjYW52YXNcIixEbj1cIi5kYXRhLWFwaVwiLCRuPWBsb2FkJHtTbn0ke0RufWAsSW49XCJzaG93XCIsTm49XCJzaG93aW5nXCIsUG49XCJoaWRpbmdcIixqbj1cIi5vZmZjYW52YXMuc2hvd1wiLE1uPWBzaG93JHtTbn1gLEZuPWBzaG93biR7U259YCxIbj1gaGlkZSR7U259YCxXbj1gaGlkZVByZXZlbnRlZCR7U259YCxCbj1gaGlkZGVuJHtTbn1gLHpuPWByZXNpemUke1NufWAsUm49YGNsaWNrJHtTbn0ke0RufWAscW49YGtleWRvd24uZGlzbWlzcyR7U259YCxWbj17YmFja2Ryb3A6ITAsa2V5Ym9hcmQ6ITAsc2Nyb2xsOiExfSxLbj17YmFja2Ryb3A6XCIoYm9vbGVhbnxzdHJpbmcpXCIsa2V5Ym9hcmQ6XCJib29sZWFuXCIsc2Nyb2xsOlwiYm9vbGVhblwifTtjbGFzcyBRbiBleHRlbmRzIEJ7Y29uc3RydWN0b3IodCxlKXtzdXBlcih0LGUpLHRoaXMuX2lzU2hvd249ITEsdGhpcy5fYmFja2Ryb3A9dGhpcy5faW5pdGlhbGl6ZUJhY2tEcm9wKCksdGhpcy5fZm9jdXN0cmFwPXRoaXMuX2luaXRpYWxpemVGb2N1c1RyYXAoKSx0aGlzLl9hZGRFdmVudExpc3RlbmVycygpfXN0YXRpYyBnZXQgRGVmYXVsdCgpe3JldHVybiBWbn1zdGF0aWMgZ2V0IERlZmF1bHRUeXBlKCl7cmV0dXJuIEtufXN0YXRpYyBnZXQgTkFNRSgpe3JldHVyblwib2ZmY2FudmFzXCJ9dG9nZ2xlKHQpe3JldHVybiB0aGlzLl9pc1Nob3duP3RoaXMuaGlkZSgpOnRoaXMuc2hvdyh0KX1zaG93KHQpe3RoaXMuX2lzU2hvd258fFAudHJpZ2dlcih0aGlzLl9lbGVtZW50LE1uLHtyZWxhdGVkVGFyZ2V0OnR9KS5kZWZhdWx0UHJldmVudGVkfHwodGhpcy5faXNTaG93bj0hMCx0aGlzLl9iYWNrZHJvcC5zaG93KCksdGhpcy5fY29uZmlnLnNjcm9sbHx8KG5ldyB1bikuaGlkZSgpLHRoaXMuX2VsZW1lbnQuc2V0QXR0cmlidXRlKFwiYXJpYS1tb2RhbFwiLCEwKSx0aGlzLl9lbGVtZW50LnNldEF0dHJpYnV0ZShcInJvbGVcIixcImRpYWxvZ1wiKSx0aGlzLl9lbGVtZW50LmNsYXNzTGlzdC5hZGQoTm4pLHRoaXMuX3F1ZXVlQ2FsbGJhY2soKCk9Pnt0aGlzLl9jb25maWcuc2Nyb2xsJiYhdGhpcy5fY29uZmlnLmJhY2tkcm9wfHx0aGlzLl9mb2N1c3RyYXAuYWN0aXZhdGUoKSx0aGlzLl9lbGVtZW50LmNsYXNzTGlzdC5hZGQoSW4pLHRoaXMuX2VsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZShObiksUC50cmlnZ2VyKHRoaXMuX2VsZW1lbnQsRm4se3JlbGF0ZWRUYXJnZXQ6dH0pfSx0aGlzLl9lbGVtZW50LCEwKSl9aGlkZSgpe3RoaXMuX2lzU2hvd24mJihQLnRyaWdnZXIodGhpcy5fZWxlbWVudCxIbikuZGVmYXVsdFByZXZlbnRlZHx8KHRoaXMuX2ZvY3VzdHJhcC5kZWFjdGl2YXRlKCksdGhpcy5fZWxlbWVudC5ibHVyKCksdGhpcy5faXNTaG93bj0hMSx0aGlzLl9lbGVtZW50LmNsYXNzTGlzdC5hZGQoUG4pLHRoaXMuX2JhY2tkcm9wLmhpZGUoKSx0aGlzLl9xdWV1ZUNhbGxiYWNrKCgpPT57dGhpcy5fZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKEluLFBuKSx0aGlzLl9lbGVtZW50LnJlbW92ZUF0dHJpYnV0ZShcImFyaWEtbW9kYWxcIiksdGhpcy5fZWxlbWVudC5yZW1vdmVBdHRyaWJ1dGUoXCJyb2xlXCIpLHRoaXMuX2NvbmZpZy5zY3JvbGx8fChuZXcgdW4pLnJlc2V0KCksUC50cmlnZ2VyKHRoaXMuX2VsZW1lbnQsQm4pfSx0aGlzLl9lbGVtZW50LCEwKSkpfWRpc3Bvc2UoKXt0aGlzLl9iYWNrZHJvcC5kaXNwb3NlKCksdGhpcy5fZm9jdXN0cmFwLmRlYWN0aXZhdGUoKSxzdXBlci5kaXNwb3NlKCl9X2luaXRpYWxpemVCYWNrRHJvcCgpe2NvbnN0IHQ9Qm9vbGVhbih0aGlzLl9jb25maWcuYmFja2Ryb3ApO3JldHVybiBuZXcgWmkoe2NsYXNzTmFtZTpcIm9mZmNhbnZhcy1iYWNrZHJvcFwiLGlzVmlzaWJsZTp0LGlzQW5pbWF0ZWQ6ITAscm9vdEVsZW1lbnQ6dGhpcy5fZWxlbWVudC5wYXJlbnROb2RlLGNsaWNrQ2FsbGJhY2s6dD8oKT0+e1wic3RhdGljXCIhPT10aGlzLl9jb25maWcuYmFja2Ryb3A/dGhpcy5oaWRlKCk6UC50cmlnZ2VyKHRoaXMuX2VsZW1lbnQsV24pfTpudWxsfSl9X2luaXRpYWxpemVGb2N1c1RyYXAoKXtyZXR1cm4gbmV3IGFuKHt0cmFwRWxlbWVudDp0aGlzLl9lbGVtZW50fSl9X2FkZEV2ZW50TGlzdGVuZXJzKCl7UC5vbih0aGlzLl9lbGVtZW50LHFuLHQ9PntcIkVzY2FwZVwiPT09dC5rZXkmJih0aGlzLl9jb25maWcua2V5Ym9hcmQ/dGhpcy5oaWRlKCk6UC50cmlnZ2VyKHRoaXMuX2VsZW1lbnQsV24pKX0pfXN0YXRpYyBqUXVlcnlJbnRlcmZhY2UodCl7cmV0dXJuIHRoaXMuZWFjaChmdW5jdGlvbigpe2NvbnN0IGU9UW4uZ2V0T3JDcmVhdGVJbnN0YW5jZSh0aGlzLHQpO2lmKFwic3RyaW5nXCI9PXR5cGVvZiB0KXtpZih2b2lkIDA9PT1lW3RdfHx0LnN0YXJ0c1dpdGgoXCJfXCIpfHxcImNvbnN0cnVjdG9yXCI9PT10KXRocm93IG5ldyBUeXBlRXJyb3IoYE5vIG1ldGhvZCBuYW1lZCBcIiR7dH1cImApO2VbdF0odGhpcyl9fSl9fVAub24oZG9jdW1lbnQsUm4sJ1tkYXRhLWJzLXRvZ2dsZT1cIm9mZmNhbnZhc1wiXScsZnVuY3Rpb24odCl7Y29uc3QgZT1SLmdldEVsZW1lbnRGcm9tU2VsZWN0b3IodGhpcyk7aWYoW1wiQVwiLFwiQVJFQVwiXS5pbmNsdWRlcyh0aGlzLnRhZ05hbWUpJiZ0LnByZXZlbnREZWZhdWx0KCksYyh0aGlzKSlyZXR1cm47UC5vbmUoZSxCbiwoKT0+e2wodGhpcykmJnRoaXMuZm9jdXMoKX0pO2NvbnN0IGk9Ui5maW5kT25lKGpuKTtpJiZpIT09ZSYmUW4uZ2V0SW5zdGFuY2UoaSkuaGlkZSgpLFFuLmdldE9yQ3JlYXRlSW5zdGFuY2UoZSkudG9nZ2xlKHRoaXMpfSksUC5vbih3aW5kb3csJG4sKCk9Pntmb3IoY29uc3QgdCBvZiBSLmZpbmQoam4pKVFuLmdldE9yQ3JlYXRlSW5zdGFuY2UodCkuc2hvdygpfSksUC5vbih3aW5kb3csem4sKCk9Pntmb3IoY29uc3QgdCBvZiBSLmZpbmQoXCJbYXJpYS1tb2RhbF1bY2xhc3MqPXNob3ddW2NsYXNzKj1vZmZjYW52YXMtXVwiKSlcImZpeGVkXCIhPT1nZXRDb21wdXRlZFN0eWxlKHQpLnBvc2l0aW9uJiZRbi5nZXRPckNyZWF0ZUluc3RhbmNlKHQpLmhpZGUoKX0pLHEoUW4pLGcoUW4pO2NvbnN0IFhuPXtcIipcIjpbXCJjbGFzc1wiLFwiZGlyXCIsXCJpZFwiLFwibGFuZ1wiLFwicm9sZVwiLC9eYXJpYS1bXFx3LV0qJC9pXSxhOltcInRhcmdldFwiLFwiaHJlZlwiLFwidGl0bGVcIixcInJlbFwiXSxhcmVhOltdLGI6W10sYnI6W10sY29sOltdLGNvZGU6W10sZGQ6W10sZGl2OltdLGRsOltdLGR0OltdLGVtOltdLGhyOltdLGgxOltdLGgyOltdLGgzOltdLGg0OltdLGg1OltdLGg2OltdLGk6W10saW1nOltcInNyY1wiLFwic3Jjc2V0XCIsXCJhbHRcIixcInRpdGxlXCIsXCJ3aWR0aFwiLFwiaGVpZ2h0XCJdLGxpOltdLG9sOltdLHA6W10scHJlOltdLHM6W10sc21hbGw6W10sc3BhbjpbXSxzdWI6W10sc3VwOltdLHN0cm9uZzpbXSx1OltdLHVsOltdfSxZbj1uZXcgU2V0KFtcImJhY2tncm91bmRcIixcImNpdGVcIixcImhyZWZcIixcIml0ZW10eXBlXCIsXCJsb25nZGVzY1wiLFwicG9zdGVyXCIsXCJzcmNcIixcInhsaW5rOmhyZWZcIl0pLFVuPS9eKD8hamF2YXNjcmlwdDopKD86W2EtejAtOSsuLV0rOnxbXiY6Lz8jXSooPzpbLz8jXXwkKSkvaSxHbj0odCxlKT0+e2NvbnN0IGk9dC5ub2RlTmFtZS50b0xvd2VyQ2FzZSgpO3JldHVybiBlLmluY2x1ZGVzKGkpPyFZbi5oYXMoaSl8fEJvb2xlYW4oVW4udGVzdCh0Lm5vZGVWYWx1ZSkpOmUuZmlsdGVyKHQ9PnQgaW5zdGFuY2VvZiBSZWdFeHApLnNvbWUodD0+dC50ZXN0KGkpKX0sSm49e2FsbG93TGlzdDpYbixjb250ZW50Ont9LGV4dHJhQ2xhc3M6XCJcIixodG1sOiExLHNhbml0aXplOiEwLHNhbml0aXplRm46bnVsbCx0ZW1wbGF0ZTpcIjxkaXY+PC9kaXY+XCJ9LFpuPXthbGxvd0xpc3Q6XCJvYmplY3RcIixjb250ZW50Olwib2JqZWN0XCIsZXh0cmFDbGFzczpcIihzdHJpbmd8ZnVuY3Rpb24pXCIsaHRtbDpcImJvb2xlYW5cIixzYW5pdGl6ZTpcImJvb2xlYW5cIixzYW5pdGl6ZUZuOlwiKG51bGx8ZnVuY3Rpb24pXCIsdGVtcGxhdGU6XCJzdHJpbmdcIn0sdHM9e2VudHJ5OlwiKHN0cmluZ3xlbGVtZW50fGZ1bmN0aW9ufG51bGwpXCIsc2VsZWN0b3I6XCIoc3RyaW5nfGVsZW1lbnQpXCJ9O2NsYXNzIGVzIGV4dGVuZHMgV3tjb25zdHJ1Y3Rvcih0KXtzdXBlcigpLHRoaXMuX2NvbmZpZz10aGlzLl9nZXRDb25maWcodCl9c3RhdGljIGdldCBEZWZhdWx0KCl7cmV0dXJuIEpufXN0YXRpYyBnZXQgRGVmYXVsdFR5cGUoKXtyZXR1cm4gWm59c3RhdGljIGdldCBOQU1FKCl7cmV0dXJuXCJUZW1wbGF0ZUZhY3RvcnlcIn1nZXRDb250ZW50KCl7cmV0dXJuIE9iamVjdC52YWx1ZXModGhpcy5fY29uZmlnLmNvbnRlbnQpLm1hcCh0PT50aGlzLl9yZXNvbHZlUG9zc2libGVGdW5jdGlvbih0KSkuZmlsdGVyKEJvb2xlYW4pfWhhc0NvbnRlbnQoKXtyZXR1cm4gdGhpcy5nZXRDb250ZW50KCkubGVuZ3RoPjB9Y2hhbmdlQ29udGVudCh0KXtyZXR1cm4gdGhpcy5fY2hlY2tDb250ZW50KHQpLHRoaXMuX2NvbmZpZy5jb250ZW50PXsuLi50aGlzLl9jb25maWcuY29udGVudCwuLi50fSx0aGlzfXRvSHRtbCgpe2NvbnN0IHQ9ZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTt0LmlubmVySFRNTD10aGlzLl9tYXliZVNhbml0aXplKHRoaXMuX2NvbmZpZy50ZW1wbGF0ZSk7Zm9yKGNvbnN0W2UsaV1vZiBPYmplY3QuZW50cmllcyh0aGlzLl9jb25maWcuY29udGVudCkpdGhpcy5fc2V0Q29udGVudCh0LGksZSk7Y29uc3QgZT10LmNoaWxkcmVuWzBdLGk9dGhpcy5fcmVzb2x2ZVBvc3NpYmxlRnVuY3Rpb24odGhpcy5fY29uZmlnLmV4dHJhQ2xhc3MpO3JldHVybiBpJiZlLmNsYXNzTGlzdC5hZGQoLi4uaS5zcGxpdChcIiBcIikpLGV9X3R5cGVDaGVja0NvbmZpZyh0KXtzdXBlci5fdHlwZUNoZWNrQ29uZmlnKHQpLHRoaXMuX2NoZWNrQ29udGVudCh0LmNvbnRlbnQpfV9jaGVja0NvbnRlbnQodCl7Zm9yKGNvbnN0W2UsaV1vZiBPYmplY3QuZW50cmllcyh0KSlzdXBlci5fdHlwZUNoZWNrQ29uZmlnKHtzZWxlY3RvcjplLGVudHJ5Oml9LHRzKX1fc2V0Q29udGVudCh0LGUsaSl7Y29uc3Qgbj1SLmZpbmRPbmUoaSx0KTtuJiYoKGU9dGhpcy5fcmVzb2x2ZVBvc3NpYmxlRnVuY3Rpb24oZSkpP3IoZSk/dGhpcy5fcHV0RWxlbWVudEluVGVtcGxhdGUoYShlKSxuKTp0aGlzLl9jb25maWcuaHRtbD9uLmlubmVySFRNTD10aGlzLl9tYXliZVNhbml0aXplKGUpOm4udGV4dENvbnRlbnQ9ZTpuLnJlbW92ZSgpKX1fbWF5YmVTYW5pdGl6ZSh0KXtyZXR1cm4gdGhpcy5fY29uZmlnLnNhbml0aXplP2Z1bmN0aW9uKHQsZSxpKXtpZighdC5sZW5ndGgpcmV0dXJuIHQ7aWYoaSYmXCJmdW5jdGlvblwiPT10eXBlb2YgaSlyZXR1cm4gaSh0KTtjb25zdCBuPShuZXcgd2luZG93LkRPTVBhcnNlcikucGFyc2VGcm9tU3RyaW5nKHQsXCJ0ZXh0L2h0bWxcIikscz1bXS5jb25jYXQoLi4ubi5ib2R5LnF1ZXJ5U2VsZWN0b3JBbGwoXCIqXCIpKTtmb3IoY29uc3QgdCBvZiBzKXtjb25zdCBpPXQubm9kZU5hbWUudG9Mb3dlckNhc2UoKTtpZighT2JqZWN0LmtleXMoZSkuaW5jbHVkZXMoaSkpe3QucmVtb3ZlKCk7Y29udGludWV9Y29uc3Qgbj1bXS5jb25jYXQoLi4udC5hdHRyaWJ1dGVzKSxzPVtdLmNvbmNhdChlW1wiKlwiXXx8W10sZVtpXXx8W10pO2Zvcihjb25zdCBlIG9mIG4pR24oZSxzKXx8dC5yZW1vdmVBdHRyaWJ1dGUoZS5ub2RlTmFtZSl9cmV0dXJuIG4uYm9keS5pbm5lckhUTUx9KHQsdGhpcy5fY29uZmlnLmFsbG93TGlzdCx0aGlzLl9jb25maWcuc2FuaXRpemVGbik6dH1fcmVzb2x2ZVBvc3NpYmxlRnVuY3Rpb24odCl7cmV0dXJuIF8odCxbdm9pZCAwLHRoaXNdKX1fcHV0RWxlbWVudEluVGVtcGxhdGUodCxlKXtpZih0aGlzLl9jb25maWcuaHRtbClyZXR1cm4gZS5pbm5lckhUTUw9XCJcIix2b2lkIGUuYXBwZW5kKHQpO2UudGV4dENvbnRlbnQ9dC50ZXh0Q29udGVudH19Y29uc3QgaXM9bmV3IFNldChbXCJzYW5pdGl6ZVwiLFwiYWxsb3dMaXN0XCIsXCJzYW5pdGl6ZUZuXCJdKSxucz1cImZhZGVcIixzcz1cInNob3dcIixvcz1cIi50b29sdGlwLWlubmVyXCIscnM9XCIubW9kYWxcIixhcz1cImhpZGUuYnMubW9kYWxcIixscz1cImhvdmVyXCIsY3M9XCJmb2N1c1wiLGhzPVwiY2xpY2tcIixkcz17QVVUTzpcImF1dG9cIixUT1A6XCJ0b3BcIixSSUdIVDptKCk/XCJsZWZ0XCI6XCJyaWdodFwiLEJPVFRPTTpcImJvdHRvbVwiLExFRlQ6bSgpP1wicmlnaHRcIjpcImxlZnRcIn0sdXM9e2FsbG93TGlzdDpYbixhbmltYXRpb246ITAsYm91bmRhcnk6XCJjbGlwcGluZ1BhcmVudHNcIixjb250YWluZXI6ITEsY3VzdG9tQ2xhc3M6XCJcIixkZWxheTowLGZhbGxiYWNrUGxhY2VtZW50czpbXCJ0b3BcIixcInJpZ2h0XCIsXCJib3R0b21cIixcImxlZnRcIl0saHRtbDohMSxvZmZzZXQ6WzAsNl0scGxhY2VtZW50OlwidG9wXCIscG9wcGVyQ29uZmlnOm51bGwsc2FuaXRpemU6ITAsc2FuaXRpemVGbjpudWxsLHNlbGVjdG9yOiExLHRlbXBsYXRlOic8ZGl2IGNsYXNzPVwidG9vbHRpcFwiIHJvbGU9XCJ0b29sdGlwXCI+PGRpdiBjbGFzcz1cInRvb2x0aXAtYXJyb3dcIj48L2Rpdj48ZGl2IGNsYXNzPVwidG9vbHRpcC1pbm5lclwiPjwvZGl2PjwvZGl2PicsdGl0bGU6XCJcIix0cmlnZ2VyOlwiaG92ZXIgZm9jdXNcIn0sZnM9e2FsbG93TGlzdDpcIm9iamVjdFwiLGFuaW1hdGlvbjpcImJvb2xlYW5cIixib3VuZGFyeTpcIihzdHJpbmd8ZWxlbWVudClcIixjb250YWluZXI6XCIoc3RyaW5nfGVsZW1lbnR8Ym9vbGVhbilcIixjdXN0b21DbGFzczpcIihzdHJpbmd8ZnVuY3Rpb24pXCIsZGVsYXk6XCIobnVtYmVyfG9iamVjdClcIixmYWxsYmFja1BsYWNlbWVudHM6XCJhcnJheVwiLGh0bWw6XCJib29sZWFuXCIsb2Zmc2V0OlwiKGFycmF5fHN0cmluZ3xmdW5jdGlvbilcIixwbGFjZW1lbnQ6XCIoc3RyaW5nfGZ1bmN0aW9uKVwiLHBvcHBlckNvbmZpZzpcIihudWxsfG9iamVjdHxmdW5jdGlvbilcIixzYW5pdGl6ZTpcImJvb2xlYW5cIixzYW5pdGl6ZUZuOlwiKG51bGx8ZnVuY3Rpb24pXCIsc2VsZWN0b3I6XCIoc3RyaW5nfGJvb2xlYW4pXCIsdGVtcGxhdGU6XCJzdHJpbmdcIix0aXRsZTpcIihzdHJpbmd8ZWxlbWVudHxmdW5jdGlvbilcIix0cmlnZ2VyOlwic3RyaW5nXCJ9O2NsYXNzIHBzIGV4dGVuZHMgQntjb25zdHJ1Y3Rvcih0LGUpe2lmKHZvaWQgMD09PUFpKXRocm93IG5ldyBUeXBlRXJyb3IoXCJCb290c3RyYXAncyB0b29sdGlwcyByZXF1aXJlIFBvcHBlciAoaHR0cHM6Ly9wb3BwZXIuanMub3JnL2RvY3MvdjIvKVwiKTtzdXBlcih0LGUpLHRoaXMuX2lzRW5hYmxlZD0hMCx0aGlzLl90aW1lb3V0PTAsdGhpcy5faXNIb3ZlcmVkPW51bGwsdGhpcy5fYWN0aXZlVHJpZ2dlcj17fSx0aGlzLl9wb3BwZXI9bnVsbCx0aGlzLl90ZW1wbGF0ZUZhY3Rvcnk9bnVsbCx0aGlzLl9uZXdDb250ZW50PW51bGwsdGhpcy50aXA9bnVsbCx0aGlzLl9zZXRMaXN0ZW5lcnMoKSx0aGlzLl9jb25maWcuc2VsZWN0b3J8fHRoaXMuX2ZpeFRpdGxlKCl9c3RhdGljIGdldCBEZWZhdWx0KCl7cmV0dXJuIHVzfXN0YXRpYyBnZXQgRGVmYXVsdFR5cGUoKXtyZXR1cm4gZnN9c3RhdGljIGdldCBOQU1FKCl7cmV0dXJuXCJ0b29sdGlwXCJ9ZW5hYmxlKCl7dGhpcy5faXNFbmFibGVkPSEwfWRpc2FibGUoKXt0aGlzLl9pc0VuYWJsZWQ9ITF9dG9nZ2xlRW5hYmxlZCgpe3RoaXMuX2lzRW5hYmxlZD0hdGhpcy5faXNFbmFibGVkfXRvZ2dsZSgpe3RoaXMuX2lzRW5hYmxlZCYmKHRoaXMuX2lzU2hvd24oKT90aGlzLl9sZWF2ZSgpOnRoaXMuX2VudGVyKCkpfWRpc3Bvc2UoKXtjbGVhclRpbWVvdXQodGhpcy5fdGltZW91dCksUC5vZmYodGhpcy5fZWxlbWVudC5jbG9zZXN0KHJzKSxhcyx0aGlzLl9oaWRlTW9kYWxIYW5kbGVyKSx0aGlzLl9lbGVtZW50LmdldEF0dHJpYnV0ZShcImRhdGEtYnMtb3JpZ2luYWwtdGl0bGVcIikmJnRoaXMuX2VsZW1lbnQuc2V0QXR0cmlidXRlKFwidGl0bGVcIix0aGlzLl9lbGVtZW50LmdldEF0dHJpYnV0ZShcImRhdGEtYnMtb3JpZ2luYWwtdGl0bGVcIikpLHRoaXMuX2Rpc3Bvc2VQb3BwZXIoKSxzdXBlci5kaXNwb3NlKCl9c2hvdygpe2lmKFwibm9uZVwiPT09dGhpcy5fZWxlbWVudC5zdHlsZS5kaXNwbGF5KXRocm93IG5ldyBFcnJvcihcIlBsZWFzZSB1c2Ugc2hvdyBvbiB2aXNpYmxlIGVsZW1lbnRzXCIpO2lmKCF0aGlzLl9pc1dpdGhDb250ZW50KCl8fCF0aGlzLl9pc0VuYWJsZWQpcmV0dXJuO2NvbnN0IHQ9UC50cmlnZ2VyKHRoaXMuX2VsZW1lbnQsdGhpcy5jb25zdHJ1Y3Rvci5ldmVudE5hbWUoXCJzaG93XCIpKSxlPShoKHRoaXMuX2VsZW1lbnQpfHx0aGlzLl9lbGVtZW50Lm93bmVyRG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50KS5jb250YWlucyh0aGlzLl9lbGVtZW50KTtpZih0LmRlZmF1bHRQcmV2ZW50ZWR8fCFlKXJldHVybjt0aGlzLl9kaXNwb3NlUG9wcGVyKCk7Y29uc3QgaT10aGlzLl9nZXRUaXBFbGVtZW50KCk7dGhpcy5fZWxlbWVudC5zZXRBdHRyaWJ1dGUoXCJhcmlhLWRlc2NyaWJlZGJ5XCIsaS5nZXRBdHRyaWJ1dGUoXCJpZFwiKSk7Y29uc3R7Y29udGFpbmVyOm59PXRoaXMuX2NvbmZpZztpZih0aGlzLl9lbGVtZW50Lm93bmVyRG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LmNvbnRhaW5zKHRoaXMudGlwKXx8KG4uYXBwZW5kKGkpLFAudHJpZ2dlcih0aGlzLl9lbGVtZW50LHRoaXMuY29uc3RydWN0b3IuZXZlbnROYW1lKFwiaW5zZXJ0ZWRcIikpKSx0aGlzLl9wb3BwZXI9dGhpcy5fY3JlYXRlUG9wcGVyKGkpLGkuY2xhc3NMaXN0LmFkZChzcyksXCJvbnRvdWNoc3RhcnRcImluIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudClmb3IoY29uc3QgdCBvZltdLmNvbmNhdCguLi5kb2N1bWVudC5ib2R5LmNoaWxkcmVuKSlQLm9uKHQsXCJtb3VzZW92ZXJcIixkKTt0aGlzLl9xdWV1ZUNhbGxiYWNrKCgpPT57UC50cmlnZ2VyKHRoaXMuX2VsZW1lbnQsdGhpcy5jb25zdHJ1Y3Rvci5ldmVudE5hbWUoXCJzaG93blwiKSksITE9PT10aGlzLl9pc0hvdmVyZWQmJnRoaXMuX2xlYXZlKCksdGhpcy5faXNIb3ZlcmVkPSExfSx0aGlzLnRpcCx0aGlzLl9pc0FuaW1hdGVkKCkpfWhpZGUoKXtpZih0aGlzLl9pc1Nob3duKCkmJiFQLnRyaWdnZXIodGhpcy5fZWxlbWVudCx0aGlzLmNvbnN0cnVjdG9yLmV2ZW50TmFtZShcImhpZGVcIikpLmRlZmF1bHRQcmV2ZW50ZWQpe2lmKHRoaXMuX2dldFRpcEVsZW1lbnQoKS5jbGFzc0xpc3QucmVtb3ZlKHNzKSxcIm9udG91Y2hzdGFydFwiaW4gZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50KWZvcihjb25zdCB0IG9mW10uY29uY2F0KC4uLmRvY3VtZW50LmJvZHkuY2hpbGRyZW4pKVAub2ZmKHQsXCJtb3VzZW92ZXJcIixkKTt0aGlzLl9hY3RpdmVUcmlnZ2VyW2hzXT0hMSx0aGlzLl9hY3RpdmVUcmlnZ2VyW2NzXT0hMSx0aGlzLl9hY3RpdmVUcmlnZ2VyW2xzXT0hMSx0aGlzLl9pc0hvdmVyZWQ9bnVsbCx0aGlzLl9xdWV1ZUNhbGxiYWNrKCgpPT57dGhpcy5faXNXaXRoQWN0aXZlVHJpZ2dlcigpfHwodGhpcy5faXNIb3ZlcmVkfHx0aGlzLl9kaXNwb3NlUG9wcGVyKCksdGhpcy5fZWxlbWVudC5yZW1vdmVBdHRyaWJ1dGUoXCJhcmlhLWRlc2NyaWJlZGJ5XCIpLFAudHJpZ2dlcih0aGlzLl9lbGVtZW50LHRoaXMuY29uc3RydWN0b3IuZXZlbnROYW1lKFwiaGlkZGVuXCIpKSl9LHRoaXMudGlwLHRoaXMuX2lzQW5pbWF0ZWQoKSl9fXVwZGF0ZSgpe3RoaXMuX3BvcHBlciYmdGhpcy5fcG9wcGVyLnVwZGF0ZSgpfV9pc1dpdGhDb250ZW50KCl7cmV0dXJuIEJvb2xlYW4odGhpcy5fZ2V0VGl0bGUoKSl9X2dldFRpcEVsZW1lbnQoKXtyZXR1cm4gdGhpcy50aXB8fCh0aGlzLnRpcD10aGlzLl9jcmVhdGVUaXBFbGVtZW50KHRoaXMuX25ld0NvbnRlbnR8fHRoaXMuX2dldENvbnRlbnRGb3JUZW1wbGF0ZSgpKSksdGhpcy50aXB9X2NyZWF0ZVRpcEVsZW1lbnQodCl7Y29uc3QgZT10aGlzLl9nZXRUZW1wbGF0ZUZhY3RvcnkodCkudG9IdG1sKCk7aWYoIWUpcmV0dXJuIG51bGw7ZS5jbGFzc0xpc3QucmVtb3ZlKG5zLHNzKSxlLmNsYXNzTGlzdC5hZGQoYGJzLSR7dGhpcy5jb25zdHJ1Y3Rvci5OQU1FfS1hdXRvYCk7Y29uc3QgaT0odD0+e2Rve3QrPU1hdGguZmxvb3IoMWU2Kk1hdGgucmFuZG9tKCkpfXdoaWxlKGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKHQpKTtyZXR1cm4gdH0pKHRoaXMuY29uc3RydWN0b3IuTkFNRSkudG9TdHJpbmcoKTtyZXR1cm4gZS5zZXRBdHRyaWJ1dGUoXCJpZFwiLGkpLHRoaXMuX2lzQW5pbWF0ZWQoKSYmZS5jbGFzc0xpc3QuYWRkKG5zKSxlfXNldENvbnRlbnQodCl7dGhpcy5fbmV3Q29udGVudD10LHRoaXMuX2lzU2hvd24oKSYmKHRoaXMuX2Rpc3Bvc2VQb3BwZXIoKSx0aGlzLnNob3coKSl9X2dldFRlbXBsYXRlRmFjdG9yeSh0KXtyZXR1cm4gdGhpcy5fdGVtcGxhdGVGYWN0b3J5P3RoaXMuX3RlbXBsYXRlRmFjdG9yeS5jaGFuZ2VDb250ZW50KHQpOnRoaXMuX3RlbXBsYXRlRmFjdG9yeT1uZXcgZXMoey4uLnRoaXMuX2NvbmZpZyxjb250ZW50OnQsZXh0cmFDbGFzczp0aGlzLl9yZXNvbHZlUG9zc2libGVGdW5jdGlvbih0aGlzLl9jb25maWcuY3VzdG9tQ2xhc3MpfSksdGhpcy5fdGVtcGxhdGVGYWN0b3J5fV9nZXRDb250ZW50Rm9yVGVtcGxhdGUoKXtyZXR1cm57W29zXTp0aGlzLl9nZXRUaXRsZSgpfX1fZ2V0VGl0bGUoKXtyZXR1cm4gdGhpcy5fcmVzb2x2ZVBvc3NpYmxlRnVuY3Rpb24odGhpcy5fY29uZmlnLnRpdGxlKXx8dGhpcy5fZWxlbWVudC5nZXRBdHRyaWJ1dGUoXCJkYXRhLWJzLW9yaWdpbmFsLXRpdGxlXCIpfV9pbml0aWFsaXplT25EZWxlZ2F0ZWRUYXJnZXQodCl7cmV0dXJuIHRoaXMuY29uc3RydWN0b3IuZ2V0T3JDcmVhdGVJbnN0YW5jZSh0LmRlbGVnYXRlVGFyZ2V0LHRoaXMuX2dldERlbGVnYXRlQ29uZmlnKCkpfV9pc0FuaW1hdGVkKCl7cmV0dXJuIHRoaXMuX2NvbmZpZy5hbmltYXRpb258fHRoaXMudGlwJiZ0aGlzLnRpcC5jbGFzc0xpc3QuY29udGFpbnMobnMpfV9pc1Nob3duKCl7cmV0dXJuIHRoaXMudGlwJiZ0aGlzLnRpcC5jbGFzc0xpc3QuY29udGFpbnMoc3MpfV9jcmVhdGVQb3BwZXIodCl7Y29uc3QgZT1fKHRoaXMuX2NvbmZpZy5wbGFjZW1lbnQsW3RoaXMsdCx0aGlzLl9lbGVtZW50XSksaT1kc1tlLnRvVXBwZXJDYXNlKCldO3JldHVybiB3aSh0aGlzLl9lbGVtZW50LHQsdGhpcy5fZ2V0UG9wcGVyQ29uZmlnKGkpKX1fZ2V0T2Zmc2V0KCl7Y29uc3R7b2Zmc2V0OnR9PXRoaXMuX2NvbmZpZztyZXR1cm5cInN0cmluZ1wiPT10eXBlb2YgdD90LnNwbGl0KFwiLFwiKS5tYXAodD0+TnVtYmVyLnBhcnNlSW50KHQsMTApKTpcImZ1bmN0aW9uXCI9PXR5cGVvZiB0P2U9PnQoZSx0aGlzLl9lbGVtZW50KTp0fV9yZXNvbHZlUG9zc2libGVGdW5jdGlvbih0KXtyZXR1cm4gXyh0LFt0aGlzLl9lbGVtZW50LHRoaXMuX2VsZW1lbnRdKX1fZ2V0UG9wcGVyQ29uZmlnKHQpe2NvbnN0IGU9e3BsYWNlbWVudDp0LG1vZGlmaWVyczpbe25hbWU6XCJmbGlwXCIsb3B0aW9uczp7ZmFsbGJhY2tQbGFjZW1lbnRzOnRoaXMuX2NvbmZpZy5mYWxsYmFja1BsYWNlbWVudHN9fSx7bmFtZTpcIm9mZnNldFwiLG9wdGlvbnM6e29mZnNldDp0aGlzLl9nZXRPZmZzZXQoKX19LHtuYW1lOlwicHJldmVudE92ZXJmbG93XCIsb3B0aW9uczp7Ym91bmRhcnk6dGhpcy5fY29uZmlnLmJvdW5kYXJ5fX0se25hbWU6XCJhcnJvd1wiLG9wdGlvbnM6e2VsZW1lbnQ6YC4ke3RoaXMuY29uc3RydWN0b3IuTkFNRX0tYXJyb3dgfX0se25hbWU6XCJwcmVTZXRQbGFjZW1lbnRcIixlbmFibGVkOiEwLHBoYXNlOlwiYmVmb3JlTWFpblwiLGZuOnQ9Pnt0aGlzLl9nZXRUaXBFbGVtZW50KCkuc2V0QXR0cmlidXRlKFwiZGF0YS1wb3BwZXItcGxhY2VtZW50XCIsdC5zdGF0ZS5wbGFjZW1lbnQpfX1dfTtyZXR1cm57Li4uZSwuLi5fKHRoaXMuX2NvbmZpZy5wb3BwZXJDb25maWcsW3ZvaWQgMCxlXSl9fV9zZXRMaXN0ZW5lcnMoKXtjb25zdCB0PXRoaXMuX2NvbmZpZy50cmlnZ2VyLnNwbGl0KFwiIFwiKTtmb3IoY29uc3QgZSBvZiB0KWlmKFwiY2xpY2tcIj09PWUpUC5vbih0aGlzLl9lbGVtZW50LHRoaXMuY29uc3RydWN0b3IuZXZlbnROYW1lKFwiY2xpY2tcIiksdGhpcy5fY29uZmlnLnNlbGVjdG9yLHQ9Pntjb25zdCBlPXRoaXMuX2luaXRpYWxpemVPbkRlbGVnYXRlZFRhcmdldCh0KTtlLl9hY3RpdmVUcmlnZ2VyW2hzXT0hKGUuX2lzU2hvd24oKSYmZS5fYWN0aXZlVHJpZ2dlcltoc10pLGUudG9nZ2xlKCl9KTtlbHNlIGlmKFwibWFudWFsXCIhPT1lKXtjb25zdCB0PWU9PT1scz90aGlzLmNvbnN0cnVjdG9yLmV2ZW50TmFtZShcIm1vdXNlZW50ZXJcIik6dGhpcy5jb25zdHJ1Y3Rvci5ldmVudE5hbWUoXCJmb2N1c2luXCIpLGk9ZT09PWxzP3RoaXMuY29uc3RydWN0b3IuZXZlbnROYW1lKFwibW91c2VsZWF2ZVwiKTp0aGlzLmNvbnN0cnVjdG9yLmV2ZW50TmFtZShcImZvY3Vzb3V0XCIpO1Aub24odGhpcy5fZWxlbWVudCx0LHRoaXMuX2NvbmZpZy5zZWxlY3Rvcix0PT57Y29uc3QgZT10aGlzLl9pbml0aWFsaXplT25EZWxlZ2F0ZWRUYXJnZXQodCk7ZS5fYWN0aXZlVHJpZ2dlcltcImZvY3VzaW5cIj09PXQudHlwZT9jczpsc109ITAsZS5fZW50ZXIoKX0pLFAub24odGhpcy5fZWxlbWVudCxpLHRoaXMuX2NvbmZpZy5zZWxlY3Rvcix0PT57Y29uc3QgZT10aGlzLl9pbml0aWFsaXplT25EZWxlZ2F0ZWRUYXJnZXQodCk7ZS5fYWN0aXZlVHJpZ2dlcltcImZvY3Vzb3V0XCI9PT10LnR5cGU/Y3M6bHNdPWUuX2VsZW1lbnQuY29udGFpbnModC5yZWxhdGVkVGFyZ2V0KSxlLl9sZWF2ZSgpfSl9dGhpcy5faGlkZU1vZGFsSGFuZGxlcj0oKT0+e3RoaXMuX2VsZW1lbnQmJnRoaXMuaGlkZSgpfSxQLm9uKHRoaXMuX2VsZW1lbnQuY2xvc2VzdChycyksYXMsdGhpcy5faGlkZU1vZGFsSGFuZGxlcil9X2ZpeFRpdGxlKCl7Y29uc3QgdD10aGlzLl9lbGVtZW50LmdldEF0dHJpYnV0ZShcInRpdGxlXCIpO3QmJih0aGlzLl9lbGVtZW50LmdldEF0dHJpYnV0ZShcImFyaWEtbGFiZWxcIil8fHRoaXMuX2VsZW1lbnQudGV4dENvbnRlbnQudHJpbSgpfHx0aGlzLl9lbGVtZW50LnNldEF0dHJpYnV0ZShcImFyaWEtbGFiZWxcIix0KSx0aGlzLl9lbGVtZW50LnNldEF0dHJpYnV0ZShcImRhdGEtYnMtb3JpZ2luYWwtdGl0bGVcIix0KSx0aGlzLl9lbGVtZW50LnJlbW92ZUF0dHJpYnV0ZShcInRpdGxlXCIpKX1fZW50ZXIoKXt0aGlzLl9pc1Nob3duKCl8fHRoaXMuX2lzSG92ZXJlZD90aGlzLl9pc0hvdmVyZWQ9ITA6KHRoaXMuX2lzSG92ZXJlZD0hMCx0aGlzLl9zZXRUaW1lb3V0KCgpPT57dGhpcy5faXNIb3ZlcmVkJiZ0aGlzLnNob3coKX0sdGhpcy5fY29uZmlnLmRlbGF5LnNob3cpKX1fbGVhdmUoKXt0aGlzLl9pc1dpdGhBY3RpdmVUcmlnZ2VyKCl8fCh0aGlzLl9pc0hvdmVyZWQ9ITEsdGhpcy5fc2V0VGltZW91dCgoKT0+e3RoaXMuX2lzSG92ZXJlZHx8dGhpcy5oaWRlKCl9LHRoaXMuX2NvbmZpZy5kZWxheS5oaWRlKSl9X3NldFRpbWVvdXQodCxlKXtjbGVhclRpbWVvdXQodGhpcy5fdGltZW91dCksdGhpcy5fdGltZW91dD1zZXRUaW1lb3V0KHQsZSl9X2lzV2l0aEFjdGl2ZVRyaWdnZXIoKXtyZXR1cm4gT2JqZWN0LnZhbHVlcyh0aGlzLl9hY3RpdmVUcmlnZ2VyKS5pbmNsdWRlcyghMCl9X2dldENvbmZpZyh0KXtjb25zdCBlPUguZ2V0RGF0YUF0dHJpYnV0ZXModGhpcy5fZWxlbWVudCk7Zm9yKGNvbnN0IHQgb2YgT2JqZWN0LmtleXMoZSkpaXMuaGFzKHQpJiZkZWxldGUgZVt0XTtyZXR1cm4gdD17Li4uZSwuLi5cIm9iamVjdFwiPT10eXBlb2YgdCYmdD90Ont9fSx0PXRoaXMuX21lcmdlQ29uZmlnT2JqKHQpLHQ9dGhpcy5fY29uZmlnQWZ0ZXJNZXJnZSh0KSx0aGlzLl90eXBlQ2hlY2tDb25maWcodCksdH1fY29uZmlnQWZ0ZXJNZXJnZSh0KXtyZXR1cm4gdC5jb250YWluZXI9ITE9PT10LmNvbnRhaW5lcj9kb2N1bWVudC5ib2R5OmEodC5jb250YWluZXIpLFwibnVtYmVyXCI9PXR5cGVvZiB0LmRlbGF5JiYodC5kZWxheT17c2hvdzp0LmRlbGF5LGhpZGU6dC5kZWxheX0pLFwibnVtYmVyXCI9PXR5cGVvZiB0LnRpdGxlJiYodC50aXRsZT10LnRpdGxlLnRvU3RyaW5nKCkpLFwibnVtYmVyXCI9PXR5cGVvZiB0LmNvbnRlbnQmJih0LmNvbnRlbnQ9dC5jb250ZW50LnRvU3RyaW5nKCkpLHR9X2dldERlbGVnYXRlQ29uZmlnKCl7Y29uc3QgdD17fTtmb3IoY29uc3RbZSxpXW9mIE9iamVjdC5lbnRyaWVzKHRoaXMuX2NvbmZpZykpdGhpcy5jb25zdHJ1Y3Rvci5EZWZhdWx0W2VdIT09aSYmKHRbZV09aSk7cmV0dXJuIHQuc2VsZWN0b3I9ITEsdC50cmlnZ2VyPVwibWFudWFsXCIsdH1fZGlzcG9zZVBvcHBlcigpe3RoaXMuX3BvcHBlciYmKHRoaXMuX3BvcHBlci5kZXN0cm95KCksdGhpcy5fcG9wcGVyPW51bGwpLHRoaXMudGlwJiYodGhpcy50aXAucmVtb3ZlKCksdGhpcy50aXA9bnVsbCl9c3RhdGljIGpRdWVyeUludGVyZmFjZSh0KXtyZXR1cm4gdGhpcy5lYWNoKGZ1bmN0aW9uKCl7Y29uc3QgZT1wcy5nZXRPckNyZWF0ZUluc3RhbmNlKHRoaXMsdCk7aWYoXCJzdHJpbmdcIj09dHlwZW9mIHQpe2lmKHZvaWQgMD09PWVbdF0pdGhyb3cgbmV3IFR5cGVFcnJvcihgTm8gbWV0aG9kIG5hbWVkIFwiJHt0fVwiYCk7ZVt0XSgpfX0pfX1nKHBzKTtjb25zdCBtcz1cIi5wb3BvdmVyLWhlYWRlclwiLGdzPVwiLnBvcG92ZXItYm9keVwiLF9zPXsuLi5wcy5EZWZhdWx0LGNvbnRlbnQ6XCJcIixvZmZzZXQ6WzAsOF0scGxhY2VtZW50OlwicmlnaHRcIix0ZW1wbGF0ZTonPGRpdiBjbGFzcz1cInBvcG92ZXJcIiByb2xlPVwidG9vbHRpcFwiPjxkaXYgY2xhc3M9XCJwb3BvdmVyLWFycm93XCI+PC9kaXY+PGgzIGNsYXNzPVwicG9wb3Zlci1oZWFkZXJcIj48L2gzPjxkaXYgY2xhc3M9XCJwb3BvdmVyLWJvZHlcIj48L2Rpdj48L2Rpdj4nLHRyaWdnZXI6XCJjbGlja1wifSxicz17Li4ucHMuRGVmYXVsdFR5cGUsY29udGVudDpcIihudWxsfHN0cmluZ3xlbGVtZW50fGZ1bmN0aW9uKVwifTtjbGFzcyB2cyBleHRlbmRzIHBze3N0YXRpYyBnZXQgRGVmYXVsdCgpe3JldHVybiBfc31zdGF0aWMgZ2V0IERlZmF1bHRUeXBlKCl7cmV0dXJuIGJzfXN0YXRpYyBnZXQgTkFNRSgpe3JldHVyblwicG9wb3ZlclwifV9pc1dpdGhDb250ZW50KCl7cmV0dXJuIHRoaXMuX2dldFRpdGxlKCl8fHRoaXMuX2dldENvbnRlbnQoKX1fZ2V0Q29udGVudEZvclRlbXBsYXRlKCl7cmV0dXJue1ttc106dGhpcy5fZ2V0VGl0bGUoKSxbZ3NdOnRoaXMuX2dldENvbnRlbnQoKX19X2dldENvbnRlbnQoKXtyZXR1cm4gdGhpcy5fcmVzb2x2ZVBvc3NpYmxlRnVuY3Rpb24odGhpcy5fY29uZmlnLmNvbnRlbnQpfXN0YXRpYyBqUXVlcnlJbnRlcmZhY2UodCl7cmV0dXJuIHRoaXMuZWFjaChmdW5jdGlvbigpe2NvbnN0IGU9dnMuZ2V0T3JDcmVhdGVJbnN0YW5jZSh0aGlzLHQpO2lmKFwic3RyaW5nXCI9PXR5cGVvZiB0KXtpZih2b2lkIDA9PT1lW3RdKXRocm93IG5ldyBUeXBlRXJyb3IoYE5vIG1ldGhvZCBuYW1lZCBcIiR7dH1cImApO2VbdF0oKX19KX19Zyh2cyk7Y29uc3QgeXM9XCIuYnMuc2Nyb2xsc3B5XCIsd3M9YGFjdGl2YXRlJHt5c31gLEFzPWBjbGljayR7eXN9YCxFcz1gbG9hZCR7eXN9LmRhdGEtYXBpYCxUcz1cImFjdGl2ZVwiLENzPVwiW2hyZWZdXCIsT3M9XCIubmF2LWxpbmtcIix4cz1gJHtPc30sIC5uYXYtaXRlbSA+ICR7T3N9LCAubGlzdC1ncm91cC1pdGVtYCxrcz17b2Zmc2V0Om51bGwscm9vdE1hcmdpbjpcIjBweCAwcHggLTI1JVwiLHNtb290aFNjcm9sbDohMSx0YXJnZXQ6bnVsbCx0aHJlc2hvbGQ6Wy4xLC41LDFdfSxMcz17b2Zmc2V0OlwiKG51bWJlcnxudWxsKVwiLHJvb3RNYXJnaW46XCJzdHJpbmdcIixzbW9vdGhTY3JvbGw6XCJib29sZWFuXCIsdGFyZ2V0OlwiZWxlbWVudFwiLHRocmVzaG9sZDpcImFycmF5XCJ9O2NsYXNzIFNzIGV4dGVuZHMgQntjb25zdHJ1Y3Rvcih0LGUpe3N1cGVyKHQsZSksdGhpcy5fdGFyZ2V0TGlua3M9bmV3IE1hcCx0aGlzLl9vYnNlcnZhYmxlU2VjdGlvbnM9bmV3IE1hcCx0aGlzLl9yb290RWxlbWVudD1cInZpc2libGVcIj09PWdldENvbXB1dGVkU3R5bGUodGhpcy5fZWxlbWVudCkub3ZlcmZsb3dZP251bGw6dGhpcy5fZWxlbWVudCx0aGlzLl9hY3RpdmVUYXJnZXQ9bnVsbCx0aGlzLl9vYnNlcnZlcj1udWxsLHRoaXMuX3ByZXZpb3VzU2Nyb2xsRGF0YT17dmlzaWJsZUVudHJ5VG9wOjAscGFyZW50U2Nyb2xsVG9wOjB9LHRoaXMucmVmcmVzaCgpfXN0YXRpYyBnZXQgRGVmYXVsdCgpe3JldHVybiBrc31zdGF0aWMgZ2V0IERlZmF1bHRUeXBlKCl7cmV0dXJuIExzfXN0YXRpYyBnZXQgTkFNRSgpe3JldHVyblwic2Nyb2xsc3B5XCJ9cmVmcmVzaCgpe3RoaXMuX2luaXRpYWxpemVUYXJnZXRzQW5kT2JzZXJ2YWJsZXMoKSx0aGlzLl9tYXliZUVuYWJsZVNtb290aFNjcm9sbCgpLHRoaXMuX29ic2VydmVyP3RoaXMuX29ic2VydmVyLmRpc2Nvbm5lY3QoKTp0aGlzLl9vYnNlcnZlcj10aGlzLl9nZXROZXdPYnNlcnZlcigpO2Zvcihjb25zdCB0IG9mIHRoaXMuX29ic2VydmFibGVTZWN0aW9ucy52YWx1ZXMoKSl0aGlzLl9vYnNlcnZlci5vYnNlcnZlKHQpfWRpc3Bvc2UoKXt0aGlzLl9vYnNlcnZlci5kaXNjb25uZWN0KCksc3VwZXIuZGlzcG9zZSgpfV9jb25maWdBZnRlck1lcmdlKHQpe3JldHVybiB0LnRhcmdldD1hKHQudGFyZ2V0KXx8ZG9jdW1lbnQuYm9keSx0LnJvb3RNYXJnaW49dC5vZmZzZXQ/YCR7dC5vZmZzZXR9cHggMHB4IC0zMCVgOnQucm9vdE1hcmdpbixcInN0cmluZ1wiPT10eXBlb2YgdC50aHJlc2hvbGQmJih0LnRocmVzaG9sZD10LnRocmVzaG9sZC5zcGxpdChcIixcIikubWFwKHQ9Pk51bWJlci5wYXJzZUZsb2F0KHQpKSksdH1fbWF5YmVFbmFibGVTbW9vdGhTY3JvbGwoKXt0aGlzLl9jb25maWcuc21vb3RoU2Nyb2xsJiYoUC5vZmYodGhpcy5fY29uZmlnLnRhcmdldCxBcyksUC5vbih0aGlzLl9jb25maWcudGFyZ2V0LEFzLENzLHQ9Pntjb25zdCBlPXRoaXMuX29ic2VydmFibGVTZWN0aW9ucy5nZXQodC50YXJnZXQuaGFzaCk7aWYoZSl7dC5wcmV2ZW50RGVmYXVsdCgpO2NvbnN0IGk9dGhpcy5fcm9vdEVsZW1lbnR8fHdpbmRvdyxuPWUub2Zmc2V0VG9wLXRoaXMuX2VsZW1lbnQub2Zmc2V0VG9wO2lmKGkuc2Nyb2xsVG8pcmV0dXJuIHZvaWQgaS5zY3JvbGxUbyh7dG9wOm4sYmVoYXZpb3I6XCJzbW9vdGhcIn0pO2kuc2Nyb2xsVG9wPW59fSkpfV9nZXROZXdPYnNlcnZlcigpe2NvbnN0IHQ9e3Jvb3Q6dGhpcy5fcm9vdEVsZW1lbnQsdGhyZXNob2xkOnRoaXMuX2NvbmZpZy50aHJlc2hvbGQscm9vdE1hcmdpbjp0aGlzLl9jb25maWcucm9vdE1hcmdpbn07cmV0dXJuIG5ldyBJbnRlcnNlY3Rpb25PYnNlcnZlcih0PT50aGlzLl9vYnNlcnZlckNhbGxiYWNrKHQpLHQpfV9vYnNlcnZlckNhbGxiYWNrKHQpe2NvbnN0IGU9dD0+dGhpcy5fdGFyZ2V0TGlua3MuZ2V0KGAjJHt0LnRhcmdldC5pZH1gKSxpPXQ9Pnt0aGlzLl9wcmV2aW91c1Njcm9sbERhdGEudmlzaWJsZUVudHJ5VG9wPXQudGFyZ2V0Lm9mZnNldFRvcCx0aGlzLl9wcm9jZXNzKGUodCkpfSxuPSh0aGlzLl9yb290RWxlbWVudHx8ZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50KS5zY3JvbGxUb3Ascz1uPj10aGlzLl9wcmV2aW91c1Njcm9sbERhdGEucGFyZW50U2Nyb2xsVG9wO3RoaXMuX3ByZXZpb3VzU2Nyb2xsRGF0YS5wYXJlbnRTY3JvbGxUb3A9bjtmb3IoY29uc3QgbyBvZiB0KXtpZighby5pc0ludGVyc2VjdGluZyl7dGhpcy5fYWN0aXZlVGFyZ2V0PW51bGwsdGhpcy5fY2xlYXJBY3RpdmVDbGFzcyhlKG8pKTtjb250aW51ZX1jb25zdCB0PW8udGFyZ2V0Lm9mZnNldFRvcD49dGhpcy5fcHJldmlvdXNTY3JvbGxEYXRhLnZpc2libGVFbnRyeVRvcDtpZihzJiZ0KXtpZihpKG8pLCFuKXJldHVybn1lbHNlIHN8fHR8fGkobyl9fV9pbml0aWFsaXplVGFyZ2V0c0FuZE9ic2VydmFibGVzKCl7dGhpcy5fdGFyZ2V0TGlua3M9bmV3IE1hcCx0aGlzLl9vYnNlcnZhYmxlU2VjdGlvbnM9bmV3IE1hcDtjb25zdCB0PVIuZmluZChDcyx0aGlzLl9jb25maWcudGFyZ2V0KTtmb3IoY29uc3QgZSBvZiB0KXtpZighZS5oYXNofHxjKGUpKWNvbnRpbnVlO2NvbnN0IHQ9Ui5maW5kT25lKGRlY29kZVVSSShlLmhhc2gpLHRoaXMuX2VsZW1lbnQpO2wodCkmJih0aGlzLl90YXJnZXRMaW5rcy5zZXQoZGVjb2RlVVJJKGUuaGFzaCksZSksdGhpcy5fb2JzZXJ2YWJsZVNlY3Rpb25zLnNldChlLmhhc2gsdCkpfX1fcHJvY2Vzcyh0KXt0aGlzLl9hY3RpdmVUYXJnZXQhPT10JiYodGhpcy5fY2xlYXJBY3RpdmVDbGFzcyh0aGlzLl9jb25maWcudGFyZ2V0KSx0aGlzLl9hY3RpdmVUYXJnZXQ9dCx0LmNsYXNzTGlzdC5hZGQoVHMpLHRoaXMuX2FjdGl2YXRlUGFyZW50cyh0KSxQLnRyaWdnZXIodGhpcy5fZWxlbWVudCx3cyx7cmVsYXRlZFRhcmdldDp0fSkpfV9hY3RpdmF0ZVBhcmVudHModCl7aWYodC5jbGFzc0xpc3QuY29udGFpbnMoXCJkcm9wZG93bi1pdGVtXCIpKVIuZmluZE9uZShcIi5kcm9wZG93bi10b2dnbGVcIix0LmNsb3Nlc3QoXCIuZHJvcGRvd25cIikpLmNsYXNzTGlzdC5hZGQoVHMpO2Vsc2UgZm9yKGNvbnN0IGUgb2YgUi5wYXJlbnRzKHQsXCIubmF2LCAubGlzdC1ncm91cFwiKSlmb3IoY29uc3QgdCBvZiBSLnByZXYoZSx4cykpdC5jbGFzc0xpc3QuYWRkKFRzKX1fY2xlYXJBY3RpdmVDbGFzcyh0KXt0LmNsYXNzTGlzdC5yZW1vdmUoVHMpO2NvbnN0IGU9Ui5maW5kKGAke0NzfS4ke1RzfWAsdCk7Zm9yKGNvbnN0IHQgb2YgZSl0LmNsYXNzTGlzdC5yZW1vdmUoVHMpfXN0YXRpYyBqUXVlcnlJbnRlcmZhY2UodCl7cmV0dXJuIHRoaXMuZWFjaChmdW5jdGlvbigpe2NvbnN0IGU9U3MuZ2V0T3JDcmVhdGVJbnN0YW5jZSh0aGlzLHQpO2lmKFwic3RyaW5nXCI9PXR5cGVvZiB0KXtpZih2b2lkIDA9PT1lW3RdfHx0LnN0YXJ0c1dpdGgoXCJfXCIpfHxcImNvbnN0cnVjdG9yXCI9PT10KXRocm93IG5ldyBUeXBlRXJyb3IoYE5vIG1ldGhvZCBuYW1lZCBcIiR7dH1cImApO2VbdF0oKX19KX19UC5vbih3aW5kb3csRXMsKCk9Pntmb3IoY29uc3QgdCBvZiBSLmZpbmQoJ1tkYXRhLWJzLXNweT1cInNjcm9sbFwiXScpKVNzLmdldE9yQ3JlYXRlSW5zdGFuY2UodCl9KSxnKFNzKTtjb25zdCBEcz1cIi5icy50YWJcIiwkcz1gaGlkZSR7RHN9YCxJcz1gaGlkZGVuJHtEc31gLE5zPWBzaG93JHtEc31gLFBzPWBzaG93biR7RHN9YCxqcz1gY2xpY2ske0RzfWAsTXM9YGtleWRvd24ke0RzfWAsRnM9YGxvYWQke0RzfWAsSHM9XCJBcnJvd0xlZnRcIixXcz1cIkFycm93UmlnaHRcIixCcz1cIkFycm93VXBcIix6cz1cIkFycm93RG93blwiLFJzPVwiSG9tZVwiLHFzPVwiRW5kXCIsVnM9XCJhY3RpdmVcIixLcz1cImZhZGVcIixRcz1cInNob3dcIixYcz1cIi5kcm9wZG93bi10b2dnbGVcIixZcz1gOm5vdCgke1hzfSlgLFVzPSdbZGF0YS1icy10b2dnbGU9XCJ0YWJcIl0sIFtkYXRhLWJzLXRvZ2dsZT1cInBpbGxcIl0sIFtkYXRhLWJzLXRvZ2dsZT1cImxpc3RcIl0nLEdzPWAubmF2LWxpbmske1lzfSwgLmxpc3QtZ3JvdXAtaXRlbSR7WXN9LCBbcm9sZT1cInRhYlwiXSR7WXN9LCAke1VzfWAsSnM9YC4ke1ZzfVtkYXRhLWJzLXRvZ2dsZT1cInRhYlwiXSwgLiR7VnN9W2RhdGEtYnMtdG9nZ2xlPVwicGlsbFwiXSwgLiR7VnN9W2RhdGEtYnMtdG9nZ2xlPVwibGlzdFwiXWA7Y2xhc3MgWnMgZXh0ZW5kcyBCe2NvbnN0cnVjdG9yKHQpe3N1cGVyKHQpLHRoaXMuX3BhcmVudD10aGlzLl9lbGVtZW50LmNsb3Nlc3QoJy5saXN0LWdyb3VwLCAubmF2LCBbcm9sZT1cInRhYmxpc3RcIl0nKSx0aGlzLl9wYXJlbnQmJih0aGlzLl9zZXRJbml0aWFsQXR0cmlidXRlcyh0aGlzLl9wYXJlbnQsdGhpcy5fZ2V0Q2hpbGRyZW4oKSksUC5vbih0aGlzLl9lbGVtZW50LE1zLHQ9PnRoaXMuX2tleWRvd24odCkpKX1zdGF0aWMgZ2V0IE5BTUUoKXtyZXR1cm5cInRhYlwifXNob3coKXtjb25zdCB0PXRoaXMuX2VsZW1lbnQ7aWYodGhpcy5fZWxlbUlzQWN0aXZlKHQpKXJldHVybjtjb25zdCBlPXRoaXMuX2dldEFjdGl2ZUVsZW0oKSxpPWU/UC50cmlnZ2VyKGUsJHMse3JlbGF0ZWRUYXJnZXQ6dH0pOm51bGw7UC50cmlnZ2VyKHQsTnMse3JlbGF0ZWRUYXJnZXQ6ZX0pLmRlZmF1bHRQcmV2ZW50ZWR8fGkmJmkuZGVmYXVsdFByZXZlbnRlZHx8KHRoaXMuX2RlYWN0aXZhdGUoZSx0KSx0aGlzLl9hY3RpdmF0ZSh0LGUpKX1fYWN0aXZhdGUodCxlKXt0JiYodC5jbGFzc0xpc3QuYWRkKFZzKSx0aGlzLl9hY3RpdmF0ZShSLmdldEVsZW1lbnRGcm9tU2VsZWN0b3IodCkpLHRoaXMuX3F1ZXVlQ2FsbGJhY2soKCk9PntcInRhYlwiPT09dC5nZXRBdHRyaWJ1dGUoXCJyb2xlXCIpPyh0LnJlbW92ZUF0dHJpYnV0ZShcInRhYmluZGV4XCIpLHQuc2V0QXR0cmlidXRlKFwiYXJpYS1zZWxlY3RlZFwiLCEwKSx0aGlzLl90b2dnbGVEcm9wRG93bih0LCEwKSxQLnRyaWdnZXIodCxQcyx7cmVsYXRlZFRhcmdldDplfSkpOnQuY2xhc3NMaXN0LmFkZChRcyl9LHQsdC5jbGFzc0xpc3QuY29udGFpbnMoS3MpKSl9X2RlYWN0aXZhdGUodCxlKXt0JiYodC5jbGFzc0xpc3QucmVtb3ZlKFZzKSx0LmJsdXIoKSx0aGlzLl9kZWFjdGl2YXRlKFIuZ2V0RWxlbWVudEZyb21TZWxlY3Rvcih0KSksdGhpcy5fcXVldWVDYWxsYmFjaygoKT0+e1widGFiXCI9PT10LmdldEF0dHJpYnV0ZShcInJvbGVcIik/KHQuc2V0QXR0cmlidXRlKFwiYXJpYS1zZWxlY3RlZFwiLCExKSx0LnNldEF0dHJpYnV0ZShcInRhYmluZGV4XCIsXCItMVwiKSx0aGlzLl90b2dnbGVEcm9wRG93bih0LCExKSxQLnRyaWdnZXIodCxJcyx7cmVsYXRlZFRhcmdldDplfSkpOnQuY2xhc3NMaXN0LnJlbW92ZShRcyl9LHQsdC5jbGFzc0xpc3QuY29udGFpbnMoS3MpKSl9X2tleWRvd24odCl7aWYoIVtIcyxXcyxCcyx6cyxScyxxc10uaW5jbHVkZXModC5rZXkpKXJldHVybjt0LnN0b3BQcm9wYWdhdGlvbigpLHQucHJldmVudERlZmF1bHQoKTtjb25zdCBlPXRoaXMuX2dldENoaWxkcmVuKCkuZmlsdGVyKHQ9PiFjKHQpKTtsZXQgaTtpZihbUnMscXNdLmluY2x1ZGVzKHQua2V5KSlpPWVbdC5rZXk9PT1Scz8wOmUubGVuZ3RoLTFdO2Vsc2V7Y29uc3Qgbj1bV3MsenNdLmluY2x1ZGVzKHQua2V5KTtpPXYoZSx0LnRhcmdldCxuLCEwKX1pJiYoaS5mb2N1cyh7cHJldmVudFNjcm9sbDohMH0pLFpzLmdldE9yQ3JlYXRlSW5zdGFuY2UoaSkuc2hvdygpKX1fZ2V0Q2hpbGRyZW4oKXtyZXR1cm4gUi5maW5kKEdzLHRoaXMuX3BhcmVudCl9X2dldEFjdGl2ZUVsZW0oKXtyZXR1cm4gdGhpcy5fZ2V0Q2hpbGRyZW4oKS5maW5kKHQ9PnRoaXMuX2VsZW1Jc0FjdGl2ZSh0KSl8fG51bGx9X3NldEluaXRpYWxBdHRyaWJ1dGVzKHQsZSl7dGhpcy5fc2V0QXR0cmlidXRlSWZOb3RFeGlzdHModCxcInJvbGVcIixcInRhYmxpc3RcIik7Zm9yKGNvbnN0IHQgb2YgZSl0aGlzLl9zZXRJbml0aWFsQXR0cmlidXRlc09uQ2hpbGQodCl9X3NldEluaXRpYWxBdHRyaWJ1dGVzT25DaGlsZCh0KXt0PXRoaXMuX2dldElubmVyRWxlbWVudCh0KTtjb25zdCBlPXRoaXMuX2VsZW1Jc0FjdGl2ZSh0KSxpPXRoaXMuX2dldE91dGVyRWxlbWVudCh0KTt0LnNldEF0dHJpYnV0ZShcImFyaWEtc2VsZWN0ZWRcIixlKSxpIT09dCYmdGhpcy5fc2V0QXR0cmlidXRlSWZOb3RFeGlzdHMoaSxcInJvbGVcIixcInByZXNlbnRhdGlvblwiKSxlfHx0LnNldEF0dHJpYnV0ZShcInRhYmluZGV4XCIsXCItMVwiKSx0aGlzLl9zZXRBdHRyaWJ1dGVJZk5vdEV4aXN0cyh0LFwicm9sZVwiLFwidGFiXCIpLHRoaXMuX3NldEluaXRpYWxBdHRyaWJ1dGVzT25UYXJnZXRQYW5lbCh0KX1fc2V0SW5pdGlhbEF0dHJpYnV0ZXNPblRhcmdldFBhbmVsKHQpe2NvbnN0IGU9Ui5nZXRFbGVtZW50RnJvbVNlbGVjdG9yKHQpO2UmJih0aGlzLl9zZXRBdHRyaWJ1dGVJZk5vdEV4aXN0cyhlLFwicm9sZVwiLFwidGFicGFuZWxcIiksdC5pZCYmdGhpcy5fc2V0QXR0cmlidXRlSWZOb3RFeGlzdHMoZSxcImFyaWEtbGFiZWxsZWRieVwiLGAke3QuaWR9YCkpfV90b2dnbGVEcm9wRG93bih0LGUpe2NvbnN0IGk9dGhpcy5fZ2V0T3V0ZXJFbGVtZW50KHQpO2lmKCFpLmNsYXNzTGlzdC5jb250YWlucyhcImRyb3Bkb3duXCIpKXJldHVybjtjb25zdCBuPSh0LG4pPT57Y29uc3Qgcz1SLmZpbmRPbmUodCxpKTtzJiZzLmNsYXNzTGlzdC50b2dnbGUobixlKX07bihYcyxWcyksbihcIi5kcm9wZG93bi1tZW51XCIsUXMpLGkuc2V0QXR0cmlidXRlKFwiYXJpYS1leHBhbmRlZFwiLGUpfV9zZXRBdHRyaWJ1dGVJZk5vdEV4aXN0cyh0LGUsaSl7dC5oYXNBdHRyaWJ1dGUoZSl8fHQuc2V0QXR0cmlidXRlKGUsaSl9X2VsZW1Jc0FjdGl2ZSh0KXtyZXR1cm4gdC5jbGFzc0xpc3QuY29udGFpbnMoVnMpfV9nZXRJbm5lckVsZW1lbnQodCl7cmV0dXJuIHQubWF0Y2hlcyhHcyk/dDpSLmZpbmRPbmUoR3MsdCl9X2dldE91dGVyRWxlbWVudCh0KXtyZXR1cm4gdC5jbG9zZXN0KFwiLm5hdi1pdGVtLCAubGlzdC1ncm91cC1pdGVtXCIpfHx0fXN0YXRpYyBqUXVlcnlJbnRlcmZhY2UodCl7cmV0dXJuIHRoaXMuZWFjaChmdW5jdGlvbigpe2NvbnN0IGU9WnMuZ2V0T3JDcmVhdGVJbnN0YW5jZSh0aGlzKTtpZihcInN0cmluZ1wiPT10eXBlb2YgdCl7aWYodm9pZCAwPT09ZVt0XXx8dC5zdGFydHNXaXRoKFwiX1wiKXx8XCJjb25zdHJ1Y3RvclwiPT09dCl0aHJvdyBuZXcgVHlwZUVycm9yKGBObyBtZXRob2QgbmFtZWQgXCIke3R9XCJgKTtlW3RdKCl9fSl9fVAub24oZG9jdW1lbnQsanMsVXMsZnVuY3Rpb24odCl7W1wiQVwiLFwiQVJFQVwiXS5pbmNsdWRlcyh0aGlzLnRhZ05hbWUpJiZ0LnByZXZlbnREZWZhdWx0KCksYyh0aGlzKXx8WnMuZ2V0T3JDcmVhdGVJbnN0YW5jZSh0aGlzKS5zaG93KCl9KSxQLm9uKHdpbmRvdyxGcywoKT0+e2Zvcihjb25zdCB0IG9mIFIuZmluZChKcykpWnMuZ2V0T3JDcmVhdGVJbnN0YW5jZSh0KX0pLGcoWnMpO2NvbnN0IHRvPVwiLmJzLnRvYXN0XCIsZW89YG1vdXNlb3ZlciR7dG99YCxpbz1gbW91c2VvdXQke3RvfWAsbm89YGZvY3VzaW4ke3RvfWAsc289YGZvY3Vzb3V0JHt0b31gLG9vPWBoaWRlJHt0b31gLHJvPWBoaWRkZW4ke3RvfWAsYW89YHNob3cke3RvfWAsbG89YHNob3duJHt0b31gLGNvPVwiaGlkZVwiLGhvPVwic2hvd1wiLHVvPVwic2hvd2luZ1wiLGZvPXthbmltYXRpb246XCJib29sZWFuXCIsYXV0b2hpZGU6XCJib29sZWFuXCIsZGVsYXk6XCJudW1iZXJcIn0scG89e2FuaW1hdGlvbjohMCxhdXRvaGlkZTohMCxkZWxheTo1ZTN9O2NsYXNzIG1vIGV4dGVuZHMgQntjb25zdHJ1Y3Rvcih0LGUpe3N1cGVyKHQsZSksdGhpcy5fdGltZW91dD1udWxsLHRoaXMuX2hhc01vdXNlSW50ZXJhY3Rpb249ITEsdGhpcy5faGFzS2V5Ym9hcmRJbnRlcmFjdGlvbj0hMSx0aGlzLl9zZXRMaXN0ZW5lcnMoKX1zdGF0aWMgZ2V0IERlZmF1bHQoKXtyZXR1cm4gcG99c3RhdGljIGdldCBEZWZhdWx0VHlwZSgpe3JldHVybiBmb31zdGF0aWMgZ2V0IE5BTUUoKXtyZXR1cm5cInRvYXN0XCJ9c2hvdygpe1AudHJpZ2dlcih0aGlzLl9lbGVtZW50LGFvKS5kZWZhdWx0UHJldmVudGVkfHwodGhpcy5fY2xlYXJUaW1lb3V0KCksdGhpcy5fY29uZmlnLmFuaW1hdGlvbiYmdGhpcy5fZWxlbWVudC5jbGFzc0xpc3QuYWRkKFwiZmFkZVwiKSx0aGlzLl9lbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoY28pLHUodGhpcy5fZWxlbWVudCksdGhpcy5fZWxlbWVudC5jbGFzc0xpc3QuYWRkKGhvLHVvKSx0aGlzLl9xdWV1ZUNhbGxiYWNrKCgpPT57dGhpcy5fZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKHVvKSxQLnRyaWdnZXIodGhpcy5fZWxlbWVudCxsbyksdGhpcy5fbWF5YmVTY2hlZHVsZUhpZGUoKX0sdGhpcy5fZWxlbWVudCx0aGlzLl9jb25maWcuYW5pbWF0aW9uKSl9aGlkZSgpe3RoaXMuaXNTaG93bigpJiYoUC50cmlnZ2VyKHRoaXMuX2VsZW1lbnQsb28pLmRlZmF1bHRQcmV2ZW50ZWR8fCh0aGlzLl9lbGVtZW50LmNsYXNzTGlzdC5hZGQodW8pLHRoaXMuX3F1ZXVlQ2FsbGJhY2soKCk9Pnt0aGlzLl9lbGVtZW50LmNsYXNzTGlzdC5hZGQoY28pLHRoaXMuX2VsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZSh1byxobyksUC50cmlnZ2VyKHRoaXMuX2VsZW1lbnQscm8pfSx0aGlzLl9lbGVtZW50LHRoaXMuX2NvbmZpZy5hbmltYXRpb24pKSl9ZGlzcG9zZSgpe3RoaXMuX2NsZWFyVGltZW91dCgpLHRoaXMuaXNTaG93bigpJiZ0aGlzLl9lbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoaG8pLHN1cGVyLmRpc3Bvc2UoKX1pc1Nob3duKCl7cmV0dXJuIHRoaXMuX2VsZW1lbnQuY2xhc3NMaXN0LmNvbnRhaW5zKGhvKX1fbWF5YmVTY2hlZHVsZUhpZGUoKXt0aGlzLl9jb25maWcuYXV0b2hpZGUmJih0aGlzLl9oYXNNb3VzZUludGVyYWN0aW9ufHx0aGlzLl9oYXNLZXlib2FyZEludGVyYWN0aW9ufHwodGhpcy5fdGltZW91dD1zZXRUaW1lb3V0KCgpPT57dGhpcy5oaWRlKCl9LHRoaXMuX2NvbmZpZy5kZWxheSkpKX1fb25JbnRlcmFjdGlvbih0LGUpe3N3aXRjaCh0LnR5cGUpe2Nhc2VcIm1vdXNlb3ZlclwiOmNhc2VcIm1vdXNlb3V0XCI6dGhpcy5faGFzTW91c2VJbnRlcmFjdGlvbj1lO2JyZWFrO2Nhc2VcImZvY3VzaW5cIjpjYXNlXCJmb2N1c291dFwiOnRoaXMuX2hhc0tleWJvYXJkSW50ZXJhY3Rpb249ZX1pZihlKXJldHVybiB2b2lkIHRoaXMuX2NsZWFyVGltZW91dCgpO2NvbnN0IGk9dC5yZWxhdGVkVGFyZ2V0O3RoaXMuX2VsZW1lbnQ9PT1pfHx0aGlzLl9lbGVtZW50LmNvbnRhaW5zKGkpfHx0aGlzLl9tYXliZVNjaGVkdWxlSGlkZSgpfV9zZXRMaXN0ZW5lcnMoKXtQLm9uKHRoaXMuX2VsZW1lbnQsZW8sdD0+dGhpcy5fb25JbnRlcmFjdGlvbih0LCEwKSksUC5vbih0aGlzLl9lbGVtZW50LGlvLHQ9PnRoaXMuX29uSW50ZXJhY3Rpb24odCwhMSkpLFAub24odGhpcy5fZWxlbWVudCxubyx0PT50aGlzLl9vbkludGVyYWN0aW9uKHQsITApKSxQLm9uKHRoaXMuX2VsZW1lbnQsc28sdD0+dGhpcy5fb25JbnRlcmFjdGlvbih0LCExKSl9X2NsZWFyVGltZW91dCgpe2NsZWFyVGltZW91dCh0aGlzLl90aW1lb3V0KSx0aGlzLl90aW1lb3V0PW51bGx9c3RhdGljIGpRdWVyeUludGVyZmFjZSh0KXtyZXR1cm4gdGhpcy5lYWNoKGZ1bmN0aW9uKCl7Y29uc3QgZT1tby5nZXRPckNyZWF0ZUluc3RhbmNlKHRoaXMsdCk7aWYoXCJzdHJpbmdcIj09dHlwZW9mIHQpe2lmKHZvaWQgMD09PWVbdF0pdGhyb3cgbmV3IFR5cGVFcnJvcihgTm8gbWV0aG9kIG5hbWVkIFwiJHt0fVwiYCk7ZVt0XSh0aGlzKX19KX19cmV0dXJuIHEobW8pLGcobW8pLHtBbGVydDpYLEJ1dHRvbjpVLENhcm91c2VsOlN0LENvbGxhcHNlOnF0LERyb3Bkb3duOlFpLE1vZGFsOkxuLE9mZmNhbnZhczpRbixQb3BvdmVyOnZzLFNjcm9sbFNweTpTcyxUYWI6WnMsVG9hc3Q6bW8sVG9vbHRpcDpwc319KTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWJvb3RzdHJhcC5idW5kbGUubWluLmpzLm1hcCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Q0FLQSxDQUFDLFNBQVMsR0FBRSxHQUFFO0VBQUMsWUFBVSxPQUFPLFdBQVMsZUFBYSxPQUFPLFNBQU8sT0FBTyxVQUFRLEVBQUUsSUFBRSxjQUFZLE9BQU8sVUFBUSxPQUFPLE1BQUksT0FBTyxDQUFDLElBQUUsQ0FBQyxJQUFFLGVBQWEsT0FBTyxhQUFXLGFBQVcsS0FBRyxLQUFBLENBQU0sWUFBVSxFQUFFO0NBQUMsRUFBQSxDQUFDLFNBQU0sV0FBVTtFQUFDO0VBQWEsTUFBTSxvQkFBRSxJQUFJLElBQUUsR0FBRSxJQUFFO0dBQUMsSUFBSSxHQUFFLEdBQUUsR0FBRTtJQUFDLEVBQUUsSUFBSSxDQUFDLEtBQUcsRUFBRSxJQUFJLG1CQUFFLElBQUksSUFBRSxDQUFDO0lBQUUsTUFBTSxJQUFFLEVBQUUsSUFBSSxDQUFDO0lBQUUsRUFBRSxJQUFJLENBQUMsS0FBRyxNQUFJLEVBQUUsT0FBSyxFQUFFLElBQUksR0FBRSxDQUFDLElBQUUsUUFBUSxNQUFNLCtFQUErRSxNQUFNLEtBQUssRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRTtHQUFDO0dBQUUsTUFBSyxHQUFFLE1BQUksRUFBRSxJQUFJLENBQUMsS0FBRyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUc7R0FBSyxPQUFPLEdBQUUsR0FBRTtJQUFDLElBQUcsQ0FBQyxFQUFFLElBQUksQ0FBQyxHQUFFO0lBQU8sTUFBTSxJQUFFLEVBQUUsSUFBSSxDQUFDO0lBQUUsRUFBRSxPQUFPLENBQUMsR0FBRSxNQUFJLEVBQUUsUUFBTSxFQUFFLE9BQU8sQ0FBQztHQUFDO0VBQUMsR0FBRSxJQUFFLGlCQUFnQixLQUFFLE9BQUksS0FBRyxPQUFPLE9BQUssT0FBTyxJQUFJLFdBQVMsSUFBRSxFQUFFLFFBQVEsa0JBQWlCLEdBQUUsTUFBSSxJQUFJLElBQUksT0FBTyxDQUFDLEdBQUcsSUFBRyxJQUFHLEtBQUUsTUFBRyxRQUFNLElBQUUsR0FBRyxNQUFJLE9BQU8sVUFBVSxTQUFTLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxhQUFhLENBQUMsQ0FBQyxFQUFFLENBQUMsWUFBWSxHQUFFLEtBQUUsTUFBRztHQUFDLEVBQUUsY0FBYyxJQUFJLE1BQU0sQ0FBQyxDQUFDO0VBQUMsR0FBRSxLQUFFLE1BQUcsRUFBRSxDQUFDLEtBQUcsWUFBVSxPQUFPLE9BQUssS0FBSyxNQUFJLEVBQUUsV0FBUyxJQUFFLEVBQUUsS0FBSSxLQUFLLE1BQUksRUFBRSxXQUFVLEtBQUUsTUFBRyxFQUFFLENBQUMsSUFBRSxFQUFFLFNBQU8sRUFBRSxLQUFHLElBQUUsWUFBVSxPQUFPLEtBQUcsRUFBRSxTQUFPLElBQUUsU0FBUyxjQUFjLEVBQUUsQ0FBQyxDQUFDLElBQUUsTUFBSyxLQUFFLE1BQUc7R0FBQyxJQUFHLENBQUMsRUFBRSxDQUFDLEtBQUcsTUFBSSxFQUFFLGVBQWUsQ0FBQyxDQUFDLFFBQU8sT0FBTSxDQUFDO0dBQUUsTUFBTSxJQUFFLGNBQVksaUJBQWlCLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixZQUFZLEdBQUUsSUFBRSxFQUFFLFFBQVEscUJBQXFCO0dBQUUsSUFBRyxDQUFDLEdBQUUsT0FBTztHQUFFLElBQUcsTUFBSSxHQUFFO0lBQUMsTUFBTSxJQUFFLEVBQUUsUUFBUSxTQUFTO0lBQUUsSUFBRyxLQUFHLEVBQUUsZUFBYSxHQUFFLE9BQU0sQ0FBQztJQUFFLElBQUcsU0FBTyxHQUFFLE9BQU0sQ0FBQztHQUFDO0dBQUMsT0FBTztFQUFDLEdBQUUsS0FBRSxNQUFHLENBQUMsS0FBRyxFQUFFLGFBQVcsS0FBSyxnQkFBYyxDQUFDLENBQUMsRUFBRSxVQUFVLFNBQVMsVUFBVSxNQUFJLEtBQUssTUFBSSxFQUFFLFdBQVMsRUFBRSxXQUFTLEVBQUUsYUFBYSxVQUFVLEtBQUcsWUFBVSxFQUFFLGFBQWEsVUFBVSxJQUFHLEtBQUUsTUFBRztHQUFDLElBQUcsQ0FBQyxTQUFTLGdCQUFnQixjQUFhLE9BQU87R0FBSyxJQUFHLGNBQVksT0FBTyxFQUFFLGFBQVk7SUFBQyxNQUFNLElBQUUsRUFBRSxZQUFZO0lBQUUsT0FBTyxhQUFhLGFBQVcsSUFBRTtHQUFJO0dBQUMsT0FBTyxhQUFhLGFBQVcsSUFBRSxFQUFFLGFBQVcsRUFBRSxFQUFFLFVBQVUsSUFBRTtFQUFJLEdBQUUsVUFBTSxDQUFDLEdBQUUsS0FBRSxNQUFHO0dBQUMsRUFBRTtFQUFZLEdBQUUsVUFBTSxPQUFPLFVBQVEsQ0FBQyxTQUFTLEtBQUssYUFBYSxtQkFBbUIsSUFBRSxPQUFPLFNBQU8sTUFBSyxJQUFFLENBQUMsR0FBRSxVQUFNLFVBQVEsU0FBUyxnQkFBZ0IsS0FBSSxLQUFFLE1BQUc7R0FBQyxJQUFJLFVBQVE7SUFBQyxNQUFNLElBQUUsRUFBRTtJQUFFLElBQUcsR0FBRTtLQUFDLE1BQU0sSUFBRSxFQUFFLE1BQUssSUFBRSxFQUFFLEdBQUc7S0FBRyxFQUFFLEdBQUcsS0FBRyxFQUFFLGlCQUFnQixFQUFFLEdBQUcsRUFBRSxDQUFDLGNBQVksR0FBRSxFQUFFLEdBQUcsRUFBRSxDQUFDLG9CQUFnQixFQUFFLEdBQUcsS0FBRyxHQUFFLEVBQUU7SUFBZ0I7R0FBQztHQUFFLGNBQVksU0FBUyxjQUFZLEVBQUUsVUFBUSxTQUFTLGlCQUFpQiwwQkFBdUI7SUFBQyxLQUFJLE1BQU0sS0FBSyxHQUFFLEVBQUU7R0FBQyxDQUFDLEdBQUUsRUFBRSxLQUFLLENBQUMsS0FBRyxFQUFFO0VBQUMsR0FBRSxLQUFHLEdBQUUsSUFBRSxDQUFDLEdBQUUsSUFBRSxNQUFJLGNBQVksT0FBTyxJQUFFLEVBQUUsS0FBSyxHQUFHLENBQUMsSUFBRSxHQUFFLEtBQUcsR0FBRSxHQUFFLElBQUUsQ0FBQyxNQUFJO0dBQUMsSUFBRyxDQUFDLEdBQUUsT0FBTyxLQUFLLEVBQUUsQ0FBQztHQUFFLE1BQU0sTUFBRyxNQUFHO0lBQUMsSUFBRyxDQUFDLEdBQUUsT0FBTztJQUFFLElBQUcsRUFBQyxvQkFBbUIsR0FBRSxpQkFBZ0IsTUFBRyxPQUFPLGlCQUFpQixDQUFDO0lBQXNELE9BQTVDLE9BQU8sV0FBVyxDQUFpQyxLQUE1QixPQUFPLFdBQVcsQ0FBYSxLQUFHLElBQUUsRUFBRSxNQUFNLEdBQUcsQ0FBQyxDQUFDLElBQUcsSUFBRSxFQUFFLE1BQU0sR0FBRyxDQUFDLENBQUMsSUFBRyxPQUFLLE9BQU8sV0FBVyxDQUFDLElBQUUsT0FBTyxXQUFXLENBQUMsTUFBSTtHQUFDLEVBQUEsQ0FBRyxDQUFDLElBQUU7R0FBRSxJQUFJLElBQUUsQ0FBQztHQUFFLE1BQU0sS0FBRyxFQUFDLFFBQU8sUUFBSztJQUFDLE1BQUksTUFBSSxJQUFFLENBQUMsR0FBRSxFQUFFLG9CQUFvQixHQUFFLENBQUMsR0FBRSxFQUFFLENBQUM7R0FBRTtHQUFFLEVBQUUsaUJBQWlCLEdBQUUsQ0FBQyxHQUFFLGlCQUFlO0lBQUMsS0FBRyxFQUFFLENBQUM7R0FBQyxHQUFFLENBQUM7RUFBQyxHQUFFLEtBQUcsR0FBRSxHQUFFLEdBQUUsTUFBSTtHQUFDLE1BQU0sSUFBRSxFQUFFO0dBQU8sSUFBSSxJQUFFLEVBQUUsUUFBUSxDQUFDO0dBQUUsT0FBTSxPQUFLLElBQUUsQ0FBQyxLQUFHLElBQUUsRUFBRSxJQUFFLEtBQUcsRUFBRSxNQUFJLEtBQUcsSUFBRSxJQUFFLElBQUcsTUFBSSxLQUFHLElBQUUsS0FBRyxJQUFHLEVBQUUsS0FBSyxJQUFJLEdBQUUsS0FBSyxJQUFJLEdBQUUsSUFBRSxDQUFDLENBQUM7RUFBRyxHQUFFLElBQUUsc0JBQXFCLElBQUUsUUFBTyxJQUFFLFVBQVMsSUFBRSxDQUFDO0VBQUUsSUFBSSxJQUFFO0VBQUUsTUFBTSxJQUFFO0dBQUMsWUFBVztHQUFZLFlBQVc7RUFBVSxHQUFFLG9CQUFFLElBQUksSUFBSTtHQUFDO0dBQVE7R0FBVztHQUFVO0dBQVk7R0FBYztHQUFhO0dBQWlCO0dBQVk7R0FBVztHQUFZO0dBQWM7R0FBWTtHQUFVO0dBQVc7R0FBUTtHQUFvQjtHQUFhO0dBQVk7R0FBVztHQUFjO0dBQWM7R0FBYztHQUFZO0dBQWU7R0FBZ0I7R0FBZTtHQUFnQjtHQUFhO0dBQVE7R0FBTztHQUFTO0dBQVE7R0FBUztHQUFTO0dBQVU7R0FBVztHQUFPO0dBQVM7R0FBZTtHQUFTO0dBQU87R0FBbUI7R0FBbUI7R0FBUTtHQUFRO0VBQVEsQ0FBQztFQUFFLFNBQVMsRUFBRSxHQUFFLEdBQUU7R0FBQyxPQUFPLEtBQUcsR0FBRyxFQUFFLElBQUksU0FBTyxFQUFFLFlBQVU7RUFBRztFQUFDLFNBQVMsRUFBRSxHQUFFO0dBQUMsTUFBTSxJQUFFLEVBQUUsQ0FBQztHQUFFLE9BQU8sRUFBRSxXQUFTLEdBQUUsRUFBRSxLQUFHLEVBQUUsTUFBSSxDQUFDLEdBQUUsRUFBRTtFQUFFO0VBQUMsU0FBUyxFQUFFLEdBQUUsR0FBRSxJQUFFLE1BQUs7R0FBQyxPQUFPLE9BQU8sT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFLLE1BQUcsRUFBRSxhQUFXLEtBQUcsRUFBRSx1QkFBcUIsQ0FBQztFQUFDO0VBQUMsU0FBUyxFQUFFLEdBQUUsR0FBRSxHQUFFO0dBQUMsTUFBTSxJQUFFLFlBQVUsT0FBTyxHQUFFLElBQUUsSUFBRSxJQUFFLEtBQUc7R0FBRSxJQUFJLElBQUUsRUFBRSxDQUFDO0dBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxNQUFJLElBQUUsSUFBRztJQUFDO0lBQUU7SUFBRTtHQUFDO0VBQUM7RUFBQyxTQUFTLEVBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFO0dBQUMsSUFBRyxZQUFVLE9BQU8sS0FBRyxDQUFDLEdBQUU7R0FBTyxJQUFHLENBQUMsR0FBRSxHQUFFLEtBQUcsRUFBRSxHQUFFLEdBQUUsQ0FBQztHQUFFLElBQUcsS0FBSyxHQUFFO0lBQUMsTUFBTSxLQUFFLE1BQUcsU0FBUyxHQUFFO0tBQUMsSUFBRyxDQUFDLEVBQUUsaUJBQWUsRUFBRSxrQkFBZ0IsRUFBRSxrQkFBZ0IsQ0FBQyxFQUFFLGVBQWUsU0FBUyxFQUFFLGFBQWEsR0FBRSxPQUFPLEVBQUUsS0FBSyxNQUFLLENBQUM7SUFBQztJQUFFLElBQUUsRUFBRSxDQUFDO0dBQUM7R0FBQyxNQUFNLElBQUUsRUFBRSxDQUFDLEdBQUUsSUFBRSxFQUFFLE9BQUssRUFBRSxLQUFHLENBQUMsSUFBRyxJQUFFLEVBQUUsR0FBRSxHQUFFLElBQUUsSUFBRSxJQUFJO0dBQUUsSUFBRyxHQUFFLE9BQU8sTUFBSyxFQUFFLFNBQU8sRUFBRSxVQUFRO0dBQUcsTUFBTSxJQUFFLEVBQUUsR0FBRSxFQUFFLFFBQVEsR0FBRSxFQUFFLENBQUMsR0FBRSxJQUFFLElBQUUsU0FBUyxHQUFFLEdBQUUsR0FBRTtJQUFDLE9BQU8sU0FBUyxFQUFFLEdBQUU7S0FBQyxNQUFNLElBQUUsRUFBRSxpQkFBaUIsQ0FBQztLQUFFLEtBQUksSUFBRyxFQUFDLFFBQU8sTUFBRyxHQUFFLEtBQUcsTUFBSSxNQUFLLElBQUUsRUFBRSxZQUFXLEtBQUksTUFBTSxLQUFLLEdBQUUsSUFBRyxNQUFJLEdBQUUsT0FBTyxFQUFFLEdBQUUsRUFBQyxnQkFBZSxFQUFDLENBQUMsR0FBRSxFQUFFLFVBQVEsRUFBRSxJQUFJLEdBQUUsRUFBRSxNQUFLLEdBQUUsQ0FBQyxHQUFFLEVBQUUsTUFBTSxHQUFFLENBQUMsQ0FBQyxDQUFDO0lBQUM7R0FBQyxFQUFFLEdBQUUsR0FBRSxDQUFDLElBQUUsU0FBUyxHQUFFLEdBQUU7SUFBQyxPQUFPLFNBQVMsRUFBRSxHQUFFO0tBQUMsT0FBTyxFQUFFLEdBQUUsRUFBQyxnQkFBZSxFQUFDLENBQUMsR0FBRSxFQUFFLFVBQVEsRUFBRSxJQUFJLEdBQUUsRUFBRSxNQUFLLENBQUMsR0FBRSxFQUFFLE1BQU0sR0FBRSxDQUFDLENBQUMsQ0FBQztJQUFDO0dBQUMsRUFBRSxHQUFFLENBQUM7R0FBRSxFQUFFLHFCQUFtQixJQUFFLElBQUUsTUFBSyxFQUFFLFdBQVMsR0FBRSxFQUFFLFNBQU8sR0FBRSxFQUFFLFdBQVMsR0FBRSxFQUFFLEtBQUcsR0FBRSxFQUFFLGlCQUFpQixHQUFFLEdBQUUsQ0FBQztFQUFDO0VBQUMsU0FBUyxFQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRTtHQUFDLE1BQU0sSUFBRSxFQUFFLEVBQUUsSUFBRyxHQUFFLENBQUM7R0FBRSxNQUFJLEVBQUUsb0JBQW9CLEdBQUUsR0FBRSxRQUFRLENBQUMsQ0FBQyxHQUFFLE9BQU8sRUFBRSxFQUFFLENBQUMsRUFBRTtFQUFVO0VBQUMsU0FBUyxFQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUU7R0FBQyxNQUFNLElBQUUsRUFBRSxNQUFJLENBQUM7R0FBRSxLQUFJLE1BQUssQ0FBQyxHQUFFLE1BQUssT0FBTyxRQUFRLENBQUMsR0FBRSxFQUFFLFNBQVMsQ0FBQyxLQUFHLEVBQUUsR0FBRSxHQUFFLEdBQUUsRUFBRSxVQUFTLEVBQUUsa0JBQWtCO0VBQUM7RUFBQyxTQUFTLEVBQUUsR0FBRTtHQUFDLE9BQU8sSUFBRSxFQUFFLFFBQVEsR0FBRSxFQUFFLEdBQUUsRUFBRSxNQUFJO0VBQUM7RUFBQyxNQUFNLElBQUU7R0FBQyxHQUFHLEdBQUUsR0FBRSxHQUFFLEdBQUU7SUFBQyxFQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsQ0FBQyxDQUFDO0dBQUM7R0FBRSxJQUFJLEdBQUUsR0FBRSxHQUFFLEdBQUU7SUFBQyxFQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsQ0FBQyxDQUFDO0dBQUM7R0FBRSxJQUFJLEdBQUUsR0FBRSxHQUFFLEdBQUU7SUFBQyxJQUFHLFlBQVUsT0FBTyxLQUFHLENBQUMsR0FBRTtJQUFPLE1BQUssQ0FBQyxHQUFFLEdBQUUsS0FBRyxFQUFFLEdBQUUsR0FBRSxDQUFDLEdBQUUsSUFBRSxNQUFJLEdBQUUsSUFBRSxFQUFFLENBQUMsR0FBRSxJQUFFLEVBQUUsTUFBSSxDQUFDLEdBQUUsSUFBRSxFQUFFLFdBQVcsR0FBRztJQUFFLElBQUcsS0FBSyxNQUFJLEdBQUU7S0FBQyxJQUFHLEdBQUUsS0FBSSxNQUFNLEtBQUssT0FBTyxLQUFLLENBQUMsR0FBRSxFQUFFLEdBQUUsR0FBRSxHQUFFLEVBQUUsTUFBTSxDQUFDLENBQUM7S0FBRSxLQUFJLE1BQUssQ0FBQyxHQUFFLE1BQUssT0FBTyxRQUFRLENBQUMsR0FBRTtNQUFDLE1BQU0sSUFBRSxFQUFFLFFBQVEsR0FBRSxFQUFFO01BQUUsS0FBRyxDQUFDLEVBQUUsU0FBUyxDQUFDLEtBQUcsRUFBRSxHQUFFLEdBQUUsR0FBRSxFQUFFLFVBQVMsRUFBRSxrQkFBa0I7S0FBQztJQUFDLE9BQUs7S0FBQyxJQUFHLENBQUMsT0FBTyxLQUFLLENBQUMsQ0FBQyxDQUFDLFFBQU87S0FBTyxFQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsSUFBRSxJQUFFLElBQUk7SUFBQztHQUFDO0dBQUUsUUFBUSxHQUFFLEdBQUUsR0FBRTtJQUFDLElBQUcsWUFBVSxPQUFPLEtBQUcsQ0FBQyxHQUFFLE9BQU87SUFBSyxNQUFNLElBQUUsRUFBRTtJQUFFLElBQUksSUFBRSxNQUFLLElBQUUsQ0FBQyxHQUFFLElBQUUsQ0FBQyxHQUFFLElBQUUsQ0FBQztJQUFFLE1BQUksRUFBRSxDQUFDLEtBQUcsTUFBSSxJQUFFLEVBQUUsTUFBTSxHQUFFLENBQUMsR0FBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxHQUFFLElBQUUsQ0FBQyxFQUFFLHFCQUFxQixHQUFFLElBQUUsQ0FBQyxFQUFFLDhCQUE4QixHQUFFLElBQUUsRUFBRSxtQkFBbUI7SUFBRyxNQUFNLElBQUUsRUFBRSxJQUFJLE1BQU0sR0FBRTtLQUFDLFNBQVE7S0FBRSxZQUFXLENBQUM7SUFBQyxDQUFDLEdBQUUsQ0FBQztJQUFFLE9BQU8sS0FBRyxFQUFFLGVBQWUsR0FBRSxLQUFHLEVBQUUsY0FBYyxDQUFDLEdBQUUsRUFBRSxvQkFBa0IsS0FBRyxFQUFFLGVBQWUsR0FBRTtHQUFDO0VBQUM7RUFBRSxTQUFTLEVBQUUsR0FBRSxJQUFFLENBQUMsR0FBRTtHQUFDLEtBQUksTUFBSyxDQUFDLEdBQUUsTUFBSyxPQUFPLFFBQVEsQ0FBQyxHQUFFLElBQUc7SUFBQyxFQUFFLEtBQUc7R0FBQyxTQUFPLEdBQUU7SUFBQyxPQUFPLGVBQWUsR0FBRSxHQUFFO0tBQUMsY0FBYSxDQUFDO0tBQUUsV0FBUTtJQUFDLENBQUM7R0FBQztHQUFDLE9BQU87RUFBQztFQUFDLFNBQVMsRUFBRSxHQUFFO0dBQUMsSUFBRyxXQUFTLEdBQUUsT0FBTSxDQUFDO0dBQUUsSUFBRyxZQUFVLEdBQUUsT0FBTSxDQUFDO0dBQUUsSUFBRyxNQUFJLE9BQU8sQ0FBQyxDQUFDLENBQUMsU0FBUyxHQUFFLE9BQU8sT0FBTyxDQUFDO0dBQUUsSUFBRyxPQUFLLEtBQUcsV0FBUyxHQUFFLE9BQU87R0FBSyxJQUFHLFlBQVUsT0FBTyxHQUFFLE9BQU87R0FBRSxJQUFHO0lBQUMsT0FBTyxLQUFLLE1BQU0sbUJBQW1CLENBQUMsQ0FBQztHQUFDLFNBQU8sR0FBRTtJQUFDLE9BQU87R0FBQztFQUFDO0VBQUMsU0FBUyxFQUFFLEdBQUU7R0FBQyxPQUFPLEVBQUUsUUFBUSxXQUFTLE1BQUcsSUFBSSxFQUFFLFlBQVksR0FBRztFQUFDO0VBQUMsTUFBTSxJQUFFO0dBQUMsaUJBQWlCLEdBQUUsR0FBRSxHQUFFO0lBQUMsRUFBRSxhQUFhLFdBQVcsRUFBRSxDQUFDLEtBQUksQ0FBQztHQUFDO0dBQUUsb0JBQW9CLEdBQUUsR0FBRTtJQUFDLEVBQUUsZ0JBQWdCLFdBQVcsRUFBRSxDQUFDLEdBQUc7R0FBQztHQUFFLGtCQUFrQixHQUFFO0lBQUMsSUFBRyxDQUFDLEdBQUUsT0FBTSxDQUFDO0lBQUUsTUFBTSxJQUFFLENBQUMsR0FBRSxJQUFFLE9BQU8sS0FBSyxFQUFFLE9BQU8sQ0FBQyxDQUFDLFFBQU8sTUFBRyxFQUFFLFdBQVcsSUFBSSxLQUFHLENBQUMsRUFBRSxXQUFXLFVBQVUsQ0FBQztJQUFFLEtBQUksTUFBTSxLQUFLLEdBQUU7S0FBQyxJQUFJLElBQUUsRUFBRSxRQUFRLE9BQU0sRUFBRTtLQUFFLElBQUUsRUFBRSxPQUFPLENBQUMsQ0FBQyxDQUFDLFlBQVksSUFBRSxFQUFFLE1BQU0sQ0FBQyxHQUFFLEVBQUUsS0FBRyxFQUFFLEVBQUUsUUFBUSxFQUFFO0lBQUM7SUFBQyxPQUFPO0dBQUM7R0FBRSxtQkFBa0IsR0FBRSxNQUFJLEVBQUUsRUFBRSxhQUFhLFdBQVcsRUFBRSxDQUFDLEdBQUcsQ0FBQztFQUFDO0VBQUUsTUFBTSxFQUFDO0dBQUMsV0FBVyxVQUFTO0lBQUMsT0FBTSxDQUFDO0dBQUM7R0FBQyxXQUFXLGNBQWE7SUFBQyxPQUFNLENBQUM7R0FBQztHQUFDLFdBQVcsT0FBTTtJQUFDLE1BQU0sSUFBSSxNQUFNLHVFQUFxRTtHQUFDO0dBQUMsV0FBVyxHQUFFO0lBQUMsT0FBTyxJQUFFLEtBQUssZ0JBQWdCLENBQUMsR0FBRSxJQUFFLEtBQUssa0JBQWtCLENBQUMsR0FBRSxLQUFLLGlCQUFpQixDQUFDLEdBQUU7R0FBQztHQUFDLGtCQUFrQixHQUFFO0lBQUMsT0FBTztHQUFDO0dBQUMsZ0JBQWdCLEdBQUUsR0FBRTtJQUFDLE1BQU0sSUFBRSxFQUFFLENBQUMsSUFBRSxFQUFFLGlCQUFpQixHQUFFLFFBQVEsSUFBRSxDQUFDO0lBQUUsT0FBTTtLQUFDLEdBQUcsS0FBSyxZQUFZO0tBQVEsR0FBRyxZQUFVLE9BQU8sSUFBRSxJQUFFLENBQUM7S0FBRSxHQUFHLEVBQUUsQ0FBQyxJQUFFLEVBQUUsa0JBQWtCLENBQUMsSUFBRSxDQUFDO0tBQUUsR0FBRyxZQUFVLE9BQU8sSUFBRSxJQUFFLENBQUM7SUFBQztHQUFDO0dBQUMsaUJBQWlCLEdBQUUsSUFBRSxLQUFLLFlBQVksYUFBWTtJQUFDLEtBQUksTUFBSyxDQUFDLEdBQUUsTUFBSyxPQUFPLFFBQVEsQ0FBQyxHQUFFO0tBQUMsTUFBTSxJQUFFLEVBQUUsSUFBRyxJQUFFLEVBQUUsQ0FBQyxJQUFFLFlBQVUsRUFBRSxDQUFDO0tBQUUsSUFBRyxDQUFDLElBQUksT0FBTyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRSxNQUFNLElBQUksVUFBVSxHQUFHLEtBQUssWUFBWSxLQUFLLFlBQVksRUFBRSxZQUFZLEVBQUUsbUJBQW1CLEVBQUUsdUJBQXVCLEVBQUUsR0FBRztJQUFDO0dBQUM7RUFBQztFQUFDLE1BQU0sVUFBVSxFQUFDO0dBQUMsWUFBWSxHQUFFLEdBQUU7SUFBQyxNQUFNLElBQUcsSUFBRSxFQUFFLENBQUMsT0FBSyxLQUFLLFdBQVMsR0FBRSxLQUFLLFVBQVEsS0FBSyxXQUFXLENBQUMsR0FBRSxFQUFFLElBQUksS0FBSyxVQUFTLEtBQUssWUFBWSxVQUFTLElBQUk7R0FBRTtHQUFDLFVBQVM7SUFBQyxFQUFFLE9BQU8sS0FBSyxVQUFTLEtBQUssWUFBWSxRQUFRLEdBQUUsRUFBRSxJQUFJLEtBQUssVUFBUyxLQUFLLFlBQVksU0FBUztJQUFFLEtBQUksTUFBTSxLQUFLLE9BQU8sb0JBQW9CLElBQUksR0FBRSxLQUFLLEtBQUc7R0FBSTtHQUFDLGVBQWUsR0FBRSxHQUFFLElBQUUsQ0FBQyxHQUFFO0lBQUMsRUFBRSxHQUFFLEdBQUUsQ0FBQztHQUFDO0dBQUMsV0FBVyxHQUFFO0lBQUMsT0FBTyxJQUFFLEtBQUssZ0JBQWdCLEdBQUUsS0FBSyxRQUFRLEdBQUUsSUFBRSxLQUFLLGtCQUFrQixDQUFDLEdBQUUsS0FBSyxpQkFBaUIsQ0FBQyxHQUFFO0dBQUM7R0FBQyxPQUFPLFlBQVksR0FBRTtJQUFDLE9BQU8sRUFBRSxJQUFJLEVBQUUsQ0FBQyxHQUFFLEtBQUssUUFBUTtHQUFDO0dBQUMsT0FBTyxvQkFBb0IsR0FBRSxJQUFFLENBQUMsR0FBRTtJQUFDLE9BQU8sS0FBSyxZQUFZLENBQUMsS0FBRyxJQUFJLEtBQUssR0FBRSxZQUFVLE9BQU8sSUFBRSxJQUFFLElBQUk7R0FBQztHQUFDLFdBQVcsVUFBUztJQUFDLE9BQU07R0FBTztHQUFDLFdBQVcsV0FBVTtJQUFDLE9BQU0sTUFBTSxLQUFLO0dBQU07R0FBQyxXQUFXLFlBQVc7SUFBQyxPQUFNLElBQUksS0FBSztHQUFVO0dBQUMsT0FBTyxVQUFVLEdBQUU7SUFBQyxPQUFNLEdBQUcsSUFBSSxLQUFLO0dBQVc7RUFBQztFQUFDLE1BQU0sS0FBRSxNQUFHO0dBQUMsSUFBSSxJQUFFLEVBQUUsYUFBYSxnQkFBZ0I7R0FBRSxJQUFHLENBQUMsS0FBRyxRQUFNLEdBQUU7SUFBQyxJQUFJLElBQUUsRUFBRSxhQUFhLE1BQU07SUFBRSxJQUFHLENBQUMsS0FBRyxDQUFDLEVBQUUsU0FBUyxHQUFHLEtBQUcsQ0FBQyxFQUFFLFdBQVcsR0FBRyxHQUFFLE9BQU87SUFBSyxFQUFFLFNBQVMsR0FBRyxLQUFHLENBQUMsRUFBRSxXQUFXLEdBQUcsTUFBSSxJQUFFLElBQUksRUFBRSxNQUFNLEdBQUcsQ0FBQyxDQUFDLE9BQU0sSUFBRSxLQUFHLFFBQU0sSUFBRSxFQUFFLEtBQUssSUFBRTtHQUFJO0dBQUMsT0FBTyxJQUFFLEVBQUUsTUFBTSxHQUFHLENBQUMsQ0FBQyxLQUFJLE1BQUcsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxJQUFFO0VBQUksR0FBRSxJQUFFO0dBQUMsT0FBTSxHQUFFLElBQUUsU0FBUyxvQkFBa0IsQ0FBQyxDQUFDLENBQUMsT0FBTyxHQUFHLFFBQVEsVUFBVSxpQkFBaUIsS0FBSyxHQUFFLENBQUMsQ0FBQztHQUFFLFVBQVMsR0FBRSxJQUFFLFNBQVMsb0JBQWtCLFFBQVEsVUFBVSxjQUFjLEtBQUssR0FBRSxDQUFDO0dBQUUsV0FBVSxHQUFFLE1BQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxHQUFHLEVBQUUsUUFBUSxDQUFDLENBQUMsUUFBTyxNQUFHLEVBQUUsUUFBUSxDQUFDLENBQUM7R0FBRSxRQUFRLEdBQUUsR0FBRTtJQUFDLE1BQU0sSUFBRSxDQUFDO0lBQUUsSUFBSSxJQUFFLEVBQUUsV0FBVyxRQUFRLENBQUM7SUFBRSxPQUFLLElBQUcsRUFBRSxLQUFLLENBQUMsR0FBRSxJQUFFLEVBQUUsV0FBVyxRQUFRLENBQUM7SUFBRSxPQUFPO0dBQUM7R0FBRSxLQUFLLEdBQUUsR0FBRTtJQUFDLElBQUksSUFBRSxFQUFFO0lBQXVCLE9BQUssSUFBRztLQUFDLElBQUcsRUFBRSxRQUFRLENBQUMsR0FBRSxPQUFNLENBQUMsQ0FBQztLQUFFLElBQUUsRUFBRTtJQUFzQjtJQUFDLE9BQU0sQ0FBQztHQUFDO0dBQUUsS0FBSyxHQUFFLEdBQUU7SUFBQyxJQUFJLElBQUUsRUFBRTtJQUFtQixPQUFLLElBQUc7S0FBQyxJQUFHLEVBQUUsUUFBUSxDQUFDLEdBQUUsT0FBTSxDQUFDLENBQUM7S0FBRSxJQUFFLEVBQUU7SUFBa0I7SUFBQyxPQUFNLENBQUM7R0FBQztHQUFFLGtCQUFrQixHQUFFO0lBQUMsTUFBTSxJQUFFO0tBQUM7S0FBSTtLQUFTO0tBQVE7S0FBVztLQUFTO0tBQVU7S0FBYTtJQUEwQixDQUFDLENBQUMsS0FBSSxNQUFHLEdBQUcsRUFBRSxzQkFBc0IsQ0FBQyxDQUFDLEtBQUssR0FBRztJQUFFLE9BQU8sS0FBSyxLQUFLLEdBQUUsQ0FBQyxDQUFDLENBQUMsUUFBTyxNQUFHLENBQUMsRUFBRSxDQUFDLEtBQUcsRUFBRSxDQUFDLENBQUM7R0FBQztHQUFFLHVCQUF1QixHQUFFO0lBQUMsTUFBTSxJQUFFLEVBQUUsQ0FBQztJQUFFLE9BQU8sS0FBRyxFQUFFLFFBQVEsQ0FBQyxJQUFFLElBQUU7R0FBSTtHQUFFLHVCQUF1QixHQUFFO0lBQUMsTUFBTSxJQUFFLEVBQUUsQ0FBQztJQUFFLE9BQU8sSUFBRSxFQUFFLFFBQVEsQ0FBQyxJQUFFO0dBQUk7R0FBRSxnQ0FBZ0MsR0FBRTtJQUFDLE1BQU0sSUFBRSxFQUFFLENBQUM7SUFBRSxPQUFPLElBQUUsRUFBRSxLQUFLLENBQUMsSUFBRSxDQUFDO0dBQUM7RUFBQyxHQUFFLEtBQUcsR0FBRSxJQUFFLFdBQVM7R0FBQyxNQUFNLElBQUUsZ0JBQWdCLEVBQUUsYUFBWSxJQUFFLEVBQUU7R0FBSyxFQUFFLEdBQUcsVUFBUyxHQUFFLHFCQUFxQixFQUFFLEtBQUksU0FBUyxHQUFFO0lBQUMsSUFBRyxDQUFDLEtBQUksTUFBTSxDQUFDLENBQUMsU0FBUyxLQUFLLE9BQU8sS0FBRyxFQUFFLGVBQWUsR0FBRSxFQUFFLElBQUksR0FBRTtJQUFPLE1BQU0sSUFBRSxFQUFFLHVCQUF1QixJQUFJLEtBQUcsS0FBSyxRQUFRLElBQUksR0FBRztJQUFFLEVBQUUsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztHQUFDLENBQUM7RUFBQyxHQUFFLElBQUUsYUFBWSxJQUFFLFFBQVEsS0FBSSxJQUFFLFNBQVM7RUFBSSxNQUFNLFVBQVUsRUFBQztHQUFDLFdBQVcsT0FBTTtJQUFDLE9BQU07R0FBTztHQUFDLFFBQU87SUFBQyxJQUFHLEVBQUUsUUFBUSxLQUFLLFVBQVMsQ0FBQyxDQUFDLENBQUMsa0JBQWlCO0lBQU8sS0FBSyxTQUFTLFVBQVUsT0FBTyxNQUFNO0lBQUUsTUFBTSxJQUFFLEtBQUssU0FBUyxVQUFVLFNBQVMsTUFBTTtJQUFFLEtBQUsscUJBQW1CLEtBQUssZ0JBQWdCLEdBQUUsS0FBSyxVQUFTLENBQUM7R0FBQztHQUFDLGtCQUFpQjtJQUFDLEtBQUssU0FBUyxPQUFPLEdBQUUsRUFBRSxRQUFRLEtBQUssVUFBUyxDQUFDLEdBQUUsS0FBSyxRQUFRO0dBQUM7R0FBQyxPQUFPLGdCQUFnQixHQUFFO0lBQUMsT0FBTyxLQUFLLEtBQUssV0FBVTtLQUFDLE1BQU0sSUFBRSxFQUFFLG9CQUFvQixJQUFJO0tBQUUsSUFBRyxZQUFVLE9BQU8sR0FBRTtNQUFDLElBQUcsS0FBSyxNQUFJLEVBQUUsTUFBSSxFQUFFLFdBQVcsR0FBRyxLQUFHLGtCQUFnQixHQUFFLE1BQU0sSUFBSSxVQUFVLG9CQUFvQixFQUFFLEVBQUU7TUFBRSxFQUFFLEVBQUUsQ0FBQyxJQUFJO0tBQUM7SUFBQyxDQUFDO0dBQUM7RUFBQztFQUFDLEVBQUUsR0FBRSxPQUFPLEdBQUUsRUFBRSxDQUFDO0VBQUUsTUFBTSxJQUFFO0VBQTRCLE1BQU0sVUFBVSxFQUFDO0dBQUMsV0FBVyxPQUFNO0lBQUMsT0FBTTtHQUFRO0dBQUMsU0FBUTtJQUFDLEtBQUssU0FBUyxhQUFhLGdCQUFlLEtBQUssU0FBUyxVQUFVLE9BQU8sUUFBUSxDQUFDO0dBQUM7R0FBQyxPQUFPLGdCQUFnQixHQUFFO0lBQUMsT0FBTyxLQUFLLEtBQUssV0FBVTtLQUFDLE1BQU0sSUFBRSxFQUFFLG9CQUFvQixJQUFJO0tBQUUsYUFBVyxLQUFHLEVBQUUsRUFBRSxDQUFDO0lBQUMsQ0FBQztHQUFDO0VBQUM7RUFBQyxFQUFFLEdBQUcsVUFBUyw0QkFBMkIsSUFBRSxNQUFHO0dBQUMsRUFBRSxlQUFlO0dBQUUsTUFBTSxJQUFFLEVBQUUsT0FBTyxRQUFRLENBQUM7R0FBRSxFQUFFLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxPQUFPO0VBQUMsQ0FBQyxHQUFFLEVBQUUsQ0FBQztFQUFFLE1BQU0sSUFBRSxhQUFZLElBQUUsYUFBYSxLQUFJLElBQUUsWUFBWSxLQUFJLEtBQUcsV0FBVyxLQUFJLEtBQUcsY0FBYyxLQUFJLEtBQUcsWUFBWSxLQUFJLEtBQUc7R0FBQyxhQUFZO0dBQUssY0FBYTtHQUFLLGVBQWM7RUFBSSxHQUFFLEtBQUc7R0FBQyxhQUFZO0dBQWtCLGNBQWE7R0FBa0IsZUFBYztFQUFpQjtFQUFFLE1BQU0sV0FBVyxFQUFDO0dBQUMsWUFBWSxHQUFFLEdBQUU7SUFBQyxNQUFNLEdBQUUsS0FBSyxXQUFTLEdBQUUsS0FBRyxHQUFHLFlBQVksTUFBSSxLQUFLLFVBQVEsS0FBSyxXQUFXLENBQUMsR0FBRSxLQUFLLFVBQVEsR0FBRSxLQUFLLHdCQUFzQixRQUFRLE9BQU8sWUFBWSxHQUFFLEtBQUssWUFBWTtHQUFFO0dBQUMsV0FBVyxVQUFTO0lBQUMsT0FBTztHQUFFO0dBQUMsV0FBVyxjQUFhO0lBQUMsT0FBTztHQUFFO0dBQUMsV0FBVyxPQUFNO0lBQUMsT0FBTTtHQUFPO0dBQUMsVUFBUztJQUFDLEVBQUUsSUFBSSxLQUFLLFVBQVMsQ0FBQztHQUFDO0dBQUMsT0FBTyxHQUFFO0lBQUMsS0FBSyx3QkFBc0IsS0FBSyx3QkFBd0IsQ0FBQyxNQUFJLEtBQUssVUFBUSxFQUFFLFdBQVMsS0FBSyxVQUFRLEVBQUUsUUFBUSxFQUFFLENBQUM7R0FBTztHQUFDLEtBQUssR0FBRTtJQUFDLEtBQUssd0JBQXdCLENBQUMsTUFBSSxLQUFLLFVBQVEsRUFBRSxVQUFRLEtBQUssVUFBUyxLQUFLLGFBQWEsR0FBRSxFQUFFLEtBQUssUUFBUSxXQUFXO0dBQUM7R0FBQyxNQUFNLEdBQUU7SUFBQyxLQUFLLFVBQVEsRUFBRSxXQUFTLEVBQUUsUUFBUSxTQUFPLElBQUUsSUFBRSxFQUFFLFFBQVEsRUFBRSxDQUFDLFVBQVEsS0FBSztHQUFPO0dBQUMsZUFBYztJQUFDLE1BQU0sSUFBRSxLQUFLLElBQUksS0FBSyxPQUFPO0lBQUUsSUFBRyxLQUFHLElBQUc7SUFBTyxNQUFNLElBQUUsSUFBRSxLQUFLO0lBQVEsS0FBSyxVQUFRLEdBQUUsS0FBRyxFQUFFLElBQUUsSUFBRSxLQUFLLFFBQVEsZ0JBQWMsS0FBSyxRQUFRLFlBQVk7R0FBQztHQUFDLGNBQWE7SUFBQyxLQUFLLHlCQUF1QixFQUFFLEdBQUcsS0FBSyxVQUFTLEtBQUcsTUFBRyxLQUFLLE9BQU8sQ0FBQyxDQUFDLEdBQUUsRUFBRSxHQUFHLEtBQUssVUFBUyxLQUFHLE1BQUcsS0FBSyxLQUFLLENBQUMsQ0FBQyxHQUFFLEtBQUssU0FBUyxVQUFVLElBQUksZUFBZSxNQUFJLEVBQUUsR0FBRyxLQUFLLFVBQVMsSUFBRSxNQUFHLEtBQUssT0FBTyxDQUFDLENBQUMsR0FBRSxFQUFFLEdBQUcsS0FBSyxVQUFTLElBQUUsTUFBRyxLQUFLLE1BQU0sQ0FBQyxDQUFDLEdBQUUsRUFBRSxHQUFHLEtBQUssVUFBUyxLQUFHLE1BQUcsS0FBSyxLQUFLLENBQUMsQ0FBQztHQUFFO0dBQUMsd0JBQXdCLEdBQUU7SUFBQyxPQUFPLEtBQUssMEJBQXdCLFVBQVEsRUFBRSxlQUFhLFlBQVUsRUFBRTtHQUFZO0dBQUMsT0FBTyxjQUFhO0lBQUMsT0FBTSxrQkFBaUIsU0FBUyxtQkFBaUIsVUFBVSxpQkFBZTtHQUFDO0VBQUM7RUFBQyxNQUFNLEtBQUcsZ0JBQWUsS0FBRyxhQUFZLEtBQUcsYUFBWSxLQUFHLGNBQWEsS0FBRyxRQUFPLEtBQUcsUUFBTyxLQUFHLFFBQU8sS0FBRyxTQUFRLEtBQUcsUUFBUSxNQUFLLEtBQUcsT0FBTyxNQUFLLEtBQUcsVUFBVSxNQUFLLEtBQUcsYUFBYSxNQUFLLEtBQUcsYUFBYSxNQUFLLEtBQUcsWUFBWSxNQUFLLEtBQUcsT0FBTyxLQUFLLE1BQUssS0FBRyxRQUFRLEtBQUssTUFBSyxLQUFHLFlBQVcsS0FBRyxVQUFTLEtBQUcsV0FBVSxLQUFHLGtCQUFpQixLQUFHLEtBQUcsSUFBRyxLQUFHO0lBQUUsS0FBSTtJQUFJLEtBQUk7RUFBRSxHQUFFLEtBQUc7R0FBQyxVQUFTO0dBQUksVUFBUyxDQUFDO0dBQUUsT0FBTTtHQUFRLE1BQUssQ0FBQztHQUFFLE9BQU0sQ0FBQztHQUFFLE1BQUssQ0FBQztFQUFDLEdBQUUsS0FBRztHQUFDLFVBQVM7R0FBbUIsVUFBUztHQUFVLE9BQU07R0FBbUIsTUFBSztHQUFtQixPQUFNO0dBQVUsTUFBSztFQUFTO0VBQUUsTUFBTSxXQUFXLEVBQUM7R0FBQyxZQUFZLEdBQUUsR0FBRTtJQUFDLE1BQU0sR0FBRSxDQUFDLEdBQUUsS0FBSyxZQUFVLE1BQUssS0FBSyxpQkFBZSxNQUFLLEtBQUssYUFBVyxDQUFDLEdBQUUsS0FBSyxlQUFhLE1BQUssS0FBSyxlQUFhLE1BQUssS0FBSyxxQkFBbUIsRUFBRSxRQUFRLHdCQUF1QixLQUFLLFFBQVEsR0FBRSxLQUFLLG1CQUFtQixHQUFFLEtBQUssUUFBUSxTQUFPLE1BQUksS0FBSyxNQUFNO0dBQUM7R0FBQyxXQUFXLFVBQVM7SUFBQyxPQUFPO0dBQUU7R0FBQyxXQUFXLGNBQWE7SUFBQyxPQUFPO0dBQUU7R0FBQyxXQUFXLE9BQU07SUFBQyxPQUFNO0dBQVU7R0FBQyxPQUFNO0lBQUMsS0FBSyxPQUFPLEVBQUU7R0FBQztHQUFDLGtCQUFpQjtJQUFDLENBQUMsU0FBUyxVQUFRLEVBQUUsS0FBSyxRQUFRLEtBQUcsS0FBSyxLQUFLO0dBQUM7R0FBQyxPQUFNO0lBQUMsS0FBSyxPQUFPLEVBQUU7R0FBQztHQUFDLFFBQU87SUFBQyxLQUFLLGNBQVksRUFBRSxLQUFLLFFBQVEsR0FBRSxLQUFLLGVBQWU7R0FBQztHQUFDLFFBQU87SUFBQyxLQUFLLGVBQWUsR0FBRSxLQUFLLGdCQUFnQixHQUFFLEtBQUssWUFBVSxrQkFBZ0IsS0FBSyxnQkFBZ0IsR0FBRSxLQUFLLFFBQVEsUUFBUTtHQUFDO0dBQUMsb0JBQW1CO0lBQUMsS0FBSyxRQUFRLFNBQU8sS0FBSyxhQUFXLEVBQUUsSUFBSSxLQUFLLFVBQVMsVUFBTyxLQUFLLE1BQU0sQ0FBQyxJQUFFLEtBQUssTUFBTTtHQUFFO0dBQUMsR0FBRyxHQUFFO0lBQUMsTUFBTSxJQUFFLEtBQUssVUFBVTtJQUFFLElBQUcsSUFBRSxFQUFFLFNBQU8sS0FBRyxJQUFFLEdBQUU7SUFBTyxJQUFHLEtBQUssWUFBVyxPQUFPLEtBQUssRUFBRSxJQUFJLEtBQUssVUFBUyxVQUFPLEtBQUssR0FBRyxDQUFDLENBQUM7SUFBRSxNQUFNLElBQUUsS0FBSyxjQUFjLEtBQUssV0FBVyxDQUFDO0lBQUUsSUFBRyxNQUFJLEdBQUU7SUFBTyxNQUFNLElBQUUsSUFBRSxJQUFFLEtBQUc7SUFBRyxLQUFLLE9BQU8sR0FBRSxFQUFFLEVBQUU7R0FBQztHQUFDLFVBQVM7SUFBQyxLQUFLLGdCQUFjLEtBQUssYUFBYSxRQUFRLEdBQUUsTUFBTSxRQUFRO0dBQUM7R0FBQyxrQkFBa0IsR0FBRTtJQUFDLE9BQU8sRUFBRSxrQkFBZ0IsRUFBRSxVQUFTO0dBQUM7R0FBQyxxQkFBb0I7SUFBQyxLQUFLLFFBQVEsWUFBVSxFQUFFLEdBQUcsS0FBSyxVQUFTLEtBQUcsTUFBRyxLQUFLLFNBQVMsQ0FBQyxDQUFDLEdBQUUsWUFBVSxLQUFLLFFBQVEsVUFBUSxFQUFFLEdBQUcsS0FBSyxVQUFTLFVBQU8sS0FBSyxNQUFNLENBQUMsR0FBRSxFQUFFLEdBQUcsS0FBSyxVQUFTLFVBQU8sS0FBSyxrQkFBa0IsQ0FBQyxJQUFHLEtBQUssUUFBUSxTQUFPLEdBQUcsWUFBWSxLQUFHLEtBQUssd0JBQXdCO0dBQUM7R0FBQywwQkFBeUI7SUFBQyxLQUFJLE1BQU0sS0FBSyxFQUFFLEtBQUssc0JBQXFCLEtBQUssUUFBUSxHQUFFLEVBQUUsR0FBRyxHQUFFLEtBQUcsTUFBRyxFQUFFLGVBQWUsQ0FBQztJQUFFLE1BQU0sSUFBRTtLQUFDLG9CQUFpQixLQUFLLE9BQU8sS0FBSyxrQkFBa0IsRUFBRSxDQUFDO0tBQUUscUJBQWtCLEtBQUssT0FBTyxLQUFLLGtCQUFrQixFQUFFLENBQUM7S0FBRSxtQkFBZ0I7TUFBQyxZQUFVLEtBQUssUUFBUSxVQUFRLEtBQUssTUFBTSxHQUFFLEtBQUssZ0JBQWMsYUFBYSxLQUFLLFlBQVksR0FBRSxLQUFLLGVBQWEsaUJBQWUsS0FBSyxrQkFBa0IsR0FBRSxNQUFJLEtBQUssUUFBUSxRQUFRO0tBQUU7SUFBQztJQUFFLEtBQUssZUFBYSxJQUFJLEdBQUcsS0FBSyxVQUFTLENBQUM7R0FBQztHQUFDLFNBQVMsR0FBRTtJQUFDLElBQUcsa0JBQWtCLEtBQUssRUFBRSxPQUFPLE9BQU8sR0FBRTtJQUFPLE1BQU0sSUFBRSxHQUFHLEVBQUU7SUFBSyxNQUFJLEVBQUUsZUFBZSxHQUFFLEtBQUssT0FBTyxLQUFLLGtCQUFrQixDQUFDLENBQUM7R0FBRTtHQUFDLGNBQWMsR0FBRTtJQUFDLE9BQU8sS0FBSyxVQUFVLENBQUMsQ0FBQyxRQUFRLENBQUM7R0FBQztHQUFDLDJCQUEyQixHQUFFO0lBQUMsSUFBRyxDQUFDLEtBQUssb0JBQW1CO0lBQU8sTUFBTSxJQUFFLEVBQUUsUUFBUSxJQUFHLEtBQUssa0JBQWtCO0lBQUUsRUFBRSxVQUFVLE9BQU8sRUFBRSxHQUFFLEVBQUUsZ0JBQWdCLGNBQWM7SUFBRSxNQUFNLElBQUUsRUFBRSxRQUFRLHNCQUFzQixFQUFFLEtBQUksS0FBSyxrQkFBa0I7SUFBRSxNQUFJLEVBQUUsVUFBVSxJQUFJLEVBQUUsR0FBRSxFQUFFLGFBQWEsZ0JBQWUsTUFBTTtHQUFFO0dBQUMsa0JBQWlCO0lBQUMsTUFBTSxJQUFFLEtBQUssa0JBQWdCLEtBQUssV0FBVztJQUFFLElBQUcsQ0FBQyxHQUFFO0lBQU8sTUFBTSxJQUFFLE9BQU8sU0FBUyxFQUFFLGFBQWEsa0JBQWtCLEdBQUUsRUFBRTtJQUFFLEtBQUssUUFBUSxXQUFTLEtBQUcsS0FBSyxRQUFRO0dBQWU7R0FBQyxPQUFPLEdBQUUsSUFBRSxNQUFLO0lBQUMsSUFBRyxLQUFLLFlBQVc7SUFBTyxNQUFNLElBQUUsS0FBSyxXQUFXLEdBQUUsSUFBRSxNQUFJLElBQUcsSUFBRSxLQUFHLEVBQUUsS0FBSyxVQUFVLEdBQUUsR0FBRSxHQUFFLEtBQUssUUFBUSxJQUFJO0lBQUUsSUFBRyxNQUFJLEdBQUU7SUFBTyxNQUFNLElBQUUsS0FBSyxjQUFjLENBQUMsR0FBRSxLQUFFLE1BQUcsRUFBRSxRQUFRLEtBQUssVUFBUyxHQUFFO0tBQUMsZUFBYztLQUFFLFdBQVUsS0FBSyxrQkFBa0IsQ0FBQztLQUFFLE1BQUssS0FBSyxjQUFjLENBQUM7S0FBRSxJQUFHO0lBQUMsQ0FBQztJQUFFLElBQUcsRUFBRSxFQUFFLENBQUMsQ0FBQyxrQkFBaUI7SUFBTyxJQUFHLENBQUMsS0FBRyxDQUFDLEdBQUU7SUFBTyxNQUFNLElBQUUsUUFBUSxLQUFLLFNBQVM7SUFBRSxLQUFLLE1BQU0sR0FBRSxLQUFLLGFBQVcsQ0FBQyxHQUFFLEtBQUssMkJBQTJCLENBQUMsR0FBRSxLQUFLLGlCQUFlO0lBQUUsTUFBTSxJQUFFLElBQUUsd0JBQXNCLHFCQUFvQixJQUFFLElBQUUsdUJBQXFCO0lBQXFCLEVBQUUsVUFBVSxJQUFJLENBQUMsR0FBRSxFQUFFLENBQUMsR0FBRSxFQUFFLFVBQVUsSUFBSSxDQUFDLEdBQUUsRUFBRSxVQUFVLElBQUksQ0FBQyxHQUFFLEtBQUsscUJBQW1CO0tBQUMsRUFBRSxVQUFVLE9BQU8sR0FBRSxDQUFDLEdBQUUsRUFBRSxVQUFVLElBQUksRUFBRSxHQUFFLEVBQUUsVUFBVSxPQUFPLElBQUcsR0FBRSxDQUFDLEdBQUUsS0FBSyxhQUFXLENBQUMsR0FBRSxFQUFFLEVBQUU7SUFBQyxHQUFFLEdBQUUsS0FBSyxZQUFZLENBQUMsR0FBRSxLQUFHLEtBQUssTUFBTTtHQUFDO0dBQUMsY0FBYTtJQUFDLE9BQU8sS0FBSyxTQUFTLFVBQVUsU0FBUyxPQUFPO0dBQUM7R0FBQyxhQUFZO0lBQUMsT0FBTyxFQUFFLFFBQVEsSUFBRyxLQUFLLFFBQVE7R0FBQztHQUFDLFlBQVc7SUFBQyxPQUFPLEVBQUUsS0FBSyxJQUFHLEtBQUssUUFBUTtHQUFDO0dBQUMsaUJBQWdCO0lBQUMsS0FBSyxjQUFZLGNBQWMsS0FBSyxTQUFTLEdBQUUsS0FBSyxZQUFVO0dBQUs7R0FBQyxrQkFBa0IsR0FBRTtJQUFDLE9BQU8sRUFBRSxJQUFFLE1BQUksS0FBRyxLQUFHLEtBQUcsTUFBSSxLQUFHLEtBQUc7R0FBRTtHQUFDLGtCQUFrQixHQUFFO0lBQUMsT0FBTyxFQUFFLElBQUUsTUFBSSxLQUFHLEtBQUcsS0FBRyxNQUFJLEtBQUcsS0FBRztHQUFFO0dBQUMsT0FBTyxnQkFBZ0IsR0FBRTtJQUFDLE9BQU8sS0FBSyxLQUFLLFdBQVU7S0FBQyxNQUFNLElBQUUsR0FBRyxvQkFBb0IsTUFBSyxDQUFDO0tBQUUsSUFBRyxZQUFVLE9BQU8sR0FBTTtVQUFBLFlBQVUsT0FBTyxHQUFFO09BQUMsSUFBRyxLQUFLLE1BQUksRUFBRSxNQUFJLEVBQUUsV0FBVyxHQUFHLEtBQUcsa0JBQWdCLEdBQUUsTUFBTSxJQUFJLFVBQVUsb0JBQW9CLEVBQUUsRUFBRTtPQUFFLEVBQUUsRUFBRSxDQUFDO01BQUM7WUFBTyxFQUFFLEdBQUcsQ0FBQztJQUFDLENBQUM7R0FBQztFQUFDO0VBQUMsRUFBRSxHQUFHLFVBQVMsSUFBRyx1Q0FBc0MsU0FBUyxHQUFFO0dBQUMsTUFBTSxJQUFFLEVBQUUsdUJBQXVCLElBQUk7R0FBRSxJQUFHLENBQUMsS0FBRyxDQUFDLEVBQUUsVUFBVSxTQUFTLEVBQUUsR0FBRTtHQUFPLEVBQUUsZUFBZTtHQUFFLE1BQU0sSUFBRSxHQUFHLG9CQUFvQixDQUFDLEdBQUUsSUFBRSxLQUFLLGFBQWEsa0JBQWtCO0dBQVMsS0FBRyxFQUFFLEdBQUcsQ0FBQyxHQUFPLEVBQUUsa0JBQWtCLEtBQUcsV0FBUyxFQUFFLGlCQUFpQixNQUFLLE9BQU8sS0FBRyxFQUFFLEtBQUssR0FBTyxFQUFFLGtCQUFrQixNQUFJLEVBQUUsS0FBSyxHQUFPLEVBQUUsa0JBQWtCO0VBQUUsQ0FBQyxHQUFFLEVBQUUsR0FBRyxRQUFPLFVBQU87R0FBQyxNQUFNLElBQUUsRUFBRSxLQUFLLDZCQUEyQjtHQUFFLEtBQUksTUFBTSxLQUFLLEdBQUUsR0FBRyxvQkFBb0IsQ0FBQztFQUFDLENBQUMsR0FBRSxFQUFFLEVBQUU7RUFBRSxNQUFNLEtBQUcsZ0JBQWUsS0FBRyxPQUFPLE1BQUssS0FBRyxRQUFRLE1BQUssS0FBRyxPQUFPLE1BQUssS0FBRyxTQUFTLE1BQUssS0FBRyxRQUFRLEdBQUcsWUFBVyxLQUFHLFFBQU8sS0FBRyxZQUFXLEtBQUcsY0FBYSxLQUFHLFdBQVcsR0FBRyxJQUFJLE1BQUssS0FBRyxpQ0FBOEIsS0FBRztHQUFDLFFBQU87R0FBSyxRQUFPLENBQUM7RUFBQyxHQUFFLEtBQUc7R0FBQyxRQUFPO0dBQWlCLFFBQU87RUFBUztFQUFFLE1BQU0sV0FBVyxFQUFDO0dBQUMsWUFBWSxHQUFFLEdBQUU7SUFBQyxNQUFNLEdBQUUsQ0FBQyxHQUFFLEtBQUssbUJBQWlCLENBQUMsR0FBRSxLQUFLLGdCQUFjLENBQUM7SUFBRSxNQUFNLElBQUUsRUFBRSxLQUFLLEVBQUU7SUFBRSxLQUFJLE1BQU0sS0FBSyxHQUFFO0tBQUMsTUFBTSxJQUFFLEVBQUUsdUJBQXVCLENBQUMsR0FBRSxJQUFFLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxRQUFPLE1BQUcsTUFBSSxLQUFLLFFBQVE7S0FBRSxTQUFPLEtBQUcsRUFBRSxVQUFRLEtBQUssY0FBYyxLQUFLLENBQUM7SUFBQztJQUFDLEtBQUssb0JBQW9CLEdBQUUsS0FBSyxRQUFRLFVBQVEsS0FBSywwQkFBMEIsS0FBSyxlQUFjLEtBQUssU0FBUyxDQUFDLEdBQUUsS0FBSyxRQUFRLFVBQVEsS0FBSyxPQUFPO0dBQUM7R0FBQyxXQUFXLFVBQVM7SUFBQyxPQUFPO0dBQUU7R0FBQyxXQUFXLGNBQWE7SUFBQyxPQUFPO0dBQUU7R0FBQyxXQUFXLE9BQU07SUFBQyxPQUFNO0dBQVU7R0FBQyxTQUFRO0lBQUMsS0FBSyxTQUFTLElBQUUsS0FBSyxLQUFLLElBQUUsS0FBSyxLQUFLO0dBQUM7R0FBQyxPQUFNO0lBQUMsSUFBRyxLQUFLLG9CQUFrQixLQUFLLFNBQVMsR0FBRTtJQUFPLElBQUksSUFBRSxDQUFDO0lBQUUsSUFBRyxLQUFLLFFBQVEsV0FBUyxJQUFFLEtBQUssdUJBQXVCLHNDQUFzQyxDQUFDLENBQUMsUUFBTyxNQUFHLE1BQUksS0FBSyxRQUFRLENBQUMsQ0FBQyxLQUFJLE1BQUcsR0FBRyxvQkFBb0IsR0FBRSxFQUFDLFFBQU8sQ0FBQyxFQUFDLENBQUMsQ0FBQyxJQUFHLEVBQUUsVUFBUSxFQUFFLEVBQUUsQ0FBQyxrQkFBaUI7SUFBTyxJQUFHLEVBQUUsUUFBUSxLQUFLLFVBQVMsRUFBRSxDQUFDLENBQUMsa0JBQWlCO0lBQU8sS0FBSSxNQUFNLEtBQUssR0FBRSxFQUFFLEtBQUs7SUFBRSxNQUFNLElBQUUsS0FBSyxjQUFjO0lBQUUsS0FBSyxTQUFTLFVBQVUsT0FBTyxFQUFFLEdBQUUsS0FBSyxTQUFTLFVBQVUsSUFBSSxFQUFFLEdBQUUsS0FBSyxTQUFTLE1BQU0sS0FBRyxHQUFFLEtBQUssMEJBQTBCLEtBQUssZUFBYyxDQUFDLENBQUMsR0FBRSxLQUFLLG1CQUFpQixDQUFDO0lBQUUsTUFBTSxJQUFFLFNBQVMsRUFBRSxFQUFFLENBQUMsWUFBWSxJQUFFLEVBQUUsTUFBTSxDQUFDO0lBQUksS0FBSyxxQkFBbUI7S0FBQyxLQUFLLG1CQUFpQixDQUFDLEdBQUUsS0FBSyxTQUFTLFVBQVUsT0FBTyxFQUFFLEdBQUUsS0FBSyxTQUFTLFVBQVUsSUFBSSxJQUFHLEVBQUUsR0FBRSxLQUFLLFNBQVMsTUFBTSxLQUFHLElBQUcsRUFBRSxRQUFRLEtBQUssVUFBUyxFQUFFO0lBQUMsR0FBRSxLQUFLLFVBQVMsQ0FBQyxDQUFDLEdBQUUsS0FBSyxTQUFTLE1BQU0sS0FBRyxHQUFHLEtBQUssU0FBUyxHQUFHO0dBQUc7R0FBQyxPQUFNO0lBQUMsSUFBRyxLQUFLLG9CQUFrQixDQUFDLEtBQUssU0FBUyxHQUFFO0lBQU8sSUFBRyxFQUFFLFFBQVEsS0FBSyxVQUFTLEVBQUUsQ0FBQyxDQUFDLGtCQUFpQjtJQUFPLE1BQU0sSUFBRSxLQUFLLGNBQWM7SUFBRSxLQUFLLFNBQVMsTUFBTSxLQUFHLEdBQUcsS0FBSyxTQUFTLHNCQUFzQixDQUFDLENBQUMsR0FBRyxLQUFJLEVBQUUsS0FBSyxRQUFRLEdBQUUsS0FBSyxTQUFTLFVBQVUsSUFBSSxFQUFFLEdBQUUsS0FBSyxTQUFTLFVBQVUsT0FBTyxJQUFHLEVBQUU7SUFBRSxLQUFJLE1BQU0sS0FBSyxLQUFLLGVBQWM7S0FBQyxNQUFNLElBQUUsRUFBRSx1QkFBdUIsQ0FBQztLQUFFLEtBQUcsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxLQUFHLEtBQUssMEJBQTBCLENBQUMsQ0FBQyxHQUFFLENBQUMsQ0FBQztJQUFDO0lBQUMsS0FBSyxtQkFBaUIsQ0FBQyxHQUFFLEtBQUssU0FBUyxNQUFNLEtBQUcsSUFBRyxLQUFLLHFCQUFtQjtLQUFDLEtBQUssbUJBQWlCLENBQUMsR0FBRSxLQUFLLFNBQVMsVUFBVSxPQUFPLEVBQUUsR0FBRSxLQUFLLFNBQVMsVUFBVSxJQUFJLEVBQUUsR0FBRSxFQUFFLFFBQVEsS0FBSyxVQUFTLEVBQUU7SUFBQyxHQUFFLEtBQUssVUFBUyxDQUFDLENBQUM7R0FBQztHQUFDLFNBQVMsSUFBRSxLQUFLLFVBQVM7SUFBQyxPQUFPLEVBQUUsVUFBVSxTQUFTLEVBQUU7R0FBQztHQUFDLGtCQUFrQixHQUFFO0lBQUMsT0FBTyxFQUFFLFNBQU8sUUFBUSxFQUFFLE1BQU0sR0FBRSxFQUFFLFNBQU8sRUFBRSxFQUFFLE1BQU0sR0FBRTtHQUFDO0dBQUMsZ0JBQWU7SUFBQyxPQUFPLEtBQUssU0FBUyxVQUFVLFNBQVMscUJBQXFCLElBQUUsVUFBUTtHQUFRO0dBQUMsc0JBQXFCO0lBQUMsSUFBRyxDQUFDLEtBQUssUUFBUSxRQUFPO0lBQU8sTUFBTSxJQUFFLEtBQUssdUJBQXVCLEVBQUU7SUFBRSxLQUFJLE1BQU0sS0FBSyxHQUFFO0tBQUMsTUFBTSxJQUFFLEVBQUUsdUJBQXVCLENBQUM7S0FBRSxLQUFHLEtBQUssMEJBQTBCLENBQUMsQ0FBQyxHQUFFLEtBQUssU0FBUyxDQUFDLENBQUM7SUFBQztHQUFDO0dBQUMsdUJBQXVCLEdBQUU7SUFBQyxNQUFNLElBQUUsRUFBRSxLQUFLLElBQUcsS0FBSyxRQUFRLE1BQU07SUFBRSxPQUFPLEVBQUUsS0FBSyxHQUFFLEtBQUssUUFBUSxNQUFNLENBQUMsQ0FBQyxRQUFPLE1BQUcsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxDQUFDO0dBQUM7R0FBQywwQkFBMEIsR0FBRSxHQUFFO0lBQUMsSUFBRyxFQUFFLFFBQU8sS0FBSSxNQUFNLEtBQUssR0FBRSxFQUFFLFVBQVUsT0FBTyxhQUFZLENBQUMsQ0FBQyxHQUFFLEVBQUUsYUFBYSxpQkFBZ0IsQ0FBQztHQUFDO0dBQUMsT0FBTyxnQkFBZ0IsR0FBRTtJQUFDLE1BQU0sSUFBRSxDQUFDO0lBQUUsT0FBTSxZQUFVLE9BQU8sS0FBRyxZQUFZLEtBQUssQ0FBQyxNQUFJLEVBQUUsU0FBTyxDQUFDLElBQUcsS0FBSyxLQUFLLFdBQVU7S0FBQyxNQUFNLElBQUUsR0FBRyxvQkFBb0IsTUFBSyxDQUFDO0tBQUUsSUFBRyxZQUFVLE9BQU8sR0FBRTtNQUFDLElBQUcsS0FBSyxNQUFJLEVBQUUsSUFBRyxNQUFNLElBQUksVUFBVSxvQkFBb0IsRUFBRSxFQUFFO01BQUUsRUFBRSxFQUFFLENBQUM7S0FBQztJQUFDLENBQUM7R0FBQztFQUFDO0VBQUMsRUFBRSxHQUFHLFVBQVMsSUFBRyxJQUFHLFNBQVMsR0FBRTtHQUFDLENBQUMsUUFBTSxFQUFFLE9BQU8sV0FBUyxFQUFFLGtCQUFnQixRQUFNLEVBQUUsZUFBZSxZQUFVLEVBQUUsZUFBZTtHQUFFLEtBQUksTUFBTSxLQUFLLEVBQUUsZ0NBQWdDLElBQUksR0FBRSxHQUFHLG9CQUFvQixHQUFFLEVBQUMsUUFBTyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTztFQUFDLENBQUMsR0FBRSxFQUFFLEVBQUU7RUFBRSxJQUFJLEtBQUcsT0FBTSxLQUFHLFVBQVMsS0FBRyxTQUFRLEtBQUcsUUFBTyxLQUFHLFFBQU8sS0FBRztHQUFDO0dBQUc7R0FBRztHQUFHO0VBQUUsR0FBRSxLQUFHLFNBQVEsS0FBRyxPQUFNLEtBQUcsbUJBQWtCLEtBQUcsWUFBVyxLQUFHLFVBQVMsS0FBRyxhQUFZLEtBQUcsR0FBRyxPQUFPLFNBQVMsR0FBRSxHQUFFO0dBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxJQUFFLE1BQUksSUFBRyxJQUFFLE1BQUksRUFBRSxDQUFDO0VBQUMsR0FBRSxDQUFDLENBQUMsR0FBRSxLQUFHLENBQUMsQ0FBQyxDQUFDLE9BQU8sSUFBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsT0FBTyxTQUFTLEdBQUUsR0FBRTtHQUFDLE9BQU8sRUFBRSxPQUFPO0lBQUM7SUFBRSxJQUFFLE1BQUk7SUFBRyxJQUFFLE1BQUk7R0FBRSxDQUFDO0VBQUMsR0FBRSxDQUFDLENBQUMsR0FBRSxLQUFHLGNBQWEsS0FBRyxRQUFPLEtBQUcsYUFBWSxLQUFHLGNBQWEsS0FBRyxRQUFPLEtBQUcsYUFBWSxLQUFHLGVBQWMsS0FBRyxTQUFRLEtBQUcsY0FBYSxLQUFHO0dBQUM7R0FBRztHQUFHO0dBQUc7R0FBRztHQUFHO0dBQUc7R0FBRztHQUFHO0VBQUU7RUFBRSxTQUFTLEdBQUcsR0FBRTtHQUFDLE9BQU8sS0FBRyxFQUFFLFlBQVUsR0FBQSxDQUFJLFlBQVksSUFBRTtFQUFJO0VBQUMsU0FBUyxHQUFHLEdBQUU7R0FBQyxJQUFHLFFBQU0sR0FBRSxPQUFPO0dBQU8sSUFBRyxzQkFBb0IsRUFBRSxTQUFTLEdBQUU7SUFBQyxJQUFJLElBQUUsRUFBRTtJQUFjLE9BQU8sS0FBRyxFQUFFLGVBQWE7R0FBTTtHQUFDLE9BQU87RUFBQztFQUFDLFNBQVMsR0FBRyxHQUFFO0dBQUMsT0FBTyxhQUFhLEdBQUcsQ0FBQyxDQUFDLENBQUMsV0FBUyxhQUFhO0VBQU87RUFBQyxTQUFTLEdBQUcsR0FBRTtHQUFDLE9BQU8sYUFBYSxHQUFHLENBQUMsQ0FBQyxDQUFDLGVBQWEsYUFBYTtFQUFXO0VBQUMsU0FBUyxHQUFHLEdBQUU7R0FBQyxPQUFNLGVBQWEsT0FBTyxlQUFhLGFBQWEsR0FBRyxDQUFDLENBQUMsQ0FBQyxjQUFZLGFBQWE7RUFBVztFQUFDLE1BQU0sS0FBRztHQUFDLE1BQUs7R0FBYyxTQUFRLENBQUM7R0FBRSxPQUFNO0dBQVEsSUFBRyxTQUFTLEdBQUU7SUFBQyxJQUFJLElBQUUsRUFBRTtJQUFNLE9BQU8sS0FBSyxFQUFFLFFBQVEsQ0FBQyxDQUFDLFFBQVEsU0FBUyxHQUFFO0tBQUMsSUFBSSxJQUFFLEVBQUUsT0FBTyxNQUFJLENBQUMsR0FBRSxJQUFFLEVBQUUsV0FBVyxNQUFJLENBQUMsR0FBRSxJQUFFLEVBQUUsU0FBUztLQUFHLEdBQUcsQ0FBQyxLQUFHLEdBQUcsQ0FBQyxNQUFJLE9BQU8sT0FBTyxFQUFFLE9BQU0sQ0FBQyxHQUFFLE9BQU8sS0FBSyxDQUFDLENBQUMsQ0FBQyxRQUFRLFNBQVMsR0FBRTtNQUFDLElBQUksSUFBRSxFQUFFO01BQUcsQ0FBQyxNQUFJLElBQUUsRUFBRSxnQkFBZ0IsQ0FBQyxJQUFFLEVBQUUsYUFBYSxHQUFFLENBQUMsTUFBSSxJQUFFLEtBQUcsQ0FBQztLQUFDLENBQUM7SUFBRSxDQUFDO0dBQUM7R0FBRSxRQUFPLFNBQVMsR0FBRTtJQUFDLElBQUksSUFBRSxFQUFFLE9BQU0sSUFBRTtLQUFDLFFBQU87TUFBQyxVQUFTLEVBQUUsUUFBUTtNQUFTLE1BQUs7TUFBSSxLQUFJO01BQUksUUFBTztLQUFHO0tBQUUsT0FBTSxFQUFDLFVBQVMsV0FBVTtLQUFFLFdBQVUsQ0FBQztJQUFDO0lBQUUsT0FBTyxPQUFPLE9BQU8sRUFBRSxTQUFTLE9BQU8sT0FBTSxFQUFFLE1BQU0sR0FBRSxFQUFFLFNBQU8sR0FBRSxFQUFFLFNBQVMsU0FBTyxPQUFPLE9BQU8sRUFBRSxTQUFTLE1BQU0sT0FBTSxFQUFFLEtBQUssR0FBRSxXQUFVO0tBQUMsT0FBTyxLQUFLLEVBQUUsUUFBUSxDQUFDLENBQUMsUUFBUSxTQUFTLEdBQUU7TUFBQyxJQUFJLElBQUUsRUFBRSxTQUFTLElBQUcsSUFBRSxFQUFFLFdBQVcsTUFBSSxDQUFDLEdBQUUsSUFBRSxPQUFPLEtBQUssRUFBRSxPQUFPLGVBQWUsQ0FBQyxJQUFFLEVBQUUsT0FBTyxLQUFHLEVBQUUsRUFBRSxDQUFDLENBQUMsT0FBTyxTQUFTLEdBQUUsR0FBRTtPQUFDLE9BQU8sRUFBRSxLQUFHLElBQUc7TUFBQyxHQUFFLENBQUMsQ0FBQztNQUFFLEdBQUcsQ0FBQyxLQUFHLEdBQUcsQ0FBQyxNQUFJLE9BQU8sT0FBTyxFQUFFLE9BQU0sQ0FBQyxHQUFFLE9BQU8sS0FBSyxDQUFDLENBQUMsQ0FBQyxRQUFRLFNBQVMsR0FBRTtPQUFDLEVBQUUsZ0JBQWdCLENBQUM7TUFBQyxDQUFDO0tBQUUsQ0FBQztJQUFDO0dBQUM7R0FBRSxVQUFTLENBQUMsZUFBZTtFQUFDO0VBQUUsU0FBUyxHQUFHLEdBQUU7R0FBQyxPQUFPLEVBQUUsTUFBTSxHQUFHLENBQUMsQ0FBQztFQUFFO0VBQUMsSUFBSSxLQUFHLEtBQUssS0FBSSxLQUFHLEtBQUssS0FBSSxLQUFHLEtBQUs7RUFBTSxTQUFTLEtBQUk7R0FBQyxJQUFJLElBQUUsVUFBVTtHQUFjLE9BQU8sUUFBTSxLQUFHLEVBQUUsVUFBUSxNQUFNLFFBQVEsRUFBRSxNQUFNLElBQUUsRUFBRSxPQUFPLElBQUksU0FBUyxHQUFFO0lBQUMsT0FBTyxFQUFFLFFBQU0sTUFBSSxFQUFFO0dBQU8sQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLElBQUUsVUFBVTtFQUFTO0VBQUMsU0FBUyxLQUFJO0dBQUMsT0FBTSxDQUFDLGlDQUFpQyxLQUFLLEdBQUcsQ0FBQztFQUFDO0VBQUMsU0FBUyxHQUFHLEdBQUUsR0FBRSxHQUFFO0dBQUMsS0FBSyxNQUFJLE1BQUksSUFBRSxDQUFDLElBQUcsS0FBSyxNQUFJLE1BQUksSUFBRSxDQUFDO0dBQUcsSUFBSSxJQUFFLEVBQUUsc0JBQXNCLEdBQUUsSUFBRSxHQUFFLElBQUU7R0FBRSxLQUFHLEdBQUcsQ0FBQyxNQUFJLElBQUUsRUFBRSxjQUFZLEtBQUcsR0FBRyxFQUFFLEtBQUssSUFBRSxFQUFFLGVBQWEsR0FBRSxJQUFFLEVBQUUsZUFBYSxLQUFHLEdBQUcsRUFBRSxNQUFNLElBQUUsRUFBRSxnQkFBYztHQUFHLElBQUksS0FBRyxHQUFHLENBQUMsSUFBRSxHQUFHLENBQUMsSUFBRSxPQUFBLENBQVEsZ0JBQWUsSUFBRSxDQUFDLEdBQUcsS0FBRyxHQUFFLEtBQUcsRUFBRSxRQUFNLEtBQUcsSUFBRSxFQUFFLGFBQVcsTUFBSSxHQUFFLEtBQUcsRUFBRSxPQUFLLEtBQUcsSUFBRSxFQUFFLFlBQVUsTUFBSSxHQUFFLElBQUUsRUFBRSxRQUFNLEdBQUUsSUFBRSxFQUFFLFNBQU87R0FBRSxPQUFNO0lBQUMsT0FBTTtJQUFFLFFBQU87SUFBRSxLQUFJO0lBQUUsT0FBTSxJQUFFO0lBQUUsUUFBTyxJQUFFO0lBQUUsTUFBSztJQUFFLEdBQUU7SUFBRSxHQUFFO0dBQUM7RUFBQztFQUFDLFNBQVMsR0FBRyxHQUFFO0dBQUMsSUFBSSxJQUFFLEdBQUcsQ0FBQyxHQUFFLElBQUUsRUFBRSxhQUFZLElBQUUsRUFBRTtHQUFhLE9BQU8sS0FBSyxJQUFJLEVBQUUsUUFBTSxDQUFDLEtBQUcsTUFBSSxJQUFFLEVBQUUsUUFBTyxLQUFLLElBQUksRUFBRSxTQUFPLENBQUMsS0FBRyxNQUFJLElBQUUsRUFBRSxTQUFRO0lBQUMsR0FBRSxFQUFFO0lBQVcsR0FBRSxFQUFFO0lBQVUsT0FBTTtJQUFFLFFBQU87R0FBQztFQUFDO0VBQUMsU0FBUyxHQUFHLEdBQUUsR0FBRTtHQUFDLElBQUksSUFBRSxFQUFFLGVBQWEsRUFBRSxZQUFZO0dBQUUsSUFBRyxFQUFFLFNBQVMsQ0FBQyxHQUFFLE9BQU0sQ0FBQztHQUFFLElBQUcsS0FBRyxHQUFHLENBQUMsR0FBRTtJQUFDLElBQUksSUFBRTtJQUFFLEdBQUU7S0FBQyxJQUFHLEtBQUcsRUFBRSxXQUFXLENBQUMsR0FBRSxPQUFNLENBQUM7S0FBRSxJQUFFLEVBQUUsY0FBWSxFQUFFO0lBQUksU0FBTztHQUFFO0dBQUMsT0FBTSxDQUFDO0VBQUM7RUFBQyxTQUFTLEdBQUcsR0FBRTtHQUFDLE9BQU8sR0FBRyxDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQztFQUFDO0VBQUMsU0FBUyxHQUFHLEdBQUU7R0FBQyxPQUFNO0lBQUM7SUFBUTtJQUFLO0dBQUksQ0FBQyxDQUFDLFFBQVEsR0FBRyxDQUFDLENBQUMsS0FBRztFQUFDO0VBQUMsU0FBUyxHQUFHLEdBQUU7R0FBQyxTQUFRLEdBQUcsQ0FBQyxJQUFFLEVBQUUsZ0JBQWMsRUFBRSxhQUFXLE9BQU8sU0FBQSxDQUFVO0VBQWU7RUFBQyxTQUFTLEdBQUcsR0FBRTtHQUFDLE9BQU0sV0FBUyxHQUFHLENBQUMsSUFBRSxJQUFFLEVBQUUsZ0JBQWMsRUFBRSxlQUFhLEdBQUcsQ0FBQyxJQUFFLEVBQUUsT0FBSyxTQUFPLEdBQUcsQ0FBQztFQUFDO0VBQUMsU0FBUyxHQUFHLEdBQUU7R0FBQyxPQUFPLEdBQUcsQ0FBQyxLQUFHLFlBQVUsR0FBRyxDQUFDLENBQUMsQ0FBQyxXQUFTLEVBQUUsZUFBYTtFQUFJO0VBQUMsU0FBUyxHQUFHLEdBQUU7R0FBQyxLQUFJLElBQUksSUFBRSxHQUFHLENBQUMsR0FBRSxJQUFFLEdBQUcsQ0FBQyxHQUFFLEtBQUcsR0FBRyxDQUFDLEtBQUcsYUFBVyxHQUFHLENBQUMsQ0FBQyxDQUFDLFdBQVUsSUFBRSxHQUFHLENBQUM7R0FBRSxPQUFPLE1BQUksV0FBUyxHQUFHLENBQUMsS0FBRyxXQUFTLEdBQUcsQ0FBQyxLQUFHLGFBQVcsR0FBRyxDQUFDLENBQUMsQ0FBQyxZQUFVLElBQUUsS0FBRyxTQUFTLEdBQUU7SUFBQyxJQUFJLElBQUUsV0FBVyxLQUFLLEdBQUcsQ0FBQztJQUFFLElBQUcsV0FBVyxLQUFLLEdBQUcsQ0FBQyxLQUFHLEdBQUcsQ0FBQyxLQUFHLFlBQVUsR0FBRyxDQUFDLENBQUMsQ0FBQyxVQUFTLE9BQU87SUFBSyxJQUFJLElBQUUsR0FBRyxDQUFDO0lBQUUsS0FBSSxHQUFHLENBQUMsTUFBSSxJQUFFLEVBQUUsT0FBTSxHQUFHLENBQUMsS0FBRyxDQUFDLFFBQU8sTUFBTSxDQUFDLENBQUMsUUFBUSxHQUFHLENBQUMsQ0FBQyxJQUFFLElBQUc7S0FBQyxJQUFJLElBQUUsR0FBRyxDQUFDO0tBQUUsSUFBRyxXQUFTLEVBQUUsYUFBVyxXQUFTLEVBQUUsZUFBYSxZQUFVLEVBQUUsV0FBUyxPQUFLLENBQUMsYUFBWSxhQUFhLENBQUMsQ0FBQyxRQUFRLEVBQUUsVUFBVSxLQUFHLEtBQUcsYUFBVyxFQUFFLGNBQVksS0FBRyxFQUFFLFVBQVEsV0FBUyxFQUFFLFFBQU8sT0FBTztLQUFFLElBQUUsRUFBRTtJQUFVO0lBQUMsT0FBTztHQUFJLEVBQUUsQ0FBQyxLQUFHO0VBQUM7RUFBQyxTQUFTLEdBQUcsR0FBRTtHQUFDLE9BQU0sQ0FBQyxPQUFNLFFBQVEsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFHLElBQUUsTUFBSTtFQUFHO0VBQUMsU0FBUyxHQUFHLEdBQUUsR0FBRSxHQUFFO0dBQUMsT0FBTyxHQUFHLEdBQUUsR0FBRyxHQUFFLENBQUMsQ0FBQztFQUFDO0VBQUMsU0FBUyxHQUFHLEdBQUU7R0FBQyxPQUFPLE9BQU8sT0FBTyxDQUFDLEdBQUU7SUFBQyxLQUFJO0lBQUUsT0FBTTtJQUFFLFFBQU87SUFBRSxNQUFLO0dBQUMsR0FBRSxDQUFDO0VBQUM7RUFBQyxTQUFTLEdBQUcsR0FBRSxHQUFFO0dBQUMsT0FBTyxFQUFFLE9BQU8sU0FBUyxHQUFFLEdBQUU7SUFBQyxPQUFPLEVBQUUsS0FBRyxHQUFFO0dBQUMsR0FBRSxDQUFDLENBQUM7RUFBQztFQUFDLE1BQU0sS0FBRztHQUFDLE1BQUs7R0FBUSxTQUFRLENBQUM7R0FBRSxPQUFNO0dBQU8sSUFBRyxTQUFTLEdBQUU7SUFBQyxJQUFJLEdBQUUsSUFBRSxFQUFFLE9BQU0sSUFBRSxFQUFFLE1BQUssSUFBRSxFQUFFLFNBQVEsSUFBRSxFQUFFLFNBQVMsT0FBTSxJQUFFLEVBQUUsY0FBYyxlQUFjLElBQUUsR0FBRyxFQUFFLFNBQVMsR0FBRSxJQUFFLEdBQUcsQ0FBQyxHQUFFLElBQUUsQ0FBQyxJQUFHLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFHLElBQUUsV0FBUztJQUFRLElBQUcsS0FBRyxHQUFFO0tBQUMsSUFBSSxJQUFFLFNBQVMsR0FBRSxHQUFFO01BQUMsT0FBTyxHQUFHLFlBQVUsUUFBTyxJQUFFLGNBQVksT0FBTyxJQUFFLEVBQUUsT0FBTyxPQUFPLENBQUMsR0FBRSxFQUFFLE9BQU0sRUFBQyxXQUFVLEVBQUUsVUFBUyxDQUFDLENBQUMsSUFBRSxLQUFHLElBQUUsR0FBRyxHQUFFLEVBQUUsQ0FBQztLQUFDLEVBQUUsRUFBRSxTQUFRLENBQUMsR0FBRSxJQUFFLEdBQUcsQ0FBQyxHQUFFLElBQUUsUUFBTSxJQUFFLEtBQUcsSUFBRyxJQUFFLFFBQU0sSUFBRSxLQUFHLElBQUcsSUFBRSxFQUFFLE1BQU0sVUFBVSxLQUFHLEVBQUUsTUFBTSxVQUFVLEtBQUcsRUFBRSxLQUFHLEVBQUUsTUFBTSxPQUFPLElBQUcsSUFBRSxFQUFFLEtBQUcsRUFBRSxNQUFNLFVBQVUsSUFBRyxJQUFFLEdBQUcsQ0FBQyxHQUFFLElBQUUsSUFBRSxRQUFNLElBQUUsRUFBRSxnQkFBYyxJQUFFLEVBQUUsZUFBYSxJQUFFLEdBQUUsSUFBRSxJQUFFLElBQUUsSUFBRSxHQUFFLElBQUUsRUFBRSxJQUFHLElBQUUsSUFBRSxFQUFFLEtBQUcsRUFBRSxJQUFHLElBQUUsSUFBRSxJQUFFLEVBQUUsS0FBRyxJQUFFLEdBQUUsSUFBRSxHQUFHLEdBQUUsR0FBRSxDQUFDLEdBQUUsSUFBRTtLQUFFLEVBQUUsY0FBYyxNQUFJLENBQUMsSUFBRSxDQUFDLEVBQUEsQ0FBRyxLQUFHLEdBQUUsRUFBRSxlQUFhLElBQUUsR0FBRTtJQUFFO0dBQUM7R0FBRSxRQUFPLFNBQVMsR0FBRTtJQUFDLElBQUksSUFBRSxFQUFFLE9BQU0sSUFBRSxFQUFFLFFBQVEsU0FBUSxJQUFFLEtBQUssTUFBSSxJQUFFLHdCQUFzQjtJQUFFLFFBQU0sTUFBSSxZQUFVLE9BQU8sTUFBSSxJQUFFLEVBQUUsU0FBUyxPQUFPLGNBQWMsQ0FBQyxPQUFLLEdBQUcsRUFBRSxTQUFTLFFBQU8sQ0FBQyxNQUFJLEVBQUUsU0FBUyxRQUFNO0dBQUU7R0FBRSxVQUFTLENBQUMsZUFBZTtHQUFFLGtCQUFpQixDQUFDLGlCQUFpQjtFQUFDO0VBQUUsU0FBUyxHQUFHLEdBQUU7R0FBQyxPQUFPLEVBQUUsTUFBTSxHQUFHLENBQUMsQ0FBQztFQUFFO0VBQUMsSUFBSSxLQUFHO0dBQUMsS0FBSTtHQUFPLE9BQU07R0FBTyxRQUFPO0dBQU8sTUFBSztFQUFNO0VBQUUsU0FBUyxHQUFHLEdBQUU7R0FBQyxJQUFJLEdBQUUsSUFBRSxFQUFFLFFBQU8sSUFBRSxFQUFFLFlBQVcsSUFBRSxFQUFFLFdBQVUsSUFBRSxFQUFFLFdBQVUsSUFBRSxFQUFFLFNBQVEsSUFBRSxFQUFFLFVBQVMsSUFBRSxFQUFFLGlCQUFnQixJQUFFLEVBQUUsVUFBUyxJQUFFLEVBQUUsY0FBYSxJQUFFLEVBQUUsU0FBUSxJQUFFLEVBQUUsR0FBRSxJQUFFLEtBQUssTUFBSSxJQUFFLElBQUUsR0FBRSxJQUFFLEVBQUUsR0FBRSxJQUFFLEtBQUssTUFBSSxJQUFFLElBQUUsR0FBRSxJQUFFLGNBQVksT0FBTyxJQUFFLEVBQUU7SUFBQyxHQUFFO0lBQUUsR0FBRTtHQUFDLENBQUMsSUFBRTtJQUFDLEdBQUU7SUFBRSxHQUFFO0dBQUM7R0FBRSxJQUFFLEVBQUUsR0FBRSxJQUFFLEVBQUU7R0FBRSxJQUFJLElBQUUsRUFBRSxlQUFlLEdBQUcsR0FBRSxJQUFFLEVBQUUsZUFBZSxHQUFHLEdBQUUsSUFBRSxJQUFHLElBQUUsSUFBRyxJQUFFO0dBQU8sSUFBRyxHQUFFO0lBQUMsSUFBSSxJQUFFLEdBQUcsQ0FBQyxHQUFFLElBQUUsZ0JBQWUsSUFBRTtJQUFjLE1BQUksR0FBRyxDQUFDLEtBQUcsYUFBVyxHQUFHLElBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVUsZUFBYSxNQUFJLElBQUUsZ0JBQWUsSUFBRSxpQkFBZ0IsTUFBSSxPQUFLLE1BQUksTUFBSSxNQUFJLE9BQUssTUFBSSxRQUFNLElBQUUsSUFBRyxNQUFJLEtBQUcsTUFBSSxLQUFHLEVBQUUsaUJBQWUsRUFBRSxlQUFlLFNBQU8sRUFBRSxNQUFJLEVBQUUsUUFBTyxLQUFHLElBQUUsSUFBRSxLQUFJLE1BQUksT0FBSyxNQUFJLE1BQUksTUFBSSxNQUFJLE1BQUksUUFBTSxJQUFFLElBQUcsTUFBSSxLQUFHLE1BQUksS0FBRyxFQUFFLGlCQUFlLEVBQUUsZUFBZSxRQUFNLEVBQUUsTUFBSSxFQUFFLE9BQU0sS0FBRyxJQUFFLElBQUU7R0FBRztHQUFDLElBQUksR0FBRSxJQUFFLE9BQU8sT0FBTyxFQUFDLFVBQVMsRUFBQyxHQUFFLEtBQUcsRUFBRSxHQUFFLElBQUUsQ0FBQyxNQUFJLElBQUUsU0FBUyxHQUFFLEdBQUU7SUFBQyxJQUFJLElBQUUsRUFBRSxHQUFFLElBQUUsRUFBRSxHQUFFLElBQUUsRUFBRSxvQkFBa0I7SUFBRSxPQUFNO0tBQUMsR0FBRSxHQUFHLElBQUUsQ0FBQyxJQUFFLEtBQUc7S0FBRSxHQUFFLEdBQUcsSUFBRSxDQUFDLElBQUUsS0FBRztJQUFDO0dBQUMsRUFBRTtJQUFDLEdBQUU7SUFBRSxHQUFFO0dBQUMsR0FBRSxHQUFHLENBQUMsQ0FBQyxJQUFFO0lBQUMsR0FBRTtJQUFFLEdBQUU7R0FBQztHQUFFLE9BQU8sSUFBRSxFQUFFLEdBQUUsSUFBRSxFQUFFLEdBQUUsSUFBRSxPQUFPLE9BQU8sQ0FBQyxHQUFFLElBQUcsQ0FBQyxJQUFFLENBQUMsRUFBQSxDQUFHLEtBQUcsSUFBRSxNQUFJLElBQUcsRUFBRSxLQUFHLElBQUUsTUFBSSxJQUFHLEVBQUUsYUFBVyxFQUFFLG9CQUFrQixNQUFJLElBQUUsZUFBYSxJQUFFLFNBQU8sSUFBRSxRQUFNLGlCQUFlLElBQUUsU0FBTyxJQUFFLFVBQVMsRUFBRSxJQUFFLE9BQU8sT0FBTyxDQUFDLEdBQUUsSUFBRyxDQUFDLElBQUUsQ0FBQyxFQUFBLENBQUcsS0FBRyxJQUFFLElBQUUsT0FBSyxJQUFHLEVBQUUsS0FBRyxJQUFFLElBQUUsT0FBSyxJQUFHLEVBQUUsWUFBVSxJQUFHLEVBQUU7RUFBQztFQUFDLE1BQU0sS0FBRztHQUFDLE1BQUs7R0FBZ0IsU0FBUSxDQUFDO0dBQUUsT0FBTTtHQUFjLElBQUcsU0FBUyxHQUFFO0lBQUMsSUFBSSxJQUFFLEVBQUUsT0FBTSxJQUFFLEVBQUUsU0FBUSxJQUFFLEVBQUUsaUJBQWdCLElBQUUsS0FBSyxNQUFJLEtBQUcsR0FBRSxJQUFFLEVBQUUsVUFBUyxJQUFFLEtBQUssTUFBSSxLQUFHLEdBQUUsSUFBRSxFQUFFLGNBQWEsSUFBRSxLQUFLLE1BQUksS0FBRyxHQUFFLElBQUU7S0FBQyxXQUFVLEdBQUcsRUFBRSxTQUFTO0tBQUUsV0FBVSxHQUFHLEVBQUUsU0FBUztLQUFFLFFBQU8sRUFBRSxTQUFTO0tBQU8sWUFBVyxFQUFFLE1BQU07S0FBTyxpQkFBZ0I7S0FBRSxTQUFRLFlBQVUsRUFBRSxRQUFRO0lBQVE7SUFBRSxRQUFNLEVBQUUsY0FBYyxrQkFBZ0IsRUFBRSxPQUFPLFNBQU8sT0FBTyxPQUFPLENBQUMsR0FBRSxFQUFFLE9BQU8sUUFBTyxHQUFHLE9BQU8sT0FBTyxDQUFDLEdBQUUsR0FBRTtLQUFDLFNBQVEsRUFBRSxjQUFjO0tBQWMsVUFBUyxFQUFFLFFBQVE7S0FBUyxVQUFTO0tBQUUsY0FBYTtJQUFDLENBQUMsQ0FBQyxDQUFDLElBQUcsUUFBTSxFQUFFLGNBQWMsVUFBUSxFQUFFLE9BQU8sUUFBTSxPQUFPLE9BQU8sQ0FBQyxHQUFFLEVBQUUsT0FBTyxPQUFNLEdBQUcsT0FBTyxPQUFPLENBQUMsR0FBRSxHQUFFO0tBQUMsU0FBUSxFQUFFLGNBQWM7S0FBTSxVQUFTO0tBQVcsVUFBUyxDQUFDO0tBQUUsY0FBYTtJQUFDLENBQUMsQ0FBQyxDQUFDLElBQUcsRUFBRSxXQUFXLFNBQU8sT0FBTyxPQUFPLENBQUMsR0FBRSxFQUFFLFdBQVcsUUFBTyxFQUFDLHlCQUF3QixFQUFFLFVBQVMsQ0FBQztHQUFDO0dBQUUsTUFBSyxDQUFDO0VBQUM7RUFBRSxJQUFJLEtBQUcsRUFBQyxTQUFRLENBQUMsRUFBQztFQUFFLE1BQU0sS0FBRztHQUFDLE1BQUs7R0FBaUIsU0FBUSxDQUFDO0dBQUUsT0FBTTtHQUFRLElBQUcsV0FBVSxDQUFDO0dBQUUsUUFBTyxTQUFTLEdBQUU7SUFBQyxJQUFJLElBQUUsRUFBRSxPQUFNLElBQUUsRUFBRSxVQUFTLElBQUUsRUFBRSxTQUFRLElBQUUsRUFBRSxRQUFPLElBQUUsS0FBSyxNQUFJLEtBQUcsR0FBRSxJQUFFLEVBQUUsUUFBTyxJQUFFLEtBQUssTUFBSSxLQUFHLEdBQUUsSUFBRSxHQUFHLEVBQUUsU0FBUyxNQUFNLEdBQUUsSUFBRSxDQUFDLENBQUMsQ0FBQyxPQUFPLEVBQUUsY0FBYyxXQUFVLEVBQUUsY0FBYyxNQUFNO0lBQUUsT0FBTyxLQUFHLEVBQUUsUUFBUSxTQUFTLEdBQUU7S0FBQyxFQUFFLGlCQUFpQixVQUFTLEVBQUUsUUFBTyxFQUFFO0lBQUMsQ0FBQyxHQUFFLEtBQUcsRUFBRSxpQkFBaUIsVUFBUyxFQUFFLFFBQU8sRUFBRSxHQUFFLFdBQVU7S0FBQyxLQUFHLEVBQUUsUUFBUSxTQUFTLEdBQUU7TUFBQyxFQUFFLG9CQUFvQixVQUFTLEVBQUUsUUFBTyxFQUFFO0tBQUMsQ0FBQyxHQUFFLEtBQUcsRUFBRSxvQkFBb0IsVUFBUyxFQUFFLFFBQU8sRUFBRTtJQUFDO0dBQUM7R0FBRSxNQUFLLENBQUM7RUFBQztFQUFFLElBQUksS0FBRztHQUFDLE1BQUs7R0FBUSxPQUFNO0dBQU8sUUFBTztHQUFNLEtBQUk7RUFBUTtFQUFFLFNBQVMsR0FBRyxHQUFFO0dBQUMsT0FBTyxFQUFFLFFBQVEsMEJBQXlCLFNBQVMsR0FBRTtJQUFDLE9BQU8sR0FBRztHQUFFLENBQUM7RUFBQztFQUFDLElBQUksS0FBRztHQUFDLE9BQU07R0FBTSxLQUFJO0VBQU87RUFBRSxTQUFTLEdBQUcsR0FBRTtHQUFDLE9BQU8sRUFBRSxRQUFRLGNBQWEsU0FBUyxHQUFFO0lBQUMsT0FBTyxHQUFHO0dBQUUsQ0FBQztFQUFDO0VBQUMsU0FBUyxHQUFHLEdBQUU7R0FBQyxJQUFJLElBQUUsR0FBRyxDQUFDO0dBQUUsT0FBTTtJQUFDLFlBQVcsRUFBRTtJQUFZLFdBQVUsRUFBRTtHQUFXO0VBQUM7RUFBQyxTQUFTLEdBQUcsR0FBRTtHQUFDLE9BQU8sR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDO0VBQVU7RUFBQyxTQUFTLEdBQUcsR0FBRTtHQUFDLElBQUksSUFBRSxHQUFHLENBQUMsR0FBRSxJQUFFLEVBQUUsVUFBUyxJQUFFLEVBQUUsV0FBVSxJQUFFLEVBQUU7R0FBVSxPQUFNLDZCQUE2QixLQUFLLElBQUUsSUFBRSxDQUFDO0VBQUM7RUFBQyxTQUFTLEdBQUcsR0FBRTtHQUFDLE9BQU07SUFBQztJQUFPO0lBQU87R0FBVyxDQUFDLENBQUMsUUFBUSxHQUFHLENBQUMsQ0FBQyxLQUFHLElBQUUsRUFBRSxjQUFjLE9BQUssR0FBRyxDQUFDLEtBQUcsR0FBRyxDQUFDLElBQUUsSUFBRSxHQUFHLEdBQUcsQ0FBQyxDQUFDO0VBQUM7RUFBQyxTQUFTLEdBQUcsR0FBRSxHQUFFO0dBQUMsSUFBSTtHQUFFLEtBQUssTUFBSSxNQUFJLElBQUUsQ0FBQztHQUFHLElBQUksSUFBRSxHQUFHLENBQUMsR0FBRSxJQUFFLE9BQUssU0FBTyxJQUFFLEVBQUUsaUJBQWUsS0FBSyxJQUFFLEVBQUUsT0FBTSxJQUFFLEdBQUcsQ0FBQyxHQUFFLElBQUUsSUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sRUFBRSxrQkFBZ0IsQ0FBQyxHQUFFLEdBQUcsQ0FBQyxJQUFFLElBQUUsQ0FBQyxDQUFDLElBQUUsR0FBRSxJQUFFLEVBQUUsT0FBTyxDQUFDO0dBQUUsT0FBTyxJQUFFLElBQUUsRUFBRSxPQUFPLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQztFQUFDO0VBQUMsU0FBUyxHQUFHLEdBQUU7R0FBQyxPQUFPLE9BQU8sT0FBTyxDQUFDLEdBQUUsR0FBRTtJQUFDLE1BQUssRUFBRTtJQUFFLEtBQUksRUFBRTtJQUFFLE9BQU0sRUFBRSxJQUFFLEVBQUU7SUFBTSxRQUFPLEVBQUUsSUFBRSxFQUFFO0dBQU0sQ0FBQztFQUFDO0VBQUMsU0FBUyxHQUFHLEdBQUUsR0FBRSxHQUFFO0dBQUMsT0FBTyxNQUFJLEtBQUcsR0FBRyxTQUFTLEdBQUUsR0FBRTtJQUFDLElBQUksSUFBRSxHQUFHLENBQUMsR0FBRSxJQUFFLEdBQUcsQ0FBQyxHQUFFLElBQUUsRUFBRSxnQkFBZSxJQUFFLEVBQUUsYUFBWSxJQUFFLEVBQUUsY0FBYSxJQUFFLEdBQUUsSUFBRTtJQUFFLElBQUcsR0FBRTtLQUFDLElBQUUsRUFBRSxPQUFNLElBQUUsRUFBRTtLQUFPLElBQUksSUFBRSxHQUFHO0tBQUUsQ0FBQyxLQUFHLENBQUMsS0FBRyxZQUFVLE9BQUssSUFBRSxFQUFFLFlBQVcsSUFBRSxFQUFFO0lBQVU7SUFBQyxPQUFNO0tBQUMsT0FBTTtLQUFFLFFBQU87S0FBRSxHQUFFLElBQUUsR0FBRyxDQUFDO0tBQUUsR0FBRTtJQUFDO0dBQUMsRUFBRSxHQUFFLENBQUMsQ0FBQyxJQUFFLEdBQUcsQ0FBQyxJQUFFLFNBQVMsR0FBRSxHQUFFO0lBQUMsSUFBSSxJQUFFLEdBQUcsR0FBRSxDQUFDLEdBQUUsWUFBVSxDQUFDO0lBQUUsT0FBTyxFQUFFLE1BQUksRUFBRSxNQUFJLEVBQUUsV0FBVSxFQUFFLE9BQUssRUFBRSxPQUFLLEVBQUUsWUFBVyxFQUFFLFNBQU8sRUFBRSxNQUFJLEVBQUUsY0FBYSxFQUFFLFFBQU0sRUFBRSxPQUFLLEVBQUUsYUFBWSxFQUFFLFFBQU0sRUFBRSxhQUFZLEVBQUUsU0FBTyxFQUFFLGNBQWEsRUFBRSxJQUFFLEVBQUUsTUFBSyxFQUFFLElBQUUsRUFBRSxLQUFJO0dBQUMsRUFBRSxHQUFFLENBQUMsSUFBRSxHQUFHLFNBQVMsR0FBRTtJQUFDLElBQUksR0FBRSxJQUFFLEdBQUcsQ0FBQyxHQUFFLElBQUUsR0FBRyxDQUFDLEdBQUUsSUFBRSxTQUFPLElBQUUsRUFBRSxpQkFBZSxLQUFLLElBQUUsRUFBRSxNQUFLLElBQUUsR0FBRyxFQUFFLGFBQVksRUFBRSxhQUFZLElBQUUsRUFBRSxjQUFZLEdBQUUsSUFBRSxFQUFFLGNBQVksQ0FBQyxHQUFFLElBQUUsR0FBRyxFQUFFLGNBQWEsRUFBRSxjQUFhLElBQUUsRUFBRSxlQUFhLEdBQUUsSUFBRSxFQUFFLGVBQWEsQ0FBQyxHQUFFLElBQUUsQ0FBQyxFQUFFLGFBQVcsR0FBRyxDQUFDLEdBQUUsSUFBRSxDQUFDLEVBQUU7SUFBVSxPQUFNLFVBQVEsR0FBRyxLQUFHLENBQUMsQ0FBQyxDQUFDLGNBQVksS0FBRyxHQUFHLEVBQUUsYUFBWSxJQUFFLEVBQUUsY0FBWSxDQUFDLElBQUUsSUFBRztLQUFDLE9BQU07S0FBRSxRQUFPO0tBQUUsR0FBRTtLQUFFLEdBQUU7SUFBQztHQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQztFQUFDO0VBQUMsU0FBUyxHQUFHLEdBQUU7R0FBQyxJQUFJLEdBQUUsSUFBRSxFQUFFLFdBQVUsSUFBRSxFQUFFLFNBQVEsSUFBRSxFQUFFLFdBQVUsSUFBRSxJQUFFLEdBQUcsQ0FBQyxJQUFFLE1BQUssSUFBRSxJQUFFLEdBQUcsQ0FBQyxJQUFFLE1BQUssSUFBRSxFQUFFLElBQUUsRUFBRSxRQUFNLElBQUUsRUFBRSxRQUFNLEdBQUUsSUFBRSxFQUFFLElBQUUsRUFBRSxTQUFPLElBQUUsRUFBRSxTQUFPO0dBQUUsUUFBTyxHQUFQO0lBQVUsS0FBSztLQUFHLElBQUU7TUFBQyxHQUFFO01BQUUsR0FBRSxFQUFFLElBQUUsRUFBRTtLQUFNO0tBQUU7SUFBTSxLQUFLO0tBQUcsSUFBRTtNQUFDLEdBQUU7TUFBRSxHQUFFLEVBQUUsSUFBRSxFQUFFO0tBQU07S0FBRTtJQUFNLEtBQUs7S0FBRyxJQUFFO01BQUMsR0FBRSxFQUFFLElBQUUsRUFBRTtNQUFNLEdBQUU7S0FBQztLQUFFO0lBQU0sS0FBSztLQUFHLElBQUU7TUFBQyxHQUFFLEVBQUUsSUFBRSxFQUFFO01BQU0sR0FBRTtLQUFDO0tBQUU7SUFBTSxTQUFRLElBQUU7S0FBQyxHQUFFLEVBQUU7S0FBRSxHQUFFLEVBQUU7SUFBQztHQUFDO0dBQUMsSUFBSSxJQUFFLElBQUUsR0FBRyxDQUFDLElBQUU7R0FBSyxJQUFHLFFBQU0sR0FBRTtJQUFDLElBQUksSUFBRSxRQUFNLElBQUUsV0FBUztJQUFRLFFBQU8sR0FBUDtLQUFVLEtBQUs7TUFBRyxFQUFFLEtBQUcsRUFBRSxNQUFJLEVBQUUsS0FBRyxJQUFFLEVBQUUsS0FBRztNQUFHO0tBQU0sS0FBSyxJQUFHLEVBQUUsS0FBRyxFQUFFLE1BQUksRUFBRSxLQUFHLElBQUUsRUFBRSxLQUFHO0lBQUU7R0FBQztHQUFDLE9BQU87RUFBQztFQUFDLFNBQVMsR0FBRyxHQUFFLEdBQUU7R0FBQyxLQUFLLE1BQUksTUFBSSxJQUFFLENBQUM7R0FBRyxJQUFJLElBQUUsR0FBRSxJQUFFLEVBQUUsV0FBVSxJQUFFLEtBQUssTUFBSSxJQUFFLEVBQUUsWUFBVSxHQUFFLElBQUUsRUFBRSxVQUFTLElBQUUsS0FBSyxNQUFJLElBQUUsRUFBRSxXQUFTLEdBQUUsSUFBRSxFQUFFLFVBQVMsSUFBRSxLQUFLLE1BQUksSUFBRSxLQUFHLEdBQUUsSUFBRSxFQUFFLGNBQWEsSUFBRSxLQUFLLE1BQUksSUFBRSxLQUFHLEdBQUUsSUFBRSxFQUFFLGdCQUFlLElBQUUsS0FBSyxNQUFJLElBQUUsS0FBRyxHQUFFLElBQUUsRUFBRSxhQUFZLElBQUUsS0FBSyxNQUFJLEtBQUcsR0FBRSxJQUFFLEVBQUUsU0FBUSxJQUFFLEtBQUssTUFBSSxJQUFFLElBQUUsR0FBRSxJQUFFLEdBQUcsWUFBVSxPQUFPLElBQUUsSUFBRSxHQUFHLEdBQUUsRUFBRSxDQUFDLEdBQUUsSUFBRSxNQUFJLEtBQUcsS0FBRyxJQUFHLElBQUUsRUFBRSxNQUFNLFFBQU8sSUFBRSxFQUFFLFNBQVMsSUFBRSxJQUFFLElBQUcsSUFBRSxTQUFTLEdBQUUsR0FBRSxHQUFFLEdBQUU7SUFBQyxJQUFJLElBQUUsc0JBQW9CLElBQUUsU0FBUyxHQUFFO0tBQUMsSUFBSSxJQUFFLEdBQUcsR0FBRyxDQUFDLENBQUMsR0FBRSxJQUFFLENBQUMsWUFBVyxPQUFPLENBQUMsQ0FBQyxRQUFRLEdBQUcsQ0FBQyxDQUFDLENBQUMsUUFBUSxLQUFHLEtBQUcsR0FBRyxDQUFDLElBQUUsR0FBRyxDQUFDLElBQUU7S0FBRSxPQUFPLEdBQUcsQ0FBQyxJQUFFLEVBQUUsT0FBTyxTQUFTLEdBQUU7TUFBQyxPQUFPLEdBQUcsQ0FBQyxLQUFHLEdBQUcsR0FBRSxDQUFDLEtBQUcsV0FBUyxHQUFHLENBQUM7S0FBQyxDQUFDLElBQUUsQ0FBQztJQUFDLEVBQUUsQ0FBQyxJQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFFLElBQUUsQ0FBQyxDQUFDLENBQUMsT0FBTyxHQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUUsSUFBRSxFQUFFLElBQUcsSUFBRSxFQUFFLE9BQU8sU0FBUyxHQUFFLEdBQUU7S0FBQyxJQUFJLElBQUUsR0FBRyxHQUFFLEdBQUUsQ0FBQztLQUFFLE9BQU8sRUFBRSxNQUFJLEdBQUcsRUFBRSxLQUFJLEVBQUUsR0FBRyxHQUFFLEVBQUUsUUFBTSxHQUFHLEVBQUUsT0FBTSxFQUFFLEtBQUssR0FBRSxFQUFFLFNBQU8sR0FBRyxFQUFFLFFBQU8sRUFBRSxNQUFNLEdBQUUsRUFBRSxPQUFLLEdBQUcsRUFBRSxNQUFLLEVBQUUsSUFBSSxHQUFFO0lBQUMsR0FBRSxHQUFHLEdBQUUsR0FBRSxDQUFDLENBQUM7SUFBRSxPQUFPLEVBQUUsUUFBTSxFQUFFLFFBQU0sRUFBRSxNQUFLLEVBQUUsU0FBTyxFQUFFLFNBQU8sRUFBRSxLQUFJLEVBQUUsSUFBRSxFQUFFLE1BQUssRUFBRSxJQUFFLEVBQUUsS0FBSTtHQUFDLEVBQUUsR0FBRyxDQUFDLElBQUUsSUFBRSxFQUFFLGtCQUFnQixHQUFHLEVBQUUsU0FBUyxNQUFNLEdBQUUsR0FBRSxHQUFFLENBQUMsR0FBRSxJQUFFLEdBQUcsRUFBRSxTQUFTLFNBQVMsR0FBRSxJQUFFLEdBQUc7SUFBQyxXQUFVO0lBQUUsU0FBUTtJQUFFLFdBQVU7R0FBQyxDQUFDLEdBQUUsSUFBRSxHQUFHLE9BQU8sT0FBTyxDQUFDLEdBQUUsR0FBRSxDQUFDLENBQUMsR0FBRSxJQUFFLE1BQUksS0FBRyxJQUFFLEdBQUUsSUFBRTtJQUFDLEtBQUksRUFBRSxNQUFJLEVBQUUsTUFBSSxFQUFFO0lBQUksUUFBTyxFQUFFLFNBQU8sRUFBRSxTQUFPLEVBQUU7SUFBTyxNQUFLLEVBQUUsT0FBSyxFQUFFLE9BQUssRUFBRTtJQUFLLE9BQU0sRUFBRSxRQUFNLEVBQUUsUUFBTSxFQUFFO0dBQUssR0FBRSxJQUFFLEVBQUUsY0FBYztHQUFPLElBQUcsTUFBSSxNQUFJLEdBQUU7SUFBQyxJQUFJLElBQUUsRUFBRTtJQUFHLE9BQU8sS0FBSyxDQUFDLENBQUMsQ0FBQyxRQUFRLFNBQVMsR0FBRTtLQUFDLElBQUksSUFBRSxDQUFDLElBQUcsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUcsSUFBRSxJQUFFLElBQUcsSUFBRSxDQUFDLElBQUcsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUcsSUFBRSxNQUFJO0tBQUksRUFBRSxNQUFJLEVBQUUsS0FBRztJQUFDLENBQUM7R0FBQztHQUFDLE9BQU87RUFBQztFQUFDLFNBQVMsR0FBRyxHQUFFLEdBQUU7R0FBQyxLQUFLLE1BQUksTUFBSSxJQUFFLENBQUM7R0FBRyxJQUFJLElBQUUsR0FBRSxJQUFFLEVBQUUsV0FBVSxJQUFFLEVBQUUsVUFBUyxJQUFFLEVBQUUsY0FBYSxJQUFFLEVBQUUsU0FBUSxJQUFFLEVBQUUsZ0JBQWUsSUFBRSxFQUFFLHVCQUFzQixJQUFFLEtBQUssTUFBSSxJQUFFLEtBQUcsR0FBRSxJQUFFLEdBQUcsQ0FBQyxHQUFFLElBQUUsSUFBRSxJQUFFLEtBQUcsR0FBRyxPQUFPLFNBQVMsR0FBRTtJQUFDLE9BQU8sR0FBRyxDQUFDLE1BQUk7R0FBQyxDQUFDLElBQUUsSUFBRyxJQUFFLEVBQUUsT0FBTyxTQUFTLEdBQUU7SUFBQyxPQUFPLEVBQUUsUUFBUSxDQUFDLEtBQUc7R0FBQyxDQUFDO0dBQUUsTUFBSSxFQUFFLFdBQVMsSUFBRTtHQUFHLElBQUksSUFBRSxFQUFFLE9BQU8sU0FBUyxHQUFFLEdBQUU7SUFBQyxPQUFPLEVBQUUsS0FBRyxHQUFHLEdBQUU7S0FBQyxXQUFVO0tBQUUsVUFBUztLQUFFLGNBQWE7S0FBRSxTQUFRO0lBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUc7R0FBQyxHQUFFLENBQUMsQ0FBQztHQUFFLE9BQU8sT0FBTyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxHQUFFLEdBQUU7SUFBQyxPQUFPLEVBQUUsS0FBRyxFQUFFO0dBQUUsQ0FBQztFQUFDO0VBQUMsTUFBTSxLQUFHO0dBQUMsTUFBSztHQUFPLFNBQVEsQ0FBQztHQUFFLE9BQU07R0FBTyxJQUFHLFNBQVMsR0FBRTtJQUFDLElBQUksSUFBRSxFQUFFLE9BQU0sSUFBRSxFQUFFLFNBQVEsSUFBRSxFQUFFO0lBQUssSUFBRyxDQUFDLEVBQUUsY0FBYyxFQUFFLENBQUMsT0FBTTtLQUFDLEtBQUksSUFBSSxJQUFFLEVBQUUsVUFBUyxJQUFFLEtBQUssTUFBSSxLQUFHLEdBQUUsSUFBRSxFQUFFLFNBQVEsSUFBRSxLQUFLLE1BQUksS0FBRyxHQUFFLElBQUUsRUFBRSxvQkFBbUIsSUFBRSxFQUFFLFNBQVEsSUFBRSxFQUFFLFVBQVMsSUFBRSxFQUFFLGNBQWEsSUFBRSxFQUFFLGFBQVksSUFBRSxFQUFFLGdCQUFlLElBQUUsS0FBSyxNQUFJLEtBQUcsR0FBRSxJQUFFLEVBQUUsdUJBQXNCLElBQUUsRUFBRSxRQUFRLFdBQVUsSUFBRSxHQUFHLENBQUMsR0FBRSxJQUFFLE1BQUksTUFBSSxLQUFHLElBQUUsU0FBUyxHQUFFO01BQUMsSUFBRyxHQUFHLENBQUMsTUFBSSxJQUFHLE9BQU0sQ0FBQztNQUFFLElBQUksSUFBRSxHQUFHLENBQUM7TUFBRSxPQUFNO09BQUMsR0FBRyxDQUFDO09BQUU7T0FBRSxHQUFHLENBQUM7TUFBQztLQUFDLEVBQUUsQ0FBQyxJQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBRyxJQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLFNBQVMsR0FBRSxHQUFFO01BQUMsT0FBTyxFQUFFLE9BQU8sR0FBRyxDQUFDLE1BQUksS0FBRyxHQUFHLEdBQUU7T0FBQyxXQUFVO09BQUUsVUFBUztPQUFFLGNBQWE7T0FBRSxTQUFRO09BQUUsZ0JBQWU7T0FBRSx1QkFBc0I7TUFBQyxDQUFDLElBQUUsQ0FBQztLQUFDLEdBQUUsQ0FBQyxDQUFDLEdBQUUsSUFBRSxFQUFFLE1BQU0sV0FBVSxJQUFFLEVBQUUsTUFBTSxRQUFPLG9CQUFFLElBQUksSUFBRSxHQUFFLElBQUUsQ0FBQyxHQUFFLElBQUUsRUFBRSxJQUFHLElBQUUsR0FBRSxJQUFFLEVBQUUsUUFBTyxLQUFJO01BQUMsSUFBSSxJQUFFLEVBQUUsSUFBRyxJQUFFLEdBQUcsQ0FBQyxHQUFFLElBQUUsR0FBRyxDQUFDLE1BQUksSUFBRyxJQUFFLENBQUMsSUFBRyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBRyxHQUFFLElBQUUsSUFBRSxVQUFRLFVBQVMsSUFBRSxHQUFHLEdBQUU7T0FBQyxXQUFVO09BQUUsVUFBUztPQUFFLGNBQWE7T0FBRSxhQUFZO09BQUUsU0FBUTtNQUFDLENBQUMsR0FBRSxJQUFFLElBQUUsSUFBRSxLQUFHLEtBQUcsSUFBRSxLQUFHO01BQUcsRUFBRSxLQUFHLEVBQUUsT0FBSyxJQUFFLEdBQUcsQ0FBQztNQUFHLElBQUksSUFBRSxHQUFHLENBQUMsR0FBRSxJQUFFLENBQUM7TUFBRSxJQUFHLEtBQUcsRUFBRSxLQUFLLEVBQUUsTUFBSSxDQUFDLEdBQUUsS0FBRyxFQUFFLEtBQUssRUFBRSxNQUFJLEdBQUUsRUFBRSxNQUFJLENBQUMsR0FBRSxFQUFFLE1BQU0sU0FBUyxHQUFFO09BQUMsT0FBTztNQUFDLENBQUMsR0FBRTtPQUFDLElBQUUsR0FBRSxJQUFFLENBQUM7T0FBRTtNQUFLO01BQUMsRUFBRSxJQUFJLEdBQUUsQ0FBQztLQUFDO0tBQUMsSUFBRyxHQUFFLEtBQUksSUFBSSxJQUFFLFNBQVMsR0FBRTtNQUFDLElBQUksSUFBRSxFQUFFLEtBQUssU0FBUyxHQUFFO09BQUMsSUFBSSxJQUFFLEVBQUUsSUFBSSxDQUFDO09BQUUsSUFBRyxHQUFFLE9BQU8sRUFBRSxNQUFNLEdBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxTQUFTLEdBQUU7UUFBQyxPQUFPO09BQUMsQ0FBQztNQUFDLENBQUM7TUFBRSxJQUFHLEdBQUUsT0FBTyxJQUFFLEdBQUU7S0FBTyxHQUFFLElBQUUsSUFBRSxJQUFFLEdBQUUsSUFBRSxLQUFHLFlBQVUsRUFBRSxDQUFDLEdBQUU7S0FBSyxFQUFFLGNBQVksTUFBSSxFQUFFLGNBQWMsRUFBRSxDQUFDLFFBQU0sQ0FBQyxHQUFFLEVBQUUsWUFBVSxHQUFFLEVBQUUsUUFBTSxDQUFDO0lBQUU7R0FBQztHQUFFLGtCQUFpQixDQUFDLFFBQVE7R0FBRSxNQUFLLEVBQUMsT0FBTSxDQUFDLEVBQUM7RUFBQztFQUFFLFNBQVMsR0FBRyxHQUFFLEdBQUUsR0FBRTtHQUFDLE9BQU8sS0FBSyxNQUFJLE1BQUksSUFBRTtJQUFDLEdBQUU7SUFBRSxHQUFFO0dBQUMsSUFBRztJQUFDLEtBQUksRUFBRSxNQUFJLEVBQUUsU0FBTyxFQUFFO0lBQUUsT0FBTSxFQUFFLFFBQU0sRUFBRSxRQUFNLEVBQUU7SUFBRSxRQUFPLEVBQUUsU0FBTyxFQUFFLFNBQU8sRUFBRTtJQUFFLE1BQUssRUFBRSxPQUFLLEVBQUUsUUFBTSxFQUFFO0dBQUM7RUFBQztFQUFDLFNBQVMsR0FBRyxHQUFFO0dBQUMsT0FBTTtJQUFDO0lBQUc7SUFBRztJQUFHO0dBQUUsQ0FBQyxDQUFDLEtBQUssU0FBUyxHQUFFO0lBQUMsT0FBTyxFQUFFLE1BQUk7R0FBQyxDQUFDO0VBQUM7RUFBQyxNQUFNLEtBQUc7R0FBQyxNQUFLO0dBQU8sU0FBUSxDQUFDO0dBQUUsT0FBTTtHQUFPLGtCQUFpQixDQUFDLGlCQUFpQjtHQUFFLElBQUcsU0FBUyxHQUFFO0lBQUMsSUFBSSxJQUFFLEVBQUUsT0FBTSxJQUFFLEVBQUUsTUFBSyxJQUFFLEVBQUUsTUFBTSxXQUFVLElBQUUsRUFBRSxNQUFNLFFBQU8sSUFBRSxFQUFFLGNBQWMsaUJBQWdCLElBQUUsR0FBRyxHQUFFLEVBQUMsZ0JBQWUsWUFBVyxDQUFDLEdBQUUsSUFBRSxHQUFHLEdBQUUsRUFBQyxhQUFZLENBQUMsRUFBQyxDQUFDLEdBQUUsSUFBRSxHQUFHLEdBQUUsQ0FBQyxHQUFFLElBQUUsR0FBRyxHQUFFLEdBQUUsQ0FBQyxHQUFFLElBQUUsR0FBRyxDQUFDLEdBQUUsSUFBRSxHQUFHLENBQUM7SUFBRSxFQUFFLGNBQWMsS0FBRztLQUFDLDBCQUF5QjtLQUFFLHFCQUFvQjtLQUFFLG1CQUFrQjtLQUFFLGtCQUFpQjtJQUFDLEdBQUUsRUFBRSxXQUFXLFNBQU8sT0FBTyxPQUFPLENBQUMsR0FBRSxFQUFFLFdBQVcsUUFBTztLQUFDLGdDQUErQjtLQUFFLHVCQUFzQjtJQUFDLENBQUM7R0FBQztFQUFDLEdBQUUsS0FBRztHQUFDLE1BQUs7R0FBUyxTQUFRLENBQUM7R0FBRSxPQUFNO0dBQU8sVUFBUyxDQUFDLGVBQWU7R0FBRSxJQUFHLFNBQVMsR0FBRTtJQUFDLElBQUksSUFBRSxFQUFFLE9BQU0sSUFBRSxFQUFFLFNBQVEsSUFBRSxFQUFFLE1BQUssSUFBRSxFQUFFLFFBQU8sSUFBRSxLQUFLLE1BQUksSUFBRSxDQUFDLEdBQUUsQ0FBQyxJQUFFLEdBQUUsSUFBRSxHQUFHLE9BQU8sU0FBUyxHQUFFLEdBQUU7S0FBQyxPQUFPLEVBQUUsS0FBRyxTQUFTLEdBQUUsR0FBRSxHQUFFO01BQUMsSUFBSSxJQUFFLEdBQUcsQ0FBQyxHQUFFLElBQUUsQ0FBQyxJQUFHLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFHLElBQUUsS0FBRyxHQUFFLElBQUUsY0FBWSxPQUFPLElBQUUsRUFBRSxPQUFPLE9BQU8sQ0FBQyxHQUFFLEdBQUUsRUFBQyxXQUFVLEVBQUMsQ0FBQyxDQUFDLElBQUUsR0FBRSxJQUFFLEVBQUUsSUFBRyxJQUFFLEVBQUU7TUFBRyxPQUFPLElBQUUsS0FBRyxHQUFFLEtBQUcsS0FBRyxLQUFHLEdBQUUsQ0FBQyxJQUFHLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFHLElBQUU7T0FBQyxHQUFFO09BQUUsR0FBRTtNQUFDLElBQUU7T0FBQyxHQUFFO09BQUUsR0FBRTtNQUFDO0tBQUMsRUFBRSxHQUFFLEVBQUUsT0FBTSxDQUFDLEdBQUU7SUFBQyxHQUFFLENBQUMsQ0FBQyxHQUFFLElBQUUsRUFBRSxFQUFFLFlBQVcsSUFBRSxFQUFFLEdBQUUsSUFBRSxFQUFFO0lBQUUsUUFBTSxFQUFFLGNBQWMsa0JBQWdCLEVBQUUsY0FBYyxjQUFjLEtBQUcsR0FBRSxFQUFFLGNBQWMsY0FBYyxLQUFHLElBQUcsRUFBRSxjQUFjLEtBQUc7R0FBQztFQUFDLEdBQUUsS0FBRztHQUFDLE1BQUs7R0FBZ0IsU0FBUSxDQUFDO0dBQUUsT0FBTTtHQUFPLElBQUcsU0FBUyxHQUFFO0lBQUMsSUFBSSxJQUFFLEVBQUUsT0FBTSxJQUFFLEVBQUU7SUFBSyxFQUFFLGNBQWMsS0FBRyxHQUFHO0tBQUMsV0FBVSxFQUFFLE1BQU07S0FBVSxTQUFRLEVBQUUsTUFBTTtLQUFPLFdBQVUsRUFBRTtJQUFTLENBQUM7R0FBQztHQUFFLE1BQUssQ0FBQztFQUFDLEdBQUUsS0FBRztHQUFDLE1BQUs7R0FBa0IsU0FBUSxDQUFDO0dBQUUsT0FBTTtHQUFPLElBQUcsU0FBUyxHQUFFO0lBQUMsSUFBSSxJQUFFLEVBQUUsT0FBTSxJQUFFLEVBQUUsU0FBUSxJQUFFLEVBQUUsTUFBSyxJQUFFLEVBQUUsVUFBUyxJQUFFLEtBQUssTUFBSSxLQUFHLEdBQUUsSUFBRSxFQUFFLFNBQVEsSUFBRSxLQUFLLE1BQUksS0FBRyxHQUFFLElBQUUsRUFBRSxVQUFTLElBQUUsRUFBRSxjQUFhLElBQUUsRUFBRSxhQUFZLElBQUUsRUFBRSxTQUFRLElBQUUsRUFBRSxRQUFPLElBQUUsS0FBSyxNQUFJLEtBQUcsR0FBRSxJQUFFLEVBQUUsY0FBYSxJQUFFLEtBQUssTUFBSSxJQUFFLElBQUUsR0FBRSxJQUFFLEdBQUcsR0FBRTtLQUFDLFVBQVM7S0FBRSxjQUFhO0tBQUUsU0FBUTtLQUFFLGFBQVk7SUFBQyxDQUFDLEdBQUUsSUFBRSxHQUFHLEVBQUUsU0FBUyxHQUFFLElBQUUsR0FBRyxFQUFFLFNBQVMsR0FBRSxJQUFFLENBQUMsR0FBRSxJQUFFLEdBQUcsQ0FBQyxHQUFFLElBQUUsUUFBTSxJQUFFLE1BQUksS0FBSSxJQUFFLEVBQUUsY0FBYyxlQUFjLElBQUUsRUFBRSxNQUFNLFdBQVUsSUFBRSxFQUFFLE1BQU0sUUFBTyxJQUFFLGNBQVksT0FBTyxJQUFFLEVBQUUsT0FBTyxPQUFPLENBQUMsR0FBRSxFQUFFLE9BQU0sRUFBQyxXQUFVLEVBQUUsVUFBUyxDQUFDLENBQUMsSUFBRSxHQUFFLElBQUUsWUFBVSxPQUFPLElBQUU7S0FBQyxVQUFTO0tBQUUsU0FBUTtJQUFDLElBQUUsT0FBTyxPQUFPO0tBQUMsVUFBUztLQUFFLFNBQVE7SUFBQyxHQUFFLENBQUMsR0FBRSxJQUFFLEVBQUUsY0FBYyxTQUFPLEVBQUUsY0FBYyxPQUFPLEVBQUUsYUFBVyxNQUFLLElBQUU7S0FBQyxHQUFFO0tBQUUsR0FBRTtJQUFDO0lBQUUsSUFBRyxHQUFFO0tBQUMsSUFBRyxHQUFFO01BQUMsSUFBSSxHQUFFLElBQUUsUUFBTSxJQUFFLEtBQUcsSUFBRyxJQUFFLFFBQU0sSUFBRSxLQUFHLElBQUcsSUFBRSxRQUFNLElBQUUsV0FBUyxTQUFRLElBQUUsRUFBRSxJQUFHLElBQUUsSUFBRSxFQUFFLElBQUcsSUFBRSxJQUFFLEVBQUUsSUFBRyxJQUFFLElBQUUsQ0FBQyxFQUFFLEtBQUcsSUFBRSxHQUFFLElBQUUsTUFBSSxLQUFHLEVBQUUsS0FBRyxFQUFFLElBQUcsSUFBRSxNQUFJLEtBQUcsQ0FBQyxFQUFFLEtBQUcsQ0FBQyxFQUFFLElBQUcsSUFBRSxFQUFFLFNBQVMsT0FBTSxJQUFFLEtBQUcsSUFBRSxHQUFHLENBQUMsSUFBRTtPQUFDLE9BQU07T0FBRSxRQUFPO01BQUMsR0FBRSxJQUFFLEVBQUUsY0FBYyxzQkFBb0IsRUFBRSxjQUFjLG1CQUFtQixDQUFDLFVBQVE7T0FBQyxLQUFJO09BQUUsT0FBTTtPQUFFLFFBQU87T0FBRSxNQUFLO01BQUMsR0FBRSxJQUFFLEVBQUUsSUFBRyxJQUFFLEVBQUUsSUFBRyxJQUFFLEdBQUcsR0FBRSxFQUFFLElBQUcsRUFBRSxFQUFFLEdBQUUsSUFBRSxJQUFFLEVBQUUsS0FBRyxJQUFFLElBQUUsSUFBRSxJQUFFLEVBQUUsV0FBUyxJQUFFLElBQUUsSUFBRSxFQUFFLFVBQVMsSUFBRSxJQUFFLENBQUMsRUFBRSxLQUFHLElBQUUsSUFBRSxJQUFFLElBQUUsRUFBRSxXQUFTLElBQUUsSUFBRSxJQUFFLEVBQUUsVUFBUyxJQUFFLEVBQUUsU0FBUyxTQUFPLEdBQUcsRUFBRSxTQUFTLEtBQUssR0FBRSxJQUFFLElBQUUsUUFBTSxJQUFFLEVBQUUsYUFBVyxJQUFFLEVBQUUsY0FBWSxJQUFFLEdBQUUsSUFBRSxTQUFPLElBQUUsUUFBTSxJQUFFLEtBQUssSUFBRSxFQUFFLE1BQUksSUFBRSxHQUFFLElBQUUsSUFBRSxJQUFFLEdBQUUsSUFBRSxHQUFHLElBQUUsR0FBRyxHQUFFLElBQUUsSUFBRSxJQUFFLENBQUMsSUFBRSxHQUFFLEdBQUUsSUFBRSxHQUFHLEdBQUUsQ0FBQyxJQUFFLENBQUM7TUFBRSxFQUFFLEtBQUcsR0FBRSxFQUFFLEtBQUcsSUFBRTtLQUFDO0tBQUMsSUFBRyxHQUFFO01BQUMsSUFBSSxHQUFFLElBQUUsUUFBTSxJQUFFLEtBQUcsSUFBRyxLQUFHLFFBQU0sSUFBRSxLQUFHLElBQUcsS0FBRyxFQUFFLElBQUcsS0FBRyxRQUFNLElBQUUsV0FBUyxTQUFRLEtBQUcsS0FBRyxFQUFFLElBQUcsS0FBRyxLQUFHLEVBQUUsS0FBSSxLQUFHLE9BQUssQ0FBQyxJQUFHLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxHQUFFLEtBQUcsU0FBTyxJQUFFLFFBQU0sSUFBRSxLQUFLLElBQUUsRUFBRSxNQUFJLElBQUUsR0FBRSxLQUFHLEtBQUcsS0FBRyxLQUFHLEVBQUUsTUFBSSxFQUFFLE1BQUksS0FBRyxFQUFFLFNBQVEsS0FBRyxLQUFHLEtBQUcsRUFBRSxNQUFJLEVBQUUsTUFBSSxLQUFHLEVBQUUsVUFBUSxJQUFHLEtBQUcsS0FBRyxLQUFHLFNBQVMsR0FBRSxHQUFFLEdBQUU7T0FBQyxJQUFJLElBQUUsR0FBRyxHQUFFLEdBQUUsQ0FBQztPQUFFLE9BQU8sSUFBRSxJQUFFLElBQUU7TUFBQyxFQUFFLElBQUcsSUFBRyxFQUFFLElBQUUsR0FBRyxJQUFFLEtBQUcsSUFBRyxJQUFHLElBQUUsS0FBRyxFQUFFO01BQUUsRUFBRSxLQUFHLElBQUcsRUFBRSxLQUFHLEtBQUc7S0FBRTtLQUFDLEVBQUUsY0FBYyxLQUFHO0lBQUM7R0FBQztHQUFFLGtCQUFpQixDQUFDLFFBQVE7RUFBQztFQUFFLFNBQVMsR0FBRyxHQUFFLEdBQUUsR0FBRTtHQUFDLEtBQUssTUFBSSxNQUFJLElBQUUsQ0FBQztHQUFHLElBQUksR0FBRSxHQUFFLElBQUUsR0FBRyxDQUFDLEdBQUUsSUFBRSxHQUFHLENBQUMsS0FBRyxTQUFTLEdBQUU7SUFBQyxJQUFJLElBQUUsRUFBRSxzQkFBc0IsR0FBRSxJQUFFLEdBQUcsRUFBRSxLQUFLLElBQUUsRUFBRSxlQUFhLEdBQUUsSUFBRSxHQUFHLEVBQUUsTUFBTSxJQUFFLEVBQUUsZ0JBQWM7SUFBRSxPQUFPLE1BQUksS0FBRyxNQUFJO0dBQUMsRUFBRSxDQUFDLEdBQUUsSUFBRSxHQUFHLENBQUMsR0FBRSxJQUFFLEdBQUcsR0FBRSxHQUFFLENBQUMsR0FBRSxJQUFFO0lBQUMsWUFBVztJQUFFLFdBQVU7R0FBQyxHQUFFLElBQUU7SUFBQyxHQUFFO0lBQUUsR0FBRTtHQUFDO0dBQUUsUUFBTyxLQUFHLENBQUMsS0FBRyxDQUFDLFFBQU0sV0FBUyxHQUFHLENBQUMsS0FBRyxHQUFHLENBQUMsT0FBSyxLQUFHLElBQUUsT0FBSyxHQUFHLENBQUMsS0FBRyxHQUFHLENBQUMsSUFBRTtJQUFDLGFBQVksSUFBRSxFQUFBLENBQUc7SUFBVyxXQUFVLEVBQUU7R0FBUyxJQUFFLEdBQUcsQ0FBQyxJQUFHLEdBQUcsQ0FBQyxLQUFHLENBQUMsSUFBRSxHQUFHLEdBQUUsQ0FBQyxDQUFDLEVBQUEsQ0FBRyxLQUFHLEVBQUUsWUFBVyxFQUFFLEtBQUcsRUFBRSxhQUFXLE1BQUksRUFBRSxJQUFFLEdBQUcsQ0FBQyxLQUFJO0lBQUMsR0FBRSxFQUFFLE9BQUssRUFBRSxhQUFXLEVBQUU7SUFBRSxHQUFFLEVBQUUsTUFBSSxFQUFFLFlBQVUsRUFBRTtJQUFFLE9BQU0sRUFBRTtJQUFNLFFBQU8sRUFBRTtHQUFNO0VBQUM7RUFBQyxTQUFTLEdBQUcsR0FBRTtHQUFDLElBQUksb0JBQUUsSUFBSSxJQUFFLEdBQUUsb0JBQUUsSUFBSSxJQUFFLEdBQUUsSUFBRSxDQUFDO0dBQUUsU0FBUyxFQUFFLEdBQUU7SUFBQyxFQUFFLElBQUksRUFBRSxJQUFJLEdBQUUsQ0FBQyxDQUFDLENBQUMsT0FBTyxFQUFFLFlBQVUsQ0FBQyxHQUFFLEVBQUUsb0JBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxTQUFTLEdBQUU7S0FBQyxJQUFHLENBQUMsRUFBRSxJQUFJLENBQUMsR0FBRTtNQUFDLElBQUksSUFBRSxFQUFFLElBQUksQ0FBQztNQUFFLEtBQUcsRUFBRSxDQUFDO0tBQUM7SUFBQyxDQUFDLEdBQUUsRUFBRSxLQUFLLENBQUM7R0FBQztHQUFDLE9BQU8sRUFBRSxRQUFRLFNBQVMsR0FBRTtJQUFDLEVBQUUsSUFBSSxFQUFFLE1BQUssQ0FBQztHQUFDLENBQUMsR0FBRSxFQUFFLFFBQVEsU0FBUyxHQUFFO0lBQUMsRUFBRSxJQUFJLEVBQUUsSUFBSSxLQUFHLEVBQUUsQ0FBQztHQUFDLENBQUMsR0FBRTtFQUFDO0VBQUMsSUFBSSxLQUFHO0dBQUMsV0FBVTtHQUFTLFdBQVUsQ0FBQztHQUFFLFVBQVM7RUFBVTtFQUFFLFNBQVMsS0FBSTtHQUFDLEtBQUksSUFBSSxJQUFFLFVBQVUsUUFBTyxJQUFFLElBQUksTUFBTSxDQUFDLEdBQUUsSUFBRSxHQUFFLElBQUUsR0FBRSxLQUFJLEVBQUUsS0FBRyxVQUFVO0dBQUcsT0FBTSxDQUFDLEVBQUUsS0FBSyxTQUFTLEdBQUU7SUFBQyxPQUFNLEVBQUUsS0FBRyxjQUFZLE9BQU8sRUFBRTtHQUFzQixDQUFDO0VBQUM7RUFBQyxTQUFTLEdBQUcsR0FBRTtHQUFDLEtBQUssTUFBSSxNQUFJLElBQUUsQ0FBQztHQUFHLElBQUksSUFBRSxHQUFFLElBQUUsRUFBRSxrQkFBaUIsSUFBRSxLQUFLLE1BQUksSUFBRSxDQUFDLElBQUUsR0FBRSxJQUFFLEVBQUUsZ0JBQWUsSUFBRSxLQUFLLE1BQUksSUFBRSxLQUFHO0dBQUUsT0FBTyxTQUFTLEdBQUUsR0FBRSxHQUFFO0lBQUMsS0FBSyxNQUFJLE1BQUksSUFBRTtJQUFHLElBQUksR0FBRSxHQUFFLElBQUU7S0FBQyxXQUFVO0tBQVMsa0JBQWlCLENBQUM7S0FBRSxTQUFRLE9BQU8sT0FBTyxDQUFDLEdBQUUsSUFBRyxDQUFDO0tBQUUsZUFBYyxDQUFDO0tBQUUsVUFBUztNQUFDLFdBQVU7TUFBRSxRQUFPO0tBQUM7S0FBRSxZQUFXLENBQUM7S0FBRSxRQUFPLENBQUM7SUFBQyxHQUFFLElBQUUsQ0FBQyxHQUFFLElBQUUsQ0FBQyxHQUFFLElBQUU7S0FBQyxPQUFNO0tBQUUsWUFBVyxTQUFTLEdBQUU7TUFBQyxJQUFJLElBQUUsY0FBWSxPQUFPLElBQUUsRUFBRSxFQUFFLE9BQU8sSUFBRTtNQUFFLEVBQUUsR0FBRSxFQUFFLFVBQVEsT0FBTyxPQUFPLENBQUMsR0FBRSxHQUFFLEVBQUUsU0FBUSxDQUFDLEdBQUUsRUFBRSxnQkFBYztPQUFDLFdBQVUsR0FBRyxDQUFDLElBQUUsR0FBRyxDQUFDLElBQUUsRUFBRSxpQkFBZSxHQUFHLEVBQUUsY0FBYyxJQUFFLENBQUM7T0FBRSxRQUFPLEdBQUcsQ0FBQztNQUFDO01BQUUsSUFBSSxHQUFFLEdBQUUsSUFBRSxTQUFTLEdBQUU7T0FBQyxJQUFJLElBQUUsR0FBRyxDQUFDO09BQUUsT0FBTyxHQUFHLE9BQU8sU0FBUyxHQUFFLEdBQUU7UUFBQyxPQUFPLEVBQUUsT0FBTyxFQUFFLE9BQU8sU0FBUyxHQUFFO1NBQUMsT0FBTyxFQUFFLFVBQVE7UUFBQyxDQUFDLENBQUM7T0FBQyxHQUFFLENBQUMsQ0FBQztNQUFDLEdBQUcsSUFBRSxDQUFDLENBQUMsQ0FBQyxPQUFPLEdBQUUsRUFBRSxRQUFRLFNBQVMsR0FBRSxJQUFFLEVBQUUsT0FBTyxTQUFTLEdBQUUsR0FBRTtPQUFDLElBQUksSUFBRSxFQUFFLEVBQUU7T0FBTSxPQUFPLEVBQUUsRUFBRSxRQUFNLElBQUUsT0FBTyxPQUFPLENBQUMsR0FBRSxHQUFFLEdBQUU7UUFBQyxTQUFRLE9BQU8sT0FBTyxDQUFDLEdBQUUsRUFBRSxTQUFRLEVBQUUsT0FBTztRQUFFLE1BQUssT0FBTyxPQUFPLENBQUMsR0FBRSxFQUFFLE1BQUssRUFBRSxJQUFJO09BQUMsQ0FBQyxJQUFFLEdBQUU7TUFBQyxHQUFFLENBQUMsQ0FBQyxHQUFFLE9BQU8sS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLFNBQVMsR0FBRTtPQUFDLE9BQU8sRUFBRTtNQUFFLENBQUMsRUFBRTtNQUFFLE9BQU8sRUFBRSxtQkFBaUIsRUFBRSxPQUFPLFNBQVMsR0FBRTtPQUFDLE9BQU8sRUFBRTtNQUFPLENBQUMsR0FBRSxFQUFFLGlCQUFpQixRQUFRLFNBQVMsR0FBRTtPQUFDLElBQUksSUFBRSxFQUFFLE1BQUssSUFBRSxFQUFFLFNBQVEsSUFBRSxLQUFLLE1BQUksSUFBRSxDQUFDLElBQUUsR0FBRSxJQUFFLEVBQUU7T0FBTyxJQUFHLGNBQVksT0FBTyxHQUFFO1FBQUMsSUFBSSxJQUFFLEVBQUU7U0FBQyxPQUFNO1NBQUUsTUFBSztTQUFFLFVBQVM7U0FBRSxTQUFRO1FBQUMsQ0FBQztRQUFFLEVBQUUsS0FBSyxLQUFHLFdBQVUsQ0FBQyxDQUFDO09BQUM7TUFBQyxDQUFDLEdBQUUsRUFBRSxPQUFPO0tBQUM7S0FBRSxhQUFZLFdBQVU7TUFBQyxJQUFHLENBQUMsR0FBRTtPQUFDLElBQUksSUFBRSxFQUFFLFVBQVMsSUFBRSxFQUFFLFdBQVUsSUFBRSxFQUFFO09BQU8sSUFBRyxHQUFHLEdBQUUsQ0FBQyxHQUFFO1FBQUMsRUFBRSxRQUFNO1NBQUMsV0FBVSxHQUFHLEdBQUUsR0FBRyxDQUFDLEdBQUUsWUFBVSxFQUFFLFFBQVEsUUFBUTtTQUFFLFFBQU8sR0FBRyxDQUFDO1FBQUMsR0FBRSxFQUFFLFFBQU0sQ0FBQyxHQUFFLEVBQUUsWUFBVSxFQUFFLFFBQVEsV0FBVSxFQUFFLGlCQUFpQixRQUFRLFNBQVMsR0FBRTtTQUFDLE9BQU8sRUFBRSxjQUFjLEVBQUUsUUFBTSxPQUFPLE9BQU8sQ0FBQyxHQUFFLEVBQUUsSUFBSTtRQUFDLENBQUM7UUFBRSxLQUFJLElBQUksSUFBRSxHQUFFLElBQUUsRUFBRSxpQkFBaUIsUUFBTyxLQUFJLElBQUcsQ0FBQyxNQUFJLEVBQUUsT0FBTTtTQUFDLElBQUksSUFBRSxFQUFFLGlCQUFpQixJQUFHLElBQUUsRUFBRSxJQUFHLElBQUUsRUFBRSxTQUFRLElBQUUsS0FBSyxNQUFJLElBQUUsQ0FBQyxJQUFFLEdBQUUsSUFBRSxFQUFFO1NBQUssY0FBWSxPQUFPLE1BQUksSUFBRSxFQUFFO1VBQUMsT0FBTTtVQUFFLFNBQVE7VUFBRSxNQUFLO1VBQUUsVUFBUztTQUFDLENBQUMsS0FBRztRQUFFLE9BQU0sRUFBRSxRQUFNLENBQUMsR0FBRSxJQUFFO09BQUU7TUFBQztLQUFDO0tBQUUsU0FBUSxJQUFFLFdBQVU7TUFBQyxPQUFPLElBQUksUUFBUSxTQUFTLEdBQUU7T0FBQyxFQUFFLFlBQVksR0FBRSxFQUFFLENBQUM7TUFBQyxDQUFDO0tBQUMsR0FBRSxXQUFVO01BQUMsT0FBTyxNQUFJLElBQUUsSUFBSSxRQUFRLFNBQVMsR0FBRTtPQUFDLFFBQVEsUUFBUSxDQUFDLENBQUMsS0FBSyxXQUFVO1FBQUMsSUFBRSxLQUFLLEdBQUUsRUFBRSxFQUFFLENBQUM7T0FBQyxDQUFDO01BQUMsQ0FBQyxJQUFHO0tBQUM7S0FBRyxTQUFRLFdBQVU7TUFBQyxFQUFFLEdBQUUsSUFBRSxDQUFDO0tBQUM7SUFBQztJQUFFLElBQUcsQ0FBQyxHQUFHLEdBQUUsQ0FBQyxHQUFFLE9BQU87SUFBRSxTQUFTLElBQUc7S0FBQyxFQUFFLFFBQVEsU0FBUyxHQUFFO01BQUMsT0FBTyxFQUFFO0tBQUMsQ0FBQyxHQUFFLElBQUUsQ0FBQztJQUFDO0lBQUMsT0FBTyxFQUFFLFdBQVcsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLEdBQUU7S0FBQyxDQUFDLEtBQUcsRUFBRSxpQkFBZSxFQUFFLGNBQWMsQ0FBQztJQUFDLENBQUMsR0FBRTtHQUFDO0VBQUM7RUFBQyxJQUFJLEtBQUcsR0FBRyxHQUFFLEtBQUcsR0FBRyxFQUFDLGtCQUFpQjtHQUFDO0dBQUc7R0FBRztHQUFHO0VBQUUsRUFBQyxDQUFDLEdBQUUsS0FBRyxHQUFHLEVBQUMsa0JBQWlCO0dBQUM7R0FBRztHQUFHO0dBQUc7R0FBRztHQUFHO0dBQUc7R0FBRztHQUFHO0VBQUUsRUFBQyxDQUFDO0VBQUUsTUFBTSxLQUFHLE9BQU8sT0FBTyxPQUFPLGVBQWU7R0FBQyxXQUFVO0dBQUssV0FBVTtHQUFHLFdBQVU7R0FBRyxZQUFXO0dBQUcsYUFBWTtHQUFHLE9BQU07R0FBRyxNQUFLO0dBQUcsZ0JBQWU7R0FBRyxZQUFXO0dBQUcsWUFBVztHQUFHLGFBQVk7R0FBRyxRQUFPO0dBQUcsaUJBQWdCO0dBQUcsZUFBYztHQUFHLGNBQWE7R0FBRyxrQkFBaUI7R0FBRyxrQkFBaUI7R0FBRyxnQkFBZTtHQUFHLEtBQUk7R0FBRyxnQkFBZTtHQUFHLE1BQUs7R0FBRyxNQUFLO0dBQUcsTUFBSztHQUFHLE1BQUs7R0FBRyxnQkFBZTtHQUFHLFFBQU87R0FBRyxZQUFXO0dBQUcsUUFBTztHQUFHLGlCQUFnQjtHQUFHLGVBQWM7R0FBRyxpQkFBZ0I7R0FBRyxNQUFLO0dBQUcsV0FBVTtHQUFHLE9BQU07R0FBRyxPQUFNO0dBQUcsS0FBSTtHQUFHLHFCQUFvQjtHQUFHLFVBQVM7R0FBRyxPQUFNO0VBQUUsR0FBRSxPQUFPLGFBQVksRUFBQyxPQUFNLFNBQVEsQ0FBQyxDQUFDLEdBQUUsS0FBRyxZQUFXLEtBQUcsZ0JBQWUsS0FBRyxhQUFZLEtBQUcsV0FBVSxLQUFHLGFBQVksS0FBRyxPQUFPLE1BQUssS0FBRyxTQUFTLE1BQUssS0FBRyxPQUFPLE1BQUssS0FBRyxRQUFRLE1BQUssS0FBRyxRQUFRLEtBQUssTUFBSyxLQUFHLFVBQVUsS0FBSyxNQUFLLEtBQUcsUUFBUSxLQUFLLE1BQUssS0FBRyxRQUFPLEtBQUcsK0RBQTRELEtBQUcsR0FBRyxHQUFHLEdBQUcsTUFBSyxLQUFHLGtCQUFpQixLQUFHLEVBQUUsSUFBRSxZQUFVLGFBQVksS0FBRyxFQUFFLElBQUUsY0FBWSxXQUFVLEtBQUcsRUFBRSxJQUFFLGVBQWEsZ0JBQWUsS0FBRyxFQUFFLElBQUUsaUJBQWUsY0FBYSxLQUFHLEVBQUUsSUFBRSxlQUFhLGVBQWMsS0FBRyxFQUFFLElBQUUsZ0JBQWMsY0FBYSxLQUFHO0dBQUMsV0FBVSxDQUFDO0dBQUUsVUFBUztHQUFrQixTQUFRO0dBQVUsUUFBTyxDQUFDLEdBQUUsQ0FBQztHQUFFLGNBQWE7R0FBSyxXQUFVO0VBQVEsR0FBRSxLQUFHO0dBQUMsV0FBVTtHQUFtQixVQUFTO0dBQW1CLFNBQVE7R0FBUyxRQUFPO0dBQTBCLGNBQWE7R0FBeUIsV0FBVTtFQUF5QjtFQUFFLE1BQU0sV0FBVyxFQUFDO0dBQUMsWUFBWSxHQUFFLEdBQUU7SUFBQyxNQUFNLEdBQUUsQ0FBQyxHQUFFLEtBQUssVUFBUSxNQUFLLEtBQUssVUFBUSxLQUFLLFNBQVMsWUFBVyxLQUFLLFFBQU0sRUFBRSxLQUFLLEtBQUssVUFBUyxFQUFFLENBQUMsQ0FBQyxNQUFJLEVBQUUsS0FBSyxLQUFLLFVBQVMsRUFBRSxDQUFDLENBQUMsTUFBSSxFQUFFLFFBQVEsSUFBRyxLQUFLLE9BQU8sR0FBRSxLQUFLLFlBQVUsS0FBSyxjQUFjO0dBQUM7R0FBQyxXQUFXLFVBQVM7SUFBQyxPQUFPO0dBQUU7R0FBQyxXQUFXLGNBQWE7SUFBQyxPQUFPO0dBQUU7R0FBQyxXQUFXLE9BQU07SUFBQyxPQUFPO0dBQUU7R0FBQyxTQUFRO0lBQUMsT0FBTyxLQUFLLFNBQVMsSUFBRSxLQUFLLEtBQUssSUFBRSxLQUFLLEtBQUs7R0FBQztHQUFDLE9BQU07SUFBQyxJQUFHLEVBQUUsS0FBSyxRQUFRLEtBQUcsS0FBSyxTQUFTLEdBQUU7SUFBTyxNQUFNLElBQUUsRUFBQyxlQUFjLEtBQUssU0FBUTtJQUFFLElBQUcsQ0FBQyxFQUFFLFFBQVEsS0FBSyxVQUFTLElBQUcsQ0FBQyxDQUFDLENBQUMsa0JBQWlCO0tBQUMsSUFBRyxLQUFLLGNBQWMsR0FBRSxrQkFBaUIsU0FBUyxtQkFBaUIsQ0FBQyxLQUFLLFFBQVEsUUFBUSxhQUFhLEdBQUUsS0FBSSxNQUFNLEtBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxHQUFHLFNBQVMsS0FBSyxRQUFRLEdBQUUsRUFBRSxHQUFHLEdBQUUsYUFBWSxDQUFDO0tBQUUsS0FBSyxTQUFTLE1BQU0sR0FBRSxLQUFLLFNBQVMsYUFBYSxpQkFBZ0IsQ0FBQyxDQUFDLEdBQUUsS0FBSyxNQUFNLFVBQVUsSUFBSSxFQUFFLEdBQUUsS0FBSyxTQUFTLFVBQVUsSUFBSSxFQUFFLEdBQUUsRUFBRSxRQUFRLEtBQUssVUFBUyxJQUFHLENBQUM7SUFBQztHQUFDO0dBQUMsT0FBTTtJQUFDLElBQUcsRUFBRSxLQUFLLFFBQVEsS0FBRyxDQUFDLEtBQUssU0FBUyxHQUFFO0lBQU8sTUFBTSxJQUFFLEVBQUMsZUFBYyxLQUFLLFNBQVE7SUFBRSxLQUFLLGNBQWMsQ0FBQztHQUFDO0dBQUMsVUFBUztJQUFDLEtBQUssV0FBUyxLQUFLLFFBQVEsUUFBUSxHQUFFLE1BQU0sUUFBUTtHQUFDO0dBQUMsU0FBUTtJQUFDLEtBQUssWUFBVSxLQUFLLGNBQWMsR0FBRSxLQUFLLFdBQVMsS0FBSyxRQUFRLE9BQU87R0FBQztHQUFDLGNBQWMsR0FBRTtJQUFDLElBQUcsQ0FBQyxFQUFFLFFBQVEsS0FBSyxVQUFTLElBQUcsQ0FBQyxDQUFDLENBQUMsa0JBQWlCO0tBQUMsSUFBRyxrQkFBaUIsU0FBUyxpQkFBZ0IsS0FBSSxNQUFNLEtBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxHQUFHLFNBQVMsS0FBSyxRQUFRLEdBQUUsRUFBRSxJQUFJLEdBQUUsYUFBWSxDQUFDO0tBQUUsS0FBSyxXQUFTLEtBQUssUUFBUSxRQUFRLEdBQUUsS0FBSyxNQUFNLFVBQVUsT0FBTyxFQUFFLEdBQUUsS0FBSyxTQUFTLFVBQVUsT0FBTyxFQUFFLEdBQUUsS0FBSyxTQUFTLGFBQWEsaUJBQWdCLE9BQU8sR0FBRSxFQUFFLG9CQUFvQixLQUFLLE9BQU0sUUFBUSxHQUFFLEVBQUUsUUFBUSxLQUFLLFVBQVMsSUFBRyxDQUFDO0lBQUM7R0FBQztHQUFDLFdBQVcsR0FBRTtJQUFDLElBQUcsWUFBVSxRQUFPLElBQUUsTUFBTSxXQUFXLENBQUMsRUFBQSxDQUFHLGFBQVcsQ0FBQyxFQUFFLEVBQUUsU0FBUyxLQUFHLGNBQVksT0FBTyxFQUFFLFVBQVUsdUJBQXNCLE1BQU0sSUFBSSxVQUFVLEdBQUcsR0FBRyxZQUFZLEVBQUUsK0ZBQStGO0lBQUUsT0FBTztHQUFDO0dBQUMsZ0JBQWU7SUFBQyxJQUFHLEtBQUssTUFBSSxJQUFHLE1BQU0sSUFBSSxVQUFVLHVFQUF1RTtJQUFFLElBQUksSUFBRSxLQUFLO0lBQVMsYUFBVyxLQUFLLFFBQVEsWUFBVSxJQUFFLEtBQUssVUFBUSxFQUFFLEtBQUssUUFBUSxTQUFTLElBQUUsSUFBRSxFQUFFLEtBQUssUUFBUSxTQUFTLElBQUUsWUFBVSxPQUFPLEtBQUssUUFBUSxjQUFZLElBQUUsS0FBSyxRQUFRO0lBQVcsTUFBTSxJQUFFLEtBQUssaUJBQWlCO0lBQUUsS0FBSyxVQUFRLEdBQUcsR0FBRSxLQUFLLE9BQU0sQ0FBQztHQUFDO0dBQUMsV0FBVTtJQUFDLE9BQU8sS0FBSyxNQUFNLFVBQVUsU0FBUyxFQUFFO0dBQUM7R0FBQyxnQkFBZTtJQUFDLE1BQU0sSUFBRSxLQUFLO0lBQVEsSUFBRyxFQUFFLFVBQVUsU0FBUyxTQUFTLEdBQUUsT0FBTztJQUFHLElBQUcsRUFBRSxVQUFVLFNBQVMsV0FBVyxHQUFFLE9BQU87SUFBRyxJQUFHLEVBQUUsVUFBVSxTQUFTLGVBQWUsR0FBRSxPQUFNO0lBQU0sSUFBRyxFQUFFLFVBQVUsU0FBUyxpQkFBaUIsR0FBRSxPQUFNO0lBQVMsTUFBTSxJQUFFLFVBQVEsaUJBQWlCLEtBQUssS0FBSyxDQUFDLENBQUMsaUJBQWlCLGVBQWUsQ0FBQyxDQUFDLEtBQUs7SUFBRSxPQUFPLEVBQUUsVUFBVSxTQUFTLFFBQVEsSUFBRSxJQUFFLEtBQUcsS0FBRyxJQUFFLEtBQUc7R0FBRTtHQUFDLGdCQUFlO0lBQUMsT0FBTyxTQUFPLEtBQUssU0FBUyxRQUFRLFNBQVM7R0FBQztHQUFDLGFBQVk7SUFBQyxNQUFLLEVBQUMsUUFBTyxNQUFHLEtBQUs7SUFBUSxPQUFNLFlBQVUsT0FBTyxJQUFFLEVBQUUsTUFBTSxHQUFHLENBQUMsQ0FBQyxLQUFJLE1BQUcsT0FBTyxTQUFTLEdBQUUsRUFBRSxDQUFDLElBQUUsY0FBWSxPQUFPLEtBQUUsTUFBRyxFQUFFLEdBQUUsS0FBSyxRQUFRLElBQUU7R0FBQztHQUFDLG1CQUFrQjtJQUFDLE1BQU0sSUFBRTtLQUFDLFdBQVUsS0FBSyxjQUFjO0tBQUUsV0FBVSxDQUFDO01BQUMsTUFBSztNQUFrQixTQUFRLEVBQUMsVUFBUyxLQUFLLFFBQVEsU0FBUTtLQUFDLEdBQUU7TUFBQyxNQUFLO01BQVMsU0FBUSxFQUFDLFFBQU8sS0FBSyxXQUFXLEVBQUM7S0FBQyxDQUFDO0lBQUM7SUFBRSxRQUFPLEtBQUssYUFBVyxhQUFXLEtBQUssUUFBUSxhQUFXLEVBQUUsaUJBQWlCLEtBQUssT0FBTSxVQUFTLFFBQVEsR0FBRSxFQUFFLFlBQVUsQ0FBQztLQUFDLE1BQUs7S0FBYyxTQUFRLENBQUM7SUFBQyxDQUFDLElBQUc7S0FBQyxHQUFHO0tBQUUsR0FBRyxFQUFFLEtBQUssUUFBUSxjQUFhLENBQUMsS0FBSyxHQUFFLENBQUMsQ0FBQztJQUFDO0dBQUM7R0FBQyxnQkFBZ0IsRUFBQyxLQUFJLEdBQUUsUUFBTyxLQUFHO0lBQUMsTUFBTSxJQUFFLEVBQUUsS0FBSywrREFBOEQsS0FBSyxLQUFLLENBQUMsQ0FBQyxRQUFPLE1BQUcsRUFBRSxDQUFDLENBQUM7SUFBRSxFQUFFLFVBQVEsRUFBRSxHQUFFLEdBQUUsTUFBSSxJQUFHLENBQUMsRUFBRSxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTTtHQUFDO0dBQUMsT0FBTyxnQkFBZ0IsR0FBRTtJQUFDLE9BQU8sS0FBSyxLQUFLLFdBQVU7S0FBQyxNQUFNLElBQUUsR0FBRyxvQkFBb0IsTUFBSyxDQUFDO0tBQUUsSUFBRyxZQUFVLE9BQU8sR0FBRTtNQUFDLElBQUcsS0FBSyxNQUFJLEVBQUUsSUFBRyxNQUFNLElBQUksVUFBVSxvQkFBb0IsRUFBRSxFQUFFO01BQUUsRUFBRSxFQUFFLENBQUM7S0FBQztJQUFDLENBQUM7R0FBQztHQUFDLE9BQU8sV0FBVyxHQUFFO0lBQUMsSUFBRyxNQUFJLEVBQUUsVUFBUSxZQUFVLEVBQUUsUUFBTSxVQUFRLEVBQUUsS0FBSTtJQUFPLE1BQU0sSUFBRSxFQUFFLEtBQUssRUFBRTtJQUFFLEtBQUksTUFBTSxLQUFLLEdBQUU7S0FBQyxNQUFNLElBQUUsR0FBRyxZQUFZLENBQUM7S0FBRSxJQUFHLENBQUMsS0FBRyxDQUFDLE1BQUksRUFBRSxRQUFRLFdBQVU7S0FBUyxNQUFNLElBQUUsRUFBRSxhQUFhLEdBQUUsSUFBRSxFQUFFLFNBQVMsRUFBRSxLQUFLO0tBQUUsSUFBRyxFQUFFLFNBQVMsRUFBRSxRQUFRLEtBQUcsYUFBVyxFQUFFLFFBQVEsYUFBVyxDQUFDLEtBQUcsY0FBWSxFQUFFLFFBQVEsYUFBVyxHQUFFO0tBQVMsSUFBRyxFQUFFLE1BQU0sU0FBUyxFQUFFLE1BQU0sTUFBSSxZQUFVLEVBQUUsUUFBTSxVQUFRLEVBQUUsT0FBSyxxQ0FBcUMsS0FBSyxFQUFFLE9BQU8sT0FBTyxJQUFHO0tBQVMsTUFBTSxJQUFFLEVBQUMsZUFBYyxFQUFFLFNBQVE7S0FBRSxZQUFVLEVBQUUsU0FBTyxFQUFFLGFBQVcsSUFBRyxFQUFFLGNBQWMsQ0FBQztJQUFDO0dBQUM7R0FBQyxPQUFPLHNCQUFzQixHQUFFO0lBQUMsTUFBTSxJQUFFLGtCQUFrQixLQUFLLEVBQUUsT0FBTyxPQUFPLEdBQUUsSUFBRSxhQUFXLEVBQUUsS0FBSSxJQUFFLENBQUMsSUFBRyxFQUFFLENBQUMsQ0FBQyxTQUFTLEVBQUUsR0FBRztJQUFFLElBQUcsQ0FBQyxLQUFHLENBQUMsR0FBRTtJQUFPLElBQUcsS0FBRyxDQUFDLEdBQUU7SUFBTyxFQUFFLGVBQWU7SUFBRSxNQUFNLElBQUUsS0FBSyxRQUFRLEVBQUUsSUFBRSxPQUFLLEVBQUUsS0FBSyxNQUFLLEVBQUUsQ0FBQyxDQUFDLE1BQUksRUFBRSxLQUFLLE1BQUssRUFBRSxDQUFDLENBQUMsTUFBSSxFQUFFLFFBQVEsSUFBRyxFQUFFLGVBQWUsVUFBVSxHQUFFLElBQUUsR0FBRyxvQkFBb0IsQ0FBQztJQUFFLElBQUcsR0FBRSxPQUFPLEVBQUUsZ0JBQWdCLEdBQUUsRUFBRSxLQUFLLEdBQUUsS0FBSyxFQUFFLGdCQUFnQixDQUFDO0lBQUUsRUFBRSxTQUFTLE1BQUksRUFBRSxnQkFBZ0IsR0FBRSxFQUFFLEtBQUssR0FBRSxFQUFFLE1BQU07R0FBRTtFQUFDO0VBQUMsRUFBRSxHQUFHLFVBQVMsSUFBRyxJQUFHLEdBQUcscUJBQXFCLEdBQUUsRUFBRSxHQUFHLFVBQVMsSUFBRyxJQUFHLEdBQUcscUJBQXFCLEdBQUUsRUFBRSxHQUFHLFVBQVMsSUFBRyxHQUFHLFVBQVUsR0FBRSxFQUFFLEdBQUcsVUFBUyxJQUFHLEdBQUcsVUFBVSxHQUFFLEVBQUUsR0FBRyxVQUFTLElBQUcsSUFBRyxTQUFTLEdBQUU7R0FBQyxFQUFFLGVBQWUsR0FBRSxHQUFHLG9CQUFvQixJQUFJLENBQUMsQ0FBQyxPQUFPO0VBQUMsQ0FBQyxHQUFFLEVBQUUsRUFBRTtFQUFFLE1BQU0sS0FBRyxZQUFXLEtBQUcsUUFBTyxLQUFHLGdCQUFnQixNQUFLLEtBQUc7R0FBQyxXQUFVO0dBQWlCLGVBQWM7R0FBSyxZQUFXLENBQUM7R0FBRSxXQUFVLENBQUM7R0FBRSxhQUFZO0VBQU0sR0FBRSxLQUFHO0dBQUMsV0FBVTtHQUFTLGVBQWM7R0FBa0IsWUFBVztHQUFVLFdBQVU7R0FBVSxhQUFZO0VBQWtCO0VBQUUsTUFBTSxXQUFXLEVBQUM7R0FBQyxZQUFZLEdBQUU7SUFBQyxNQUFNLEdBQUUsS0FBSyxVQUFRLEtBQUssV0FBVyxDQUFDLEdBQUUsS0FBSyxjQUFZLENBQUMsR0FBRSxLQUFLLFdBQVM7R0FBSTtHQUFDLFdBQVcsVUFBUztJQUFDLE9BQU87R0FBRTtHQUFDLFdBQVcsY0FBYTtJQUFDLE9BQU87R0FBRTtHQUFDLFdBQVcsT0FBTTtJQUFDLE9BQU87R0FBRTtHQUFDLEtBQUssR0FBRTtJQUFDLElBQUcsQ0FBQyxLQUFLLFFBQVEsV0FBVSxPQUFPLEtBQUssRUFBRSxDQUFDO0lBQUUsS0FBSyxRQUFRO0lBQUUsTUFBTSxJQUFFLEtBQUssWUFBWTtJQUFFLEtBQUssUUFBUSxjQUFZLEVBQUUsQ0FBQyxHQUFFLEVBQUUsVUFBVSxJQUFJLEVBQUUsR0FBRSxLQUFLLHdCQUFzQjtLQUFDLEVBQUUsQ0FBQztJQUFDLENBQUM7R0FBQztHQUFDLEtBQUssR0FBRTtJQUFDLEtBQUssUUFBUSxhQUFXLEtBQUssWUFBWSxDQUFDLENBQUMsVUFBVSxPQUFPLEVBQUUsR0FBRSxLQUFLLHdCQUFzQjtLQUFDLEtBQUssUUFBUSxHQUFFLEVBQUUsQ0FBQztJQUFDLENBQUMsS0FBRyxFQUFFLENBQUM7R0FBQztHQUFDLFVBQVM7SUFBQyxLQUFLLGdCQUFjLEVBQUUsSUFBSSxLQUFLLFVBQVMsRUFBRSxHQUFFLEtBQUssU0FBUyxPQUFPLEdBQUUsS0FBSyxjQUFZLENBQUM7R0FBRTtHQUFDLGNBQWE7SUFBQyxJQUFHLENBQUMsS0FBSyxVQUFTO0tBQUMsTUFBTSxJQUFFLFNBQVMsY0FBYyxLQUFLO0tBQUUsRUFBRSxZQUFVLEtBQUssUUFBUSxXQUFVLEtBQUssUUFBUSxjQUFZLEVBQUUsVUFBVSxJQUFJLE1BQU0sR0FBRSxLQUFLLFdBQVM7SUFBQztJQUFDLE9BQU8sS0FBSztHQUFRO0dBQUMsa0JBQWtCLEdBQUU7SUFBQyxPQUFPLEVBQUUsY0FBWSxFQUFFLEVBQUUsV0FBVyxHQUFFO0dBQUM7R0FBQyxVQUFTO0lBQUMsSUFBRyxLQUFLLGFBQVk7SUFBTyxNQUFNLElBQUUsS0FBSyxZQUFZO0lBQUUsS0FBSyxRQUFRLFlBQVksT0FBTyxDQUFDLEdBQUUsRUFBRSxHQUFHLEdBQUUsVUFBTztLQUFDLEVBQUUsS0FBSyxRQUFRLGFBQWE7SUFBQyxDQUFDLEdBQUUsS0FBSyxjQUFZLENBQUM7R0FBQztHQUFDLGtCQUFrQixHQUFFO0lBQUMsRUFBRSxHQUFFLEtBQUssWUFBWSxHQUFFLEtBQUssUUFBUSxVQUFVO0dBQUM7RUFBQztFQUFDLE1BQU0sS0FBRyxpQkFBZ0IsS0FBRyxVQUFVLE1BQUssS0FBRyxjQUFjLE1BQUssS0FBRyxZQUFXLEtBQUc7R0FBQyxXQUFVLENBQUM7R0FBRSxhQUFZO0VBQUksR0FBRSxLQUFHO0dBQUMsV0FBVTtHQUFVLGFBQVk7RUFBUztFQUFFLE1BQU0sV0FBVyxFQUFDO0dBQUMsWUFBWSxHQUFFO0lBQUMsTUFBTSxHQUFFLEtBQUssVUFBUSxLQUFLLFdBQVcsQ0FBQyxHQUFFLEtBQUssWUFBVSxDQUFDLEdBQUUsS0FBSyx1QkFBcUI7R0FBSTtHQUFDLFdBQVcsVUFBUztJQUFDLE9BQU87R0FBRTtHQUFDLFdBQVcsY0FBYTtJQUFDLE9BQU87R0FBRTtHQUFDLFdBQVcsT0FBTTtJQUFDLE9BQU07R0FBVztHQUFDLFdBQVU7SUFBQyxLQUFLLGNBQVksS0FBSyxRQUFRLGFBQVcsS0FBSyxRQUFRLFlBQVksTUFBTSxHQUFFLEVBQUUsSUFBSSxVQUFTLEVBQUUsR0FBRSxFQUFFLEdBQUcsVUFBUyxLQUFHLE1BQUcsS0FBSyxlQUFlLENBQUMsQ0FBQyxHQUFFLEVBQUUsR0FBRyxVQUFTLEtBQUcsTUFBRyxLQUFLLGVBQWUsQ0FBQyxDQUFDLEdBQUUsS0FBSyxZQUFVLENBQUM7R0FBRTtHQUFDLGFBQVk7SUFBQyxLQUFLLGNBQVksS0FBSyxZQUFVLENBQUMsR0FBRSxFQUFFLElBQUksVUFBUyxFQUFFO0dBQUU7R0FBQyxlQUFlLEdBQUU7SUFBQyxNQUFLLEVBQUMsYUFBWSxNQUFHLEtBQUs7SUFBUSxJQUFHLEVBQUUsV0FBUyxZQUFVLEVBQUUsV0FBUyxLQUFHLEVBQUUsU0FBUyxFQUFFLE1BQU0sR0FBRTtJQUFPLE1BQU0sSUFBRSxFQUFFLGtCQUFrQixDQUFDO0lBQUUsTUFBSSxFQUFFLFNBQU8sRUFBRSxNQUFNLElBQUUsS0FBSyx5QkFBdUIsS0FBRyxFQUFFLEVBQUUsU0FBTyxFQUFFLENBQUMsTUFBTSxJQUFFLEVBQUUsRUFBRSxDQUFDLE1BQU07R0FBQztHQUFDLGVBQWUsR0FBRTtJQUFDLFVBQVEsRUFBRSxRQUFNLEtBQUssdUJBQXFCLEVBQUUsV0FBUyxLQUFHO0dBQVU7RUFBQztFQUFDLE1BQU0sS0FBRyxxREFBb0QsS0FBRyxlQUFjLEtBQUcsaUJBQWdCLEtBQUc7RUFBZSxNQUFNLEdBQUU7R0FBQyxjQUFhO0lBQUMsS0FBSyxXQUFTLFNBQVM7R0FBSTtHQUFDLFdBQVU7SUFBQyxNQUFNLElBQUUsU0FBUyxnQkFBZ0I7SUFBWSxPQUFPLEtBQUssSUFBSSxPQUFPLGFBQVcsQ0FBQztHQUFDO0dBQUMsT0FBTTtJQUFDLE1BQU0sSUFBRSxLQUFLLFNBQVM7SUFBRSxLQUFLLGlCQUFpQixHQUFFLEtBQUssc0JBQXNCLEtBQUssVUFBUyxLQUFHLE1BQUcsSUFBRSxDQUFDLEdBQUUsS0FBSyxzQkFBc0IsSUFBRyxLQUFHLE1BQUcsSUFBRSxDQUFDLEdBQUUsS0FBSyxzQkFBc0IsSUFBRyxLQUFHLE1BQUcsSUFBRSxDQUFDO0dBQUM7R0FBQyxRQUFPO0lBQUMsS0FBSyx3QkFBd0IsS0FBSyxVQUFTLFVBQVUsR0FBRSxLQUFLLHdCQUF3QixLQUFLLFVBQVMsRUFBRSxHQUFFLEtBQUssd0JBQXdCLElBQUcsRUFBRSxHQUFFLEtBQUssd0JBQXdCLElBQUcsRUFBRTtHQUFDO0dBQUMsZ0JBQWU7SUFBQyxPQUFPLEtBQUssU0FBUyxJQUFFO0dBQUM7R0FBQyxtQkFBa0I7SUFBQyxLQUFLLHNCQUFzQixLQUFLLFVBQVMsVUFBVSxHQUFFLEtBQUssU0FBUyxNQUFNLFdBQVM7R0FBUTtHQUFDLHNCQUFzQixHQUFFLEdBQUUsR0FBRTtJQUFDLE1BQU0sSUFBRSxLQUFLLFNBQVM7SUFBRSxLQUFLLDJCQUEyQixJQUFFLE1BQUc7S0FBQyxJQUFHLE1BQUksS0FBSyxZQUFVLE9BQU8sYUFBVyxFQUFFLGNBQVksR0FBRTtLQUFPLEtBQUssc0JBQXNCLEdBQUUsQ0FBQztLQUFFLE1BQU0sSUFBRSxPQUFPLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQztLQUFFLEVBQUUsTUFBTSxZQUFZLEdBQUUsR0FBRyxFQUFFLE9BQU8sV0FBVyxDQUFDLENBQUMsRUFBRSxHQUFHO0lBQUMsQ0FBQztHQUFDO0dBQUMsc0JBQXNCLEdBQUUsR0FBRTtJQUFDLE1BQU0sSUFBRSxFQUFFLE1BQU0saUJBQWlCLENBQUM7SUFBRSxLQUFHLEVBQUUsaUJBQWlCLEdBQUUsR0FBRSxDQUFDO0dBQUM7R0FBQyx3QkFBd0IsR0FBRSxHQUFFO0lBQUMsS0FBSywyQkFBMkIsSUFBRSxNQUFHO0tBQUMsTUFBTSxJQUFFLEVBQUUsaUJBQWlCLEdBQUUsQ0FBQztLQUFFLFNBQU8sS0FBRyxFQUFFLG9CQUFvQixHQUFFLENBQUMsR0FBRSxFQUFFLE1BQU0sWUFBWSxHQUFFLENBQUMsS0FBRyxFQUFFLE1BQU0sZUFBZSxDQUFDO0lBQUMsQ0FBQztHQUFDO0dBQUMsMkJBQTJCLEdBQUUsR0FBRTtJQUFDLElBQUcsRUFBRSxDQUFDLEdBQUUsRUFBRSxDQUFDO1NBQU8sS0FBSSxNQUFNLEtBQUssRUFBRSxLQUFLLEdBQUUsS0FBSyxRQUFRLEdBQUUsRUFBRSxDQUFDO0dBQUM7RUFBQztFQUFDLE1BQU0sS0FBRyxhQUFZLEtBQUcsT0FBTyxNQUFLLEtBQUcsZ0JBQWdCLE1BQUssS0FBRyxTQUFTLE1BQUssS0FBRyxPQUFPLE1BQUssS0FBRyxRQUFRLE1BQUssS0FBRyxTQUFTLE1BQUssS0FBRyxnQkFBZ0IsTUFBSyxLQUFHLG9CQUFvQixNQUFLLEtBQUcsa0JBQWtCLE1BQUssS0FBRyxRQUFRLEdBQUcsWUFBVyxLQUFHLGNBQWEsS0FBRyxRQUFPLEtBQUcsZ0JBQWUsS0FBRztHQUFDLFVBQVMsQ0FBQztHQUFFLE9BQU0sQ0FBQztHQUFFLFVBQVMsQ0FBQztFQUFDLEdBQUUsS0FBRztHQUFDLFVBQVM7R0FBbUIsT0FBTTtHQUFVLFVBQVM7RUFBUztFQUFFLE1BQU0sV0FBVyxFQUFDO0dBQUMsWUFBWSxHQUFFLEdBQUU7SUFBQyxNQUFNLEdBQUUsQ0FBQyxHQUFFLEtBQUssVUFBUSxFQUFFLFFBQVEsaUJBQWdCLEtBQUssUUFBUSxHQUFFLEtBQUssWUFBVSxLQUFLLG9CQUFvQixHQUFFLEtBQUssYUFBVyxLQUFLLHFCQUFxQixHQUFFLEtBQUssV0FBUyxDQUFDLEdBQUUsS0FBSyxtQkFBaUIsQ0FBQyxHQUFFLEtBQUssYUFBVyxJQUFJLEdBQUMsR0FBRSxLQUFLLG1CQUFtQjtHQUFDO0dBQUMsV0FBVyxVQUFTO0lBQUMsT0FBTztHQUFFO0dBQUMsV0FBVyxjQUFhO0lBQUMsT0FBTztHQUFFO0dBQUMsV0FBVyxPQUFNO0lBQUMsT0FBTTtHQUFPO0dBQUMsT0FBTyxHQUFFO0lBQUMsT0FBTyxLQUFLLFdBQVMsS0FBSyxLQUFLLElBQUUsS0FBSyxLQUFLLENBQUM7R0FBQztHQUFDLEtBQUssR0FBRTtJQUFDLEtBQUssWUFBVSxLQUFLLG9CQUFrQixFQUFFLFFBQVEsS0FBSyxVQUFTLElBQUcsRUFBQyxlQUFjLEVBQUMsQ0FBQyxDQUFDLENBQUMscUJBQW1CLEtBQUssV0FBUyxDQUFDLEdBQUUsS0FBSyxtQkFBaUIsQ0FBQyxHQUFFLEtBQUssV0FBVyxLQUFLLEdBQUUsU0FBUyxLQUFLLFVBQVUsSUFBSSxFQUFFLEdBQUUsS0FBSyxjQUFjLEdBQUUsS0FBSyxVQUFVLFdBQVMsS0FBSyxhQUFhLENBQUMsQ0FBQztHQUFFO0dBQUMsT0FBTTtJQUFDLEtBQUssWUFBVSxDQUFDLEtBQUsscUJBQW1CLEVBQUUsUUFBUSxLQUFLLFVBQVMsRUFBRSxDQUFDLENBQUMscUJBQW1CLEtBQUssV0FBUyxDQUFDLEdBQUUsS0FBSyxtQkFBaUIsQ0FBQyxHQUFFLEtBQUssV0FBVyxXQUFXLEdBQUUsS0FBSyxTQUFTLFVBQVUsT0FBTyxFQUFFLEdBQUUsS0FBSyxxQkFBbUIsS0FBSyxXQUFXLEdBQUUsS0FBSyxVQUFTLEtBQUssWUFBWSxDQUFDO0dBQUc7R0FBQyxVQUFTO0lBQUMsRUFBRSxJQUFJLFFBQU8sRUFBRSxHQUFFLEVBQUUsSUFBSSxLQUFLLFNBQVEsRUFBRSxHQUFFLEtBQUssVUFBVSxRQUFRLEdBQUUsS0FBSyxXQUFXLFdBQVcsR0FBRSxNQUFNLFFBQVE7R0FBQztHQUFDLGVBQWM7SUFBQyxLQUFLLGNBQWM7R0FBQztHQUFDLHNCQUFxQjtJQUFDLE9BQU8sSUFBSSxHQUFHO0tBQUMsV0FBVSxRQUFRLEtBQUssUUFBUSxRQUFRO0tBQUUsWUFBVyxLQUFLLFlBQVk7SUFBQyxDQUFDO0dBQUM7R0FBQyx1QkFBc0I7SUFBQyxPQUFPLElBQUksR0FBRyxFQUFDLGFBQVksS0FBSyxTQUFRLENBQUM7R0FBQztHQUFDLGFBQWEsR0FBRTtJQUFDLFNBQVMsS0FBSyxTQUFTLEtBQUssUUFBUSxLQUFHLFNBQVMsS0FBSyxPQUFPLEtBQUssUUFBUSxHQUFFLEtBQUssU0FBUyxNQUFNLFVBQVEsU0FBUSxLQUFLLFNBQVMsZ0JBQWdCLGFBQWEsR0FBRSxLQUFLLFNBQVMsYUFBYSxjQUFhLENBQUMsQ0FBQyxHQUFFLEtBQUssU0FBUyxhQUFhLFFBQU8sUUFBUSxHQUFFLEtBQUssU0FBUyxZQUFVO0lBQUUsTUFBTSxJQUFFLEVBQUUsUUFBUSxlQUFjLEtBQUssT0FBTztJQUFFLE1BQUksRUFBRSxZQUFVLElBQUcsRUFBRSxLQUFLLFFBQVEsR0FBRSxLQUFLLFNBQVMsVUFBVSxJQUFJLEVBQUUsR0FBRSxLQUFLLHFCQUFtQjtLQUFDLEtBQUssUUFBUSxTQUFPLEtBQUssV0FBVyxTQUFTLEdBQUUsS0FBSyxtQkFBaUIsQ0FBQyxHQUFFLEVBQUUsUUFBUSxLQUFLLFVBQVMsSUFBRyxFQUFDLGVBQWMsRUFBQyxDQUFDO0lBQUMsR0FBRSxLQUFLLFNBQVEsS0FBSyxZQUFZLENBQUM7R0FBQztHQUFDLHFCQUFvQjtJQUFDLEVBQUUsR0FBRyxLQUFLLFVBQVMsS0FBRyxNQUFHO0tBQUMsYUFBVyxFQUFFLFFBQU0sS0FBSyxRQUFRLFdBQVMsS0FBSyxLQUFLLElBQUUsS0FBSywyQkFBMkI7SUFBRSxDQUFDLEdBQUUsRUFBRSxHQUFHLFFBQU8sVUFBTztLQUFDLEtBQUssWUFBVSxDQUFDLEtBQUssb0JBQWtCLEtBQUssY0FBYztJQUFDLENBQUMsR0FBRSxFQUFFLEdBQUcsS0FBSyxVQUFTLEtBQUcsTUFBRztLQUFDLEVBQUUsSUFBSSxLQUFLLFVBQVMsS0FBRyxNQUFHO01BQUMsS0FBSyxhQUFXLEVBQUUsVUFBUSxLQUFLLGFBQVcsRUFBRSxXQUFTLGFBQVcsS0FBSyxRQUFRLFdBQVMsS0FBSyxRQUFRLFlBQVUsS0FBSyxLQUFLLElBQUUsS0FBSywyQkFBMkI7S0FBRSxDQUFDO0lBQUMsQ0FBQztHQUFDO0dBQUMsYUFBWTtJQUFDLEtBQUssU0FBUyxNQUFNLFVBQVEsUUFBTyxLQUFLLFNBQVMsYUFBYSxlQUFjLENBQUMsQ0FBQyxHQUFFLEtBQUssU0FBUyxnQkFBZ0IsWUFBWSxHQUFFLEtBQUssU0FBUyxnQkFBZ0IsTUFBTSxHQUFFLEtBQUssbUJBQWlCLENBQUMsR0FBRSxLQUFLLFVBQVUsV0FBUztLQUFDLFNBQVMsS0FBSyxVQUFVLE9BQU8sRUFBRSxHQUFFLEtBQUssa0JBQWtCLEdBQUUsS0FBSyxXQUFXLE1BQU0sR0FBRSxFQUFFLFFBQVEsS0FBSyxVQUFTLEVBQUU7SUFBQyxDQUFDO0dBQUM7R0FBQyxjQUFhO0lBQUMsT0FBTyxLQUFLLFNBQVMsVUFBVSxTQUFTLE1BQU07R0FBQztHQUFDLDZCQUE0QjtJQUFDLElBQUcsRUFBRSxRQUFRLEtBQUssVUFBUyxFQUFFLENBQUMsQ0FBQyxrQkFBaUI7SUFBTyxNQUFNLElBQUUsS0FBSyxTQUFTLGVBQWEsU0FBUyxnQkFBZ0IsY0FBYSxJQUFFLEtBQUssU0FBUyxNQUFNO0lBQVUsYUFBVyxLQUFHLEtBQUssU0FBUyxVQUFVLFNBQVMsRUFBRSxNQUFJLE1BQUksS0FBSyxTQUFTLE1BQU0sWUFBVSxXQUFVLEtBQUssU0FBUyxVQUFVLElBQUksRUFBRSxHQUFFLEtBQUsscUJBQW1CO0tBQUMsS0FBSyxTQUFTLFVBQVUsT0FBTyxFQUFFLEdBQUUsS0FBSyxxQkFBbUI7TUFBQyxLQUFLLFNBQVMsTUFBTSxZQUFVO0tBQUMsR0FBRSxLQUFLLE9BQU87SUFBQyxHQUFFLEtBQUssT0FBTyxHQUFFLEtBQUssU0FBUyxNQUFNO0dBQUU7R0FBQyxnQkFBZTtJQUFDLE1BQU0sSUFBRSxLQUFLLFNBQVMsZUFBYSxTQUFTLGdCQUFnQixjQUFhLElBQUUsS0FBSyxXQUFXLFNBQVMsR0FBRSxJQUFFLElBQUU7SUFBRSxJQUFHLEtBQUcsQ0FBQyxHQUFFO0tBQUMsTUFBTSxJQUFFLEVBQUUsSUFBRSxnQkFBYztLQUFlLEtBQUssU0FBUyxNQUFNLEtBQUcsR0FBRyxFQUFFO0lBQUc7SUFBQyxJQUFHLENBQUMsS0FBRyxHQUFFO0tBQUMsTUFBTSxJQUFFLEVBQUUsSUFBRSxpQkFBZTtLQUFjLEtBQUssU0FBUyxNQUFNLEtBQUcsR0FBRyxFQUFFO0lBQUc7R0FBQztHQUFDLG9CQUFtQjtJQUFDLEtBQUssU0FBUyxNQUFNLGNBQVksSUFBRyxLQUFLLFNBQVMsTUFBTSxlQUFhO0dBQUU7R0FBQyxPQUFPLGdCQUFnQixHQUFFLEdBQUU7SUFBQyxPQUFPLEtBQUssS0FBSyxXQUFVO0tBQUMsTUFBTSxJQUFFLEdBQUcsb0JBQW9CLE1BQUssQ0FBQztLQUFFLElBQUcsWUFBVSxPQUFPLEdBQUU7TUFBQyxJQUFHLEtBQUssTUFBSSxFQUFFLElBQUcsTUFBTSxJQUFJLFVBQVUsb0JBQW9CLEVBQUUsRUFBRTtNQUFFLEVBQUUsRUFBRSxDQUFDLENBQUM7S0FBQztJQUFDLENBQUM7R0FBQztFQUFDO0VBQUMsRUFBRSxHQUFHLFVBQVMsSUFBRyw4QkFBMkIsU0FBUyxHQUFFO0dBQUMsTUFBTSxJQUFFLEVBQUUsdUJBQXVCLElBQUk7R0FBRSxDQUFDLEtBQUksTUFBTSxDQUFDLENBQUMsU0FBUyxLQUFLLE9BQU8sS0FBRyxFQUFFLGVBQWUsR0FBRSxFQUFFLElBQUksR0FBRSxLQUFHLE1BQUc7SUFBQyxFQUFFLG9CQUFrQixFQUFFLElBQUksR0FBRSxVQUFPO0tBQUMsRUFBRSxJQUFJLEtBQUcsS0FBSyxNQUFNO0lBQUMsQ0FBQztHQUFDLENBQUM7R0FBRSxNQUFNLElBQUUsRUFBRSxRQUFRLGFBQWE7R0FBRSxLQUFHLEdBQUcsWUFBWSxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUUsR0FBRyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsT0FBTyxJQUFJO0VBQUMsQ0FBQyxHQUFFLEVBQUUsRUFBRSxHQUFFLEVBQUUsRUFBRTtFQUFFLE1BQU0sS0FBRyxpQkFBZ0IsS0FBRyxhQUFZLEtBQUcsT0FBTyxLQUFLLE1BQUssS0FBRyxRQUFPLEtBQUcsV0FBVSxLQUFHLFVBQVMsS0FBRyxtQkFBa0IsS0FBRyxPQUFPLE1BQUssS0FBRyxRQUFRLE1BQUssS0FBRyxPQUFPLE1BQUssS0FBRyxnQkFBZ0IsTUFBSyxLQUFHLFNBQVMsTUFBSyxLQUFHLFNBQVMsTUFBSyxLQUFHLFFBQVEsS0FBSyxNQUFLLEtBQUcsa0JBQWtCLE1BQUssS0FBRztHQUFDLFVBQVMsQ0FBQztHQUFFLFVBQVMsQ0FBQztHQUFFLFFBQU8sQ0FBQztFQUFDLEdBQUUsS0FBRztHQUFDLFVBQVM7R0FBbUIsVUFBUztHQUFVLFFBQU87RUFBUztFQUFFLE1BQU0sV0FBVyxFQUFDO0dBQUMsWUFBWSxHQUFFLEdBQUU7SUFBQyxNQUFNLEdBQUUsQ0FBQyxHQUFFLEtBQUssV0FBUyxDQUFDLEdBQUUsS0FBSyxZQUFVLEtBQUssb0JBQW9CLEdBQUUsS0FBSyxhQUFXLEtBQUsscUJBQXFCLEdBQUUsS0FBSyxtQkFBbUI7R0FBQztHQUFDLFdBQVcsVUFBUztJQUFDLE9BQU87R0FBRTtHQUFDLFdBQVcsY0FBYTtJQUFDLE9BQU87R0FBRTtHQUFDLFdBQVcsT0FBTTtJQUFDLE9BQU07R0FBVztHQUFDLE9BQU8sR0FBRTtJQUFDLE9BQU8sS0FBSyxXQUFTLEtBQUssS0FBSyxJQUFFLEtBQUssS0FBSyxDQUFDO0dBQUM7R0FBQyxLQUFLLEdBQUU7SUFBQyxLQUFLLFlBQVUsRUFBRSxRQUFRLEtBQUssVUFBUyxJQUFHLEVBQUMsZUFBYyxFQUFDLENBQUMsQ0FBQyxDQUFDLHFCQUFtQixLQUFLLFdBQVMsQ0FBQyxHQUFFLEtBQUssVUFBVSxLQUFLLEdBQUUsS0FBSyxRQUFRLFVBQVMsSUFBSSxHQUFDLENBQUMsQ0FBRSxLQUFLLEdBQUUsS0FBSyxTQUFTLGFBQWEsY0FBYSxDQUFDLENBQUMsR0FBRSxLQUFLLFNBQVMsYUFBYSxRQUFPLFFBQVEsR0FBRSxLQUFLLFNBQVMsVUFBVSxJQUFJLEVBQUUsR0FBRSxLQUFLLHFCQUFtQjtLQUFDLEtBQUssUUFBUSxVQUFRLENBQUMsS0FBSyxRQUFRLFlBQVUsS0FBSyxXQUFXLFNBQVMsR0FBRSxLQUFLLFNBQVMsVUFBVSxJQUFJLEVBQUUsR0FBRSxLQUFLLFNBQVMsVUFBVSxPQUFPLEVBQUUsR0FBRSxFQUFFLFFBQVEsS0FBSyxVQUFTLElBQUcsRUFBQyxlQUFjLEVBQUMsQ0FBQztJQUFDLEdBQUUsS0FBSyxVQUFTLENBQUMsQ0FBQztHQUFFO0dBQUMsT0FBTTtJQUFDLEtBQUssYUFBVyxFQUFFLFFBQVEsS0FBSyxVQUFTLEVBQUUsQ0FBQyxDQUFDLHFCQUFtQixLQUFLLFdBQVcsV0FBVyxHQUFFLEtBQUssU0FBUyxLQUFLLEdBQUUsS0FBSyxXQUFTLENBQUMsR0FBRSxLQUFLLFNBQVMsVUFBVSxJQUFJLEVBQUUsR0FBRSxLQUFLLFVBQVUsS0FBSyxHQUFFLEtBQUsscUJBQW1CO0tBQUMsS0FBSyxTQUFTLFVBQVUsT0FBTyxJQUFHLEVBQUUsR0FBRSxLQUFLLFNBQVMsZ0JBQWdCLFlBQVksR0FBRSxLQUFLLFNBQVMsZ0JBQWdCLE1BQU0sR0FBRSxLQUFLLFFBQVEsVUFBUyxJQUFJLEdBQUMsQ0FBQyxDQUFFLE1BQU0sR0FBRSxFQUFFLFFBQVEsS0FBSyxVQUFTLEVBQUU7SUFBQyxHQUFFLEtBQUssVUFBUyxDQUFDLENBQUM7R0FBRztHQUFDLFVBQVM7SUFBQyxLQUFLLFVBQVUsUUFBUSxHQUFFLEtBQUssV0FBVyxXQUFXLEdBQUUsTUFBTSxRQUFRO0dBQUM7R0FBQyxzQkFBcUI7SUFBQyxNQUFNLElBQUUsUUFBUSxLQUFLLFFBQVEsUUFBUTtJQUFFLE9BQU8sSUFBSSxHQUFHO0tBQUMsV0FBVTtLQUFxQixXQUFVO0tBQUUsWUFBVyxDQUFDO0tBQUUsYUFBWSxLQUFLLFNBQVM7S0FBVyxlQUFjLFVBQU07TUFBQyxhQUFXLEtBQUssUUFBUSxXQUFTLEtBQUssS0FBSyxJQUFFLEVBQUUsUUFBUSxLQUFLLFVBQVMsRUFBRTtLQUFDLElBQUU7SUFBSSxDQUFDO0dBQUM7R0FBQyx1QkFBc0I7SUFBQyxPQUFPLElBQUksR0FBRyxFQUFDLGFBQVksS0FBSyxTQUFRLENBQUM7R0FBQztHQUFDLHFCQUFvQjtJQUFDLEVBQUUsR0FBRyxLQUFLLFVBQVMsS0FBRyxNQUFHO0tBQUMsYUFBVyxFQUFFLFFBQU0sS0FBSyxRQUFRLFdBQVMsS0FBSyxLQUFLLElBQUUsRUFBRSxRQUFRLEtBQUssVUFBUyxFQUFFO0lBQUUsQ0FBQztHQUFDO0dBQUMsT0FBTyxnQkFBZ0IsR0FBRTtJQUFDLE9BQU8sS0FBSyxLQUFLLFdBQVU7S0FBQyxNQUFNLElBQUUsR0FBRyxvQkFBb0IsTUFBSyxDQUFDO0tBQUUsSUFBRyxZQUFVLE9BQU8sR0FBRTtNQUFDLElBQUcsS0FBSyxNQUFJLEVBQUUsTUFBSSxFQUFFLFdBQVcsR0FBRyxLQUFHLGtCQUFnQixHQUFFLE1BQU0sSUFBSSxVQUFVLG9CQUFvQixFQUFFLEVBQUU7TUFBRSxFQUFFLEVBQUUsQ0FBQyxJQUFJO0tBQUM7SUFBQyxDQUFDO0dBQUM7RUFBQztFQUFDLEVBQUUsR0FBRyxVQUFTLElBQUcsa0NBQStCLFNBQVMsR0FBRTtHQUFDLE1BQU0sSUFBRSxFQUFFLHVCQUF1QixJQUFJO0dBQUUsSUFBRyxDQUFDLEtBQUksTUFBTSxDQUFDLENBQUMsU0FBUyxLQUFLLE9BQU8sS0FBRyxFQUFFLGVBQWUsR0FBRSxFQUFFLElBQUksR0FBRTtHQUFPLEVBQUUsSUFBSSxHQUFFLFVBQU87SUFBQyxFQUFFLElBQUksS0FBRyxLQUFLLE1BQU07R0FBQyxDQUFDO0dBQUUsTUFBTSxJQUFFLEVBQUUsUUFBUSxFQUFFO0dBQUUsS0FBRyxNQUFJLEtBQUcsR0FBRyxZQUFZLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRSxHQUFHLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxPQUFPLElBQUk7RUFBQyxDQUFDLEdBQUUsRUFBRSxHQUFHLFFBQU8sVUFBTztHQUFDLEtBQUksTUFBTSxLQUFLLEVBQUUsS0FBSyxFQUFFLEdBQUUsR0FBRyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsS0FBSztFQUFDLENBQUMsR0FBRSxFQUFFLEdBQUcsUUFBTyxVQUFPO0dBQUMsS0FBSSxNQUFNLEtBQUssRUFBRSxLQUFLLDhDQUE4QyxHQUFFLFlBQVUsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLFlBQVUsR0FBRyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsS0FBSztFQUFDLENBQUMsR0FBRSxFQUFFLEVBQUUsR0FBRSxFQUFFLEVBQUU7RUFBRSxNQUFNLEtBQUc7R0FBQyxLQUFJO0lBQUM7SUFBUTtJQUFNO0lBQUs7SUFBTztJQUFPO0dBQWdCO0dBQUUsR0FBRTtJQUFDO0lBQVM7SUFBTztJQUFRO0dBQUs7R0FBRSxNQUFLLENBQUM7R0FBRSxHQUFFLENBQUM7R0FBRSxJQUFHLENBQUM7R0FBRSxLQUFJLENBQUM7R0FBRSxNQUFLLENBQUM7R0FBRSxJQUFHLENBQUM7R0FBRSxLQUFJLENBQUM7R0FBRSxJQUFHLENBQUM7R0FBRSxJQUFHLENBQUM7R0FBRSxJQUFHLENBQUM7R0FBRSxJQUFHLENBQUM7R0FBRSxJQUFHLENBQUM7R0FBRSxJQUFHLENBQUM7R0FBRSxJQUFHLENBQUM7R0FBRSxJQUFHLENBQUM7R0FBRSxJQUFHLENBQUM7R0FBRSxJQUFHLENBQUM7R0FBRSxHQUFFLENBQUM7R0FBRSxLQUFJO0lBQUM7SUFBTTtJQUFTO0lBQU07SUFBUTtJQUFRO0dBQVE7R0FBRSxJQUFHLENBQUM7R0FBRSxJQUFHLENBQUM7R0FBRSxHQUFFLENBQUM7R0FBRSxLQUFJLENBQUM7R0FBRSxHQUFFLENBQUM7R0FBRSxPQUFNLENBQUM7R0FBRSxNQUFLLENBQUM7R0FBRSxLQUFJLENBQUM7R0FBRSxLQUFJLENBQUM7R0FBRSxRQUFPLENBQUM7R0FBRSxHQUFFLENBQUM7R0FBRSxJQUFHLENBQUM7RUFBQyxHQUFFLHFCQUFHLElBQUksSUFBSTtHQUFDO0dBQWE7R0FBTztHQUFPO0dBQVc7R0FBVztHQUFTO0dBQU07RUFBWSxDQUFDLEdBQUUsS0FBRywyREFBMEQsTUFBSSxHQUFFLE1BQUk7R0FBQyxNQUFNLElBQUUsRUFBRSxTQUFTLFlBQVk7R0FBRSxPQUFPLEVBQUUsU0FBUyxDQUFDLElBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxLQUFHLFFBQVEsR0FBRyxLQUFLLEVBQUUsU0FBUyxDQUFDLElBQUUsRUFBRSxRQUFPLE1BQUcsYUFBYSxNQUFNLENBQUMsQ0FBQyxNQUFLLE1BQUcsRUFBRSxLQUFLLENBQUMsQ0FBQztFQUFDLEdBQUUsS0FBRztHQUFDLFdBQVU7R0FBRyxTQUFRLENBQUM7R0FBRSxZQUFXO0dBQUcsTUFBSyxDQUFDO0dBQUUsVUFBUyxDQUFDO0dBQUUsWUFBVztHQUFLLFVBQVM7RUFBYSxHQUFFLEtBQUc7R0FBQyxXQUFVO0dBQVMsU0FBUTtHQUFTLFlBQVc7R0FBb0IsTUFBSztHQUFVLFVBQVM7R0FBVSxZQUFXO0dBQWtCLFVBQVM7RUFBUSxHQUFFLEtBQUc7R0FBQyxPQUFNO0dBQWlDLFVBQVM7RUFBa0I7RUFBRSxNQUFNLFdBQVcsRUFBQztHQUFDLFlBQVksR0FBRTtJQUFDLE1BQU0sR0FBRSxLQUFLLFVBQVEsS0FBSyxXQUFXLENBQUM7R0FBQztHQUFDLFdBQVcsVUFBUztJQUFDLE9BQU87R0FBRTtHQUFDLFdBQVcsY0FBYTtJQUFDLE9BQU87R0FBRTtHQUFDLFdBQVcsT0FBTTtJQUFDLE9BQU07R0FBaUI7R0FBQyxhQUFZO0lBQUMsT0FBTyxPQUFPLE9BQU8sS0FBSyxRQUFRLE9BQU8sQ0FBQyxDQUFDLEtBQUksTUFBRyxLQUFLLHlCQUF5QixDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTztHQUFDO0dBQUMsYUFBWTtJQUFDLE9BQU8sS0FBSyxXQUFXLENBQUMsQ0FBQyxTQUFPO0dBQUM7R0FBQyxjQUFjLEdBQUU7SUFBQyxPQUFPLEtBQUssY0FBYyxDQUFDLEdBQUUsS0FBSyxRQUFRLFVBQVE7S0FBQyxHQUFHLEtBQUssUUFBUTtLQUFRLEdBQUc7SUFBQyxHQUFFO0dBQUk7R0FBQyxTQUFRO0lBQUMsTUFBTSxJQUFFLFNBQVMsY0FBYyxLQUFLO0lBQUUsRUFBRSxZQUFVLEtBQUssZUFBZSxLQUFLLFFBQVEsUUFBUTtJQUFFLEtBQUksTUFBSyxDQUFDLEdBQUUsTUFBSyxPQUFPLFFBQVEsS0FBSyxRQUFRLE9BQU8sR0FBRSxLQUFLLFlBQVksR0FBRSxHQUFFLENBQUM7SUFBRSxNQUFNLElBQUUsRUFBRSxTQUFTLElBQUcsSUFBRSxLQUFLLHlCQUF5QixLQUFLLFFBQVEsVUFBVTtJQUFFLE9BQU8sS0FBRyxFQUFFLFVBQVUsSUFBSSxHQUFHLEVBQUUsTUFBTSxHQUFHLENBQUMsR0FBRTtHQUFDO0dBQUMsaUJBQWlCLEdBQUU7SUFBQyxNQUFNLGlCQUFpQixDQUFDLEdBQUUsS0FBSyxjQUFjLEVBQUUsT0FBTztHQUFDO0dBQUMsY0FBYyxHQUFFO0lBQUMsS0FBSSxNQUFLLENBQUMsR0FBRSxNQUFLLE9BQU8sUUFBUSxDQUFDLEdBQUUsTUFBTSxpQkFBaUI7S0FBQyxVQUFTO0tBQUUsT0FBTTtJQUFDLEdBQUUsRUFBRTtHQUFDO0dBQUMsWUFBWSxHQUFFLEdBQUUsR0FBRTtJQUFDLE1BQU0sSUFBRSxFQUFFLFFBQVEsR0FBRSxDQUFDO0lBQUUsT0FBSyxJQUFFLEtBQUsseUJBQXlCLENBQUMsS0FBRyxFQUFFLENBQUMsSUFBRSxLQUFLLHNCQUFzQixFQUFFLENBQUMsR0FBRSxDQUFDLElBQUUsS0FBSyxRQUFRLE9BQUssRUFBRSxZQUFVLEtBQUssZUFBZSxDQUFDLElBQUUsRUFBRSxjQUFZLElBQUUsRUFBRSxPQUFPO0dBQUU7R0FBQyxlQUFlLEdBQUU7SUFBQyxPQUFPLEtBQUssUUFBUSxXQUFTLFNBQVMsR0FBRSxHQUFFLEdBQUU7S0FBQyxJQUFHLENBQUMsRUFBRSxRQUFPLE9BQU87S0FBRSxJQUFHLEtBQUcsY0FBWSxPQUFPLEdBQUUsT0FBTyxFQUFFLENBQUM7S0FBRSxNQUFNLElBQUcsSUFBSSxPQUFPLFVBQVEsQ0FBQyxDQUFFLGdCQUFnQixHQUFFLFdBQVcsR0FBRSxJQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sR0FBRyxFQUFFLEtBQUssaUJBQWlCLEdBQUcsQ0FBQztLQUFFLEtBQUksTUFBTSxLQUFLLEdBQUU7TUFBQyxNQUFNLElBQUUsRUFBRSxTQUFTLFlBQVk7TUFBRSxJQUFHLENBQUMsT0FBTyxLQUFLLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFFO09BQUMsRUFBRSxPQUFPO09BQUU7TUFBUTtNQUFDLE1BQU0sSUFBRSxDQUFDLENBQUMsQ0FBQyxPQUFPLEdBQUcsRUFBRSxVQUFVLEdBQUUsSUFBRSxDQUFDLENBQUMsQ0FBQyxPQUFPLEVBQUUsUUFBTSxDQUFDLEdBQUUsRUFBRSxNQUFJLENBQUMsQ0FBQztNQUFFLEtBQUksTUFBTSxLQUFLLEdBQUUsR0FBRyxHQUFFLENBQUMsS0FBRyxFQUFFLGdCQUFnQixFQUFFLFFBQVE7S0FBQztLQUFDLE9BQU8sRUFBRSxLQUFLO0lBQVMsRUFBRSxHQUFFLEtBQUssUUFBUSxXQUFVLEtBQUssUUFBUSxVQUFVLElBQUU7R0FBQztHQUFDLHlCQUF5QixHQUFFO0lBQUMsT0FBTyxFQUFFLEdBQUUsQ0FBQyxLQUFLLEdBQUUsSUFBSSxDQUFDO0dBQUM7R0FBQyxzQkFBc0IsR0FBRSxHQUFFO0lBQUMsSUFBRyxLQUFLLFFBQVEsTUFBSyxPQUFPLEVBQUUsWUFBVSxJQUFHLEtBQUssRUFBRSxPQUFPLENBQUM7SUFBRSxFQUFFLGNBQVksRUFBRTtHQUFXO0VBQUM7RUFBQyxNQUFNLHFCQUFHLElBQUksSUFBSTtHQUFDO0dBQVc7R0FBWTtFQUFZLENBQUMsR0FBRSxLQUFHLFFBQU8sS0FBRyxRQUFPLEtBQUcsa0JBQWlCLEtBQUcsVUFBUyxLQUFHLGlCQUFnQixLQUFHLFNBQVEsS0FBRyxTQUFRLEtBQUcsU0FBUSxLQUFHO0dBQUMsTUFBSztHQUFPLEtBQUk7R0FBTSxPQUFNLEVBQUUsSUFBRSxTQUFPO0dBQVEsUUFBTztHQUFTLE1BQUssRUFBRSxJQUFFLFVBQVE7RUFBTSxHQUFFLEtBQUc7R0FBQyxXQUFVO0dBQUcsV0FBVSxDQUFDO0dBQUUsVUFBUztHQUFrQixXQUFVLENBQUM7R0FBRSxhQUFZO0dBQUcsT0FBTTtHQUFFLG9CQUFtQjtJQUFDO0lBQU07SUFBUTtJQUFTO0dBQU07R0FBRSxNQUFLLENBQUM7R0FBRSxRQUFPLENBQUMsR0FBRSxDQUFDO0dBQUUsV0FBVTtHQUFNLGNBQWE7R0FBSyxVQUFTLENBQUM7R0FBRSxZQUFXO0dBQUssVUFBUyxDQUFDO0dBQUUsVUFBUztHQUErRyxPQUFNO0dBQUcsU0FBUTtFQUFhLEdBQUUsS0FBRztHQUFDLFdBQVU7R0FBUyxXQUFVO0dBQVUsVUFBUztHQUFtQixXQUFVO0dBQTJCLGFBQVk7R0FBb0IsT0FBTTtHQUFrQixvQkFBbUI7R0FBUSxNQUFLO0dBQVUsUUFBTztHQUEwQixXQUFVO0dBQW9CLGNBQWE7R0FBeUIsVUFBUztHQUFVLFlBQVc7R0FBa0IsVUFBUztHQUFtQixVQUFTO0dBQVMsT0FBTTtHQUE0QixTQUFRO0VBQVE7RUFBRSxNQUFNLFdBQVcsRUFBQztHQUFDLFlBQVksR0FBRSxHQUFFO0lBQUMsSUFBRyxLQUFLLE1BQUksSUFBRyxNQUFNLElBQUksVUFBVSxzRUFBc0U7SUFBRSxNQUFNLEdBQUUsQ0FBQyxHQUFFLEtBQUssYUFBVyxDQUFDLEdBQUUsS0FBSyxXQUFTLEdBQUUsS0FBSyxhQUFXLE1BQUssS0FBSyxpQkFBZSxDQUFDLEdBQUUsS0FBSyxVQUFRLE1BQUssS0FBSyxtQkFBaUIsTUFBSyxLQUFLLGNBQVksTUFBSyxLQUFLLE1BQUksTUFBSyxLQUFLLGNBQWMsR0FBRSxLQUFLLFFBQVEsWUFBVSxLQUFLLFVBQVU7R0FBQztHQUFDLFdBQVcsVUFBUztJQUFDLE9BQU87R0FBRTtHQUFDLFdBQVcsY0FBYTtJQUFDLE9BQU87R0FBRTtHQUFDLFdBQVcsT0FBTTtJQUFDLE9BQU07R0FBUztHQUFDLFNBQVE7SUFBQyxLQUFLLGFBQVcsQ0FBQztHQUFDO0dBQUMsVUFBUztJQUFDLEtBQUssYUFBVyxDQUFDO0dBQUM7R0FBQyxnQkFBZTtJQUFDLEtBQUssYUFBVyxDQUFDLEtBQUs7R0FBVTtHQUFDLFNBQVE7SUFBQyxLQUFLLGVBQWEsS0FBSyxTQUFTLElBQUUsS0FBSyxPQUFPLElBQUUsS0FBSyxPQUFPO0dBQUU7R0FBQyxVQUFTO0lBQUMsYUFBYSxLQUFLLFFBQVEsR0FBRSxFQUFFLElBQUksS0FBSyxTQUFTLFFBQVEsRUFBRSxHQUFFLElBQUcsS0FBSyxpQkFBaUIsR0FBRSxLQUFLLFNBQVMsYUFBYSx3QkFBd0IsS0FBRyxLQUFLLFNBQVMsYUFBYSxTQUFRLEtBQUssU0FBUyxhQUFhLHdCQUF3QixDQUFDLEdBQUUsS0FBSyxlQUFlLEdBQUUsTUFBTSxRQUFRO0dBQUM7R0FBQyxPQUFNO0lBQUMsSUFBRyxXQUFTLEtBQUssU0FBUyxNQUFNLFNBQVEsTUFBTSxJQUFJLE1BQU0scUNBQXFDO0lBQUUsSUFBRyxDQUFDLEtBQUssZUFBZSxLQUFHLENBQUMsS0FBSyxZQUFXO0lBQU8sTUFBTSxJQUFFLEVBQUUsUUFBUSxLQUFLLFVBQVMsS0FBSyxZQUFZLFVBQVUsTUFBTSxDQUFDLEdBQUUsS0FBRyxFQUFFLEtBQUssUUFBUSxLQUFHLEtBQUssU0FBUyxjQUFjLGdCQUFBLENBQWlCLFNBQVMsS0FBSyxRQUFRO0lBQUUsSUFBRyxFQUFFLG9CQUFrQixDQUFDLEdBQUU7SUFBTyxLQUFLLGVBQWU7SUFBRSxNQUFNLElBQUUsS0FBSyxlQUFlO0lBQUUsS0FBSyxTQUFTLGFBQWEsb0JBQW1CLEVBQUUsYUFBYSxJQUFJLENBQUM7SUFBRSxNQUFLLEVBQUMsV0FBVSxNQUFHLEtBQUs7SUFBUSxJQUFHLEtBQUssU0FBUyxjQUFjLGdCQUFnQixTQUFTLEtBQUssR0FBRyxNQUFJLEVBQUUsT0FBTyxDQUFDLEdBQUUsRUFBRSxRQUFRLEtBQUssVUFBUyxLQUFLLFlBQVksVUFBVSxVQUFVLENBQUMsSUFBRyxLQUFLLFVBQVEsS0FBSyxjQUFjLENBQUMsR0FBRSxFQUFFLFVBQVUsSUFBSSxFQUFFLEdBQUUsa0JBQWlCLFNBQVMsaUJBQWdCLEtBQUksTUFBTSxLQUFJLENBQUMsQ0FBQyxDQUFDLE9BQU8sR0FBRyxTQUFTLEtBQUssUUFBUSxHQUFFLEVBQUUsR0FBRyxHQUFFLGFBQVksQ0FBQztJQUFFLEtBQUsscUJBQW1CO0tBQUMsRUFBRSxRQUFRLEtBQUssVUFBUyxLQUFLLFlBQVksVUFBVSxPQUFPLENBQUMsR0FBRSxDQUFDLE1BQUksS0FBSyxjQUFZLEtBQUssT0FBTyxHQUFFLEtBQUssYUFBVyxDQUFDO0lBQUMsR0FBRSxLQUFLLEtBQUksS0FBSyxZQUFZLENBQUM7R0FBQztHQUFDLE9BQU07SUFBQyxJQUFHLEtBQUssU0FBUyxLQUFHLENBQUMsRUFBRSxRQUFRLEtBQUssVUFBUyxLQUFLLFlBQVksVUFBVSxNQUFNLENBQUMsQ0FBQyxDQUFDLGtCQUFpQjtLQUFDLElBQUcsS0FBSyxlQUFlLENBQUMsQ0FBQyxVQUFVLE9BQU8sRUFBRSxHQUFFLGtCQUFpQixTQUFTLGlCQUFnQixLQUFJLE1BQU0sS0FBSSxDQUFDLENBQUMsQ0FBQyxPQUFPLEdBQUcsU0FBUyxLQUFLLFFBQVEsR0FBRSxFQUFFLElBQUksR0FBRSxhQUFZLENBQUM7S0FBRSxLQUFLLGVBQWUsTUFBSSxDQUFDLEdBQUUsS0FBSyxlQUFlLE1BQUksQ0FBQyxHQUFFLEtBQUssZUFBZSxNQUFJLENBQUMsR0FBRSxLQUFLLGFBQVcsTUFBSyxLQUFLLHFCQUFtQjtNQUFDLEtBQUsscUJBQXFCLE1BQUksS0FBSyxjQUFZLEtBQUssZUFBZSxHQUFFLEtBQUssU0FBUyxnQkFBZ0Isa0JBQWtCLEdBQUUsRUFBRSxRQUFRLEtBQUssVUFBUyxLQUFLLFlBQVksVUFBVSxRQUFRLENBQUM7S0FBRSxHQUFFLEtBQUssS0FBSSxLQUFLLFlBQVksQ0FBQztJQUFDO0dBQUM7R0FBQyxTQUFRO0lBQUMsS0FBSyxXQUFTLEtBQUssUUFBUSxPQUFPO0dBQUM7R0FBQyxpQkFBZ0I7SUFBQyxPQUFPLFFBQVEsS0FBSyxVQUFVLENBQUM7R0FBQztHQUFDLGlCQUFnQjtJQUFDLE9BQU8sS0FBSyxRQUFNLEtBQUssTUFBSSxLQUFLLGtCQUFrQixLQUFLLGVBQWEsS0FBSyx1QkFBdUIsQ0FBQyxJQUFHLEtBQUs7R0FBRztHQUFDLGtCQUFrQixHQUFFO0lBQUMsTUFBTSxJQUFFLEtBQUssb0JBQW9CLENBQUMsQ0FBQyxDQUFDLE9BQU87SUFBRSxJQUFHLENBQUMsR0FBRSxPQUFPO0lBQUssRUFBRSxVQUFVLE9BQU8sSUFBRyxFQUFFLEdBQUUsRUFBRSxVQUFVLElBQUksTUFBTSxLQUFLLFlBQVksS0FBSyxNQUFNO0lBQUUsTUFBTSxNQUFHLE1BQUc7S0FBQztNQUFHLEtBQUcsS0FBSyxNQUFNLE1BQUksS0FBSyxPQUFPLENBQUM7WUFBUSxTQUFTLGVBQWUsQ0FBQztLQUFHLE9BQU87SUFBQyxFQUFBLENBQUcsS0FBSyxZQUFZLElBQUksQ0FBQyxDQUFDLFNBQVM7SUFBRSxPQUFPLEVBQUUsYUFBYSxNQUFLLENBQUMsR0FBRSxLQUFLLFlBQVksS0FBRyxFQUFFLFVBQVUsSUFBSSxFQUFFLEdBQUU7R0FBQztHQUFDLFdBQVcsR0FBRTtJQUFDLEtBQUssY0FBWSxHQUFFLEtBQUssU0FBUyxNQUFJLEtBQUssZUFBZSxHQUFFLEtBQUssS0FBSztHQUFFO0dBQUMsb0JBQW9CLEdBQUU7SUFBQyxPQUFPLEtBQUssbUJBQWlCLEtBQUssaUJBQWlCLGNBQWMsQ0FBQyxJQUFFLEtBQUssbUJBQWlCLElBQUksR0FBRztLQUFDLEdBQUcsS0FBSztLQUFRLFNBQVE7S0FBRSxZQUFXLEtBQUsseUJBQXlCLEtBQUssUUFBUSxXQUFXO0lBQUMsQ0FBQyxHQUFFLEtBQUs7R0FBZ0I7R0FBQyx5QkFBd0I7SUFBQyxPQUFNLEdBQUUsS0FBSSxLQUFLLFVBQVUsRUFBQztHQUFDO0dBQUMsWUFBVztJQUFDLE9BQU8sS0FBSyx5QkFBeUIsS0FBSyxRQUFRLEtBQUssS0FBRyxLQUFLLFNBQVMsYUFBYSx3QkFBd0I7R0FBQztHQUFDLDZCQUE2QixHQUFFO0lBQUMsT0FBTyxLQUFLLFlBQVksb0JBQW9CLEVBQUUsZ0JBQWUsS0FBSyxtQkFBbUIsQ0FBQztHQUFDO0dBQUMsY0FBYTtJQUFDLE9BQU8sS0FBSyxRQUFRLGFBQVcsS0FBSyxPQUFLLEtBQUssSUFBSSxVQUFVLFNBQVMsRUFBRTtHQUFDO0dBQUMsV0FBVTtJQUFDLE9BQU8sS0FBSyxPQUFLLEtBQUssSUFBSSxVQUFVLFNBQVMsRUFBRTtHQUFDO0dBQUMsY0FBYyxHQUFFO0lBQUMsTUFBTSxJQUFFLEVBQUUsS0FBSyxRQUFRLFdBQVU7S0FBQztLQUFLO0tBQUUsS0FBSztJQUFRLENBQUMsR0FBRSxJQUFFLEdBQUcsRUFBRSxZQUFZO0lBQUcsT0FBTyxHQUFHLEtBQUssVUFBUyxHQUFFLEtBQUssaUJBQWlCLENBQUMsQ0FBQztHQUFDO0dBQUMsYUFBWTtJQUFDLE1BQUssRUFBQyxRQUFPLE1BQUcsS0FBSztJQUFRLE9BQU0sWUFBVSxPQUFPLElBQUUsRUFBRSxNQUFNLEdBQUcsQ0FBQyxDQUFDLEtBQUksTUFBRyxPQUFPLFNBQVMsR0FBRSxFQUFFLENBQUMsSUFBRSxjQUFZLE9BQU8sS0FBRSxNQUFHLEVBQUUsR0FBRSxLQUFLLFFBQVEsSUFBRTtHQUFDO0dBQUMseUJBQXlCLEdBQUU7SUFBQyxPQUFPLEVBQUUsR0FBRSxDQUFDLEtBQUssVUFBUyxLQUFLLFFBQVEsQ0FBQztHQUFDO0dBQUMsaUJBQWlCLEdBQUU7SUFBQyxNQUFNLElBQUU7S0FBQyxXQUFVO0tBQUUsV0FBVTtNQUFDO09BQUMsTUFBSztPQUFPLFNBQVEsRUFBQyxvQkFBbUIsS0FBSyxRQUFRLG1CQUFrQjtNQUFDO01BQUU7T0FBQyxNQUFLO09BQVMsU0FBUSxFQUFDLFFBQU8sS0FBSyxXQUFXLEVBQUM7TUFBQztNQUFFO09BQUMsTUFBSztPQUFrQixTQUFRLEVBQUMsVUFBUyxLQUFLLFFBQVEsU0FBUTtNQUFDO01BQUU7T0FBQyxNQUFLO09BQVEsU0FBUSxFQUFDLFNBQVEsSUFBSSxLQUFLLFlBQVksS0FBSyxRQUFPO01BQUM7TUFBRTtPQUFDLE1BQUs7T0FBa0IsU0FBUSxDQUFDO09BQUUsT0FBTTtPQUFhLEtBQUcsTUFBRztRQUFDLEtBQUssZUFBZSxDQUFDLENBQUMsYUFBYSx5QkFBd0IsRUFBRSxNQUFNLFNBQVM7T0FBQztNQUFDO0tBQUM7SUFBQztJQUFFLE9BQU07S0FBQyxHQUFHO0tBQUUsR0FBRyxFQUFFLEtBQUssUUFBUSxjQUFhLENBQUMsS0FBSyxHQUFFLENBQUMsQ0FBQztJQUFDO0dBQUM7R0FBQyxnQkFBZTtJQUFDLE1BQU0sSUFBRSxLQUFLLFFBQVEsUUFBUSxNQUFNLEdBQUc7SUFBRSxLQUFJLE1BQU0sS0FBSyxHQUFFLElBQUcsWUFBVSxHQUFFLEVBQUUsR0FBRyxLQUFLLFVBQVMsS0FBSyxZQUFZLFVBQVUsT0FBTyxHQUFFLEtBQUssUUFBUSxXQUFTLE1BQUc7S0FBQyxNQUFNLElBQUUsS0FBSyw2QkFBNkIsQ0FBQztLQUFFLEVBQUUsZUFBZSxNQUFJLEVBQUUsRUFBRSxTQUFTLEtBQUcsRUFBRSxlQUFlLE1BQUssRUFBRSxPQUFPO0lBQUMsQ0FBQztTQUFPLElBQUcsYUFBVyxHQUFFO0tBQUMsTUFBTSxJQUFFLE1BQUksS0FBRyxLQUFLLFlBQVksVUFBVSxZQUFZLElBQUUsS0FBSyxZQUFZLFVBQVUsU0FBUyxHQUFFLElBQUUsTUFBSSxLQUFHLEtBQUssWUFBWSxVQUFVLFlBQVksSUFBRSxLQUFLLFlBQVksVUFBVSxVQUFVO0tBQUUsRUFBRSxHQUFHLEtBQUssVUFBUyxHQUFFLEtBQUssUUFBUSxXQUFTLE1BQUc7TUFBQyxNQUFNLElBQUUsS0FBSyw2QkFBNkIsQ0FBQztNQUFFLEVBQUUsZUFBZSxjQUFZLEVBQUUsT0FBSyxLQUFHLE1BQUksQ0FBQyxHQUFFLEVBQUUsT0FBTztLQUFDLENBQUMsR0FBRSxFQUFFLEdBQUcsS0FBSyxVQUFTLEdBQUUsS0FBSyxRQUFRLFdBQVMsTUFBRztNQUFDLE1BQU0sSUFBRSxLQUFLLDZCQUE2QixDQUFDO01BQUUsRUFBRSxlQUFlLGVBQWEsRUFBRSxPQUFLLEtBQUcsTUFBSSxFQUFFLFNBQVMsU0FBUyxFQUFFLGFBQWEsR0FBRSxFQUFFLE9BQU87S0FBQyxDQUFDO0lBQUM7SUFBQyxLQUFLLDBCQUFzQjtLQUFDLEtBQUssWUFBVSxLQUFLLEtBQUs7SUFBQyxHQUFFLEVBQUUsR0FBRyxLQUFLLFNBQVMsUUFBUSxFQUFFLEdBQUUsSUFBRyxLQUFLLGlCQUFpQjtHQUFDO0dBQUMsWUFBVztJQUFDLE1BQU0sSUFBRSxLQUFLLFNBQVMsYUFBYSxPQUFPO0lBQUUsTUFBSSxLQUFLLFNBQVMsYUFBYSxZQUFZLEtBQUcsS0FBSyxTQUFTLFlBQVksS0FBSyxLQUFHLEtBQUssU0FBUyxhQUFhLGNBQWEsQ0FBQyxHQUFFLEtBQUssU0FBUyxhQUFhLDBCQUF5QixDQUFDLEdBQUUsS0FBSyxTQUFTLGdCQUFnQixPQUFPO0dBQUU7R0FBQyxTQUFRO0lBQUMsS0FBSyxTQUFTLEtBQUcsS0FBSyxhQUFXLEtBQUssYUFBVyxDQUFDLEtBQUcsS0FBSyxhQUFXLENBQUMsR0FBRSxLQUFLLGtCQUFnQjtLQUFDLEtBQUssY0FBWSxLQUFLLEtBQUs7SUFBQyxHQUFFLEtBQUssUUFBUSxNQUFNLElBQUk7R0FBRTtHQUFDLFNBQVE7SUFBQyxLQUFLLHFCQUFxQixNQUFJLEtBQUssYUFBVyxDQUFDLEdBQUUsS0FBSyxrQkFBZ0I7S0FBQyxLQUFLLGNBQVksS0FBSyxLQUFLO0lBQUMsR0FBRSxLQUFLLFFBQVEsTUFBTSxJQUFJO0dBQUU7R0FBQyxZQUFZLEdBQUUsR0FBRTtJQUFDLGFBQWEsS0FBSyxRQUFRLEdBQUUsS0FBSyxXQUFTLFdBQVcsR0FBRSxDQUFDO0dBQUM7R0FBQyx1QkFBc0I7SUFBQyxPQUFPLE9BQU8sT0FBTyxLQUFLLGNBQWMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDO0dBQUM7R0FBQyxXQUFXLEdBQUU7SUFBQyxNQUFNLElBQUUsRUFBRSxrQkFBa0IsS0FBSyxRQUFRO0lBQUUsS0FBSSxNQUFNLEtBQUssT0FBTyxLQUFLLENBQUMsR0FBRSxHQUFHLElBQUksQ0FBQyxLQUFHLE9BQU8sRUFBRTtJQUFHLE9BQU8sSUFBRTtLQUFDLEdBQUc7S0FBRSxHQUFHLFlBQVUsT0FBTyxLQUFHLElBQUUsSUFBRSxDQUFDO0lBQUMsR0FBRSxJQUFFLEtBQUssZ0JBQWdCLENBQUMsR0FBRSxJQUFFLEtBQUssa0JBQWtCLENBQUMsR0FBRSxLQUFLLGlCQUFpQixDQUFDLEdBQUU7R0FBQztHQUFDLGtCQUFrQixHQUFFO0lBQUMsT0FBTyxFQUFFLFlBQVUsQ0FBQyxNQUFJLEVBQUUsWUFBVSxTQUFTLE9BQUssRUFBRSxFQUFFLFNBQVMsR0FBRSxZQUFVLE9BQU8sRUFBRSxVQUFRLEVBQUUsUUFBTTtLQUFDLE1BQUssRUFBRTtLQUFNLE1BQUssRUFBRTtJQUFLLElBQUcsWUFBVSxPQUFPLEVBQUUsVUFBUSxFQUFFLFFBQU0sRUFBRSxNQUFNLFNBQVMsSUFBRyxZQUFVLE9BQU8sRUFBRSxZQUFVLEVBQUUsVUFBUSxFQUFFLFFBQVEsU0FBUyxJQUFHO0dBQUM7R0FBQyxxQkFBb0I7SUFBQyxNQUFNLElBQUUsQ0FBQztJQUFFLEtBQUksTUFBSyxDQUFDLEdBQUUsTUFBSyxPQUFPLFFBQVEsS0FBSyxPQUFPLEdBQUUsS0FBSyxZQUFZLFFBQVEsT0FBSyxNQUFJLEVBQUUsS0FBRztJQUFHLE9BQU8sRUFBRSxXQUFTLENBQUMsR0FBRSxFQUFFLFVBQVEsVUFBUztHQUFDO0dBQUMsaUJBQWdCO0lBQUMsS0FBSyxZQUFVLEtBQUssUUFBUSxRQUFRLEdBQUUsS0FBSyxVQUFRLE9BQU0sS0FBSyxRQUFNLEtBQUssSUFBSSxPQUFPLEdBQUUsS0FBSyxNQUFJO0dBQUs7R0FBQyxPQUFPLGdCQUFnQixHQUFFO0lBQUMsT0FBTyxLQUFLLEtBQUssV0FBVTtLQUFDLE1BQU0sSUFBRSxHQUFHLG9CQUFvQixNQUFLLENBQUM7S0FBRSxJQUFHLFlBQVUsT0FBTyxHQUFFO01BQUMsSUFBRyxLQUFLLE1BQUksRUFBRSxJQUFHLE1BQU0sSUFBSSxVQUFVLG9CQUFvQixFQUFFLEVBQUU7TUFBRSxFQUFFLEVBQUUsQ0FBQztLQUFDO0lBQUMsQ0FBQztHQUFDO0VBQUM7RUFBQyxFQUFFLEVBQUU7RUFBRSxNQUFNLEtBQUcsbUJBQWtCLEtBQUcsaUJBQWdCLEtBQUc7R0FBQyxHQUFHLEdBQUc7R0FBUSxTQUFRO0dBQUcsUUFBTyxDQUFDLEdBQUUsQ0FBQztHQUFFLFdBQVU7R0FBUSxVQUFTO0dBQThJLFNBQVE7RUFBTyxHQUFFLEtBQUc7R0FBQyxHQUFHLEdBQUc7R0FBWSxTQUFRO0VBQWdDO0VBQUUsTUFBTSxXQUFXLEdBQUU7R0FBQyxXQUFXLFVBQVM7SUFBQyxPQUFPO0dBQUU7R0FBQyxXQUFXLGNBQWE7SUFBQyxPQUFPO0dBQUU7R0FBQyxXQUFXLE9BQU07SUFBQyxPQUFNO0dBQVM7R0FBQyxpQkFBZ0I7SUFBQyxPQUFPLEtBQUssVUFBVSxLQUFHLEtBQUssWUFBWTtHQUFDO0dBQUMseUJBQXdCO0lBQUMsT0FBTTtNQUFFLEtBQUksS0FBSyxVQUFVO01BQUcsS0FBSSxLQUFLLFlBQVk7SUFBQztHQUFDO0dBQUMsY0FBYTtJQUFDLE9BQU8sS0FBSyx5QkFBeUIsS0FBSyxRQUFRLE9BQU87R0FBQztHQUFDLE9BQU8sZ0JBQWdCLEdBQUU7SUFBQyxPQUFPLEtBQUssS0FBSyxXQUFVO0tBQUMsTUFBTSxJQUFFLEdBQUcsb0JBQW9CLE1BQUssQ0FBQztLQUFFLElBQUcsWUFBVSxPQUFPLEdBQUU7TUFBQyxJQUFHLEtBQUssTUFBSSxFQUFFLElBQUcsTUFBTSxJQUFJLFVBQVUsb0JBQW9CLEVBQUUsRUFBRTtNQUFFLEVBQUUsRUFBRSxDQUFDO0tBQUM7SUFBQyxDQUFDO0dBQUM7RUFBQztFQUFDLEVBQUUsRUFBRTtFQUFFLE1BQU0sS0FBRyxpQkFBZ0IsS0FBRyxXQUFXLE1BQUssS0FBRyxRQUFRLE1BQUssS0FBRyxPQUFPLEdBQUcsWUFBVyxLQUFHLFVBQVMsS0FBRyxVQUFTLEtBQUcsYUFBWSxLQUFHLEdBQUcsR0FBRyxnQkFBZ0IsR0FBRyxxQkFBb0IsS0FBRztHQUFDLFFBQU87R0FBSyxZQUFXO0dBQWUsY0FBYSxDQUFDO0dBQUUsUUFBTztHQUFLLFdBQVU7SUFBQztJQUFHO0lBQUc7R0FBQztFQUFDLEdBQUUsS0FBRztHQUFDLFFBQU87R0FBZ0IsWUFBVztHQUFTLGNBQWE7R0FBVSxRQUFPO0dBQVUsV0FBVTtFQUFPO0VBQUUsTUFBTSxXQUFXLEVBQUM7R0FBQyxZQUFZLEdBQUUsR0FBRTtJQUFDLE1BQU0sR0FBRSxDQUFDLEdBQUUsS0FBSywrQkFBYSxJQUFJLElBQUUsR0FBRSxLQUFLLHNDQUFvQixJQUFJLElBQUUsR0FBRSxLQUFLLGVBQWEsY0FBWSxpQkFBaUIsS0FBSyxRQUFRLENBQUMsQ0FBQyxZQUFVLE9BQUssS0FBSyxVQUFTLEtBQUssZ0JBQWMsTUFBSyxLQUFLLFlBQVUsTUFBSyxLQUFLLHNCQUFvQjtLQUFDLGlCQUFnQjtLQUFFLGlCQUFnQjtJQUFDLEdBQUUsS0FBSyxRQUFRO0dBQUM7R0FBQyxXQUFXLFVBQVM7SUFBQyxPQUFPO0dBQUU7R0FBQyxXQUFXLGNBQWE7SUFBQyxPQUFPO0dBQUU7R0FBQyxXQUFXLE9BQU07SUFBQyxPQUFNO0dBQVc7R0FBQyxVQUFTO0lBQUMsS0FBSyxpQ0FBaUMsR0FBRSxLQUFLLHlCQUF5QixHQUFFLEtBQUssWUFBVSxLQUFLLFVBQVUsV0FBVyxJQUFFLEtBQUssWUFBVSxLQUFLLGdCQUFnQjtJQUFFLEtBQUksTUFBTSxLQUFLLEtBQUssb0JBQW9CLE9BQU8sR0FBRSxLQUFLLFVBQVUsUUFBUSxDQUFDO0dBQUM7R0FBQyxVQUFTO0lBQUMsS0FBSyxVQUFVLFdBQVcsR0FBRSxNQUFNLFFBQVE7R0FBQztHQUFDLGtCQUFrQixHQUFFO0lBQUMsT0FBTyxFQUFFLFNBQU8sRUFBRSxFQUFFLE1BQU0sS0FBRyxTQUFTLE1BQUssRUFBRSxhQUFXLEVBQUUsU0FBTyxHQUFHLEVBQUUsT0FBTyxlQUFhLEVBQUUsWUFBVyxZQUFVLE9BQU8sRUFBRSxjQUFZLEVBQUUsWUFBVSxFQUFFLFVBQVUsTUFBTSxHQUFHLENBQUMsQ0FBQyxLQUFJLE1BQUcsT0FBTyxXQUFXLENBQUMsQ0FBQyxJQUFHO0dBQUM7R0FBQywyQkFBMEI7SUFBQyxLQUFLLFFBQVEsaUJBQWUsRUFBRSxJQUFJLEtBQUssUUFBUSxRQUFPLEVBQUUsR0FBRSxFQUFFLEdBQUcsS0FBSyxRQUFRLFFBQU8sSUFBRyxLQUFHLE1BQUc7S0FBQyxNQUFNLElBQUUsS0FBSyxvQkFBb0IsSUFBSSxFQUFFLE9BQU8sSUFBSTtLQUFFLElBQUcsR0FBRTtNQUFDLEVBQUUsZUFBZTtNQUFFLE1BQU0sSUFBRSxLQUFLLGdCQUFjLFFBQU8sSUFBRSxFQUFFLFlBQVUsS0FBSyxTQUFTO01BQVUsSUFBRyxFQUFFLFVBQVMsT0FBTyxLQUFLLEVBQUUsU0FBUztPQUFDLEtBQUk7T0FBRSxVQUFTO01BQVEsQ0FBQztNQUFFLEVBQUUsWUFBVTtLQUFDO0lBQUMsQ0FBQztHQUFFO0dBQUMsa0JBQWlCO0lBQUMsTUFBTSxJQUFFO0tBQUMsTUFBSyxLQUFLO0tBQWEsV0FBVSxLQUFLLFFBQVE7S0FBVSxZQUFXLEtBQUssUUFBUTtJQUFVO0lBQUUsT0FBTyxJQUFJLHNCQUFxQixNQUFHLEtBQUssa0JBQWtCLENBQUMsR0FBRSxDQUFDO0dBQUM7R0FBQyxrQkFBa0IsR0FBRTtJQUFDLE1BQU0sS0FBRSxNQUFHLEtBQUssYUFBYSxJQUFJLElBQUksRUFBRSxPQUFPLElBQUksR0FBRSxLQUFFLE1BQUc7S0FBQyxLQUFLLG9CQUFvQixrQkFBZ0IsRUFBRSxPQUFPLFdBQVUsS0FBSyxTQUFTLEVBQUUsQ0FBQyxDQUFDO0lBQUMsR0FBRSxLQUFHLEtBQUssZ0JBQWMsU0FBUyxnQkFBQSxDQUFpQixXQUFVLElBQUUsS0FBRyxLQUFLLG9CQUFvQjtJQUFnQixLQUFLLG9CQUFvQixrQkFBZ0I7SUFBRSxLQUFJLE1BQU0sS0FBSyxHQUFFO0tBQUMsSUFBRyxDQUFDLEVBQUUsZ0JBQWU7TUFBQyxLQUFLLGdCQUFjLE1BQUssS0FBSyxrQkFBa0IsRUFBRSxDQUFDLENBQUM7TUFBRTtLQUFRO0tBQUMsTUFBTSxJQUFFLEVBQUUsT0FBTyxhQUFXLEtBQUssb0JBQW9CO0tBQWdCLElBQUcsS0FBRyxHQUFNO1VBQUEsRUFBRSxDQUFDLEdBQUUsQ0FBQyxHQUFFO0tBQUEsT0FBWSxLQUFHLEtBQUcsRUFBRSxDQUFDO0lBQUM7R0FBQztHQUFDLG1DQUFrQztJQUFDLEtBQUssK0JBQWEsSUFBSSxJQUFFLEdBQUUsS0FBSyxzQ0FBb0IsSUFBSSxJQUFFO0lBQUUsTUFBTSxJQUFFLEVBQUUsS0FBSyxJQUFHLEtBQUssUUFBUSxNQUFNO0lBQUUsS0FBSSxNQUFNLEtBQUssR0FBRTtLQUFDLElBQUcsQ0FBQyxFQUFFLFFBQU0sRUFBRSxDQUFDLEdBQUU7S0FBUyxNQUFNLElBQUUsRUFBRSxRQUFRLFVBQVUsRUFBRSxJQUFJLEdBQUUsS0FBSyxRQUFRO0tBQUUsRUFBRSxDQUFDLE1BQUksS0FBSyxhQUFhLElBQUksVUFBVSxFQUFFLElBQUksR0FBRSxDQUFDLEdBQUUsS0FBSyxvQkFBb0IsSUFBSSxFQUFFLE1BQUssQ0FBQztJQUFFO0dBQUM7R0FBQyxTQUFTLEdBQUU7SUFBQyxLQUFLLGtCQUFnQixNQUFJLEtBQUssa0JBQWtCLEtBQUssUUFBUSxNQUFNLEdBQUUsS0FBSyxnQkFBYyxHQUFFLEVBQUUsVUFBVSxJQUFJLEVBQUUsR0FBRSxLQUFLLGlCQUFpQixDQUFDLEdBQUUsRUFBRSxRQUFRLEtBQUssVUFBUyxJQUFHLEVBQUMsZUFBYyxFQUFDLENBQUM7R0FBRTtHQUFDLGlCQUFpQixHQUFFO0lBQUMsSUFBRyxFQUFFLFVBQVUsU0FBUyxlQUFlLEdBQUUsRUFBRSxRQUFRLG9CQUFtQixFQUFFLFFBQVEsV0FBVyxDQUFDLENBQUMsQ0FBQyxVQUFVLElBQUksRUFBRTtTQUFPLEtBQUksTUFBTSxLQUFLLEVBQUUsUUFBUSxHQUFFLG1CQUFtQixHQUFFLEtBQUksTUFBTSxLQUFLLEVBQUUsS0FBSyxHQUFFLEVBQUUsR0FBRSxFQUFFLFVBQVUsSUFBSSxFQUFFO0dBQUM7R0FBQyxrQkFBa0IsR0FBRTtJQUFDLEVBQUUsVUFBVSxPQUFPLEVBQUU7SUFBRSxNQUFNLElBQUUsRUFBRSxLQUFLLEdBQUcsR0FBRyxHQUFHLE1BQUssQ0FBQztJQUFFLEtBQUksTUFBTSxLQUFLLEdBQUUsRUFBRSxVQUFVLE9BQU8sRUFBRTtHQUFDO0dBQUMsT0FBTyxnQkFBZ0IsR0FBRTtJQUFDLE9BQU8sS0FBSyxLQUFLLFdBQVU7S0FBQyxNQUFNLElBQUUsR0FBRyxvQkFBb0IsTUFBSyxDQUFDO0tBQUUsSUFBRyxZQUFVLE9BQU8sR0FBRTtNQUFDLElBQUcsS0FBSyxNQUFJLEVBQUUsTUFBSSxFQUFFLFdBQVcsR0FBRyxLQUFHLGtCQUFnQixHQUFFLE1BQU0sSUFBSSxVQUFVLG9CQUFvQixFQUFFLEVBQUU7TUFBRSxFQUFFLEVBQUUsQ0FBQztLQUFDO0lBQUMsQ0FBQztHQUFDO0VBQUM7RUFBQyxFQUFFLEdBQUcsUUFBTyxVQUFPO0dBQUMsS0FBSSxNQUFNLEtBQUssRUFBRSxLQUFLLDBCQUF3QixHQUFFLEdBQUcsb0JBQW9CLENBQUM7RUFBQyxDQUFDLEdBQUUsRUFBRSxFQUFFO0VBQUUsTUFBTSxLQUFHLFdBQVUsS0FBRyxPQUFPLE1BQUssS0FBRyxTQUFTLE1BQUssS0FBRyxPQUFPLE1BQUssS0FBRyxRQUFRLE1BQUssS0FBRyxRQUFRLE1BQUssS0FBRyxVQUFVLE1BQUssS0FBRyxPQUFPLE1BQUssS0FBRyxhQUFZLEtBQUcsY0FBYSxLQUFHLFdBQVUsS0FBRyxhQUFZLEtBQUcsUUFBTyxLQUFHLE9BQU0sS0FBRyxVQUFTLEtBQUcsUUFBTyxLQUFHLFFBQU8sS0FBRyxvQkFBbUIsS0FBRyxRQUFRLEdBQUcsSUFBRyxLQUFHLGtGQUEyRSxLQUFHLFlBQVksR0FBRyxvQkFBb0IsR0FBRyxnQkFBZ0IsR0FBRyxJQUFJLE1BQUssS0FBRyxJQUFJLEdBQUcsMkJBQTJCLEdBQUcsNEJBQTRCLEdBQUc7RUFBeUIsTUFBTSxXQUFXLEVBQUM7R0FBQyxZQUFZLEdBQUU7SUFBQyxNQUFNLENBQUMsR0FBRSxLQUFLLFVBQVEsS0FBSyxTQUFTLFFBQVEsdUNBQXFDLEdBQUUsS0FBSyxZQUFVLEtBQUssc0JBQXNCLEtBQUssU0FBUSxLQUFLLGFBQWEsQ0FBQyxHQUFFLEVBQUUsR0FBRyxLQUFLLFVBQVMsS0FBRyxNQUFHLEtBQUssU0FBUyxDQUFDLENBQUM7R0FBRTtHQUFDLFdBQVcsT0FBTTtJQUFDLE9BQU07R0FBSztHQUFDLE9BQU07SUFBQyxNQUFNLElBQUUsS0FBSztJQUFTLElBQUcsS0FBSyxjQUFjLENBQUMsR0FBRTtJQUFPLE1BQU0sSUFBRSxLQUFLLGVBQWUsR0FBRSxJQUFFLElBQUUsRUFBRSxRQUFRLEdBQUUsSUFBRyxFQUFDLGVBQWMsRUFBQyxDQUFDLElBQUU7SUFBSyxFQUFFLFFBQVEsR0FBRSxJQUFHLEVBQUMsZUFBYyxFQUFDLENBQUMsQ0FBQyxDQUFDLG9CQUFrQixLQUFHLEVBQUUscUJBQW1CLEtBQUssWUFBWSxHQUFFLENBQUMsR0FBRSxLQUFLLFVBQVUsR0FBRSxDQUFDO0dBQUU7R0FBQyxVQUFVLEdBQUUsR0FBRTtJQUFDLE1BQUksRUFBRSxVQUFVLElBQUksRUFBRSxHQUFFLEtBQUssVUFBVSxFQUFFLHVCQUF1QixDQUFDLENBQUMsR0FBRSxLQUFLLHFCQUFtQjtLQUFDLFVBQVEsRUFBRSxhQUFhLE1BQU0sS0FBRyxFQUFFLGdCQUFnQixVQUFVLEdBQUUsRUFBRSxhQUFhLGlCQUFnQixDQUFDLENBQUMsR0FBRSxLQUFLLGdCQUFnQixHQUFFLENBQUMsQ0FBQyxHQUFFLEVBQUUsUUFBUSxHQUFFLElBQUcsRUFBQyxlQUFjLEVBQUMsQ0FBQyxLQUFHLEVBQUUsVUFBVSxJQUFJLEVBQUU7SUFBQyxHQUFFLEdBQUUsRUFBRSxVQUFVLFNBQVMsRUFBRSxDQUFDO0dBQUU7R0FBQyxZQUFZLEdBQUUsR0FBRTtJQUFDLE1BQUksRUFBRSxVQUFVLE9BQU8sRUFBRSxHQUFFLEVBQUUsS0FBSyxHQUFFLEtBQUssWUFBWSxFQUFFLHVCQUF1QixDQUFDLENBQUMsR0FBRSxLQUFLLHFCQUFtQjtLQUFDLFVBQVEsRUFBRSxhQUFhLE1BQU0sS0FBRyxFQUFFLGFBQWEsaUJBQWdCLENBQUMsQ0FBQyxHQUFFLEVBQUUsYUFBYSxZQUFXLElBQUksR0FBRSxLQUFLLGdCQUFnQixHQUFFLENBQUMsQ0FBQyxHQUFFLEVBQUUsUUFBUSxHQUFFLElBQUcsRUFBQyxlQUFjLEVBQUMsQ0FBQyxLQUFHLEVBQUUsVUFBVSxPQUFPLEVBQUU7SUFBQyxHQUFFLEdBQUUsRUFBRSxVQUFVLFNBQVMsRUFBRSxDQUFDO0dBQUU7R0FBQyxTQUFTLEdBQUU7SUFBQyxJQUFHLENBQUM7S0FBQztLQUFHO0tBQUc7S0FBRztLQUFHO0tBQUc7SUFBRSxDQUFDLENBQUMsU0FBUyxFQUFFLEdBQUcsR0FBRTtJQUFPLEVBQUUsZ0JBQWdCLEdBQUUsRUFBRSxlQUFlO0lBQUUsTUFBTSxJQUFFLEtBQUssYUFBYSxDQUFDLENBQUMsUUFBTyxNQUFHLENBQUMsRUFBRSxDQUFDLENBQUM7SUFBRSxJQUFJO0lBQUUsSUFBRyxDQUFDLElBQUcsRUFBRSxDQUFDLENBQUMsU0FBUyxFQUFFLEdBQUcsR0FBRSxJQUFFLEVBQUUsRUFBRSxRQUFNLEtBQUcsSUFBRSxFQUFFLFNBQU87U0FBTztLQUFDLE1BQU0sSUFBRSxDQUFDLElBQUcsRUFBRSxDQUFDLENBQUMsU0FBUyxFQUFFLEdBQUc7S0FBRSxJQUFFLEVBQUUsR0FBRSxFQUFFLFFBQU8sR0FBRSxDQUFDLENBQUM7SUFBQztJQUFDLE1BQUksRUFBRSxNQUFNLEVBQUMsZUFBYyxDQUFDLEVBQUMsQ0FBQyxHQUFFLEdBQUcsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLEtBQUs7R0FBRTtHQUFDLGVBQWM7SUFBQyxPQUFPLEVBQUUsS0FBSyxJQUFHLEtBQUssT0FBTztHQUFDO0dBQUMsaUJBQWdCO0lBQUMsT0FBTyxLQUFLLGFBQWEsQ0FBQyxDQUFDLE1BQUssTUFBRyxLQUFLLGNBQWMsQ0FBQyxDQUFDLEtBQUc7R0FBSTtHQUFDLHNCQUFzQixHQUFFLEdBQUU7SUFBQyxLQUFLLHlCQUF5QixHQUFFLFFBQU8sU0FBUztJQUFFLEtBQUksTUFBTSxLQUFLLEdBQUUsS0FBSyw2QkFBNkIsQ0FBQztHQUFDO0dBQUMsNkJBQTZCLEdBQUU7SUFBQyxJQUFFLEtBQUssaUJBQWlCLENBQUM7SUFBRSxNQUFNLElBQUUsS0FBSyxjQUFjLENBQUMsR0FBRSxJQUFFLEtBQUssaUJBQWlCLENBQUM7SUFBRSxFQUFFLGFBQWEsaUJBQWdCLENBQUMsR0FBRSxNQUFJLEtBQUcsS0FBSyx5QkFBeUIsR0FBRSxRQUFPLGNBQWMsR0FBRSxLQUFHLEVBQUUsYUFBYSxZQUFXLElBQUksR0FBRSxLQUFLLHlCQUF5QixHQUFFLFFBQU8sS0FBSyxHQUFFLEtBQUssbUNBQW1DLENBQUM7R0FBQztHQUFDLG1DQUFtQyxHQUFFO0lBQUMsTUFBTSxJQUFFLEVBQUUsdUJBQXVCLENBQUM7SUFBRSxNQUFJLEtBQUsseUJBQXlCLEdBQUUsUUFBTyxVQUFVLEdBQUUsRUFBRSxNQUFJLEtBQUsseUJBQXlCLEdBQUUsbUJBQWtCLEdBQUcsRUFBRSxJQUFJO0dBQUU7R0FBQyxnQkFBZ0IsR0FBRSxHQUFFO0lBQUMsTUFBTSxJQUFFLEtBQUssaUJBQWlCLENBQUM7SUFBRSxJQUFHLENBQUMsRUFBRSxVQUFVLFNBQVMsVUFBVSxHQUFFO0lBQU8sTUFBTSxLQUFHLEdBQUUsTUFBSTtLQUFDLE1BQU0sSUFBRSxFQUFFLFFBQVEsR0FBRSxDQUFDO0tBQUUsS0FBRyxFQUFFLFVBQVUsT0FBTyxHQUFFLENBQUM7SUFBQztJQUFFLEVBQUUsSUFBRyxFQUFFLEdBQUUsRUFBRSxrQkFBaUIsRUFBRSxHQUFFLEVBQUUsYUFBYSxpQkFBZ0IsQ0FBQztHQUFDO0dBQUMseUJBQXlCLEdBQUUsR0FBRSxHQUFFO0lBQUMsRUFBRSxhQUFhLENBQUMsS0FBRyxFQUFFLGFBQWEsR0FBRSxDQUFDO0dBQUM7R0FBQyxjQUFjLEdBQUU7SUFBQyxPQUFPLEVBQUUsVUFBVSxTQUFTLEVBQUU7R0FBQztHQUFDLGlCQUFpQixHQUFFO0lBQUMsT0FBTyxFQUFFLFFBQVEsRUFBRSxJQUFFLElBQUUsRUFBRSxRQUFRLElBQUcsQ0FBQztHQUFDO0dBQUMsaUJBQWlCLEdBQUU7SUFBQyxPQUFPLEVBQUUsUUFBUSw2QkFBNkIsS0FBRztHQUFDO0dBQUMsT0FBTyxnQkFBZ0IsR0FBRTtJQUFDLE9BQU8sS0FBSyxLQUFLLFdBQVU7S0FBQyxNQUFNLElBQUUsR0FBRyxvQkFBb0IsSUFBSTtLQUFFLElBQUcsWUFBVSxPQUFPLEdBQUU7TUFBQyxJQUFHLEtBQUssTUFBSSxFQUFFLE1BQUksRUFBRSxXQUFXLEdBQUcsS0FBRyxrQkFBZ0IsR0FBRSxNQUFNLElBQUksVUFBVSxvQkFBb0IsRUFBRSxFQUFFO01BQUUsRUFBRSxFQUFFLENBQUM7S0FBQztJQUFDLENBQUM7R0FBQztFQUFDO0VBQUMsRUFBRSxHQUFHLFVBQVMsSUFBRyxJQUFHLFNBQVMsR0FBRTtHQUFDLENBQUMsS0FBSSxNQUFNLENBQUMsQ0FBQyxTQUFTLEtBQUssT0FBTyxLQUFHLEVBQUUsZUFBZSxHQUFFLEVBQUUsSUFBSSxLQUFHLEdBQUcsb0JBQW9CLElBQUksQ0FBQyxDQUFDLEtBQUs7RUFBQyxDQUFDLEdBQUUsRUFBRSxHQUFHLFFBQU8sVUFBTztHQUFDLEtBQUksTUFBTSxLQUFLLEVBQUUsS0FBSyxFQUFFLEdBQUUsR0FBRyxvQkFBb0IsQ0FBQztFQUFDLENBQUMsR0FBRSxFQUFFLEVBQUU7RUFBRSxNQUFNLEtBQUcsYUFBWSxLQUFHLFlBQVksTUFBSyxLQUFHLFdBQVcsTUFBSyxLQUFHLFVBQVUsTUFBSyxLQUFHLFdBQVcsTUFBSyxLQUFHLE9BQU8sTUFBSyxLQUFHLFNBQVMsTUFBSyxLQUFHLE9BQU8sTUFBSyxLQUFHLFFBQVEsTUFBSyxLQUFHLFFBQU8sS0FBRyxRQUFPLEtBQUcsV0FBVSxLQUFHO0dBQUMsV0FBVTtHQUFVLFVBQVM7R0FBVSxPQUFNO0VBQVEsR0FBRSxLQUFHO0dBQUMsV0FBVSxDQUFDO0dBQUUsVUFBUyxDQUFDO0dBQUUsT0FBTTtFQUFHO0VBQUUsTUFBTSxXQUFXLEVBQUM7R0FBQyxZQUFZLEdBQUUsR0FBRTtJQUFDLE1BQU0sR0FBRSxDQUFDLEdBQUUsS0FBSyxXQUFTLE1BQUssS0FBSyx1QkFBcUIsQ0FBQyxHQUFFLEtBQUssMEJBQXdCLENBQUMsR0FBRSxLQUFLLGNBQWM7R0FBQztHQUFDLFdBQVcsVUFBUztJQUFDLE9BQU87R0FBRTtHQUFDLFdBQVcsY0FBYTtJQUFDLE9BQU87R0FBRTtHQUFDLFdBQVcsT0FBTTtJQUFDLE9BQU07R0FBTztHQUFDLE9BQU07SUFBQyxFQUFFLFFBQVEsS0FBSyxVQUFTLEVBQUUsQ0FBQyxDQUFDLHFCQUFtQixLQUFLLGNBQWMsR0FBRSxLQUFLLFFBQVEsYUFBVyxLQUFLLFNBQVMsVUFBVSxJQUFJLE1BQU0sR0FBRSxLQUFLLFNBQVMsVUFBVSxPQUFPLEVBQUUsR0FBRSxFQUFFLEtBQUssUUFBUSxHQUFFLEtBQUssU0FBUyxVQUFVLElBQUksSUFBRyxFQUFFLEdBQUUsS0FBSyxxQkFBbUI7S0FBQyxLQUFLLFNBQVMsVUFBVSxPQUFPLEVBQUUsR0FBRSxFQUFFLFFBQVEsS0FBSyxVQUFTLEVBQUUsR0FBRSxLQUFLLG1CQUFtQjtJQUFDLEdBQUUsS0FBSyxVQUFTLEtBQUssUUFBUSxTQUFTO0dBQUU7R0FBQyxPQUFNO0lBQUMsS0FBSyxRQUFRLE1BQUksRUFBRSxRQUFRLEtBQUssVUFBUyxFQUFFLENBQUMsQ0FBQyxxQkFBbUIsS0FBSyxTQUFTLFVBQVUsSUFBSSxFQUFFLEdBQUUsS0FBSyxxQkFBbUI7S0FBQyxLQUFLLFNBQVMsVUFBVSxJQUFJLEVBQUUsR0FBRSxLQUFLLFNBQVMsVUFBVSxPQUFPLElBQUcsRUFBRSxHQUFFLEVBQUUsUUFBUSxLQUFLLFVBQVMsRUFBRTtJQUFDLEdBQUUsS0FBSyxVQUFTLEtBQUssUUFBUSxTQUFTO0dBQUc7R0FBQyxVQUFTO0lBQUMsS0FBSyxjQUFjLEdBQUUsS0FBSyxRQUFRLEtBQUcsS0FBSyxTQUFTLFVBQVUsT0FBTyxFQUFFLEdBQUUsTUFBTSxRQUFRO0dBQUM7R0FBQyxVQUFTO0lBQUMsT0FBTyxLQUFLLFNBQVMsVUFBVSxTQUFTLEVBQUU7R0FBQztHQUFDLHFCQUFvQjtJQUFDLEtBQUssUUFBUSxhQUFXLEtBQUssd0JBQXNCLEtBQUssNEJBQTBCLEtBQUssV0FBUyxpQkFBZTtLQUFDLEtBQUssS0FBSztJQUFDLEdBQUUsS0FBSyxRQUFRLEtBQUs7R0FBRztHQUFDLGVBQWUsR0FBRSxHQUFFO0lBQUMsUUFBTyxFQUFFLE1BQVQ7S0FBZSxLQUFJO0tBQVksS0FBSTtNQUFXLEtBQUssdUJBQXFCO01BQUU7S0FBTSxLQUFJO0tBQVUsS0FBSSxZQUFXLEtBQUssMEJBQXdCO0lBQUM7SUFBQyxJQUFHLEdBQUUsT0FBTyxLQUFLLEtBQUssY0FBYztJQUFFLE1BQU0sSUFBRSxFQUFFO0lBQWMsS0FBSyxhQUFXLEtBQUcsS0FBSyxTQUFTLFNBQVMsQ0FBQyxLQUFHLEtBQUssbUJBQW1CO0dBQUM7R0FBQyxnQkFBZTtJQUFDLEVBQUUsR0FBRyxLQUFLLFVBQVMsS0FBRyxNQUFHLEtBQUssZUFBZSxHQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUUsRUFBRSxHQUFHLEtBQUssVUFBUyxLQUFHLE1BQUcsS0FBSyxlQUFlLEdBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRSxFQUFFLEdBQUcsS0FBSyxVQUFTLEtBQUcsTUFBRyxLQUFLLGVBQWUsR0FBRSxDQUFDLENBQUMsQ0FBQyxHQUFFLEVBQUUsR0FBRyxLQUFLLFVBQVMsS0FBRyxNQUFHLEtBQUssZUFBZSxHQUFFLENBQUMsQ0FBQyxDQUFDO0dBQUM7R0FBQyxnQkFBZTtJQUFDLGFBQWEsS0FBSyxRQUFRLEdBQUUsS0FBSyxXQUFTO0dBQUk7R0FBQyxPQUFPLGdCQUFnQixHQUFFO0lBQUMsT0FBTyxLQUFLLEtBQUssV0FBVTtLQUFDLE1BQU0sSUFBRSxHQUFHLG9CQUFvQixNQUFLLENBQUM7S0FBRSxJQUFHLFlBQVUsT0FBTyxHQUFFO01BQUMsSUFBRyxLQUFLLE1BQUksRUFBRSxJQUFHLE1BQU0sSUFBSSxVQUFVLG9CQUFvQixFQUFFLEVBQUU7TUFBRSxFQUFFLEVBQUUsQ0FBQyxJQUFJO0tBQUM7SUFBQyxDQUFDO0dBQUM7RUFBQztFQUFDLE9BQU8sRUFBRSxFQUFFLEdBQUUsRUFBRSxFQUFFLEdBQUU7R0FBQyxPQUFNO0dBQUUsUUFBTztHQUFFLFVBQVM7R0FBRyxVQUFTO0dBQUcsVUFBUztHQUFHLE9BQU07R0FBRyxXQUFVO0dBQUcsU0FBUTtHQUFHLFdBQVU7R0FBRyxLQUFJO0dBQUcsT0FBTTtHQUFHLFNBQVE7RUFBRTtDQUFDLENBQUMiLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMF19