import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Charts.jsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];const React = __vite__cjsImport3_react;import * as RefreshRuntime from "/@react-refresh";
var _jsxFileName = "C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/components/Charts.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=325d36c7";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
	if (!window.$RefreshReg$) {
		throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong.");
	}
	prevRefreshReg = window.$RefreshReg$;
	prevRefreshSig = window.$RefreshSig$;
	window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/components/Charts.jsx");
	window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=325d36c7";
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, ArcElement, Title, Tooltip, Legend, PointElement, LineElement } from "/node_modules/.vite/deps/chart__js.js?v=325d36c7";
import { Doughnut, Bar } from "/node_modules/.vite/deps/react-chartjs-2.js?v=325d36c7";
ChartJS.register(CategoryScale, LinearScale, BarElement, ArcElement, Title, Tooltip, Legend, PointElement, LineElement);
const PALETTE = [
	"#0f766e",
	"#0891b2",
	"#7c3aed",
	"#d97706",
	"#e11d48",
	"#059669",
	"#475569",
	"#4338ca",
	"#db2777",
	"#0d9488"
];
function ChartCard({ id, title, children }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "col-12 col-md-6 col-xl-4",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "card chart-card",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "card-body p-3",
				children: [/* @__PURE__ */ _jsxDEV("h5", {
					className: "card-title",
					children: title
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 54,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "chart-canvas-wrap",
					children
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 55,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 53,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 52,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 51,
		columnNumber: 5
	}, this);
}
_c = ChartCard;
export default function Charts({ charts }) {
	if (!charts) return null;
	const statusColors = [
		"#cbd5e1",
		"#fbbf24",
		"#34d399",
		"#fb7185"
	];
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "row g-3",
		children: [
			/* @__PURE__ */ _jsxDEV(ChartCard, {
				title: "Applications by Status",
				children: /* @__PURE__ */ _jsxDEV(Doughnut, {
					data: {
						labels: charts.statusBreakdown.map((d) => d.label),
						datasets: [{
							data: charts.statusBreakdown.map((d) => d.value),
							backgroundColor: statusColors,
							borderWidth: 0
						}]
					},
					options: {
						responsive: true,
						maintainAspectRatio: false,
						plugins: { legend: {
							position: "right",
							labels: { font: { size: 10 } }
						} }
					}
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 70,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 69,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(ChartCard, {
				title: "Applications by Course Domain",
				children: /* @__PURE__ */ _jsxDEV(Bar, {
					data: {
						labels: charts.domainBreakdown.map((d) => d.label),
						datasets: [{
							data: charts.domainBreakdown.map((d) => d.value),
							backgroundColor: PALETTE[0]
						}]
					},
					options: {
						responsive: true,
						maintainAspectRatio: false,
						plugins: { legend: { display: false } },
						scales: { y: {
							beginAtZero: true,
							ticks: { precision: 0 }
						} }
					}
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 90,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 89,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(ChartCard, {
				title: "Applications by Course",
				children: /* @__PURE__ */ _jsxDEV(Bar, {
					data: {
						labels: charts.courseBreakdown.map((d) => d.label),
						datasets: [{
							data: charts.courseBreakdown.map((d) => d.value),
							backgroundColor: PALETTE[2]
						}]
					},
					options: {
						indexAxis: "y",
						responsive: true,
						maintainAspectRatio: false,
						plugins: { legend: { display: false } },
						scales: { x: {
							beginAtZero: true,
							ticks: { precision: 0 }
						} }
					}
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 110,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 109,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(ChartCard, {
				title: "Applications by Institution",
				children: /* @__PURE__ */ _jsxDEV(Bar, {
					data: {
						labels: charts.institutionBreakdown.map((d) => d.label),
						datasets: [{
							data: charts.institutionBreakdown.map((d) => d.value),
							backgroundColor: PALETTE[1]
						}]
					},
					options: {
						indexAxis: "y",
						responsive: true,
						maintainAspectRatio: false,
						plugins: { legend: { display: false } },
						scales: { x: {
							beginAtZero: true,
							ticks: { precision: 0 }
						} }
					}
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 131,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 130,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(ChartCard, {
				title: "Monthly Trend (Stacked by Status)",
				children: /* @__PURE__ */ _jsxDEV(Bar, {
					data: {
						labels: charts.monthlyTrend.map((d) => d.month),
						datasets: [
							{
								label: "Submitted",
								data: charts.monthlyTrend.map((d) => d.Submitted),
								backgroundColor: "#cbd5e1"
							},
							{
								label: "Under Review",
								data: charts.monthlyTrend.map((d) => d["Under Review"]),
								backgroundColor: "#fbbf24"
							},
							{
								label: "Approved",
								data: charts.monthlyTrend.map((d) => d.Approved),
								backgroundColor: "#34d399"
							},
							{
								label: "Rejected",
								data: charts.monthlyTrend.map((d) => d.Rejected),
								backgroundColor: "#fb7185"
							}
						]
					},
					options: {
						responsive: true,
						maintainAspectRatio: false,
						scales: {
							x: { stacked: true },
							y: {
								stacked: true,
								beginAtZero: true,
								ticks: { precision: 0 }
							}
						},
						plugins: { legend: {
							position: "top",
							labels: { font: { size: 10 } }
						} }
					}
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 152,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 151,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(ChartCard, {
				title: "Credit-Score Distribution",
				children: /* @__PURE__ */ _jsxDEV(Bar, {
					data: {
						labels: charts.creditScoreBuckets.map((d) => d.bucket),
						datasets: [{
							data: charts.creditScoreBuckets.map((d) => d.count),
							backgroundColor: PALETTE[3]
						}]
					},
					options: {
						responsive: true,
						maintainAspectRatio: false,
						plugins: { legend: { display: false } },
						scales: { y: {
							beginAtZero: true,
							ticks: { precision: 0 }
						} }
					}
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 172,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 171,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(ChartCard, {
				title: "Avg Loan Amount by Course",
				children: /* @__PURE__ */ _jsxDEV(Bar, {
					data: {
						labels: charts.avgLoanByCourse.map((d) => d.courseName),
						datasets: [{
							data: charts.avgLoanByCourse.map((d) => d.avgLoanAmount),
							backgroundColor: PALETTE[5]
						}]
					},
					options: {
						indexAxis: "y",
						responsive: true,
						maintainAspectRatio: false,
						plugins: { legend: { display: false } },
						scales: { x: { beginAtZero: true } }
					}
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 192,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 191,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(ChartCard, {
				title: "Applications by Acquisition Channel",
				children: /* @__PURE__ */ _jsxDEV(Doughnut, {
					data: {
						labels: charts.channelBreakdown.map((d) => d.label),
						datasets: [{
							data: charts.channelBreakdown.map((d) => d.value),
							backgroundColor: PALETTE,
							borderWidth: 0
						}]
					},
					options: {
						responsive: true,
						maintainAspectRatio: false,
						plugins: { legend: {
							position: "right",
							labels: { font: { size: 10 } }
						} }
					}
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 213,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 212,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 68,
		columnNumber: 5
	}, this);
}
_c2 = Charts;
var _c, _c2;
$RefreshReg$(_c, "ChartCard");
$RefreshReg$(_c2, "Charts");
if (import.meta.hot && !inWebWorker) {
	window.$RefreshReg$ = prevRefreshReg;
	window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
	RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
		RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/components/Charts.jsx", currentExports);
		import.meta.hot.accept((nextExports) => {
			if (!nextExports) return;
			const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/components/Charts.jsx", currentExports, nextExports);
			if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
		});
	});
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsT0FBT0EsV0FBVztBQUNsQixTQUNFQyxTQUFTQyxTQUNUQyxlQUNBQyxhQUNBQyxZQUNBQyxZQUNBQyxPQUNBQyxTQUNBQyxRQUNBQyxjQUNBQyxtQkFDSztBQUNQLFNBQVNDLFVBQVVDLFdBQVc7QUFFOUJYLFFBQVFZLFNBQ05YLGVBQ0FDLGFBQ0FDLFlBQ0FDLFlBQ0FDLE9BQ0FDLFNBQ0FDLFFBQ0FDLGNBQ0FDLFdBQ0Y7QUFFQSxNQUFNSSxVQUFVO0NBQUM7Q0FBVztDQUFXO0NBQVc7Q0FBVztDQUFXO0NBQVc7Q0FBVztDQUFXO0NBQVc7QUFBUztBQUU3SCxTQUFTQyxVQUFVLEVBQUVDLElBQUlDLE9BQU9DLFlBQVk7Q0FDMUMsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUNiLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQ2Isd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQWNEO0lBQVU7Ozs7Y0FDdEMsd0JBQUMsT0FBRDtLQUFLLFdBQVU7S0FBcUJDO0lBQWM7Ozs7WUFDL0M7Ozs7OztFQUNGOzs7OztDQUNGOzs7OztBQUVUO0FBQUNDLEtBWFFKO0FBYVQsZUFBZSxTQUFTSyxPQUFPLEVBQUVDLFVBQVU7Q0FDekMsSUFBSSxDQUFDQSxRQUFRLE9BQU87Q0FFcEIsTUFBTUMsZUFBZTtFQUFDO0VBQVc7RUFBVztFQUFXO0NBQVM7Q0FFaEUsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBQ0Usd0JBQUMsV0FBRDtJQUFXLE9BQU07Y0FDZix3QkFBQyxVQUFEO0tBQ0UsTUFBTTtNQUNKQyxRQUFRRixPQUFPRyxnQkFBZ0JDLEtBQUtDLE1BQU1BLEVBQUVDLEtBQUs7TUFDakRDLFVBQVUsQ0FDUjtPQUNFQyxNQUFNUixPQUFPRyxnQkFBZ0JDLEtBQUtDLE1BQU1BLEVBQUVJLEtBQUs7T0FDL0NDLGlCQUFpQlQ7T0FDakJVLGFBQWE7TUFDZixDQUFDO0tBRUw7S0FDQSxTQUFTO01BQ1BDLFlBQVk7TUFDWkMscUJBQXFCO01BQ3JCQyxTQUFTLEVBQUVDLFFBQVE7T0FBRUMsVUFBVTtPQUFTZCxRQUFRLEVBQUVlLE1BQU0sRUFBRUMsTUFBTSxHQUFHLEVBQUU7TUFBRSxFQUFFO0tBQzNFO0lBQUU7Ozs7O0dBRUs7Ozs7O0dBRVgsd0JBQUMsV0FBRDtJQUFXLE9BQU07Y0FDZix3QkFBQyxLQUFEO0tBQ0UsTUFBTTtNQUNKaEIsUUFBUUYsT0FBT21CLGdCQUFnQmYsS0FBS0MsTUFBTUEsRUFBRUMsS0FBSztNQUNqREMsVUFBVSxDQUNSO09BQ0VDLE1BQU1SLE9BQU9tQixnQkFBZ0JmLEtBQUtDLE1BQU1BLEVBQUVJLEtBQUs7T0FDL0NDLGlCQUFpQmpCLFFBQVE7TUFDM0IsQ0FBQztLQUVMO0tBQ0EsU0FBUztNQUNQbUIsWUFBWTtNQUNaQyxxQkFBcUI7TUFDckJDLFNBQVMsRUFBRUMsUUFBUSxFQUFFSyxTQUFTLE1BQU0sRUFBRTtNQUN0Q0MsUUFBUSxFQUFFQyxHQUFHO09BQUVDLGFBQWE7T0FBTUMsT0FBTyxFQUFFQyxXQUFXLEVBQUU7TUFBRSxFQUFFO0tBQzlEO0lBQUU7Ozs7O0dBRUs7Ozs7O0dBRVgsd0JBQUMsV0FBRDtJQUFXLE9BQU07Y0FDZix3QkFBQyxLQUFEO0tBQ0UsTUFBTTtNQUNKdkIsUUFBUUYsT0FBTzBCLGdCQUFnQnRCLEtBQUtDLE1BQU1BLEVBQUVDLEtBQUs7TUFDakRDLFVBQVUsQ0FDUjtPQUNFQyxNQUFNUixPQUFPMEIsZ0JBQWdCdEIsS0FBS0MsTUFBTUEsRUFBRUksS0FBSztPQUMvQ0MsaUJBQWlCakIsUUFBUTtNQUMzQixDQUFDO0tBRUw7S0FDQSxTQUFTO01BQ1BrQyxXQUFXO01BQ1hmLFlBQVk7TUFDWkMscUJBQXFCO01BQ3JCQyxTQUFTLEVBQUVDLFFBQVEsRUFBRUssU0FBUyxNQUFNLEVBQUU7TUFDdENDLFFBQVEsRUFBRU8sR0FBRztPQUFFTCxhQUFhO09BQU1DLE9BQU8sRUFBRUMsV0FBVyxFQUFFO01BQUUsRUFBRTtLQUM5RDtJQUFFOzs7OztHQUVLOzs7OztHQUVYLHdCQUFDLFdBQUQ7SUFBVyxPQUFNO2NBQ2Ysd0JBQUMsS0FBRDtLQUNFLE1BQU07TUFDSnZCLFFBQVFGLE9BQU82QixxQkFBcUJ6QixLQUFLQyxNQUFNQSxFQUFFQyxLQUFLO01BQ3REQyxVQUFVLENBQ1I7T0FDRUMsTUFBTVIsT0FBTzZCLHFCQUFxQnpCLEtBQUtDLE1BQU1BLEVBQUVJLEtBQUs7T0FDcERDLGlCQUFpQmpCLFFBQVE7TUFDM0IsQ0FBQztLQUVMO0tBQ0EsU0FBUztNQUNQa0MsV0FBVztNQUNYZixZQUFZO01BQ1pDLHFCQUFxQjtNQUNyQkMsU0FBUyxFQUFFQyxRQUFRLEVBQUVLLFNBQVMsTUFBTSxFQUFFO01BQ3RDQyxRQUFRLEVBQUVPLEdBQUc7T0FBRUwsYUFBYTtPQUFNQyxPQUFPLEVBQUVDLFdBQVcsRUFBRTtNQUFFLEVBQUU7S0FDOUQ7SUFBRTs7Ozs7R0FFSzs7Ozs7R0FFWCx3QkFBQyxXQUFEO0lBQVcsT0FBTTtjQUNmLHdCQUFDLEtBQUQ7S0FDRSxNQUFNO01BQ0p2QixRQUFRRixPQUFPOEIsYUFBYTFCLEtBQUtDLE1BQU1BLEVBQUUwQixLQUFLO01BQzlDeEIsVUFBVTtPQUNSO1FBQUVELE9BQU87UUFBYUUsTUFBTVIsT0FBTzhCLGFBQWExQixLQUFLQyxNQUFNQSxFQUFFMkIsU0FBUztRQUFHdEIsaUJBQWlCO09BQVU7T0FDcEc7UUFBRUosT0FBTztRQUFnQkUsTUFBTVIsT0FBTzhCLGFBQWExQixLQUFLQyxNQUFNQSxFQUFFLGVBQWU7UUFBR0ssaUJBQWlCO09BQVU7T0FDN0c7UUFBRUosT0FBTztRQUFZRSxNQUFNUixPQUFPOEIsYUFBYTFCLEtBQUtDLE1BQU1BLEVBQUU0QixRQUFRO1FBQUd2QixpQkFBaUI7T0FBVTtPQUNsRztRQUFFSixPQUFPO1FBQVlFLE1BQU1SLE9BQU84QixhQUFhMUIsS0FBS0MsTUFBTUEsRUFBRTZCLFFBQVE7UUFBR3hCLGlCQUFpQjtPQUFVO01BQUM7S0FFdkc7S0FDQSxTQUFTO01BQ1BFLFlBQVk7TUFDWkMscUJBQXFCO01BQ3JCUSxRQUFRO09BQUVPLEdBQUcsRUFBRU8sU0FBUyxLQUFLO09BQUdiLEdBQUc7UUFBRWEsU0FBUztRQUFNWixhQUFhO1FBQU1DLE9BQU8sRUFBRUMsV0FBVyxFQUFFO09BQUU7TUFBRTtNQUNqR1gsU0FBUyxFQUFFQyxRQUFRO09BQUVDLFVBQVU7T0FBT2QsUUFBUSxFQUFFZSxNQUFNLEVBQUVDLE1BQU0sR0FBRyxFQUFFO01BQUUsRUFBRTtLQUN6RTtJQUFFOzs7OztHQUVLOzs7OztHQUVYLHdCQUFDLFdBQUQ7SUFBVyxPQUFNO2NBQ2Ysd0JBQUMsS0FBRDtLQUNFLE1BQU07TUFDSmhCLFFBQVFGLE9BQU9vQyxtQkFBbUJoQyxLQUFLQyxNQUFNQSxFQUFFZ0MsTUFBTTtNQUNyRDlCLFVBQVUsQ0FDUjtPQUNFQyxNQUFNUixPQUFPb0MsbUJBQW1CaEMsS0FBS0MsTUFBTUEsRUFBRWlDLEtBQUs7T0FDbEQ1QixpQkFBaUJqQixRQUFRO01BQzNCLENBQUM7S0FFTDtLQUNBLFNBQVM7TUFDUG1CLFlBQVk7TUFDWkMscUJBQXFCO01BQ3JCQyxTQUFTLEVBQUVDLFFBQVEsRUFBRUssU0FBUyxNQUFNLEVBQUU7TUFDdENDLFFBQVEsRUFBRUMsR0FBRztPQUFFQyxhQUFhO09BQU1DLE9BQU8sRUFBRUMsV0FBVyxFQUFFO01BQUUsRUFBRTtLQUM5RDtJQUFFOzs7OztHQUVLOzs7OztHQUVYLHdCQUFDLFdBQUQ7SUFBVyxPQUFNO2NBQ2Ysd0JBQUMsS0FBRDtLQUNFLE1BQU07TUFDSnZCLFFBQVFGLE9BQU91QyxnQkFBZ0JuQyxLQUFLQyxNQUFNQSxFQUFFbUMsVUFBVTtNQUN0RGpDLFVBQVUsQ0FDUjtPQUNFQyxNQUFNUixPQUFPdUMsZ0JBQWdCbkMsS0FBS0MsTUFBTUEsRUFBRW9DLGFBQWE7T0FDdkQvQixpQkFBaUJqQixRQUFRO01BQzNCLENBQUM7S0FFTDtLQUNBLFNBQVM7TUFDUGtDLFdBQVc7TUFDWGYsWUFBWTtNQUNaQyxxQkFBcUI7TUFDckJDLFNBQVMsRUFBRUMsUUFBUSxFQUFFSyxTQUFTLE1BQU0sRUFBRTtNQUN0Q0MsUUFBUSxFQUFFTyxHQUFHLEVBQUVMLGFBQWEsS0FBSyxFQUFFO0tBQ3JDO0lBQUU7Ozs7O0dBRUs7Ozs7O0dBRVgsd0JBQUMsV0FBRDtJQUFXLE9BQU07Y0FDZix3QkFBQyxVQUFEO0tBQ0UsTUFBTTtNQUNKckIsUUFBUUYsT0FBTzBDLGlCQUFpQnRDLEtBQUtDLE1BQU1BLEVBQUVDLEtBQUs7TUFDbERDLFVBQVUsQ0FDUjtPQUNFQyxNQUFNUixPQUFPMEMsaUJBQWlCdEMsS0FBS0MsTUFBTUEsRUFBRUksS0FBSztPQUNoREMsaUJBQWlCakI7T0FDakJrQixhQUFhO01BQ2YsQ0FBQztLQUVMO0tBQ0EsU0FBUztNQUNQQyxZQUFZO01BQ1pDLHFCQUFxQjtNQUNyQkMsU0FBUyxFQUFFQyxRQUFRO09BQUVDLFVBQVU7T0FBU2QsUUFBUSxFQUFFZSxNQUFNLEVBQUVDLE1BQU0sR0FBRyxFQUFFO01BQUUsRUFBRTtLQUMzRTtJQUFFOzs7OztHQUVLOzs7OztFQUNSOzs7Ozs7QUFFVDtBQUFDeUIsTUEzS3VCNUM7QUFBTSxJQUFBRCxJQUFBNkM7QUFBQSxhQUFBN0MsSUFBQTtBQUFBLGFBQUE2QyxLQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJDaGFydCIsIkNoYXJ0SlMiLCJDYXRlZ29yeVNjYWxlIiwiTGluZWFyU2NhbGUiLCJCYXJFbGVtZW50IiwiQXJjRWxlbWVudCIsIlRpdGxlIiwiVG9vbHRpcCIsIkxlZ2VuZCIsIlBvaW50RWxlbWVudCIsIkxpbmVFbGVtZW50IiwiRG91Z2hudXQiLCJCYXIiLCJyZWdpc3RlciIsIlBBTEVUVEUiLCJDaGFydENhcmQiLCJpZCIsInRpdGxlIiwiY2hpbGRyZW4iLCJfYyIsIkNoYXJ0cyIsImNoYXJ0cyIsInN0YXR1c0NvbG9ycyIsImxhYmVscyIsInN0YXR1c0JyZWFrZG93biIsIm1hcCIsImQiLCJsYWJlbCIsImRhdGFzZXRzIiwiZGF0YSIsInZhbHVlIiwiYmFja2dyb3VuZENvbG9yIiwiYm9yZGVyV2lkdGgiLCJyZXNwb25zaXZlIiwibWFpbnRhaW5Bc3BlY3RSYXRpbyIsInBsdWdpbnMiLCJsZWdlbmQiLCJwb3NpdGlvbiIsImZvbnQiLCJzaXplIiwiZG9tYWluQnJlYWtkb3duIiwiZGlzcGxheSIsInNjYWxlcyIsInkiLCJiZWdpbkF0WmVybyIsInRpY2tzIiwicHJlY2lzaW9uIiwiY291cnNlQnJlYWtkb3duIiwiaW5kZXhBeGlzIiwieCIsImluc3RpdHV0aW9uQnJlYWtkb3duIiwibW9udGhseVRyZW5kIiwibW9udGgiLCJTdWJtaXR0ZWQiLCJBcHByb3ZlZCIsIlJlamVjdGVkIiwic3RhY2tlZCIsImNyZWRpdFNjb3JlQnVja2V0cyIsImJ1Y2tldCIsImNvdW50IiwiYXZnTG9hbkJ5Q291cnNlIiwiY291cnNlTmFtZSIsImF2Z0xvYW5BbW91bnQiLCJjaGFubmVsQnJlYWtkb3duIiwiX2MyIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkNoYXJ0cy5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHtcbiAgQ2hhcnQgYXMgQ2hhcnRKUyxcbiAgQ2F0ZWdvcnlTY2FsZSxcbiAgTGluZWFyU2NhbGUsXG4gIEJhckVsZW1lbnQsXG4gIEFyY0VsZW1lbnQsXG4gIFRpdGxlLFxuICBUb29sdGlwLFxuICBMZWdlbmQsXG4gIFBvaW50RWxlbWVudCxcbiAgTGluZUVsZW1lbnQsXG59IGZyb20gXCJjaGFydC5qc1wiO1xuaW1wb3J0IHsgRG91Z2hudXQsIEJhciB9IGZyb20gXCJyZWFjdC1jaGFydGpzLTJcIjtcblxuQ2hhcnRKUy5yZWdpc3RlcihcbiAgQ2F0ZWdvcnlTY2FsZSxcbiAgTGluZWFyU2NhbGUsXG4gIEJhckVsZW1lbnQsXG4gIEFyY0VsZW1lbnQsXG4gIFRpdGxlLFxuICBUb29sdGlwLFxuICBMZWdlbmQsXG4gIFBvaW50RWxlbWVudCxcbiAgTGluZUVsZW1lbnRcbik7XG5cbmNvbnN0IFBBTEVUVEUgPSBbXCIjMGY3NjZlXCIsIFwiIzA4OTFiMlwiLCBcIiM3YzNhZWRcIiwgXCIjZDk3NzA2XCIsIFwiI2UxMWQ0OFwiLCBcIiMwNTk2NjlcIiwgXCIjNDc1NTY5XCIsIFwiIzQzMzhjYVwiLCBcIiNkYjI3NzdcIiwgXCIjMGQ5NDg4XCJdO1xuXG5mdW5jdGlvbiBDaGFydENhcmQoeyBpZCwgdGl0bGUsIGNoaWxkcmVuIH0pIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC0xMiBjb2wtbWQtNiBjb2wteGwtNFwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkIGNoYXJ0LWNhcmRcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkLWJvZHkgcC0zXCI+XG4gICAgICAgICAgPGg1IGNsYXNzTmFtZT1cImNhcmQtdGl0bGVcIj57dGl0bGV9PC9oNT5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNoYXJ0LWNhbnZhcy13cmFwXCI+e2NoaWxkcmVufTwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufVxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBDaGFydHMoeyBjaGFydHMgfSkge1xuICBpZiAoIWNoYXJ0cykgcmV0dXJuIG51bGw7XG5cbiAgY29uc3Qgc3RhdHVzQ29sb3JzID0gW1wiI2NiZDVlMVwiLCBcIiNmYmJmMjRcIiwgXCIjMzRkMzk5XCIsIFwiI2ZiNzE4NVwiXTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGctM1wiPlxuICAgICAgPENoYXJ0Q2FyZCB0aXRsZT1cIkFwcGxpY2F0aW9ucyBieSBTdGF0dXNcIj5cbiAgICAgICAgPERvdWdobnV0XG4gICAgICAgICAgZGF0YT17e1xuICAgICAgICAgICAgbGFiZWxzOiBjaGFydHMuc3RhdHVzQnJlYWtkb3duLm1hcCgoZCkgPT4gZC5sYWJlbCksXG4gICAgICAgICAgICBkYXRhc2V0czogW1xuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZGF0YTogY2hhcnRzLnN0YXR1c0JyZWFrZG93bi5tYXAoKGQpID0+IGQudmFsdWUpLFxuICAgICAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogc3RhdHVzQ29sb3JzLFxuICAgICAgICAgICAgICAgIGJvcmRlcldpZHRoOiAwLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgXSxcbiAgICAgICAgICB9fVxuICAgICAgICAgIG9wdGlvbnM9e3tcbiAgICAgICAgICAgIHJlc3BvbnNpdmU6IHRydWUsXG4gICAgICAgICAgICBtYWludGFpbkFzcGVjdFJhdGlvOiBmYWxzZSxcbiAgICAgICAgICAgIHBsdWdpbnM6IHsgbGVnZW5kOiB7IHBvc2l0aW9uOiBcInJpZ2h0XCIsIGxhYmVsczogeyBmb250OiB7IHNpemU6IDEwIH0gfSB9IH0sXG4gICAgICAgICAgfX1cbiAgICAgICAgLz5cbiAgICAgIDwvQ2hhcnRDYXJkPlxuXG4gICAgICA8Q2hhcnRDYXJkIHRpdGxlPVwiQXBwbGljYXRpb25zIGJ5IENvdXJzZSBEb21haW5cIj5cbiAgICAgICAgPEJhclxuICAgICAgICAgIGRhdGE9e3tcbiAgICAgICAgICAgIGxhYmVsczogY2hhcnRzLmRvbWFpbkJyZWFrZG93bi5tYXAoKGQpID0+IGQubGFiZWwpLFxuICAgICAgICAgICAgZGF0YXNldHM6IFtcbiAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGRhdGE6IGNoYXJ0cy5kb21haW5CcmVha2Rvd24ubWFwKChkKSA9PiBkLnZhbHVlKSxcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IFBBTEVUVEVbMF0sXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBdLFxuICAgICAgICAgIH19XG4gICAgICAgICAgb3B0aW9ucz17e1xuICAgICAgICAgICAgcmVzcG9uc2l2ZTogdHJ1ZSxcbiAgICAgICAgICAgIG1haW50YWluQXNwZWN0UmF0aW86IGZhbHNlLFxuICAgICAgICAgICAgcGx1Z2luczogeyBsZWdlbmQ6IHsgZGlzcGxheTogZmFsc2UgfSB9LFxuICAgICAgICAgICAgc2NhbGVzOiB7IHk6IHsgYmVnaW5BdFplcm86IHRydWUsIHRpY2tzOiB7IHByZWNpc2lvbjogMCB9IH0gfSxcbiAgICAgICAgICB9fVxuICAgICAgICAvPlxuICAgICAgPC9DaGFydENhcmQ+XG5cbiAgICAgIDxDaGFydENhcmQgdGl0bGU9XCJBcHBsaWNhdGlvbnMgYnkgQ291cnNlXCI+XG4gICAgICAgIDxCYXJcbiAgICAgICAgICBkYXRhPXt7XG4gICAgICAgICAgICBsYWJlbHM6IGNoYXJ0cy5jb3Vyc2VCcmVha2Rvd24ubWFwKChkKSA9PiBkLmxhYmVsKSxcbiAgICAgICAgICAgIGRhdGFzZXRzOiBbXG4gICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBkYXRhOiBjaGFydHMuY291cnNlQnJlYWtkb3duLm1hcCgoZCkgPT4gZC52YWx1ZSksXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiBQQUxFVFRFWzJdLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgXSxcbiAgICAgICAgICB9fVxuICAgICAgICAgIG9wdGlvbnM9e3tcbiAgICAgICAgICAgIGluZGV4QXhpczogXCJ5XCIsXG4gICAgICAgICAgICByZXNwb25zaXZlOiB0cnVlLFxuICAgICAgICAgICAgbWFpbnRhaW5Bc3BlY3RSYXRpbzogZmFsc2UsXG4gICAgICAgICAgICBwbHVnaW5zOiB7IGxlZ2VuZDogeyBkaXNwbGF5OiBmYWxzZSB9IH0sXG4gICAgICAgICAgICBzY2FsZXM6IHsgeDogeyBiZWdpbkF0WmVybzogdHJ1ZSwgdGlja3M6IHsgcHJlY2lzaW9uOiAwIH0gfSB9LFxuICAgICAgICAgIH19XG4gICAgICAgIC8+XG4gICAgICA8L0NoYXJ0Q2FyZD5cblxuICAgICAgPENoYXJ0Q2FyZCB0aXRsZT1cIkFwcGxpY2F0aW9ucyBieSBJbnN0aXR1dGlvblwiPlxuICAgICAgICA8QmFyXG4gICAgICAgICAgZGF0YT17e1xuICAgICAgICAgICAgbGFiZWxzOiBjaGFydHMuaW5zdGl0dXRpb25CcmVha2Rvd24ubWFwKChkKSA9PiBkLmxhYmVsKSxcbiAgICAgICAgICAgIGRhdGFzZXRzOiBbXG4gICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBkYXRhOiBjaGFydHMuaW5zdGl0dXRpb25CcmVha2Rvd24ubWFwKChkKSA9PiBkLnZhbHVlKSxcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IFBBTEVUVEVbMV0sXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBdLFxuICAgICAgICAgIH19XG4gICAgICAgICAgb3B0aW9ucz17e1xuICAgICAgICAgICAgaW5kZXhBeGlzOiBcInlcIixcbiAgICAgICAgICAgIHJlc3BvbnNpdmU6IHRydWUsXG4gICAgICAgICAgICBtYWludGFpbkFzcGVjdFJhdGlvOiBmYWxzZSxcbiAgICAgICAgICAgIHBsdWdpbnM6IHsgbGVnZW5kOiB7IGRpc3BsYXk6IGZhbHNlIH0gfSxcbiAgICAgICAgICAgIHNjYWxlczogeyB4OiB7IGJlZ2luQXRaZXJvOiB0cnVlLCB0aWNrczogeyBwcmVjaXNpb246IDAgfSB9IH0sXG4gICAgICAgICAgfX1cbiAgICAgICAgLz5cbiAgICAgIDwvQ2hhcnRDYXJkPlxuXG4gICAgICA8Q2hhcnRDYXJkIHRpdGxlPVwiTW9udGhseSBUcmVuZCAoU3RhY2tlZCBieSBTdGF0dXMpXCI+XG4gICAgICAgIDxCYXJcbiAgICAgICAgICBkYXRhPXt7XG4gICAgICAgICAgICBsYWJlbHM6IGNoYXJ0cy5tb250aGx5VHJlbmQubWFwKChkKSA9PiBkLm1vbnRoKSxcbiAgICAgICAgICAgIGRhdGFzZXRzOiBbXG4gICAgICAgICAgICAgIHsgbGFiZWw6IFwiU3VibWl0dGVkXCIsIGRhdGE6IGNoYXJ0cy5tb250aGx5VHJlbmQubWFwKChkKSA9PiBkLlN1Ym1pdHRlZCksIGJhY2tncm91bmRDb2xvcjogXCIjY2JkNWUxXCIgfSxcbiAgICAgICAgICAgICAgeyBsYWJlbDogXCJVbmRlciBSZXZpZXdcIiwgZGF0YTogY2hhcnRzLm1vbnRobHlUcmVuZC5tYXAoKGQpID0+IGRbXCJVbmRlciBSZXZpZXdcIl0pLCBiYWNrZ3JvdW5kQ29sb3I6IFwiI2ZiYmYyNFwiIH0sXG4gICAgICAgICAgICAgIHsgbGFiZWw6IFwiQXBwcm92ZWRcIiwgZGF0YTogY2hhcnRzLm1vbnRobHlUcmVuZC5tYXAoKGQpID0+IGQuQXBwcm92ZWQpLCBiYWNrZ3JvdW5kQ29sb3I6IFwiIzM0ZDM5OVwiIH0sXG4gICAgICAgICAgICAgIHsgbGFiZWw6IFwiUmVqZWN0ZWRcIiwgZGF0YTogY2hhcnRzLm1vbnRobHlUcmVuZC5tYXAoKGQpID0+IGQuUmVqZWN0ZWQpLCBiYWNrZ3JvdW5kQ29sb3I6IFwiI2ZiNzE4NVwiIH0sXG4gICAgICAgICAgICBdLFxuICAgICAgICAgIH19XG4gICAgICAgICAgb3B0aW9ucz17e1xuICAgICAgICAgICAgcmVzcG9uc2l2ZTogdHJ1ZSxcbiAgICAgICAgICAgIG1haW50YWluQXNwZWN0UmF0aW86IGZhbHNlLFxuICAgICAgICAgICAgc2NhbGVzOiB7IHg6IHsgc3RhY2tlZDogdHJ1ZSB9LCB5OiB7IHN0YWNrZWQ6IHRydWUsIGJlZ2luQXRaZXJvOiB0cnVlLCB0aWNrczogeyBwcmVjaXNpb246IDAgfSB9IH0sXG4gICAgICAgICAgICBwbHVnaW5zOiB7IGxlZ2VuZDogeyBwb3NpdGlvbjogXCJ0b3BcIiwgbGFiZWxzOiB7IGZvbnQ6IHsgc2l6ZTogMTAgfSB9IH0gfSxcbiAgICAgICAgICB9fVxuICAgICAgICAvPlxuICAgICAgPC9DaGFydENhcmQ+XG5cbiAgICAgIDxDaGFydENhcmQgdGl0bGU9XCJDcmVkaXQtU2NvcmUgRGlzdHJpYnV0aW9uXCI+XG4gICAgICAgIDxCYXJcbiAgICAgICAgICBkYXRhPXt7XG4gICAgICAgICAgICBsYWJlbHM6IGNoYXJ0cy5jcmVkaXRTY29yZUJ1Y2tldHMubWFwKChkKSA9PiBkLmJ1Y2tldCksXG4gICAgICAgICAgICBkYXRhc2V0czogW1xuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZGF0YTogY2hhcnRzLmNyZWRpdFNjb3JlQnVja2V0cy5tYXAoKGQpID0+IGQuY291bnQpLFxuICAgICAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogUEFMRVRURVszXSxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIF0sXG4gICAgICAgICAgfX1cbiAgICAgICAgICBvcHRpb25zPXt7XG4gICAgICAgICAgICByZXNwb25zaXZlOiB0cnVlLFxuICAgICAgICAgICAgbWFpbnRhaW5Bc3BlY3RSYXRpbzogZmFsc2UsXG4gICAgICAgICAgICBwbHVnaW5zOiB7IGxlZ2VuZDogeyBkaXNwbGF5OiBmYWxzZSB9IH0sXG4gICAgICAgICAgICBzY2FsZXM6IHsgeTogeyBiZWdpbkF0WmVybzogdHJ1ZSwgdGlja3M6IHsgcHJlY2lzaW9uOiAwIH0gfSB9LFxuICAgICAgICAgIH19XG4gICAgICAgIC8+XG4gICAgICA8L0NoYXJ0Q2FyZD5cblxuICAgICAgPENoYXJ0Q2FyZCB0aXRsZT1cIkF2ZyBMb2FuIEFtb3VudCBieSBDb3Vyc2VcIj5cbiAgICAgICAgPEJhclxuICAgICAgICAgIGRhdGE9e3tcbiAgICAgICAgICAgIGxhYmVsczogY2hhcnRzLmF2Z0xvYW5CeUNvdXJzZS5tYXAoKGQpID0+IGQuY291cnNlTmFtZSksXG4gICAgICAgICAgICBkYXRhc2V0czogW1xuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZGF0YTogY2hhcnRzLmF2Z0xvYW5CeUNvdXJzZS5tYXAoKGQpID0+IGQuYXZnTG9hbkFtb3VudCksXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiBQQUxFVFRFWzVdLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgXSxcbiAgICAgICAgICB9fVxuICAgICAgICAgIG9wdGlvbnM9e3tcbiAgICAgICAgICAgIGluZGV4QXhpczogXCJ5XCIsXG4gICAgICAgICAgICByZXNwb25zaXZlOiB0cnVlLFxuICAgICAgICAgICAgbWFpbnRhaW5Bc3BlY3RSYXRpbzogZmFsc2UsXG4gICAgICAgICAgICBwbHVnaW5zOiB7IGxlZ2VuZDogeyBkaXNwbGF5OiBmYWxzZSB9IH0sXG4gICAgICAgICAgICBzY2FsZXM6IHsgeDogeyBiZWdpbkF0WmVybzogdHJ1ZSB9IH0sXG4gICAgICAgICAgfX1cbiAgICAgICAgLz5cbiAgICAgIDwvQ2hhcnRDYXJkPlxuXG4gICAgICA8Q2hhcnRDYXJkIHRpdGxlPVwiQXBwbGljYXRpb25zIGJ5IEFjcXVpc2l0aW9uIENoYW5uZWxcIj5cbiAgICAgICAgPERvdWdobnV0XG4gICAgICAgICAgZGF0YT17e1xuICAgICAgICAgICAgbGFiZWxzOiBjaGFydHMuY2hhbm5lbEJyZWFrZG93bi5tYXAoKGQpID0+IGQubGFiZWwpLFxuICAgICAgICAgICAgZGF0YXNldHM6IFtcbiAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGRhdGE6IGNoYXJ0cy5jaGFubmVsQnJlYWtkb3duLm1hcCgoZCkgPT4gZC52YWx1ZSksXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiBQQUxFVFRFLFxuICAgICAgICAgICAgICAgIGJvcmRlcldpZHRoOiAwLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgXSxcbiAgICAgICAgICB9fVxuICAgICAgICAgIG9wdGlvbnM9e3tcbiAgICAgICAgICAgIHJlc3BvbnNpdmU6IHRydWUsXG4gICAgICAgICAgICBtYWludGFpbkFzcGVjdFJhdGlvOiBmYWxzZSxcbiAgICAgICAgICAgIHBsdWdpbnM6IHsgbGVnZW5kOiB7IHBvc2l0aW9uOiBcInJpZ2h0XCIsIGxhYmVsczogeyBmb250OiB7IHNpemU6IDEwIH0gfSB9IH0sXG4gICAgICAgICAgfX1cbiAgICAgICAgLz5cbiAgICAgIDwvQ2hhcnRDYXJkPlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiJDOi9Vc2Vycy91c2VyL0Rvd25sb2Fkcy9kaGFuaXRpLWFwcC11cGdyYWRlZC9kaGFuaXRpLWFwcC9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9DaGFydHMuanN4In0=