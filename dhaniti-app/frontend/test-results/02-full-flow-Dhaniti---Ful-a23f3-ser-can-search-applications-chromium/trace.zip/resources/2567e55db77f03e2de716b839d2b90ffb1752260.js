import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Insights.jsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];const React = __vite__cjsImport3_react;import * as RefreshRuntime from "/@react-refresh";
var _jsxFileName = "C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/components/Insights.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=325d36c7";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
	if (!window.$RefreshReg$) {
		throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong.");
	}
	prevRefreshReg = window.$RefreshReg$;
	prevRefreshSig = window.$RefreshSig$;
	window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/components/Insights.jsx");
	window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=325d36c7";
export default function Insights({ insights }) {
	if (!insights) return null;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "row g-3",
		children: insights.map((i) => /* @__PURE__ */ _jsxDEV("div", {
			className: "col-12 col-md-6 col-xl-4",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "card insight-card",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "card-body p-3",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "d-flex justify-content-between align-items-start gap-2 mb-2",
							children: [/* @__PURE__ */ _jsxDEV("h5", {
								className: "card-title mb-0",
								style: {
									fontSize: "0.92rem",
									fontWeight: 600
								},
								children: i.title
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 31,
								columnNumber: 17
							}, this), i.metric && /* @__PURE__ */ _jsxDEV("span", {
								className: "metric-pill",
								children: i.metric
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 35,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 30,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "finding mb-3",
							children: i.finding
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 38,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "calc-box mb-2",
							children: [
								/* @__PURE__ */ _jsxDEV("strong", { children: "How calculated:" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 40,
									columnNumber: 17
								}, this),
								" ",
								i.calculation
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 39,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "why-box",
							children: i.whyItMatters
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 42,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 29,
					columnNumber: 13
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 28,
				columnNumber: 11
			}, this)
		}, i.id, false, {
			fileName: _jsxFileName,
			lineNumber: 27,
			columnNumber: 7
		}, this))
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 25,
		columnNumber: 5
	}, this);
}
_c = Insights;
var _c;
$RefreshReg$(_c, "Insights");
if (import.meta.hot && !inWebWorker) {
	window.$RefreshReg$ = prevRefreshReg;
	window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
	RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
		RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/components/Insights.jsx", currentExports);
		import.meta.hot.accept((nextExports) => {
			if (!nextExports) return;
			const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/components/Insights.jsx", currentExports, nextExports);
			if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
		});
	});
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsT0FBT0EsV0FBVztBQUVsQixlQUFlLFNBQVNDLFNBQVMsRUFBRUMsWUFBWTtDQUM3QyxJQUFJLENBQUNBLFVBQVUsT0FBTztDQUN0QixPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQ1pBLFNBQVNDLEtBQUtDLE1BQ2Isd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFDYix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNiLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO1FBQWtCLE9BQU87U0FBRUMsVUFBVTtTQUFXQyxZQUFZO1FBQUk7a0JBQzNFRixFQUFFRztPQUNEOzs7O2lCQUNISCxFQUFFSSxVQUNELHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFlSixFQUFFSTtPQUFhOzs7O2VBRTdDOzs7Ozs7TUFDTCx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBZ0JKLEVBQUVLO01BQVc7Ozs7O01BQzFDLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsVUFBRCxZQUFRLGtCQUF1Qjs7Ozs7UUFBQztRQUFFTCxFQUFFTTtPQUNqQzs7Ozs7O01BQ0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQVdOLEVBQUVPO01BQWtCOzs7OztLQUMzQzs7Ozs7O0dBQ0Y7Ozs7O0VBQ0YsR0FsQjBDUCxFQUFFUTs7OztTQWtCNUMsQ0FDTjtDQUNFOzs7OztBQUVUO0FBQUNDLEtBM0J1Qlo7QUFBUSxJQUFBWTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsIkluc2lnaHRzIiwiaW5zaWdodHMiLCJtYXAiLCJpIiwiZm9udFNpemUiLCJmb250V2VpZ2h0IiwidGl0bGUiLCJtZXRyaWMiLCJmaW5kaW5nIiwiY2FsY3VsYXRpb24iLCJ3aHlJdE1hdHRlcnMiLCJpZCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkluc2lnaHRzLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEluc2lnaHRzKHsgaW5zaWdodHMgfSkge1xuICBpZiAoIWluc2lnaHRzKSByZXR1cm4gbnVsbDtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdyBnLTNcIj5cbiAgICAgIHtpbnNpZ2h0cy5tYXAoKGkpID0+IChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtMTIgY29sLW1kLTYgY29sLXhsLTRcIiBrZXk9e2kuaWR9PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZCBpbnNpZ2h0LWNhcmRcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZC1ib2R5IHAtM1wiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImQtZmxleCBqdXN0aWZ5LWNvbnRlbnQtYmV0d2VlbiBhbGlnbi1pdGVtcy1zdGFydCBnYXAtMiBtYi0yXCI+XG4gICAgICAgICAgICAgICAgPGg1IGNsYXNzTmFtZT1cImNhcmQtdGl0bGUgbWItMFwiIHN0eWxlPXt7IGZvbnRTaXplOiBcIjAuOTJyZW1cIiwgZm9udFdlaWdodDogNjAwIH19PlxuICAgICAgICAgICAgICAgICAge2kudGl0bGV9XG4gICAgICAgICAgICAgICAgPC9oNT5cbiAgICAgICAgICAgICAgICB7aS5tZXRyaWMgJiYgKFxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWV0cmljLXBpbGxcIj57aS5tZXRyaWN9PC9zcGFuPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmaW5kaW5nIG1iLTNcIj57aS5maW5kaW5nfTwvcD5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYWxjLWJveCBtYi0yXCI+XG4gICAgICAgICAgICAgICAgPHN0cm9uZz5Ib3cgY2FsY3VsYXRlZDo8L3N0cm9uZz4ge2kuY2FsY3VsYXRpb259XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIndoeS1ib3hcIj57aS53aHlJdE1hdHRlcnN9PC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiQzovVXNlcnMvdXNlci9Eb3dubG9hZHMvZGhhbml0aS1hcHAtdXBncmFkZWQvZGhhbml0aS1hcHAvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvSW5zaWdodHMuanN4In0=