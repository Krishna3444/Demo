import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/ForgotPassword.jsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport1_react_jsxDevRuntime["Fragment"];const React = __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"];import * as RefreshRuntime from "/@react-refresh";
var _jsxFileName = "C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/pages/ForgotPassword.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=325d36c7";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
	if (!window.$RefreshReg$) {
		throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong.");
	}
	prevRefreshReg = window.$RefreshReg$;
	prevRefreshSig = window.$RefreshSig$;
	window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/pages/ForgotPassword.jsx");
	window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=325d36c7";
import { Link, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=325d36c7";
import { authApi } from "/src/api/auth.js";
import { useToast } from "/src/context/ToastContext.jsx";
export default function ForgotPassword() {
	_s();
	const navigate = useNavigate();
	const toast = useToast();
	const [email, setEmail] = useState("");
	const [error, setError] = useState("");
	const [fieldError, setFieldError] = useState("");
	const [loading, setLoading] = useState(false);
	async function handleSubmit(e) {
		e.preventDefault();
		setError("");
		if (!email.trim()) {
			setFieldError("Email address is required.");
			return;
		}
		if (!/^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$/.test(email.trim())) {
			setFieldError("Invalid email address.");
			return;
		}
		setFieldError("");
		setLoading(true);
		try {
			await authApi.sendOtp(email.trim(), "password_reset");
			toast.info("If that email is registered, a reset code is on its way.");
			navigate("/verify-otp", { state: {
				email: email.trim(),
				purpose: "password_reset"
			} });
		} catch (err) {
			setError(err.message);
		} finally {
			setLoading(false);
		}
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "login-wrapper",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "card login-card",
			style: { maxWidth: 420 },
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "card-header text-center",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "mx-auto mb-2 d-flex align-items-center justify-content-center",
						style: {
							width: 48,
							height: 48,
							borderRadius: 14,
							background: "linear-gradient(135deg, #0f766e 0%, #134e4a 100%)",
							color: "white",
							fontSize: 22
						},
						children: /* @__PURE__ */ _jsxDEV("i", {
							className: "bi bi-key",
							"aria-hidden": "true"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 72,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 61,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("h5", {
						className: "mb-0 fw-semibold",
						children: "Forgot your password?"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 74,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-muted small mb-0 mt-1",
						children: "Enter your account email and we'll send you a verification code to choose a new password."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 75,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 60,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "card-body p-4",
				children: [
					error && /* @__PURE__ */ _jsxDEV("div", {
						className: "alert alert-danger py-2",
						role: "alert",
						children: error
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 82,
						columnNumber: 21
					}, this),
					/* @__PURE__ */ _jsxDEV("form", {
						onSubmit: handleSubmit,
						noValidate: true,
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "mb-4",
							children: [
								/* @__PURE__ */ _jsxDEV("label", {
									htmlFor: "fp-email",
									className: "form-label",
									children: "Email"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 86,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("input", {
									type: "email",
									className: `form-control ${fieldError ? "is-invalid" : ""}`,
									id: "fp-email",
									value: email,
									onChange: (e) => setEmail(e.target.value),
									autoComplete: "username",
									disabled: loading,
									placeholder: "you@company.com"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 87,
									columnNumber: 15
								}, this),
								fieldError && /* @__PURE__ */ _jsxDEV("div", {
									className: "invalid-feedback",
									children: fieldError
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 97,
									columnNumber: 30
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 85,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "submit",
							className: "btn btn-dhaniti w-100",
							disabled: loading,
							children: loading ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "spinner-border spinner-border-sm me-2",
								role: "status",
								"aria-hidden": "true"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 103,
								columnNumber: 19
							}, this), "Sending code…"] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 102,
								columnNumber: 15
							}, this) : "Send reset code"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 100,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 84,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-center small mt-4 mb-0",
						children: /* @__PURE__ */ _jsxDEV(Link, {
							to: "/login",
							children: [/* @__PURE__ */ _jsxDEV("i", {
								className: "bi bi-arrow-left me-1",
								"aria-hidden": "true"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 114,
								columnNumber: 15
							}, this), "Back to sign in"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 113,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 112,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 81,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 59,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 58,
		columnNumber: 5
	}, this);
}
_s(ForgotPassword, "8LDn9vi9HjNg403wzqP4G2jbx9g=", false, function() {
	return [useNavigate, useToast];
});
_c = ForgotPassword;
var _c;
$RefreshReg$(_c, "ForgotPassword");
if (import.meta.hot && !inWebWorker) {
	window.$RefreshReg$ = prevRefreshReg;
	window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
	RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
		RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/pages/ForgotPassword.jsx", currentExports);
		import.meta.hot.accept((nextExports) => {
			if (!nextExports) return;
			const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/pages/ForgotPassword.jsx", currentExports, nextExports);
			if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
		});
	});
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLE9BQU9BLFNBQVNDLGdCQUFnQjtBQUNoQyxTQUFTQyxNQUFNQyxtQkFBbUI7QUFDbEMsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxnQkFBZ0I7QUFFekIsZUFBZSxTQUFTQyxpQkFBaUI7Q0FBQUMsR0FBQTtDQUN2QyxNQUFNQyxXQUFXTCxZQUFZO0NBQzdCLE1BQU1NLFFBQVFKLFNBQVM7Q0FDdkIsTUFBTSxDQUFDSyxPQUFPQyxZQUFZVixTQUFTLEVBQUU7Q0FDckMsTUFBTSxDQUFDVyxPQUFPQyxZQUFZWixTQUFTLEVBQUU7Q0FDckMsTUFBTSxDQUFDYSxZQUFZQyxpQkFBaUJkLFNBQVMsRUFBRTtDQUMvQyxNQUFNLENBQUNlLFNBQVNDLGNBQWNoQixTQUFTLEtBQUs7Q0FFNUMsZUFBZWlCLGFBQWFDLEdBQUc7RUFDN0JBLEVBQUVDLGVBQWU7RUFDakJQLFNBQVMsRUFBRTtFQUNYLElBQUksQ0FBQ0gsTUFBTVcsS0FBSyxHQUFHO0dBQ2pCTixjQUFjLDRCQUE0QjtHQUMxQztFQUNGO0VBQ0EsSUFBSSxDQUFDLHFEQUFxRE8sS0FBS1osTUFBTVcsS0FBSyxDQUFDLEdBQUc7R0FDNUVOLGNBQWMsd0JBQXdCO0dBQ3RDO0VBQ0Y7RUFDQUEsY0FBYyxFQUFFO0VBQ2hCRSxXQUFXLElBQUk7RUFDZixJQUFJO0dBQ0YsTUFBTWIsUUFBUW1CLFFBQVFiLE1BQU1XLEtBQUssR0FBRyxnQkFBZ0I7R0FDcERaLE1BQU1lLEtBQUssMERBQTBEO0dBQ3JFaEIsU0FBUyxlQUFlLEVBQUVpQixPQUFPO0lBQUVmLE9BQU9BLE1BQU1XLEtBQUs7SUFBR0ssU0FBUztHQUFpQixFQUFFLENBQUM7RUFDdkYsU0FBU0MsS0FBSztHQUNaZCxTQUFTYyxJQUFJQyxPQUFPO0VBQ3RCLFVBQVU7R0FDUlgsV0FBVyxLQUFLO0VBQ2xCO0NBQ0Y7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQ2Isd0JBQUMsT0FBRDtHQUFLLFdBQVU7R0FBa0IsT0FBTyxFQUFFWSxVQUFVLElBQUk7YUFBeEQsQ0FDRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBQ0Usd0JBQUMsT0FBRDtNQUNFLFdBQVU7TUFDVixPQUFPO09BQ0xDLE9BQU87T0FDUEMsUUFBUTtPQUNSQyxjQUFjO09BQ2RDLFlBQVk7T0FDWkMsT0FBTztPQUNQQyxVQUFVO01BQ1o7Z0JBRUEsd0JBQUMsS0FBRDtPQUFHLFdBQVU7T0FBWSxlQUFZO01BQU07Ozs7O0tBQ3hDOzs7OztLQUNMLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFtQjtLQUF5Qjs7Ozs7S0FDMUQsd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQTRCO0tBR3RDOzs7OztJQUNBOzs7OzthQUVMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDR3ZCLFNBQVMsd0JBQUMsT0FBRDtNQUFLLFdBQVU7TUFBMEIsTUFBSztnQkFBU0E7S0FBVzs7Ozs7S0FFNUUsd0JBQUMsUUFBRDtNQUFNLFVBQVVNO01BQWM7Z0JBQTlCLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxTQUFEO1NBQU8sU0FBUTtTQUFXLFdBQVU7bUJBQWE7UUFBWTs7Ozs7UUFDN0Qsd0JBQUMsU0FBRDtTQUNFLE1BQUs7U0FDTCxXQUFXLGdCQUFnQkosYUFBYSxlQUFlO1NBQ3ZELElBQUc7U0FDSCxPQUFPSjtTQUNQLFdBQVdTLE1BQU1SLFNBQVNRLEVBQUVpQixPQUFPQyxLQUFLO1NBQ3hDLGNBQWE7U0FDYixVQUFVckI7U0FDVixhQUFZO1FBQWlCOzs7OztRQUU5QkYsY0FBYyx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBb0JBO1FBQWdCOzs7OztPQUMvRDs7Ozs7Z0JBRUwsd0JBQUMsVUFBRDtPQUFRLE1BQUs7T0FBUyxXQUFVO09BQXdCLFVBQVVFO2lCQUMvREEsVUFDQyxnREFDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtRQUF3QyxNQUFLO1FBQVMsZUFBWTtPQUFNOzs7O2lCQUFBLGVBRTFGOzs7O2tCQUVBO01BRUk7Ozs7Y0FDSjs7Ozs7O0tBRU4sd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQ1gsd0JBQUMsTUFBRDtPQUFNLElBQUc7aUJBQVQsQ0FDRSx3QkFBQyxLQUFEO1FBQUcsV0FBVTtRQUF3QixlQUFZO09BQU07Ozs7aUJBQUEsaUJBRW5EOzs7Ozs7S0FDTDs7Ozs7SUFDQTs7Ozs7V0FDRjs7Ozs7O0NBQ0Y7Ozs7O0FBRVQ7QUFBQ1QsR0FqR3VCRCxnQkFBYztDQUFBLFFBQ25CSCxhQUNIRSxRQUFRO0FBQUE7QUFBQSxLQUZBQztBQUFjLElBQUFnQztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsInVzZVN0YXRlIiwiTGluayIsInVzZU5hdmlnYXRlIiwiYXV0aEFwaSIsInVzZVRvYXN0IiwiRm9yZ290UGFzc3dvcmQiLCJfcyIsIm5hdmlnYXRlIiwidG9hc3QiLCJlbWFpbCIsInNldEVtYWlsIiwiZXJyb3IiLCJzZXRFcnJvciIsImZpZWxkRXJyb3IiLCJzZXRGaWVsZEVycm9yIiwibG9hZGluZyIsInNldExvYWRpbmciLCJoYW5kbGVTdWJtaXQiLCJlIiwicHJldmVudERlZmF1bHQiLCJ0cmltIiwidGVzdCIsInNlbmRPdHAiLCJpbmZvIiwic3RhdGUiLCJwdXJwb3NlIiwiZXJyIiwibWVzc2FnZSIsIm1heFdpZHRoIiwid2lkdGgiLCJoZWlnaHQiLCJib3JkZXJSYWRpdXMiLCJiYWNrZ3JvdW5kIiwiY29sb3IiLCJmb250U2l6ZSIsInRhcmdldCIsInZhbHVlIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiRm9yZ290UGFzc3dvcmQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgTGluaywgdXNlTmF2aWdhdGUgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xuaW1wb3J0IHsgYXV0aEFwaSB9IGZyb20gXCIuLi9hcGkvYXV0aC5qc1wiO1xuaW1wb3J0IHsgdXNlVG9hc3QgfSBmcm9tIFwiLi4vY29udGV4dC9Ub2FzdENvbnRleHQuanN4XCI7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEZvcmdvdFBhc3N3b3JkKCkge1xuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gIGNvbnN0IHRvYXN0ID0gdXNlVG9hc3QoKTtcbiAgY29uc3QgW2VtYWlsLCBzZXRFbWFpbF0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW2ZpZWxkRXJyb3IsIHNldEZpZWxkRXJyb3JdID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICBhc3luYyBmdW5jdGlvbiBoYW5kbGVTdWJtaXQoZSkge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBzZXRFcnJvcihcIlwiKTtcbiAgICBpZiAoIWVtYWlsLnRyaW0oKSkge1xuICAgICAgc2V0RmllbGRFcnJvcihcIkVtYWlsIGFkZHJlc3MgaXMgcmVxdWlyZWQuXCIpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoIS9eW0EtWmEtejAtOS5fJStcXC1dK0BbQS1aYS16MC05LlxcLV0rXFwuW0EtWmEtel17Mix9JC8udGVzdChlbWFpbC50cmltKCkpKSB7XG4gICAgICBzZXRGaWVsZEVycm9yKFwiSW52YWxpZCBlbWFpbCBhZGRyZXNzLlwiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgc2V0RmllbGRFcnJvcihcIlwiKTtcbiAgICBzZXRMb2FkaW5nKHRydWUpO1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBhdXRoQXBpLnNlbmRPdHAoZW1haWwudHJpbSgpLCBcInBhc3N3b3JkX3Jlc2V0XCIpO1xuICAgICAgdG9hc3QuaW5mbyhcIklmIHRoYXQgZW1haWwgaXMgcmVnaXN0ZXJlZCwgYSByZXNldCBjb2RlIGlzIG9uIGl0cyB3YXkuXCIpO1xuICAgICAgbmF2aWdhdGUoXCIvdmVyaWZ5LW90cFwiLCB7IHN0YXRlOiB7IGVtYWlsOiBlbWFpbC50cmltKCksIHB1cnBvc2U6IFwicGFzc3dvcmRfcmVzZXRcIiB9IH0pO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgc2V0RXJyb3IoZXJyLm1lc3NhZ2UpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwibG9naW4td3JhcHBlclwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkIGxvZ2luLWNhcmRcIiBzdHlsZT17eyBtYXhXaWR0aDogNDIwIH19PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQtaGVhZGVyIHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgPGRpdlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwibXgtYXV0byBtYi0yIGQtZmxleCBhbGlnbi1pdGVtcy1jZW50ZXIganVzdGlmeS1jb250ZW50LWNlbnRlclwiXG4gICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICB3aWR0aDogNDgsXG4gICAgICAgICAgICAgIGhlaWdodDogNDgsXG4gICAgICAgICAgICAgIGJvcmRlclJhZGl1czogMTQsXG4gICAgICAgICAgICAgIGJhY2tncm91bmQ6IFwibGluZWFyLWdyYWRpZW50KDEzNWRlZywgIzBmNzY2ZSAwJSwgIzEzNGU0YSAxMDAlKVwiLFxuICAgICAgICAgICAgICBjb2xvcjogXCJ3aGl0ZVwiLFxuICAgICAgICAgICAgICBmb250U2l6ZTogMjIsXG4gICAgICAgICAgICB9fVxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxpIGNsYXNzTmFtZT1cImJpIGJpLWtleVwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGg1IGNsYXNzTmFtZT1cIm1iLTAgZnctc2VtaWJvbGRcIj5Gb3Jnb3QgeW91ciBwYXNzd29yZD88L2g1PlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbXV0ZWQgc21hbGwgbWItMCBtdC0xXCI+XG4gICAgICAgICAgICBFbnRlciB5b3VyIGFjY291bnQgZW1haWwgYW5kIHdlJmFwb3M7bGwgc2VuZCB5b3UgYSB2ZXJpZmljYXRpb24gY29kZVxuICAgICAgICAgICAgdG8gY2hvb3NlIGEgbmV3IHBhc3N3b3JkLlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkLWJvZHkgcC00XCI+XG4gICAgICAgICAge2Vycm9yICYmIDxkaXYgY2xhc3NOYW1lPVwiYWxlcnQgYWxlcnQtZGFuZ2VyIHB5LTJcIiByb2xlPVwiYWxlcnRcIj57ZXJyb3J9PC9kaXY+fVxuXG4gICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0gbm9WYWxpZGF0ZT5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNFwiPlxuICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cImZwLWVtYWlsXCIgY2xhc3NOYW1lPVwiZm9ybS1sYWJlbFwiPkVtYWlsPC9sYWJlbD5cbiAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgdHlwZT1cImVtYWlsXCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2Bmb3JtLWNvbnRyb2wgJHtmaWVsZEVycm9yID8gXCJpcy1pbnZhbGlkXCIgOiBcIlwifWB9XG4gICAgICAgICAgICAgICAgaWQ9XCJmcC1lbWFpbFwiXG4gICAgICAgICAgICAgICAgdmFsdWU9e2VtYWlsfVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RW1haWwoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cInVzZXJuYW1lXCJcbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17bG9hZGluZ31cbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cInlvdUBjb21wYW55LmNvbVwiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIHtmaWVsZEVycm9yICYmIDxkaXYgY2xhc3NOYW1lPVwiaW52YWxpZC1mZWVkYmFja1wiPntmaWVsZEVycm9yfTwvZGl2Pn1cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBjbGFzc05hbWU9XCJidG4gYnRuLWRoYW5pdGkgdy0xMDBcIiBkaXNhYmxlZD17bG9hZGluZ30+XG4gICAgICAgICAgICAgIHtsb2FkaW5nID8gKFxuICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzcGlubmVyLWJvcmRlciBzcGlubmVyLWJvcmRlci1zbSBtZS0yXCIgcm9sZT1cInN0YXR1c1wiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgICAgICAgICBTZW5kaW5nIGNvZGXigKZcbiAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICBcIlNlbmQgcmVzZXQgY29kZVwiXG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Zvcm0+XG5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBzbWFsbCBtdC00IG1iLTBcIj5cbiAgICAgICAgICAgIDxMaW5rIHRvPVwiL2xvZ2luXCI+XG4gICAgICAgICAgICAgIDxpIGNsYXNzTmFtZT1cImJpIGJpLWFycm93LWxlZnQgbWUtMVwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgICAgIEJhY2sgdG8gc2lnbiBpblxuICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiQzovVXNlcnMvdXNlci9Eb3dubG9hZHMvZGhhbml0aS1hcHAtdXBncmFkZWQvZGhhbml0aS1hcHAvZnJvbnRlbmQvc3JjL3BhZ2VzL0ZvcmdvdFBhc3N3b3JkLmpzeCJ9