import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/OAuthCallback.jsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport1_react_jsxDevRuntime["Fragment"];const React = __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"]; const useState = __vite__cjsImport3_react["useState"];import * as RefreshRuntime from "/@react-refresh";
var _jsxFileName = "C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/pages/OAuthCallback.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=325d36c7";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
	if (!window.$RefreshReg$) {
		throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong.");
	}
	prevRefreshReg = window.$RefreshReg$;
	prevRefreshSig = window.$RefreshSig$;
	window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/pages/OAuthCallback.jsx");
	window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=325d36c7";
import { Link, useNavigate, useSearchParams } from "/node_modules/.vite/deps/react-router-dom.js?v=325d36c7";
import { authApi } from "/src/api/auth.js";
import { useAuth } from "/src/context/AuthContext.jsx";
import { useToast } from "/src/context/ToastContext.jsx";
/**
* Landing page after an OAuth provider redirects back:
*   /oauth/callback?code=<one-time-code>&status=success
*   /oauth/callback?status=error&message=...
*
* The one-time code is exchanged for the real session token via
* POST /api/auth/oauth/exchange (so the JWT never appears in a URL).
*/
export default function OAuthCallback() {
	_s();
	const [params] = useSearchParams();
	const navigate = useNavigate();
	const toast = useToast();
	const { applySession } = useAuth();
	const [error, setError] = useState("");
	const exchanged = useRef(false);
	useEffect(() => {
		if (exchanged.current) return;
		exchanged.current = true;
		const status = params.get("status");
		const code = params.get("code");
		const message = params.get("message");
		if (status === "error") {
			setError(message || "OAuth sign-in failed. Please try again.");
			return;
		}
		if (!code) {
			setError("Missing sign-in code. Please start the sign-in flow again.");
			return;
		}
		(async () => {
			try {
				const { token, user } = await authApi.oauthExchange(code);
				applySession(token, user);
				toast.success(`Welcome, ${user.name}!`);
				navigate("/dashboard", { replace: true });
			} catch (err) {
				setError(err.message || "Could not complete OAuth sign-in.");
			}
		})();
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "login-wrapper",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "card login-card",
			style: { maxWidth: 420 },
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "card-body p-4 text-center",
				children: error ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "mx-auto mb-3 d-flex align-items-center justify-content-center",
						style: {
							width: 52,
							height: 52,
							borderRadius: 14,
							background: "#fef2f2",
							color: "#dc2626",
							fontSize: 24
						},
						children: /* @__PURE__ */ _jsxDEV("i", {
							className: "bi bi-x-circle",
							"aria-hidden": "true"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 82,
							columnNumber: 17
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 78,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("h5", {
						className: "fw-semibold mb-2",
						children: "Sign-in failed"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 84,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-muted small",
						children: error
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 85,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV(Link, {
						to: "/login",
						className: "btn btn-dhaniti w-100 mt-2",
						children: "Back to sign in"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 86,
						columnNumber: 15
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 77,
					columnNumber: 11
				}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "spinner-border text-dhaniti mb-3",
						role: "status",
						"aria-hidden": "true",
						style: {
							width: 44,
							height: 44
						}
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 92,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("h5", {
						className: "fw-semibold mb-1",
						children: "Completing sign-in…"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 93,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-muted small mb-0",
						children: "Verifying your identity with the provider."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 94,
						columnNumber: 15
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 91,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 75,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 74,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 73,
		columnNumber: 5
	}, this);
}
_s(OAuthCallback, "IERGrOwcF3QgNgKkY/a15gzxoLo=", false, function() {
	return [
		useSearchParams,
		useNavigate,
		useToast,
		useAuth
	];
});
_c = OAuthCallback;
var _c;
$RefreshReg$(_c, "OAuthCallback");
if (import.meta.hot && !inWebWorker) {
	window.$RefreshReg$ = prevRefreshReg;
	window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
	RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
		RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/pages/OAuthCallback.jsx", currentExports);
		import.meta.hot.accept((nextExports) => {
			if (!nextExports) return;
			const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/pages/OAuthCallback.jsx", currentExports, nextExports);
			if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
		});
	});
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLE9BQU9BLFNBQVNDLFdBQVdDLFFBQVFDLGdCQUFnQjtBQUNuRCxTQUFTQyxNQUFNQyxhQUFhQyx1QkFBdUI7QUFDbkQsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLGdCQUFnQjs7Ozs7Ozs7O0FBVXpCLGVBQWUsU0FBU0MsZ0JBQWdCO0NBQUFDLEdBQUE7Q0FDdEMsTUFBTSxDQUFDQyxVQUFVTixnQkFBZ0I7Q0FDakMsTUFBTU8sV0FBV1IsWUFBWTtDQUM3QixNQUFNUyxRQUFRTCxTQUFTO0NBQ3ZCLE1BQU0sRUFBRU0saUJBQWlCUCxRQUFRO0NBQ2pDLE1BQU0sQ0FBQ1EsT0FBT0MsWUFBWWQsU0FBUyxFQUFFO0NBQ3JDLE1BQU1lLFlBQVloQixPQUFPLEtBQUs7Q0FFOUJELGdCQUFnQjtFQUNkLElBQUlpQixVQUFVQyxTQUFTO0VBQ3ZCRCxVQUFVQyxVQUFVO0VBRXBCLE1BQU1DLFNBQVNSLE9BQU9TLElBQUksUUFBUTtFQUNsQyxNQUFNQyxPQUFPVixPQUFPUyxJQUFJLE1BQU07RUFDOUIsTUFBTUUsVUFBVVgsT0FBT1MsSUFBSSxTQUFTO0VBRXBDLElBQUlELFdBQVcsU0FBUztHQUN0QkgsU0FBU00sV0FBVyx5Q0FBeUM7R0FDN0Q7RUFDRjtFQUNBLElBQUksQ0FBQ0QsTUFBTTtHQUNUTCxTQUFTLDREQUE0RDtHQUNyRTtFQUNGO0VBRUEsQ0FBQyxZQUFZO0dBQ1gsSUFBSTtJQUNGLE1BQU0sRUFBRU8sT0FBT0MsU0FBUyxNQUFNbEIsUUFBUW1CLGNBQWNKLElBQUk7SUFDeERQLGFBQWFTLE9BQU9DLElBQUk7SUFDeEJYLE1BQU1hLFFBQVEsWUFBWUYsS0FBS0csS0FBSSxFQUFHO0lBQ3RDZixTQUFTLGNBQWMsRUFBRWdCLFNBQVMsS0FBSyxDQUFDO0dBQzFDLFNBQVNDLEtBQUs7SUFDWmIsU0FBU2EsSUFBSVAsV0FBVyxtQ0FBbUM7R0FDN0Q7RUFDRixFQUFDLENBQUU7O0NBRUwsR0FBRyxFQUFFO0NBRUwsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUNiLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO0dBQWtCLE9BQU8sRUFBRVEsVUFBVSxJQUFJO2FBQ3RELHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ1pmLFFBQ0M7S0FDRSx3QkFBQyxPQUFEO01BQ0UsV0FBVTtNQUNWLE9BQU87T0FBRWdCLE9BQU87T0FBSUMsUUFBUTtPQUFJQyxjQUFjO09BQUlDLFlBQVk7T0FBV0MsT0FBTztPQUFXQyxVQUFVO01BQUc7Z0JBRXhHLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO09BQWlCLGVBQVk7TUFBTTs7Ozs7S0FDN0M7Ozs7O0tBQ0wsd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQW1CO0tBQWtCOzs7OztLQUNuRCx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBb0JyQjtLQUFTOzs7OztLQUMxQyx3QkFBQyxNQUFEO01BQU0sSUFBRztNQUFTLFdBQVU7Z0JBQTRCO0tBRWxEOzs7OztJQUNSOzs7O2VBRUE7S0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtNQUFtQyxNQUFLO01BQVMsZUFBWTtNQUFPLE9BQU87T0FBRWdCLE9BQU87T0FBSUMsUUFBUTtNQUFHO0tBQUU7Ozs7O0tBQ3BILHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFtQjtLQUF1Qjs7Ozs7S0FDeEQsd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQXdCO0tBQTZDOzs7OztJQUNwRjs7Ozs7R0FFQzs7Ozs7RUFDRjs7Ozs7Q0FDRjs7Ozs7QUFFVDtBQUFDdEIsR0FuRXVCRCxlQUFhO0NBQUE7RUFDbEJKO0VBQ0FEO0VBQ0hJO0VBQ1dEO0NBQU87QUFBQTtBQUFBLEtBSlZFO0FBQWEsSUFBQTRCO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwidXNlRWZmZWN0IiwidXNlUmVmIiwidXNlU3RhdGUiLCJMaW5rIiwidXNlTmF2aWdhdGUiLCJ1c2VTZWFyY2hQYXJhbXMiLCJhdXRoQXBpIiwidXNlQXV0aCIsInVzZVRvYXN0IiwiT0F1dGhDYWxsYmFjayIsIl9zIiwicGFyYW1zIiwibmF2aWdhdGUiLCJ0b2FzdCIsImFwcGx5U2Vzc2lvbiIsImVycm9yIiwic2V0RXJyb3IiLCJleGNoYW5nZWQiLCJjdXJyZW50Iiwic3RhdHVzIiwiZ2V0IiwiY29kZSIsIm1lc3NhZ2UiLCJ0b2tlbiIsInVzZXIiLCJvYXV0aEV4Y2hhbmdlIiwic3VjY2VzcyIsIm5hbWUiLCJyZXBsYWNlIiwiZXJyIiwibWF4V2lkdGgiLCJ3aWR0aCIsImhlaWdodCIsImJvcmRlclJhZGl1cyIsImJhY2tncm91bmQiLCJjb2xvciIsImZvbnRTaXplIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiT0F1dGhDYWxsYmFjay5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZUVmZmVjdCwgdXNlUmVmLCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgTGluaywgdXNlTmF2aWdhdGUsIHVzZVNlYXJjaFBhcmFtcyB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XG5pbXBvcnQgeyBhdXRoQXBpIH0gZnJvbSBcIi4uL2FwaS9hdXRoLmpzXCI7XG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSBcIi4uL2NvbnRleHQvQXV0aENvbnRleHQuanN4XCI7XG5pbXBvcnQgeyB1c2VUb2FzdCB9IGZyb20gXCIuLi9jb250ZXh0L1RvYXN0Q29udGV4dC5qc3hcIjtcblxuLyoqXG4gKiBMYW5kaW5nIHBhZ2UgYWZ0ZXIgYW4gT0F1dGggcHJvdmlkZXIgcmVkaXJlY3RzIGJhY2s6XG4gKiAgIC9vYXV0aC9jYWxsYmFjaz9jb2RlPTxvbmUtdGltZS1jb2RlPiZzdGF0dXM9c3VjY2Vzc1xuICogICAvb2F1dGgvY2FsbGJhY2s/c3RhdHVzPWVycm9yJm1lc3NhZ2U9Li4uXG4gKlxuICogVGhlIG9uZS10aW1lIGNvZGUgaXMgZXhjaGFuZ2VkIGZvciB0aGUgcmVhbCBzZXNzaW9uIHRva2VuIHZpYVxuICogUE9TVCAvYXBpL2F1dGgvb2F1dGgvZXhjaGFuZ2UgKHNvIHRoZSBKV1QgbmV2ZXIgYXBwZWFycyBpbiBhIFVSTCkuXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE9BdXRoQ2FsbGJhY2soKSB7XG4gIGNvbnN0IFtwYXJhbXNdID0gdXNlU2VhcmNoUGFyYW1zKCk7XG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgY29uc3QgdG9hc3QgPSB1c2VUb2FzdCgpO1xuICBjb25zdCB7IGFwcGx5U2Vzc2lvbiB9ID0gdXNlQXV0aCgpO1xuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBleGNoYW5nZWQgPSB1c2VSZWYoZmFsc2UpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKGV4Y2hhbmdlZC5jdXJyZW50KSByZXR1cm47XG4gICAgZXhjaGFuZ2VkLmN1cnJlbnQgPSB0cnVlO1xuXG4gICAgY29uc3Qgc3RhdHVzID0gcGFyYW1zLmdldChcInN0YXR1c1wiKTtcbiAgICBjb25zdCBjb2RlID0gcGFyYW1zLmdldChcImNvZGVcIik7XG4gICAgY29uc3QgbWVzc2FnZSA9IHBhcmFtcy5nZXQoXCJtZXNzYWdlXCIpO1xuXG4gICAgaWYgKHN0YXR1cyA9PT0gXCJlcnJvclwiKSB7XG4gICAgICBzZXRFcnJvcihtZXNzYWdlIHx8IFwiT0F1dGggc2lnbi1pbiBmYWlsZWQuIFBsZWFzZSB0cnkgYWdhaW4uXCIpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoIWNvZGUpIHtcbiAgICAgIHNldEVycm9yKFwiTWlzc2luZyBzaWduLWluIGNvZGUuIFBsZWFzZSBzdGFydCB0aGUgc2lnbi1pbiBmbG93IGFnYWluLlwiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICAoYXN5bmMgKCkgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgeyB0b2tlbiwgdXNlciB9ID0gYXdhaXQgYXV0aEFwaS5vYXV0aEV4Y2hhbmdlKGNvZGUpO1xuICAgICAgICBhcHBseVNlc3Npb24odG9rZW4sIHVzZXIpO1xuICAgICAgICB0b2FzdC5zdWNjZXNzKGBXZWxjb21lLCAke3VzZXIubmFtZX0hYCk7XG4gICAgICAgIG5hdmlnYXRlKFwiL2Rhc2hib2FyZFwiLCB7IHJlcGxhY2U6IHRydWUgfSk7XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgc2V0RXJyb3IoZXJyLm1lc3NhZ2UgfHwgXCJDb3VsZCBub3QgY29tcGxldGUgT0F1dGggc2lnbi1pbi5cIik7XG4gICAgICB9XG4gICAgfSkoKTtcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgcmVhY3QtaG9va3MvZXhoYXVzdGl2ZS1kZXBzXG4gIH0sIFtdKTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwibG9naW4td3JhcHBlclwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkIGxvZ2luLWNhcmRcIiBzdHlsZT17eyBtYXhXaWR0aDogNDIwIH19PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQtYm9keSBwLTQgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICB7ZXJyb3IgPyAoXG4gICAgICAgICAgICA8PlxuICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXgtYXV0byBtYi0zIGQtZmxleCBhbGlnbi1pdGVtcy1jZW50ZXIganVzdGlmeS1jb250ZW50LWNlbnRlclwiXG4gICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IDUyLCBoZWlnaHQ6IDUyLCBib3JkZXJSYWRpdXM6IDE0LCBiYWNrZ3JvdW5kOiBcIiNmZWYyZjJcIiwgY29sb3I6IFwiI2RjMjYyNlwiLCBmb250U2l6ZTogMjQgfX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxpIGNsYXNzTmFtZT1cImJpIGJpLXgtY2lyY2xlXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxoNSBjbGFzc05hbWU9XCJmdy1zZW1pYm9sZCBtYi0yXCI+U2lnbi1pbiBmYWlsZWQ8L2g1PlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LW11dGVkIHNtYWxsXCI+e2Vycm9yfTwvcD5cbiAgICAgICAgICAgICAgPExpbmsgdG89XCIvbG9naW5cIiBjbGFzc05hbWU9XCJidG4gYnRuLWRoYW5pdGkgdy0xMDAgbXQtMlwiPlxuICAgICAgICAgICAgICAgIEJhY2sgdG8gc2lnbiBpblxuICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICA8Lz5cbiAgICAgICAgICApIDogKFxuICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGlubmVyLWJvcmRlciB0ZXh0LWRoYW5pdGkgbWItM1wiIHJvbGU9XCJzdGF0dXNcIiBhcmlhLWhpZGRlbj1cInRydWVcIiBzdHlsZT17eyB3aWR0aDogNDQsIGhlaWdodDogNDQgfX0gLz5cbiAgICAgICAgICAgICAgPGg1IGNsYXNzTmFtZT1cImZ3LXNlbWlib2xkIG1iLTFcIj5Db21wbGV0aW5nIHNpZ24taW7igKY8L2g1PlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LW11dGVkIHNtYWxsIG1iLTBcIj5WZXJpZnlpbmcgeW91ciBpZGVudGl0eSB3aXRoIHRoZSBwcm92aWRlci48L3A+XG4gICAgICAgICAgICA8Lz5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiJDOi9Vc2Vycy91c2VyL0Rvd25sb2Fkcy9kaGFuaXRpLWFwcC11cGdyYWRlZC9kaGFuaXRpLWFwcC9mcm9udGVuZC9zcmMvcGFnZXMvT0F1dGhDYWxsYmFjay5qc3gifQ==