import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/OtpInput.jsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];const React = __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"];import * as RefreshRuntime from "/@react-refresh";
var _jsxFileName = "C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/components/OtpInput.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=325d36c7";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
	if (!window.$RefreshReg$) {
		throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong.");
	}
	prevRefreshReg = window.$RefreshReg$;
	prevRefreshSig = window.$RefreshSig$;
	window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/components/OtpInput.jsx");
	window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=325d36c7";
/**
* N-box verification code input with auto-advance, paste support and
* keyboard navigation. Calls onComplete(code) when every box is filled.
*/
export default function OtpInput({ length = 6, value, onChange, onComplete, disabled = false, autoFocus = true }) {
	_s();
	const inputsRef = useRef([]);
	const chars = Array.from({ length }, (_, i) => (value || "")[i] || "");
	useEffect(() => {
		if (autoFocus && inputsRef.current[0] && !disabled) {
			inputsRef.current[0].focus();
		}
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);
	function emit(nextChars) {
		const code = nextChars.join("");
		onChange(code);
		if (code.length === length && !nextChars.includes("")) {
			onComplete && onComplete(code);
		}
	}
	function handleChange(index, raw) {
		const digit = raw.replace(/\D/g, "").slice(-1);
		const next = [...chars];
		next[index] = digit;
		emit(next);
		if (digit && index < length - 1) {
			inputsRef.current[index + 1]?.focus();
			inputsRef.current[index + 1]?.select();
		}
	}
	function handleKeyDown(index, e) {
		if (e.key === "Backspace") {
			e.preventDefault();
			const next = [...chars];
			if (next[index]) {
				next[index] = "";
				emit(next);
			} else if (index > 0) {
				next[index - 1] = "";
				emit(next);
				inputsRef.current[index - 1]?.focus();
			}
		} else if (e.key === "ArrowLeft" && index > 0) {
			e.preventDefault();
			inputsRef.current[index - 1]?.focus();
		} else if (e.key === "ArrowRight" && index < length - 1) {
			e.preventDefault();
			inputsRef.current[index + 1]?.focus();
		}
	}
	function handlePaste(e) {
		e.preventDefault();
		const pasted = (e.clipboardData.getData("text") || "").replace(/\D/g, "").slice(0, length);
		if (!pasted) return;
		const next = Array.from({ length }, (_, i) => pasted[i] || "");
		emit(next);
		const focusIdx = Math.min(pasted.length, length - 1);
		inputsRef.current[focusIdx]?.focus();
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "d-flex justify-content-center gap-2 otp-inputs",
		onPaste: handlePaste,
		children: chars.map((char, index) => /* @__PURE__ */ _jsxDEV("input", {
			ref: (el) => inputsRef.current[index] = el,
			type: "text",
			inputMode: "numeric",
			autoComplete: "one-time-code",
			maxLength: 1,
			className: "form-control otp-box",
			value: char,
			disabled,
			"aria-label": `Digit ${index + 1} of ${length}`,
			onChange: (e) => handleChange(index, e.target.value),
			onKeyDown: (e) => handleKeyDown(index, e),
			onFocus: (e) => e.target.select()
		}, index, false, {
			fileName: _jsxFileName,
			lineNumber: 90,
			columnNumber: 7
		}, this))
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 88,
		columnNumber: 5
	}, this);
}
_s(OtpInput, "QWN8mYu3zMJFrTXkwQjAUKhkgrI=");
_c = OtpInput;
var _c;
$RefreshReg$(_c, "OtpInput");
if (import.meta.hot && !inWebWorker) {
	window.$RefreshReg$ = prevRefreshReg;
	window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
	RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
		RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/components/OtpInput.jsx", currentExports);
		import.meta.hot.accept((nextExports) => {
			if (!nextExports) return;
			const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Downloads/dhaniti-app-upgraded/dhaniti-app/frontend/src/components/OtpInput.jsx", currentExports, nextExports);
			if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
		});
	});
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLE9BQU9BLFNBQVNDLFdBQVdDLGNBQWM7Ozs7O0FBTXpDLGVBQWUsU0FBU0MsU0FBUyxFQUFFQyxTQUFTLEdBQUdDLE9BQU9DLFVBQVVDLFlBQVlDLFdBQVcsT0FBT0MsWUFBWSxRQUFRO0NBQUFDLEdBQUE7Q0FDaEgsTUFBTUMsWUFBWVQsT0FBTyxFQUFFO0NBQzNCLE1BQU1VLFFBQVFDLE1BQU1DLEtBQUssRUFBRVYsT0FBTyxJQUFJVyxHQUFHQyxPQUFPWCxTQUFTLEdBQUUsQ0FBRVcsTUFBTSxFQUFFO0NBRXJFZixnQkFBZ0I7RUFDZCxJQUFJUSxhQUFhRSxVQUFVTSxRQUFRLE1BQU0sQ0FBQ1QsVUFBVTtHQUNsREcsVUFBVU0sUUFBUSxFQUFFLENBQUNDLE1BQU07RUFDN0I7O0NBRUYsR0FBRyxFQUFFO0NBRUwsU0FBU0MsS0FBS0MsV0FBVztFQUN2QixNQUFNQyxPQUFPRCxVQUFVRSxLQUFLLEVBQUU7RUFDOUJoQixTQUFTZSxJQUFJO0VBQ2IsSUFBSUEsS0FBS2pCLFdBQVdBLFVBQVUsQ0FBQ2dCLFVBQVVHLFNBQVMsRUFBRSxHQUFHO0dBQ3JEaEIsY0FBY0EsV0FBV2MsSUFBSTtFQUMvQjtDQUNGO0NBRUEsU0FBU0csYUFBYUMsT0FBT0MsS0FBSztFQUNoQyxNQUFNQyxRQUFRRCxJQUFJRSxRQUFRLE9BQU8sRUFBRSxDQUFDLENBQUNDLE1BQU0sQ0FBQyxDQUFDO0VBQzdDLE1BQU1DLE9BQU8sQ0FBQyxHQUFHbEIsS0FBSztFQUN0QmtCLEtBQUtMLFNBQVNFO0VBQ2RSLEtBQUtXLElBQUk7RUFDVCxJQUFJSCxTQUFTRixRQUFRckIsU0FBUyxHQUFHO0dBQy9CTyxVQUFVTSxRQUFRUSxRQUFRLEVBQUUsRUFBRVAsTUFBTTtHQUNwQ1AsVUFBVU0sUUFBUVEsUUFBUSxFQUFFLEVBQUVNLE9BQU87RUFDdkM7Q0FDRjtDQUVBLFNBQVNDLGNBQWNQLE9BQU9RLEdBQUc7RUFDL0IsSUFBSUEsRUFBRUMsUUFBUSxhQUFhO0dBQ3pCRCxFQUFFRSxlQUFlO0dBQ2pCLE1BQU1MLE9BQU8sQ0FBQyxHQUFHbEIsS0FBSztHQUN0QixJQUFJa0IsS0FBS0wsUUFBUTtJQUNmSyxLQUFLTCxTQUFTO0lBQ2ROLEtBQUtXLElBQUk7R0FDWCxPQUFPLElBQUlMLFFBQVEsR0FBRztJQUNwQkssS0FBS0wsUUFBUSxLQUFLO0lBQ2xCTixLQUFLVyxJQUFJO0lBQ1RuQixVQUFVTSxRQUFRUSxRQUFRLEVBQUUsRUFBRVAsTUFBTTtHQUN0QztFQUNGLE9BQU8sSUFBSWUsRUFBRUMsUUFBUSxlQUFlVCxRQUFRLEdBQUc7R0FDN0NRLEVBQUVFLGVBQWU7R0FDakJ4QixVQUFVTSxRQUFRUSxRQUFRLEVBQUUsRUFBRVAsTUFBTTtFQUN0QyxPQUFPLElBQUllLEVBQUVDLFFBQVEsZ0JBQWdCVCxRQUFRckIsU0FBUyxHQUFHO0dBQ3ZENkIsRUFBRUUsZUFBZTtHQUNqQnhCLFVBQVVNLFFBQVFRLFFBQVEsRUFBRSxFQUFFUCxNQUFNO0VBQ3RDO0NBQ0Y7Q0FFQSxTQUFTa0IsWUFBWUgsR0FBRztFQUN0QkEsRUFBRUUsZUFBZTtFQUNqQixNQUFNRSxVQUFVSixFQUFFSyxjQUFjQyxRQUFRLE1BQU0sS0FBSyxHQUFFLENBQUVYLFFBQVEsT0FBTyxFQUFFLENBQUMsQ0FBQ0MsTUFBTSxHQUFHekIsTUFBTTtFQUN6RixJQUFJLENBQUNpQyxRQUFRO0VBQ2IsTUFBTVAsT0FBT2pCLE1BQU1DLEtBQUssRUFBRVYsT0FBTyxJQUFJVyxHQUFHQyxNQUFNcUIsT0FBT3JCLE1BQU0sRUFBRTtFQUM3REcsS0FBS1csSUFBSTtFQUNULE1BQU1VLFdBQVdDLEtBQUtDLElBQUlMLE9BQU9qQyxRQUFRQSxTQUFTLENBQUM7RUFDbkRPLFVBQVVNLFFBQVF1QixTQUFTLEVBQUV0QixNQUFNO0NBQ3JDO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtFQUFpRCxTQUFTa0I7WUFDdEV4QixNQUFNK0IsS0FBS0MsTUFBTW5CLFVBQ2hCLHdCQUFDLFNBQUQ7R0FFRSxNQUFNb0IsT0FBUWxDLFVBQVVNLFFBQVFRLFNBQVNvQjtHQUN6QyxNQUFLO0dBQ0wsV0FBVTtHQUNWLGNBQWE7R0FDYixXQUFXO0dBQ1gsV0FBVTtHQUNWLE9BQU9EO0dBQ0dwQztHQUNWLGNBQVksU0FBU2lCLFFBQVEsRUFBQyxNQUFPckI7R0FDckMsV0FBVzZCLE1BQU1ULGFBQWFDLE9BQU9RLEVBQUVhLE9BQU96QyxLQUFLO0dBQ25ELFlBQVk0QixNQUFNRCxjQUFjUCxPQUFPUSxDQUFDO0dBQ3hDLFVBQVVBLE1BQU1BLEVBQUVhLE9BQU9mLE9BQU87RUFBRSxHQVo3Qk47Ozs7U0FZNkIsQ0FFckM7Q0FDRTs7Ozs7QUFFVDtBQUFDZixHQWxGdUJQLFVBQVE7QUFBQSxLQUFSQTtBQUFRLElBQUE0QztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsInVzZUVmZmVjdCIsInVzZVJlZiIsIk90cElucHV0IiwibGVuZ3RoIiwidmFsdWUiLCJvbkNoYW5nZSIsIm9uQ29tcGxldGUiLCJkaXNhYmxlZCIsImF1dG9Gb2N1cyIsIl9zIiwiaW5wdXRzUmVmIiwiY2hhcnMiLCJBcnJheSIsImZyb20iLCJfIiwiaSIsImN1cnJlbnQiLCJmb2N1cyIsImVtaXQiLCJuZXh0Q2hhcnMiLCJjb2RlIiwiam9pbiIsImluY2x1ZGVzIiwiaGFuZGxlQ2hhbmdlIiwiaW5kZXgiLCJyYXciLCJkaWdpdCIsInJlcGxhY2UiLCJzbGljZSIsIm5leHQiLCJzZWxlY3QiLCJoYW5kbGVLZXlEb3duIiwiZSIsImtleSIsInByZXZlbnREZWZhdWx0IiwiaGFuZGxlUGFzdGUiLCJwYXN0ZWQiLCJjbGlwYm9hcmREYXRhIiwiZ2V0RGF0YSIsImZvY3VzSWR4IiwiTWF0aCIsIm1pbiIsIm1hcCIsImNoYXIiLCJlbCIsInRhcmdldCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk90cElucHV0LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCB1c2VSZWYgfSBmcm9tIFwicmVhY3RcIjtcblxuLyoqXG4gKiBOLWJveCB2ZXJpZmljYXRpb24gY29kZSBpbnB1dCB3aXRoIGF1dG8tYWR2YW5jZSwgcGFzdGUgc3VwcG9ydCBhbmRcbiAqIGtleWJvYXJkIG5hdmlnYXRpb24uIENhbGxzIG9uQ29tcGxldGUoY29kZSkgd2hlbiBldmVyeSBib3ggaXMgZmlsbGVkLlxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBPdHBJbnB1dCh7IGxlbmd0aCA9IDYsIHZhbHVlLCBvbkNoYW5nZSwgb25Db21wbGV0ZSwgZGlzYWJsZWQgPSBmYWxzZSwgYXV0b0ZvY3VzID0gdHJ1ZSB9KSB7XG4gIGNvbnN0IGlucHV0c1JlZiA9IHVzZVJlZihbXSk7XG4gIGNvbnN0IGNoYXJzID0gQXJyYXkuZnJvbSh7IGxlbmd0aCB9LCAoXywgaSkgPT4gKHZhbHVlIHx8IFwiXCIpW2ldIHx8IFwiXCIpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKGF1dG9Gb2N1cyAmJiBpbnB1dHNSZWYuY3VycmVudFswXSAmJiAhZGlzYWJsZWQpIHtcbiAgICAgIGlucHV0c1JlZi5jdXJyZW50WzBdLmZvY3VzKCk7XG4gICAgfVxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9leGhhdXN0aXZlLWRlcHNcbiAgfSwgW10pO1xuXG4gIGZ1bmN0aW9uIGVtaXQobmV4dENoYXJzKSB7XG4gICAgY29uc3QgY29kZSA9IG5leHRDaGFycy5qb2luKFwiXCIpO1xuICAgIG9uQ2hhbmdlKGNvZGUpO1xuICAgIGlmIChjb2RlLmxlbmd0aCA9PT0gbGVuZ3RoICYmICFuZXh0Q2hhcnMuaW5jbHVkZXMoXCJcIikpIHtcbiAgICAgIG9uQ29tcGxldGUgJiYgb25Db21wbGV0ZShjb2RlKTtcbiAgICB9XG4gIH1cblxuICBmdW5jdGlvbiBoYW5kbGVDaGFuZ2UoaW5kZXgsIHJhdykge1xuICAgIGNvbnN0IGRpZ2l0ID0gcmF3LnJlcGxhY2UoL1xcRC9nLCBcIlwiKS5zbGljZSgtMSk7IC8vIGtlZXAgbGFzdCBkaWdpdCB0eXBlZFxuICAgIGNvbnN0IG5leHQgPSBbLi4uY2hhcnNdO1xuICAgIG5leHRbaW5kZXhdID0gZGlnaXQ7XG4gICAgZW1pdChuZXh0KTtcbiAgICBpZiAoZGlnaXQgJiYgaW5kZXggPCBsZW5ndGggLSAxKSB7XG4gICAgICBpbnB1dHNSZWYuY3VycmVudFtpbmRleCArIDFdPy5mb2N1cygpO1xuICAgICAgaW5wdXRzUmVmLmN1cnJlbnRbaW5kZXggKyAxXT8uc2VsZWN0KCk7XG4gICAgfVxuICB9XG5cbiAgZnVuY3Rpb24gaGFuZGxlS2V5RG93bihpbmRleCwgZSkge1xuICAgIGlmIChlLmtleSA9PT0gXCJCYWNrc3BhY2VcIikge1xuICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgY29uc3QgbmV4dCA9IFsuLi5jaGFyc107XG4gICAgICBpZiAobmV4dFtpbmRleF0pIHtcbiAgICAgICAgbmV4dFtpbmRleF0gPSBcIlwiO1xuICAgICAgICBlbWl0KG5leHQpO1xuICAgICAgfSBlbHNlIGlmIChpbmRleCA+IDApIHtcbiAgICAgICAgbmV4dFtpbmRleCAtIDFdID0gXCJcIjtcbiAgICAgICAgZW1pdChuZXh0KTtcbiAgICAgICAgaW5wdXRzUmVmLmN1cnJlbnRbaW5kZXggLSAxXT8uZm9jdXMoKTtcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKGUua2V5ID09PSBcIkFycm93TGVmdFwiICYmIGluZGV4ID4gMCkge1xuICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgaW5wdXRzUmVmLmN1cnJlbnRbaW5kZXggLSAxXT8uZm9jdXMoKTtcbiAgICB9IGVsc2UgaWYgKGUua2V5ID09PSBcIkFycm93UmlnaHRcIiAmJiBpbmRleCA8IGxlbmd0aCAtIDEpIHtcbiAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgIGlucHV0c1JlZi5jdXJyZW50W2luZGV4ICsgMV0/LmZvY3VzKCk7XG4gICAgfVxuICB9XG5cbiAgZnVuY3Rpb24gaGFuZGxlUGFzdGUoZSkge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBjb25zdCBwYXN0ZWQgPSAoZS5jbGlwYm9hcmREYXRhLmdldERhdGEoXCJ0ZXh0XCIpIHx8IFwiXCIpLnJlcGxhY2UoL1xcRC9nLCBcIlwiKS5zbGljZSgwLCBsZW5ndGgpO1xuICAgIGlmICghcGFzdGVkKSByZXR1cm47XG4gICAgY29uc3QgbmV4dCA9IEFycmF5LmZyb20oeyBsZW5ndGggfSwgKF8sIGkpID0+IHBhc3RlZFtpXSB8fCBcIlwiKTtcbiAgICBlbWl0KG5leHQpO1xuICAgIGNvbnN0IGZvY3VzSWR4ID0gTWF0aC5taW4ocGFzdGVkLmxlbmd0aCwgbGVuZ3RoIC0gMSk7XG4gICAgaW5wdXRzUmVmLmN1cnJlbnRbZm9jdXNJZHhdPy5mb2N1cygpO1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImQtZmxleCBqdXN0aWZ5LWNvbnRlbnQtY2VudGVyIGdhcC0yIG90cC1pbnB1dHNcIiBvblBhc3RlPXtoYW5kbGVQYXN0ZX0+XG4gICAgICB7Y2hhcnMubWFwKChjaGFyLCBpbmRleCkgPT4gKFxuICAgICAgICA8aW5wdXRcbiAgICAgICAgICBrZXk9e2luZGV4fVxuICAgICAgICAgIHJlZj17KGVsKSA9PiAoaW5wdXRzUmVmLmN1cnJlbnRbaW5kZXhdID0gZWwpfVxuICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICBpbnB1dE1vZGU9XCJudW1lcmljXCJcbiAgICAgICAgICBhdXRvQ29tcGxldGU9XCJvbmUtdGltZS1jb2RlXCJcbiAgICAgICAgICBtYXhMZW5ndGg9ezF9XG4gICAgICAgICAgY2xhc3NOYW1lPVwiZm9ybS1jb250cm9sIG90cC1ib3hcIlxuICAgICAgICAgIHZhbHVlPXtjaGFyfVxuICAgICAgICAgIGRpc2FibGVkPXtkaXNhYmxlZH1cbiAgICAgICAgICBhcmlhLWxhYmVsPXtgRGlnaXQgJHtpbmRleCArIDF9IG9mICR7bGVuZ3RofWB9XG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVDaGFuZ2UoaW5kZXgsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICBvbktleURvd249eyhlKSA9PiBoYW5kbGVLZXlEb3duKGluZGV4LCBlKX1cbiAgICAgICAgICBvbkZvY3VzPXsoZSkgPT4gZS50YXJnZXQuc2VsZWN0KCl9XG4gICAgICAgIC8+XG4gICAgICApKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiQzovVXNlcnMvdXNlci9Eb3dubG9hZHMvZGhhbml0aS1hcHAtdXBncmFkZWQvZGhhbml0aS1hcHAvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvT3RwSW5wdXQuanN4In0=